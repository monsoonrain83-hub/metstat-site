/* MetStat v38: background station-coordinate registry, NEVER an Atlas display source. */
(()=>{
 'use strict';
 const MET_PATH='online/atlas_station_registry_v33.json?v=39a';
 const HYD_PATH='online/hydrometric_station_metadata_v33.json';
 let metPromise=null,hydPromise=null;
 function read(path){
   const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),12000);
   return fetch(new URL(path,document.baseURI),{cache:'default',credentials:'same-origin',signal:controller.signal})
     .then(r=>{if(!r.ok)throw Error('HTTP '+r.status+' / '+path);return r.json()})
     .finally(()=>clearTimeout(timer));
 }
 const loadMet=()=>metPromise||(metPromise=read(MET_PATH).catch(e=>{metPromise=null;console.warn('[MetStat] Station coordinates unavailable:',e);throw e}));
 const loadHyd=()=>hydPromise||(hydPromise=read(HYD_PATH).catch(e=>{hydPromise=null;console.warn('[MetStat] Hydrometry unavailable:',e);throw e}));
 const key=s=>String(s||'').normalize('NFKC').toLowerCase().replace(/[يى]/g,'ی').replace(/ك/g,'ک').replace(/[\u200c\u200e\u200f]/g,'').replace(/[^\p{L}\p{N}]/gu,'');
 // Only callers such as the rain-text matcher explicitly read this registry.
 // No atlas panel, no insertion into CLIM_META.st, no mutation of the historic atlas bridge.
 window.MetStatStationMetadataV33={loadMet,loadHyd,search:async(q,kind='meteorological',max=80)=>{
   const d=kind==='hydrometric'?await loadHyd():await loadMet();
   const rows=Array.isArray(d.stations)?d.stations:[];
   const k=key(q);
   return (k?rows.filter(s=>key([s.fa,s.en,...(s.aliases||[]),s.ostan].join(' ')).includes(k)):rows)
     .slice(0,Math.max(1,Math.min(300,max)));
 }};
})();
