const GEO_DATA={"continents":[["world","جهان (کل زمین)"],["asia","آسیا"],["europe","اروپا"],["africa","آفریقا"],["namerica","آمریکای شمالی"],["samerica","آمریکای جنوبی"],["oceania","اقیانوسیه"],["antarctica","جنوبگان"]],"regions":{"asia":[{"id":"me","label":"خاورمیانه","countries":["IR","IQ","SA","YE","OM","AE","QA","KW","BH","TR","IL","PS","JO","LB","SY","CY","EG","LY"]},{"id":"westasia","label":"غرب آسیا","countries":["IR","IQ","TR","AZ","AM","GE","SA","YE","OM","AE","QA","KW","BH","IL","PS","JO","LB","SY","CY"]},{"id":"eastasia","label":"شرق آسیا","countries":["CN","JP","KR","KP","MN","TW","HK","MO"]},{"id":"southasia","label":"جنوب آسیا","countries":["IN","PK","BD","AF","NP","LK","BT","MV"]},{"id":"southeastasia","label":"جنوب شرق آسیا","countries":["ID","MY","TH","VN","SG","PH","MM","KH","LA","BN","TL"]},{"id":"centralasia","label":"آسیای مرکزی","countries":["KZ","UZ","KG","TJ","TM"]}],"europe":[{"id":"northeurope","label":"شمال اروپا","countries":["GB","IE","NO","SE","FI","DK","IS","DE","NL","EE","LV","LT"]},{"id":"southeurope","label":"جنوب اروپا","countries":["TR","ES","PT","IT","GR","AL","MK","ME","RS","BA","HR","SI","MT","CY","AD","SM","VA","MC"]},{"id":"westeurope","label":"غرب اروپا","countries":["FR","DE","NL","BE","LU","CH","AT","LI"]},{"id":"easteurope","label":"شرق اروپا","countries":["PL","CZ","SK","HU","RO","BG","UA","BY","RU","MD"]}],"africa":[{"id":"northafrica","label":"شمال آفریقا","countries":["MA","DZ","TN","LY","EG","SD","MR"]},{"id":"eastafrica","label":"شرق آفریقا","countries":["ET","ER","DJ","SO","KE","UG","TZ","RW","BI","SS","SC","MU"]},{"id":"westafrica","label":"غرب آفریقا","countries":["NG","GH","CI","SN","ML","NE","BF","BJ","TG","GN","GW","SL","LR","GM","CV"]},{"id":"centralafrica","label":"مرکز آفریقا","countries":["CM","CF","TD","GA","GQ","CG","CD","AO","ST"]},{"id":"southafrica","label":"جنوب آفریقا","countries":["ZA","NA","BW","ZW","ZM","MZ","LS","SZ","MW","MG"]}],"namerica":[{"id":"northamerica","label":"آمریکای شمالی","countries":["US","CA","MX"]},{"id":"centralamerica","label":"آمریکای مرکزی","countries":["GT","BZ","HN","SV","NI","CR","PA"]},{"id":"caribbean","label":"کارائیب","countries":["CU","HT","DO","JM","BS","BB","TT","AG","DM","GD","KN","LC","VC","PR"]}],"samerica":[{"id":"southamerica","label":"آمریکای جنوبی","countries":["BR","AR","CL","UY","PY","BO","PE","EC","CO","VE","GY","SR","GF"]},{"id":"southerncone","label":"مخروط جنوبی","countries":["AR","CL","UY","PY","BR"]},{"id":"andes","label":"ناحیه آند","countries":["CO","EC","PE","BO","CL","VE"]}],"oceania":[{"id":"aunz","label":"استرالیا و نیوزیلند","countries":["AU","NZ"]},{"id":"pacific","label":"جزایر اقیانوس آرام","countries":["PG","FJ","SB","VU","WS","TO","KI","FM","MH","PW","NR","TV"]}],"antarctica":[{"id":"antarctica","label":"جنوبگان","countries":["AQ"]}]},"countries":{"IR":"ایران","IQ":"عراق","SA":"عربستان سعودی","YE":"یمن","OM":"عمان","AE":"امارات متحده عربی","QA":"قطر","KW":"کویت","BH":"بحرین","TR":"ترکیه","IL":"اسرائیل","PS":"فلسطین","JO":"اردن","LB":"لبنان","SY":"سوریه","CY":"قبرس","EG":"مصر","LY":"لیبی","AZ":"جمهوری آذربایجان","AM":"ارمنستان","GE":"گرجستان","CN":"چین","JP":"ژاپن","KR":"کره جنوبی","KP":"کره شمالی","MN":"مغولستان","TW":"تایوان","HK":"هنگ‌کنگ، منطقهٔ ویژهٔ اداری چین","MO":"ماکائو، منطقهٔ ویژهٔ اداری چین","IN":"هند","PK":"پاکستان","BD":"بنگلادش","AF":"افغانستان","NP":"نپال","LK":"سری‌لانکا","BT":"بوتان","MV":"مالدیو","ID":"اندونزی","MY":"مالزی","TH":"تایلند","VN":"ویتنام","SG":"سنگاپور","PH":"فیلیپین","MM":"میانمار (برمه)","KH":"کامبوج","LA":"لائوس","BN":"برونئی","TL":"تیمور-لسته","KZ":"قزاقستان","UZ":"ازبکستان","KG":"قرقیزستان","TJ":"تاجیکستان","TM":"ترکمنستان","GB":"بریتانیا","IE":"ایرلند","NO":"نروژ","SE":"سوئد","FI":"فنلاند","DK":"دانمارک","IS":"ایسلند","DE":"آلمان","NL":"هلند","EE":"استونی","LV":"لتونی","LT":"لیتوانی","ES":"اسپانیا","PT":"پرتغال","IT":"ایتالیا","GR":"یونان","AL":"آلبانی","MK":"مقدونیهٔ شمالی","ME":"مونته‌نگرو","RS":"صربستان","BA":"بوسنی و هرزگوین","HR":"کرواسی","SI":"اسلوونی","MT":"مالت","AD":"آندورا","SM":"سان‌مارینو","VA":"واتیکان","MC":"موناکو","FR":"فرانسه","BE":"بلژیک","LU":"لوکزامبورگ","CH":"سوئیس","AT":"اتریش","LI":"لیختن‌اشتاین","PL":"لهستان","CZ":"چک","SK":"اسلواکی","HU":"مجارستان","RO":"رومانی","BG":"بلغارستان","UA":"اوکراین","BY":"بلاروس","RU":"روسیه","MD":"مولداوی","MA":"مراکش","DZ":"الجزایر","TN":"تونس","SD":"سودان","MR":"موریتانی","ET":"اتیوپی","ER":"اریتره","DJ":"جیبوتی","SO":"سومالی","KE":"کنیا","UG":"اوگاندا","TZ":"تانزانیا","RW":"رواندا","BI":"بوروندی","SS":"سودان جنوبی","SC":"سیشل","MU":"موریس","NG":"نیجریه","GH":"غنا","CI":"ساحل عاج","SN":"سنگال","ML":"مالی","NE":"نیجر","BF":"بورکینافاسو","BJ":"بنین","TG":"توگو","GN":"گینه","GW":"گینهٔ بیسائو","SL":"سیرالئون","LR":"لیبریا","GM":"گامبیا","CV":"کیپ‌ورد","CM":"کامرون","CF":"جمهوری افریقای مرکزی","TD":"چاد","GA":"گابن","GQ":"گینهٔ استوایی","CG":"کنگو - برازویل","CD":"کنگو - کینشاسا","AO":"آنگولا","ST":"سائوتومه و پرینسیپ","ZA":"افریقای جنوبی","NA":"نامیبیا","BW":"بوتسوانا","ZW":"زیمبابوه","ZM":"زامبیا","MZ":"موزامبیک","LS":"لسوتو","SZ":"اسواتینی","MW":"مالاوی","MG":"ماداگاسکار","US":"ایالات متحده آمریکا","CA":"کانادا","MX":"مکزیک","GT":"گواتمالا","BZ":"بلیز","HN":"هندوراس","SV":"السالوادور","NI":"نیکاراگوئه","CR":"کاستاریکا","PA":"پاناما","CU":"کوبا","HT":"هائیتی","DO":"جمهوری دومینیکن","JM":"جامائیکا","BS":"باهاما","BB":"باربادوس","TT":"ترینیداد و توباگو","AG":"آنتیگوا و باربودا","DM":"دومینیکا","GD":"گرنادا","KN":"سنت کیتس و نویس","LC":"سنت لوسیا","VC":"سنت وینسنت و گرنادین","PR":"پورتوریکو","BR":"برزیل","AR":"آرژانتین","CL":"شیلی","UY":"اروگوئه","PY":"پاراگوئه","BO":"بولیوی","PE":"پرو","EC":"اکوادور","CO":"کلمبیا","VE":"ونزوئلا","GY":"گویان","SR":"سورینام","GF":"گویان فرانسه","AU":"استرالیا","NZ":"نیوزیلند","PG":"پاپوا گینهٔ نو","FJ":"فیجی","SB":"جزایر سلیمان","VU":"وانواتو","WS":"ساموآ","TO":"تونگا","KI":"کیریباتی","FM":"میکرونزی","MH":"جزایر مارشال","PW":"پالائو","NR":"نائورو","TV":"تووالو","AQ":"جنوبگان"}};

/* MetStat r203: five cascading geographic menus attached to original map controls.
   No fabricated model tiles; no map renderer or model data changes. */
(function(){
'use strict';
const VERSION='203.0', doc=document;
const state={version:VERSION,ready:false,regionStatus:'',verified:false};
window.MetStatGeo202=state;
const $=id=>doc.getElementById(id);
const EL=(name,cls)=>{const e=doc.createElement(name);if(cls)e.className=cls;return e;};
const norm=s=>String(s||'').normalize('NFKC').replace(/[يى]/g,'ی').replace(/ك/g,'ک').replace(/\s+/g,' ').trim();
function ranges(f){let w=Infinity,e=-Infinity,s=Infinity,n=-Infinity;
 for(const poly of f.g||[])for(const ring of poly)for(const xy of ring){const a=xy[0],b=xy[1];if(a<w)w=a;if(a>e)e=a;if(b<s)s=b;if(b>n)n=b;}
 return Number.isFinite(w)&&w<e&&s<n?[w,e,s,n]:null;
}
function layers(){return window.CQC_LAYERS||((typeof LAYERS!=='undefined')?LAYERS:null);}
function fill(sel,opts,selected,empty){
 sel.replaceChildren();
 for(const [value,label] of opts){const o=EL('option');o.value=value;o.textContent=label;sel.appendChild(o);}
 if(opts.some(x=>x[0]===selected))sel.value=selected;
 else if(opts.length)sel.value=opts[0][0];
 else{const o=EL('option');o.textContent=empty||'—';o.value='';sel.appendChild(o);}
 sel.disabled=!opts.length;
 return sel.value;
}
function status(message,ok=false){const el=$('msGeoStatus202');if(!el)return;el.textContent=message||'';el.dataset.ok=ok?'1':'0';state.regionStatus=message||'';}
/* Geographic coverage is fail-closed: a country/continent without a published
   raster must never inherit the last Iran/ME map underneath the dropdowns. */
function unavailable(label,reason){
 const stage=$('nvStage');
 if(stage){
  let notice=$('msGeoScopeUnavailable203');
  if(!notice){notice=EL('div','msGeoScopeUnavailable203');notice.id='msGeoScopeUnavailable203';
   notice.setAttribute('role','status');notice.setAttribute('aria-live','polite');stage.appendChild(notice);}
  notice.replaceChildren();
  const heading=EL('strong');heading.textContent=label;
  const detail=EL('span');detail.textContent=reason;
  notice.appendChild(heading);notice.appendChild(detail);notice.hidden=false;
 }
 state.available=false;state.activeScope=label;
 status(label+': '+reason);
 return false;
}
function available(label){
 const notice=$('msGeoScopeUnavailable203');if(notice)notice.hidden=true;
 state.available=true;state.activeScope=label;
}
function nativeSelect(key,label,bounds){
 const raw=$('nvReg');if(!raw||typeof raw.onchange!=='function')return unavailable(label,'موتور نقشه هنوز آماده نیست.');
 if(key.startsWith('c:') && bounds){
  try{if(typeof NV!=='undefined'&&typeof nvRegions==='function'){
   const a=nvRegions();if(!a.some(r=>r[0]===key)){
    const padding=Math.max(0.025,(bounds[1]-bounds[0])*.025),padY=Math.max(0.025,(bounds[3]-bounds[2])*.025);
    a.push([key,label,[bounds[0]-padding,bounds[1]+padding,bounds[2]-padY,bounds[3]+padY],bounds]);
   }
  }}catch(err){return unavailable(label,'مرز شهرستان به موتور نقشه متصل نشد: '+String(err.message));}
  if(![...raw.options].some(x=>x.value===key)){const o=EL('option');o.value=key;o.textContent=label;raw.appendChild(o);}
 }
 const option=[...raw.options].find(o=>o.value===key&&!o.disabled);
 if(!option)return unavailable(label,'برای این محدوده، نقشه معتبر این مدل/پارامتر منتشر نشده است.');
 const previous=raw.value;raw.value=key;
 if(raw.value!==key){raw.value=previous;return unavailable(label,'تغییر محدوده در موتور نقشه پشتیبانی نمی‌شود.');}
 try{raw.onchange();available(label);status('محدوده نمایشی: '+label,true);return true;}
 catch(err){raw.value=previous;try{raw.onchange();}catch(_){}return unavailable(label,'تغییر محدوده انجام نشد: '+String(err.message));}
}
function wireCapitalToggle(panel){
 if(!panel || panel.querySelector('[data-ms202-cap]'))return;
 const old=panel.querySelector('[data-nvl="pc"]');
 // Preserve existing centres of provinces; add a labelled switch for country capitals
 // using the EXISTING city-label visibility state (the renderer draws capitals only when city=true).
 const label=EL('label');label.dataset.ms202Cap='1';const chk=EL('input');chk.type='checkbox';
 const sync=()=>{const city=$('nvCity');chk.checked=city?!!city.checked:true;};
 chk.addEventListener('change',()=>{const city=$('nvCity');if(city){city.checked=chk.checked;city.dispatchEvent(new Event('change',{bubbles:true}));}else if(typeof NV!=='undefined'){NV.s.city=chk.checked;if(typeof nvDraw==='function')nvDraw();}});
 label.appendChild(chk);label.append(' نام شهرها و پایتخت‌های کشورها');panel.appendChild(label);sync();
 if(old){const parent=old.closest('label');if(parent && !/مراکز استان/.test(parent.textContent))parent.append(' مراکز استان');}
}
function init(card){
 if(!card || !card.querySelector('.nvR6') || !card.querySelector('#nvStage'))return false;
 if(card.dataset.msGeo202==='1')return true;
 const row=card.querySelector('.nvR6'),stage=card.querySelector('#nvStage');
 const legend=card.querySelector('#nvLg'),palette=row.querySelector('.nvCbDd');
 const oldReg=row.querySelector('.nvRegBar');
 const chain=EL('div','msGeoFive202');chain.id='msGeoFive202';chain.setAttribute('role','group');chain.setAttribute('aria-label','انتخاب محدوده جغرافیایی');
 const levels=[['continent','۱. جهان/قاره'],['region','۲. منطقه'],['country','۳. کشور'],['province','۴. استان'],['county','۵. شهرستان']];
 const fields={};
 for(const [key,cap] of levels){const lab=EL('label','msGeoLevel202');const span=EL('span');span.textContent=cap;const sel=EL('select');sel.dataset.level=key;sel.setAttribute('aria-label',cap);lab.appendChild(span);lab.appendChild(sel);fields[key]=sel;chain.appendChild(lab);}
 row.insertBefore(chain,row.firstChild);
 const warning=EL('div','msGeoNotice202');warning.id='msGeoStatus202';warning.setAttribute('role','status');stage.appendChild(warning);
 // Reuse original border/layer menus; do NOT move individual children repeatedly.
 if(stage.parentNode!==row.parentNode){status('نوار اصلی و نقشه در یک کادر نیستند؛ چیدمان دست‌نخورده باقی ماند.');chain.remove();return false;}
 stage.parentNode.insertBefore(row,stage);
 if(palette && legend && legend.parentNode){legend.insertAdjacentElement('afterend',palette);palette.classList.add('msPalette202');}
 const settings=card.querySelector('#nvR9');
 if(settings){let gear=card.querySelector('#msGear202');if(!gear){gear=EL('details','msGear202');gear.id='msGear202';const summary=EL('summary');summary.textContent='⚙';summary.title='تنظیمات ضخامت و تراکم';gear.appendChild(summary);row.appendChild(gear);}gear.appendChild(settings);}
 // Hide only the extra generated timestamp; blue status and real time slider stay intact.
 const duplicate=card.querySelector('#nvR5t');if(duplicate)duplicate.classList.add('msHiddenTime202');
 const layerPanel=row.querySelector('.nvLayDd .ovp');wireCapitalToggle(layerPanel);
 const continent=fields.continent,region=fields.region,country=fields.country,province=fields.province,county=fields.county;
 const named=GEO_DATA.countries;
 const displayRegions=()=>GEO_DATA.regions[continent.value]||[];
 const provinces=()=>((layers()||{}).ostan||[]).map(f=>f.p&&f.p.name).filter(Boolean).sort((a,b)=>a.localeCompare(b,'fa'));
 const countyData=()=>((layers()||{}).county||[]).filter(f=>f.p&&norm(f.p.ostan)===norm(province.value)&&f.p.name).sort((a,b)=>a.p.name.localeCompare(b.p.name,'fa'));
 function afterContinent(){
  const list=displayRegions();fill(region,list.map(r=>[r.id,r.label]),list.some(r=>r.id==='me')?'me':'','منطقه را انتخاب کنید');afterRegion();
 }
 function afterRegion(){
  const group=displayRegions().find(r=>r.id===region.value);
  const list=(group&&group.countries||[]).map(id=>[id,named[id]||id]).sort((a,b)=>a[1].localeCompare(b[1],'fa'));
  fill(country,list.length?[['','— انتخاب کشور —'],...list]:[], '', 'کشور موجود نیست');afterCountry(false);
 }
 function afterCountry(apply){
  const iran=country.value==='IR',ps=iran?provinces():[];
  fill(province,iran?[["","— انتخاب استان —"],...ps.map(x=>[x,x])]:[], '',iran?'استان در دسترس نیست':'اطلاعات استان بارگذاری نشده');afterProvince(false);
  if(apply){if(iran)nativeSelect('iran','ایران');else unavailable(named[country.value]||'کشور انتخاب‌شده','نقشه واقعی این کشور برای مدل/پارامتر انتخابی منتشر نشده است.');}
 }
 function afterProvince(apply){
  const cs=countyData();fill(county,cs.length?[["","— انتخاب شهرستان —"],...cs.map(f=>[f.p.name,f.p.name])]:[], '','شهرستان موجود نیست');
  if(apply){if(province.value)nativeSelect('p:'+province.value,province.value);else nativeSelect('iran','ایران');}
 }
 continent.addEventListener('change',()=>{afterContinent();unavailable(GEO_DATA.continents.find(x=>x[0]===continent.value)?.[1]||'قاره','پوشش واقعی این سطح جغرافیایی برای این مدل/پارامتر تأیید نشده؛ منطقه را انتخاب کنید.');});
 region.addEventListener('change',()=>{afterRegion();if(region.value==='me')nativeSelect('me','خاورمیانه (کادر عملیاتی مدل)');
 else unavailable(displayRegions().find(x=>x.id===region.value)?.label||'منطقه','نقشه اختصاصی این منطقه منتشر نشده است؛ کادر خاورمیانه یا اروپا را جایگزین نمی‌کنیم.');});
 country.addEventListener('change',()=>afterCountry(true));
 province.addEventListener('change',()=>afterProvince(true));
 county.addEventListener('change',()=>{
  const f=countyData().find(x=>x.p.name===county.value);const bounds=f&&ranges(f);
  if(!county.value){if(province.value)nativeSelect('p:'+province.value,province.value);return;}
  if(!f||!bounds){unavailable(county.value,'مرز معتبر این شهرستان در بانک فعلی موجود نیست.');return;}
  nativeSelect('c:'+province.value+'/'+f.p.name,province.value+' / '+f.p.name,bounds);
 });
 fill(continent,GEO_DATA.continents,'asia');continent.value='asia';afterContinent();
 const current=($('nvReg')&&$('nvReg').value)||'iran';
 if(current==='eu'){continent.value='europe';afterContinent();region.value='southeurope';afterRegion();}
 else if(current==='iran'||current.startsWith('p:')||current.startsWith('c:')){country.value='IR';afterCountry(false);if(current.startsWith('p:')||current.startsWith('c:')){let prov=current.startsWith('p:')?current.slice(2):current.slice(2).split('/')[0];if(provinces().includes(prov)){province.value=prov;afterProvince(false);if(current.startsWith('c:'))county.value=current.split('/').slice(1).join('/');}}}
 row.querySelectorAll('details').forEach(d=>d.addEventListener('toggle',()=>{if(d.open)row.querySelectorAll('details[open]').forEach(x=>{if(x!==d&&!x.contains(d))x.open=false;});}));
 doc.addEventListener('click',e=>{if(!row.contains(e.target))row.querySelectorAll('details[open]').forEach(d=>d.open=false);});
 doc.addEventListener('keydown',e=>{if(e.key==='Escape')row.querySelectorAll('details[open]').forEach(d=>d.open=false);});
 card.dataset.msGeo202='1';state.ready=true;state.verified=false;available(current);status('منوها آماده‌اند؛ صحت داده باید برای هر مدل و محدوده جداگانه تأیید شود.',true);
 return true;
}
function start(){
 let previous=null;
 const check=()=>{const stage=$('nvStage'),card=stage&&stage.closest('.nvCard');if(card!==previous){previous=card;state.ready=false;}if(card)try{init(card);}catch(err){state.error=String(err&&err.message||err);console.error('MetStat geo202',err);}};
 check();let count=0;const timer=setInterval(()=>{check();if(state.ready||++count>150)clearInterval(timer);},1500);
 const view=$('onViewer');if(view)new MutationObserver(check).observe(view,{childList:true});
 window.addEventListener('pageshow',check);
 // lightweight: no subtree mutation observers; avoids re-render/move loops from r201.
}
if(doc.readyState==='loading')doc.addEventListener('DOMContentLoaded',start,{once:true});else start();
})();
