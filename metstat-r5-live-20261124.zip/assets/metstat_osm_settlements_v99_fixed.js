/* MetStat r99, performance-limited population and meteorological-station overlay. ODbL © OpenStreetMap contributors.
   Doesn't touch MAPF, SEATS, station identities, model physics, geo.json, or id_points CRC. */
(function(root){ 'use strict';
  const path='data/osm_settlements_v98.json?v=98';
  const state={ready:false,promise:null,index:new Map(),nodes:[],error:null};
  // Capital visibility affects only this OSM overlay, never the forecast raster.
  const capitalNames=new Set(['تهران','بغداد','آنکارا','باکو','ایروان','تفلیس','کابل','اسلامآباد','عشقآباد','دوشنبه','تاشکند','آستانه','کویت','ریاض','دوحه','منامه','ابوظبی','مسقط','صنعا','دمشق','بیروت','امان','اورشلیم','بیتالمقدس','قاهره','نیکوزیا','تهران','tehran','baghdad','ankara','baku','yerevan','tbilisi','kabul','islamabad','ashgabat','dushanbe','tashkent','astana','kuwaitcity','riyadh','doha','manama','abudhabi','muscat','sanaa','damascus','beirut','amman','jerusalem','cairo','nicosia']);
  let showCapitals=true;
  try{showCapitals=localStorage.getItem('metstat.osm.showCapitals')!=='false'}catch(_){}
  function isCapital(p){return capitalNames.has(norm(p[2]))||capitalNames.has(norm(p[3]));}
  function redraw(){try{if(typeof root.nvDraw==='function')root.nvDraw(false)}catch(_){}try{if(typeof root.saDrawSoon==='function')root.saDrawSoon()}catch(_){}}
  function setCapitalsVisible(on){showCapitals=!!on;try{localStorage.setItem('metstat.osm.showCapitals',String(showCapitals))}catch(_){}redraw();return showCapitals;}
  function getCapitalsVisible(){return showCapitals;}
  function mountCapitalToggle(){
    if(!root.document||document.getElementById('metstat-osm-capitals-toggle'))return;
    const label=document.createElement('label');label.id='metstat-osm-capitals-toggle';
    label.style.cssText='display:inline-flex;align-items:center;gap:6px;padding:6px 9px;border:1px solid #cbd5e1;border-radius:8px;background:#fff;color:#263445;font:12px Tahoma,sans-serif;cursor:pointer;';
    const input=document.createElement('input');input.type='checkbox';input.checked=showCapitals;input.setAttribute('aria-label','نمایش پایتخت‌ها در لایه OSM');
    input.addEventListener('change',()=>setCapitalsVisible(input.checked));label.append(input,document.createTextNode('نمایش پایتخت‌ها (OSM)'));
    const targets=['mapSettings','map-settings','geoSettings','layerSettings','mapControls'];
    const target=targets.map(id=>document.getElementById(id)).find(Boolean);
    if(target)target.appendChild(label);
    else {const wrap=document.createElement('div');wrap.id='metstat-osm-capitals-controls';wrap.style.cssText='position:fixed;right:12px;bottom:72px;z-index:999;';wrap.appendChild(label);document.body.appendChild(wrap);}
  }
  if(root.document){if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',mountCapitalToggle,{once:true});else mountCapitalToggle();}
  const norm=s=>String(s||'').normalize('NFKC').replace(/[\u200c\s\u0640]/g,'').replace(/ي/g,'ی').replace(/ك/g,'ک').toLowerCase();
  const bin=(a,b)=>Math.floor(a*2)+':'+Math.floor(b*2);
  const mercY=la=>{let v=Math.max(-85,Math.min(85,la))*Math.PI/180;return (1-Math.log(Math.tan(v)+1/Math.cos(v))/Math.PI)/2};
  const mercX=lo=>(lo+180)/360;
  const widthOK=(w,h)=>Number.isFinite(w)&&Number.isFinite(h)&&w>0&&h>0;
  function indexNodes(nodes){state.index.clear();state.nodes=nodes;for(const p of nodes){const key=bin(p[0],p[1]);let a=state.index.get(key);if(!a)state.index.set(key,a=[]);a.push(p)}state.ready=true;}
  function load(){if(state.promise)return state.promise;state.promise=fetch(path,{cache:'force-cache'}).then(r=>{if(!r.ok)throw Error('OSM places '+r.status);return r.json()}).then(d=>{
    if(!d||!Array.isArray(d.nodes)||!Array.isArray(d.fields)||d.fields.length!==8)throw Error('Invalid OSM schema');
    indexNodes(d.nodes);
    try{if(typeof root.nvDraw==='function')root.nvDraw(false)}catch(_){}
    try{if(typeof root.saDrawSoon==='function')root.saDrawSoon()}catch(_){}
    return state;
  }).catch(e=>{state.error=e.message;state.promise=null;console.warn('MetStat OSM overlay',e.message);return state});return state.promise;}
  function query(latMin,latMax,lonMin,lonMax){if(!state.ready)return[];const a=[];const x0=Math.floor(Math.max(23,latMin)*2),x1=Math.ceil(Math.min(42,latMax)*2),y0=Math.floor(Math.max(42,lonMin)*2),y1=Math.ceil(Math.min(66,lonMax)*2);
    for(let i=x0;i<=x1;i++)for(let j=y0;j<=y1;j++)for(const p of state.index.get(i+':'+j)||[])if(p[0]>=latMin&&p[0]<=latMax&&p[1]>=lonMin&&p[1]<=lonMax)a.push(p);
    return a;
  }
  function seatsCollision(p,existing){const nm=norm(p[2]),la=p[0],lo=p[1];
    // Only same-name nearby existing places suppress a new point. Existing sources always win.
    for(const q of existing){if(norm(q[0])!==nm)continue;const qla=+q[1],qlo=+q[2];if(Math.abs(la-qla)<0.014&&Math.abs((lo-qlo)*Math.cos(la*Math.PI/180))<0.014)return true;}
    return false;
  }
  function drawPoint(ctx,x,y,c,sz,k){ctx.save();ctx.lineWidth=.95*k; if(c===7||c===8){ctx.beginPath();ctx.rect(x-sz,y-sz,sz*2,sz*2);ctx.fillStyle=c===7?'#ef8b27':'#8e4bc5';ctx.strokeStyle='#fff';ctx.fill();ctx.stroke()}else if(c===6){ctx.strokeStyle='#438452';ctx.fillStyle='#e6f2e4';ctx.fillRect(x-sz,y-sz,sz*2,sz*2);ctx.strokeRect(x-sz,y-sz,sz*2,sz*2)}else{
    ctx.beginPath();ctx.arc(x,y,sz,0,Math.PI*2);ctx.fillStyle=c<=1?'#164e87':c<=3?'#22779b':c===4?'#188b87':'#56758a';ctx.strokeStyle='#fcfdfe';ctx.fill();ctx.stroke()}
    ctx.restore();}
  function drawCore(ctx,W,H,bounds,project,scale,existing,occupied,maxPoint,flags){if(!widthOK(W,H))return 0; if(!state.ready){load();return 0;}
    let pts=query(bounds[0],bounds[1],bounds[2],bounds[3]);if(!pts.length)return 0;
    // Labels for prominent centres must reserve room before hamlets and smaller stations.
    pts.sort((a,b)=>a[4]-b[4]);
    const ref=existing||[];let drawn=0,labels=0,limit=Math.max(70,Math.min(340,Math.floor(W*H/2600))); const pointLimit=Math.min(1600,Math.max(250,Math.floor(W*H/550))), pointCells=new Set();
    const cells=new Set(), labelRects=[];ctx.save();ctx.direction=(document.documentElement.lang==='en'?'ltr':'rtl');ctx.textAlign='center';ctx.textBaseline='bottom';
    for(const p of pts){const la=p[0],lo=p[1];
      // Use the SAME bilingual name validator as other MetStat cartographic layers.
      // Retain a marker for a station even when its name needs human verification.
      const localEn=ctx.direction==='ltr', fa=String(p[2]||''), en=String(p[3]||'');
      const valid=(s,isEn)=>typeof s==='string'&&!/[?\uFFFD]/.test(s)&&
        (isEn?(/[A-Za-z\u00C0-\u024F]/.test(s)&&!/[\u0621-\u064A\u066E-\u06D3]/.test(s)):
              /[\u0621-\u064A\u066E-\u06D3]/.test(s)&&!/[A-Za-z\u00C0-\u024F]/.test(s));
      let name='';
      if(typeof root.geoLabel==='function')name=root.geoLabel(fa,en,la,lo);
      else name=localEn?(valid(en,true)?en:valid(fa,true)?fa:''):(valid(fa,false)?fa:valid(en,false)?en:'');
      if(name&&!valid(name,localEn))name=''; // locale guard if document and core language update asynchronously
      if((p[4]<=1&&!flags.city)||(p[4]>1&&p[4]<=6&&!flags.vill)||(p[4]>=7&&flags.stations===false)||p[4]===6||seatsCollision(p,ref))continue;
      const [x,y]=project(la,lo);if(x<2||x>W-2||y<2||y>H-2)continue;const c=p[4],sz=c<=1?3.8:c===4?2.5:c>=7?2.6:2.1;
      if(drawn<pointLimit){const grid=(c<=1?5:c>=7?19:14), cell=Math.floor(x/grid)+':'+Math.floor(y/grid);if(!pointCells.has(cell)){pointCells.add(cell);drawPoint(ctx,x,y,c,sz*scale,scale);drawn++;}}
      if(!name||labels>=limit)continue;
      // Larger centres first; smaller settlements/meteorological stations only when there is room.
      // No unconditional hiding solely because the map width is below 850 pixels.
      if(c>=7&&pts.length>700&&labels>limit*0.72)continue;
      const font=Math.max(9,Math.round((c<=1?11.5:c===4?9.8:9.2)*scale));
      ctx.font=`${c<=1?700:550} ${font}px Tahoma,Vazirmatn,sans-serif`;
      const tw=ctx.measureText(name).width+5*scale;
      const positions=[{tx:x,ty:y-5*scale},{tx:x+tw/2+4*scale,ty:y-3*scale},
                       {tx:x-tw/2-4*scale,ty:y-3*scale},{tx:x,ty:y+font+6*scale}];
      let chosen=null;
      for(const v of positions){
        const rect=[v.tx-tw/2,v.ty-font-2*scale,v.tx+tw/2,v.ty+2*scale];
        if(rect[0]<2||rect[2]>W-2||rect[1]<2||rect[3]>H-2)continue;
        const cell=Math.floor(v.tx/40)+':'+Math.floor(v.ty/21);
        if(cells.has(cell))continue;
        const overlaps=r=>rect[0]<r[2]+3*scale&&rect[2]>r[0]-3*scale&&rect[1]<r[3]+3*scale&&rect[3]>r[1]-3*scale;
        if(labelRects.some(overlaps)||(occupied&&occupied.some(overlaps)))continue;
        chosen={v,rect,cell};break;
      }
      if(!chosen)continue;
      cells.add(chosen.cell);labelRects.push(chosen.rect);if(occupied)occupied.push(chosen.rect);
      ctx.lineWidth=2.2*scale;ctx.strokeStyle='rgba(255,255,255,.95)';
      ctx.strokeText(name,chosen.v.tx,chosen.v.ty);
      ctx.fillStyle='#173c54';ctx.fillText(name,chosen.v.tx,chosen.v.ty);labels++;
    }
    ctx.font=`${Math.round(9*scale)}px Tahoma,Arial,sans-serif`;ctx.textAlign="left";ctx.fillStyle="rgba(15,47,67,.8)";ctx.fillText("© OpenStreetMap contributors",8*scale,H-8*scale);ctx.restore();return drawn;
  }
  function drawNwp(ctx,W,H,k,x0,y0,scale,existing,occupied,flags){
    if(!Number.isFinite(k)||k<=0||W/k>2.6)return 0;const bounds=[y0-H/k,y0,x0,x0+W/k];
    return drawCore(ctx,W,H,bounds,(la,lo)=>[(lo-x0)*k,(y0-la)*k],scale,existing,occupied,4500,flags||{city:true,vill:true});
  }
  function drawSatellite(ctx,W,H,v,scale,existing,flags){
    if(!v||((v.zl??v.z)<9))return 0;const P=256*2**v.z;
    const lonOf=x=>x*360-180,latOf=y=>Math.atan(Math.sinh(Math.PI*(1-2*y)))*180/Math.PI;
    const b=[latOf(v.cy+H/2/P),latOf(v.cy-H/2/P),lonOf(v.cx-W/2/P),lonOf(v.cx+W/2/P)];
    if(b[3]-b[2]>2.6)return 0;
    return drawCore(ctx,W,H,b,(la,lo)=>[(mercX(lo)-v.cx)*P+W/2,(mercY(la)-v.cy)*P+H/2],scale,existing,[],3500,flags||{city:true,vill:true});
  }
  root.MetStatOSM=Object.freeze({load,drawNwp,drawSatellite,query,state,norm,indexNodes,setCapitalsVisible,getCapitalsVisible,isCapital,categories:['city','town','suburb','neighbourhood','village','hamlet','agricultural','rain_gauge','climatology_station']});
})(window);
