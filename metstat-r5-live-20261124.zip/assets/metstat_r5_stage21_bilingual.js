/* MetStat R5 Stage21: scoped bilingual labels for real satellite and mountain widgets.
   Never touches actual model/field IDs, pixel values, geodata, input values or event handlers.
   No new polling timer, MutationObserver, browser storage or network calls. */
(() => {
  'use strict';
  const pairs = [["ماهواره، رادار و رعدوبرق (زنده)","Live satellite, radar and lightning"],["🛰 ماهواره‌ها","🛰 Satellites"],["🌧 رادار بارش","🌧 Rain radar"],["⚡ رعدوبرق","⚡ Lightning"],["لایه‌ها، مرزها و ظاهر نقشه","Map layers, boundaries and appearance"],["صاعقهٔ زنده (Blitzortung — آزمایشی)","Live lightning (Blitzortung — experimental)"],["مرز کشورها و ایران","Country and Iran boundaries"],["مرز و نام دریاها","Sea boundaries and names"],["مرز استان‌ها","Province boundaries"],["مرز شهرستان‌ها","County boundaries"],["مراکز استان و شهرستان (نقطه و نام)","Province and county centers (markers and names)"],["شهرها و روستاها","Cities and villages"],["رودها","Rivers"],["دریاچه‌ها","Lakes"],["جاده‌ها","Roads"],["روشنایی تصویر","Image brightness"],["کنتراست تصویر","Image contrast"],["اشباع رنگ","Color saturation"],["HD: افزودن جزئیات مرئی ۱ کیلومتری روی رنگ طبیعی (روز)","HD: add 1 km visible detail to natural color (daylight)"],["بازنشانی","Reset"],["ضخامت مرزها","Boundary line width"],["اندازهٔ نقاط","Marker size"],["اندازهٔ برچسب‌ها","Label size"],["سطح محدوده","Extent level"],["محدوده","Extent"],["جست‌وجوی شهرستان","Search county"],["قاره‌ای","Continent"],["منطقه‌ای","Region"],["کشوری","Country"],["استانی","Province-wide"],["شهرستانی","County-wide"],["ماهواره","Satellite"],["سایر ماهواره‌ها و سرویس‌ها","Other satellites and services"],["باند / محصول","Band / product"],["پیشرفته","Advanced"],["نام لایهٔ دستی (اختیاری)","Custom layer name (optional)"],["مثلاً mtg_fd:ir105_hrfi","e.g. mtg_fd:ir105_hrfi"],["محصول رعدوبرق","Lightning product"],["روی تصویر مادون‌قرمز Meteosat-12","Overlay on Meteosat-12 infrared imagery"],["منبع رادار","Radar source"],["رادار ترکیبی زمینی جهانی (RainViewer) — هر ۱۰ دقیقه","Global ground-radar mosaic (RainViewer) — every 10 min"],["بارش ماهواره‌ای NASA IMERG — هر ۳۰ دقیقه","NASA IMERG satellite precipitation — every 30 min"],["بارش ماهواره‌ای NOAA RRQPE + پیش‌بینی ۶۰ دقیقه — هر ۱۰ دقیقه","NOAA RRQPE satellite precipitation + 60-min forecast — every 10 min"],["رادار کرمانشاه (هواشناسی استان کرمانشاه) — غرب کشور","Kermanshah weather radar — western Iran"],["تعداد فریم","Frame count"],["دریافت جدیدترین تصاویر","Fetch latest imagery"],["تصاویر روی هاست ذخیره نمی‌شوند؛ مستقیم از منبع گرفته می‌شوند و خودکار هر ۵ دقیقه نو می‌شوند.","Images are loaded directly from providers, not stored on this host; refreshed automatically every 5 minutes."],["▶ پخش","▶ Play"],["❚❚ توقف","❚❚ Pause"],["ذخیره","Save PNG"],["ذخیرهٔ GIF","Save GIF"],["۴۰۹۶ (فقط PNG)","4096 (PNG only)"],["بازگشت به محدوده","Reset map extent"],["لایه","Layer"],["ماهواره + رادار","Satellite + radar"],["ابر و بارش","Cloud and precipitation"],["فقط ماهواره","Satellite only"],["باز کردن در متئوبلو ↗","Open in meteoblue ↗"],["رادارهای رسمی زمینی هر کشور (پیوند، در برگهٔ تازه):","National ground-radar agencies (open in new tab):"],["رعدوبرق از حسگر تصویرگر رعدوبرق ماهوارهٔ MTG (LI، EUMETSAT) است. شبکه‌های زمینی (پیوند، در برگهٔ تازه):","Lightning comes from the MTG Lightning Imager (LI, EUMETSAT). Ground networks (open in new tab):"],["تصاویر و محصولات ماهوارهٔ هندی INSAT-3DR و INSAT-3DS. این منابع اجازهٔ نمایش مستقیم داخل سایت را نمی‌دهند یا ثبت‌نام می‌خواهند؛ پیوندها در برگهٔ تازه باز می‌شوند:","INSAT-3DR and INSAT-3DS imagery and products. Direct embedding is restricted or registration may be required; links open in new tabs:"],["در حال دریافت از Open-Meteo…","Loading data from Open-Meteo…"],["هواشناسی کوهستان","Mountain weather"],["پیش‌بینی خودکار ۷ روزه برای قله‌ها: دما، باد، سوزباد، فشار و اکسیژن معادل در ارتفاع خود قله، امتیاز و پنجرهٔ هوا و توصیه. داده: Open-Meteo.","Automated 7-day summit forecast: temperature, wind, wind chill, pressure and equivalent oxygen at summit elevation, weather windows and guidance. Source: Open-Meteo."],["گروه","Group"],["مدل","Model"],["خودکار (best match)","Automatic (best match)"],["به‌روزرسانی","Refresh"],["رتبه‌بندی قله‌ها","Summit ranking"],["متئوگرام قله","Summit meteogram"],["مقطع باد (ارتفاع–زمان)","Wind cross-section (height–time)"],["مقطع دما (ارتفاع–زمان)","Temperature cross-section (height–time)"],["پروفایل قائم","Vertical profile"],["نیمرخ قله","Summit profile"],["خطر و دلایل","Risk and factors"],["پروفیل مسیر","Route profile"],["چندارتفاعی (تا قله)","Multi-elevation (to summit)"],["مقایسهٔ مدل‌ها","Model comparison"],["نمای ۳ بعدی","3D view"],["فرمول‌ها و ضرایب","Formulas and coefficients"],["❓ راهنما","❓ Help"],["در حال دریافت…","Loading…"],["زمان:","Time:"],["استان","Province"],["شهرستان","County"],["رشته‌کوه","Mountain range"],["ارتفاع","Elevation"],["همه","All"],["بالای ۲۰۰۰ m","Above 2000 m"],["بالای ۳۰۰۰ m","Above 3000 m"],["بالای ۴۰۰۰ m","Above 4000 m"],["بالای ۵۰۰۰ m","Above 5000 m"],["جست‌وجو","Search"],["نام قله یا مختصات (مثلاً ۲۹٫۱۲، ۵۳٫۸۰)","Summit name or coordinates (e.g. 29.12, 53.80)"],["نمایش همهٔ قله‌ها روی نقشه","Show all summits on map"],["بررسی پیشنهادها","Review suggestions"],["بستن فرم پیشنهاد","Close suggestion form"],["+ پیشنهاد قلهٔ جدید به مدیر","+ Suggest a new summit to the administrator"],["نام قله","Summit name"],["عرض (N)","Latitude (N)"],["طول (E)","Longitude (E)"],["ارتفاع m (اختیاری)","Elevation m (optional)"],["منطقه / نزدیک‌ترین آبادی / رشته‌کوه","Region / nearest settlement / mountain range"],["توضیح (اختیاری)","Notes (optional)"],["ارسال پیشنهاد","Send suggestion"],["پیشنهاد شما بعد از بررسی مدیر به فهرست اضافه می‌شود.","Your suggestion will appear after administrator review."],["افزودن به قله‌های من","Add to my summits"],["حذف","Delete"],["موردی نیست.","No results."],["موقعیت روی نقشه","Location on map"],["روی مرز استان‌ها","Along a province boundary"],["دور شدن","Zoom out"],["نزدیک شدن","Zoom in"]];
  const faToEn = new Map(pairs);
  const enToFa = new Map(pairs.map(([fa,en]) => [en,fa]));
  const isEn = () => {
    try { if (typeof LANG !== 'undefined') return LANG === 'en'; } catch (_) {}
    return document.documentElement.lang.toLowerCase().startsWith('en');
  };
  const matchValue = (value, en) => {
    const dict = en ? faToEn : enToFa;
    const exact = value.trim();
    if (dict.has(exact)) return value.replace(exact,dict.get(exact));
    // Only known templates, never arbitrary user text or scientific output.
    let m;
    if (en && (m=exact.match(/^نمایش\s+(\d+)\s+قلهٔ بعدی \(از\s+(\d+)\)$/)))
      return value.replace(exact,`Show ${m[1]} more summits (of ${m[2]})`);
    if (!en && (m=exact.match(/^Show\s+(\d+)\s+more summits \(of\s+(\d+)\)$/)))
      return value.replace(exact,`نمایش ${m[1]} قلهٔ بعدی (از ${m[2]})`);
    if (en && (m=exact.match(/^(\d+) قله با این فیلتر، به ترتیب ارتفاع$/)))
      return value.replace(exact,`${m[1]} matching summits, sorted by elevation`);
    if (!en && (m=exact.match(/^(\d+) matching summits, sorted by elevation$/)))
      return value.replace(exact,`${m[1]} قله با این فیلتر، به ترتیب ارتفاع`);
    return value;
  };
  function localize(root) {
    if (!root || !root.isConnected) return 0;
    const en=isEn(), walker=document.createTreeWalker(root,NodeFilter.SHOW_TEXT), nodes=[];
    while (walker.nextNode()) nodes.push(walker.currentNode);
    let changed=0;
    for (const node of nodes) {
      const parent=node.parentElement;
      if (!parent || parent.closest('script,style,noscript,textarea,code,pre,[contenteditable="true"]')) continue;
      // Avoid translating labels drawn inside meteorological map data or forecast tables.
      if (parent.closest('canvas,.mtBody,.saMap,.mtTb,.saFoot,.saTLab,.mtLocCv')) continue;
      const next=matchValue(node.nodeValue,en);
      if (next!==node.nodeValue) {node.nodeValue=next;changed++;}
    }
    for (const el of root.querySelectorAll('[placeholder],[title],[aria-label]')) {
      for(const attr of ['placeholder','title','aria-label']) {
        if (!el.hasAttribute(attr)) continue;
        const prev=el.getAttribute(attr),next=matchValue(prev,en);
        if(next!==prev){el.setAttribute(attr,next);changed++;}
      }
    }
    const src=document.getElementById('srcName');
    if (root.id==='saMain' && src) {
      const after=matchValue(src.textContent,en);
      if(after!==src.textContent){src.textContent=after;changed++;}
    }
    return changed;
  }
  const api=window.MetStatR5Stage21={version:'r5-stage21-bilingual-1', localize, scopes:['saMain','mtMain']};
  const refresh=()=>{for(const id of api.scopes)localize(document.getElementById(id));};
  document.addEventListener('langchange',refresh);
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',refresh,{once:true});
  else refresh();
})();