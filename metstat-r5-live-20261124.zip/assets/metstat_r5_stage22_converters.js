/* MetStat R5 stage22: local, bounded, no-network text/tabular and station GeoJSON conversion.
   No server permissions, scientific raster processing or hidden file uploads. */
(()=>{
'use strict';
const LIMIT=5*1024*1024, MAX_ROWS=30000, MAX_COLS=100;
const translations={
 'تبدیل فایل‌های اسنادی':'Document file conversion',
 'تبدیل داده‌های ایستگاهی':'Station data conversion',
 'فایل ورودی':'Input file', 'فرمت ورودی':'Input format','فرمت خروجی':'Output format',
 'خودکار':'Auto detect','اجرا و پیش‌نمایش':'Convert and preview','دانلود نتیجه':'Download converted file',
 'نتیجه':'Result','خروجی هنوز ساخته نشده است.':'No output yet.',
 'همه پردازش‌ها در همین مرورگر انجام می‌شود. هیچ فایلی به سرور ارسال نمی‌شود.':'All processing occurs in this browser. No files are uploaded.',
 'مبدل اسنادی از CSV، TSV، JSON و متن ساده پشتیبانی می‌کند. تبدیل PDF/Word به کتابخانه یا سرویس معتبر مجزا نیاز دارد.':'Supports CSV, TSV, JSON and plain text. PDF/Word require a separate validated converter.',
 'مبدل ایستگاهی فقط CSV/TSV/JSON با مختصات واقعی و GeoJSON نوع Point را تبدیل می‌کند؛ GRIB/NetCDF/GeoTIFF هنوز پشتیبانی نمی‌شوند.':'Converts CSV/TSV/JSON with real coordinates and Point GeoJSON only. GRIB/NetCDF/GeoTIFF are not yet supported.',
 'حداکثر ۵ مگابایت، ۳۰هزار ردیف و ۱۰۰ ستون.':'Maximum 5 MB, 30,000 rows and 100 columns.',
 'لطفاً یک فایل انتخاب کنید.':'Select an input file first.', 'فرمت فایل مشخص نیست.':'Could not determine the input format.',
 'مقدار معتبر انتخاب نشده است.':'Select valid formats.','دانلود آماده است.':'Your download is ready.',
 'ردیف‌های بدون مختصات معتبر حذف می‌شوند و تعدادشان گزارش می‌شود.':'Rows with invalid coordinates are skipped and counted.',
 'تعداد رکوردها':'Records','ردیف‌های حذف‌شده':'Skipped rows','فایل پردازش‌شده':'Processed file',
 'فرمت انتخاب‌شده پشتیبانی نمی‌شود.':'Selected format is not supported.',
 'این فایل ساختار قابل تبدیل ندارد.':'Unsupported input structure.',
 'مختصات طول و عرض معتبر در ستون‌ها پیدا نشد.':'No valid longitude and latitude columns were found.',
 'فقط عوارض Point قابل تبدیل‌اند.':'Only Point features are supported.',
 'خطا در پردازش فایل: ':'Conversion failed: ', 'پاک کردن':'Clear',
 'فارسی/انگلیسی':'Persian/English',
 'مبدل فایل‌های اسنادی':'Document file converter', 'مبدل فایل‌های هواشناسی':'Meteorological file converter',
 'ابزار مرورگری محلی؛ اجرای این بخش در همین صفحه انجام می‌شود.':'Local browser utility; this tool runs entirely on this page.',
 'بازگشت به مدل‌های هواشناسی':'Back to weather models'
};
const toFa=Object.fromEntries(Object.entries(translations).map(([fa,en])=>[en,fa]));
const isEn=()=>{try{if(typeof LANG!=='undefined')return LANG==='en'}catch(_){} return document.documentElement.lang.toLowerCase().startsWith('en')};
const tr=(fa)=>isEn()?(translations[fa]||fa):fa;
const mk=(tag,cls,txt)=>{const el=document.createElement(tag);if(cls)el.className=cls;if(txt!==undefined)el.textContent=txt;return el};
const label=(parent,name,control)=>{const l=mk('label','ms22-field');const span=mk('span','',tr(name));span.dataset.ms22Text=name;l.append(span,control);parent.append(l);return l};
function csvRead(text,sep){
 const out=[];let row=[],field='',quote=false,afterQuote=false;
 text=text.replace(/^\ufeff/,'');
 for(let i=0;i<text.length;i++){
   const c=text[i];
   if(quote){if(c==='"'){if(text[i+1]==='"'){field+='"';i++}else{quote=false;afterQuote=true}}else field+=c;continue}
   if(c==='"'&&field===''){quote=true;continue}
   if(c==='"')throw Error('Unexpected quote near byte '+i);
   if(c===sep){row.push(field);field='';afterQuote=false;continue}
   if(c==='\n'||c==='\r'){
     row.push(field);field='';afterQuote=false;
     if(row.some(v=>v!==''))out.push(row);
     if(out.length>MAX_ROWS+1)throw Error('Too many rows (30000 maximum)');
     row=[];if(c==='\r'&&text[i+1]==='\n')i++;continue
   }
   if(afterQuote&&!/\s/.test(c))throw Error('Unexpected text after quote');
   field+=c;afterQuote=false;
 }
 if(quote)throw Error('Unterminated quoted field');
 if(field!==''||row.length){row.push(field);if(row.some(v=>v!==''))out.push(row)}
 if(!out.length)return [];
 if(out[0].length>MAX_COLS)throw Error('Too many columns');
 return out;
}
const safeCsvValue=(value)=>{
 let str=value==null?'':typeof value==='object'?JSON.stringify(value):String(value);
 // Guard formula injection in spreadsheet apps, including values with leading whitespace.
 if(typeof value!=='number' && /^\s*[=+@\-]/.test(str) && !/^\s*[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?\s*$/.test(str))str="'"+str;
 return str;
};
const delimitedWrite=(arr,sep)=>arr.map(row=>row.map(v=>{
 const str=safeCsvValue(v);return /["\r\n]/.test(str)||str.includes(sep)?'"'+str.replace(/"/g,'""')+'"':str;
}).join(sep)).join('\r\n')+'\r\n';
function rowsFrom(text,format){
 if(format==='csv'||format==='tsv'){
  const lines=csvRead(text,format==='csv'?',':'\t');if(!lines.length)return [];
  const [header,...rest]=lines;
  if(!header.length||header.some(v=>!v.trim()))throw Error('Empty column header');
  if(new Set(header).size!==header.length)throw Error('Duplicate column header');
  return rest.map(line=>Object.fromEntries(header.map((h,i)=>[h,line[i]??''])));
 }
 if(format==='txt')return text.replace(/^\ufeff/,'').split(/\r?\n/).filter(v=>v.trim()).map(v=>({text:v}));
 if(format==='json'){
  const j=JSON.parse(text);if(!Array.isArray(j)||j.some(x=>!x||Array.isArray(x)||typeof x!=='object'))throw Error('JSON must be an array of flat objects');
  if(j.length>MAX_ROWS)throw Error('Too many rows');return j;
 }
 if(format==='geojson'){
  const j=JSON.parse(text);if(!j||j.type!=='FeatureCollection'||!Array.isArray(j.features))throw Error('Not a GeoJSON FeatureCollection');
  if(j.features.length>MAX_ROWS)throw Error('Too many features');
  return j.features.map(f=>{
    if(!f||f.type!=='Feature'||f.geometry?.type!=='Point'||!Array.isArray(f.geometry.coordinates))throw Error('Only GeoJSON Point features can be converted');
    const [lon,lat]=f.geometry.coordinates;if(!finiteLonLat(lon,lat))throw Error('Invalid GeoJSON Point coordinates');
    const props=f.properties&&typeof f.properties==='object'&&!Array.isArray(f.properties)?f.properties:{};
    return {...props,longitude:lon,latitude:lat};
  });
 }
 throw Error('Unsupported file type');
}
const columnsOf=(rows)=>{
 const keys=[];const seen=new Set();
 for(const row of rows){for(const k of Object.keys(row)){if(!seen.has(k)){keys.push(k);seen.add(k);if(keys.length>MAX_COLS)throw Error('Too many columns')}}}
 return keys;
};
const norm=(s)=>s.toLowerCase().normalize('NFKC').replace(/[\s_\-().]/g,'');
const LON=new Set(['lon','long','longitude','lng','x','طول','طولجغرافیایی','طولشرقی']);
const LAT=new Set(['lat','latitude','y','عرض','عرضجغرافیایی','عرضشمالی']);
function finiteLonLat(lon,lat){return ![lon,lat].some(v=>v===undefined||v===null||typeof v==='boolean'||typeof v==='string'&&!v.trim())&&Number.isFinite(Number(lon))&&Number.isFinite(Number(lat))&&Math.abs(Number(lon))<=180&&Math.abs(Number(lat))<=90}
function asGeojson(rows){
 const keys=columnsOf(rows);const lonKey=keys.find(k=>LON.has(norm(k))),latKey=keys.find(k=>LAT.has(norm(k)));
 if(!lonKey||!latKey)throw Error('Longitude/latitude column not found');
 let skipped=0;const features=[];
 for(const row of rows){const lon=row[lonKey],lat=row[latKey];if(!finiteLonLat(lon,lat)){skipped++;continue}
  const props=Object.fromEntries(Object.entries(row).filter(([k])=>k!==lonKey&&k!==latKey));
  features.push({type:'Feature',geometry:{type:'Point',coordinates:[Number(lon),Number(lat)]},properties:props});
 }
 if(!features.length)throw Error('No rows with valid coordinates');
 return {output:JSON.stringify({type:'FeatureCollection',features},null,2),count:features.length,skipped};
}
function convertText(text,from,to,kind){
 if(!text.trim())throw Error('Empty file');
 if(kind==='convert-document'&&from==='geojson')throw Error('GeoJSON is in the meteorological converter');
 const rows=rowsFrom(text,from);if(rows.length>MAX_ROWS)throw Error('Too many rows');
 if(to==='geojson'){
  if(kind!=='convert-weather')throw Error('Choose the station converter for GeoJSON');
  return {...asGeojson(rows),mime:'application/geo+json',ext:'geojson'};
 }
 const cols=columnsOf(rows);
 if(to==='json')return {output:JSON.stringify(rows,null,2),count:rows.length,skipped:0,mime:'application/json',ext:'json'};
 if(to==='csv'||to==='tsv')return {output:delimitedWrite([cols,...rows.map(row=>cols.map(c=>row[c]??''))],to==='csv'?',':'\t'),count:rows.length,skipped:0,mime:to==='csv'?'text/csv;charset=utf-8':'text/tab-separated-values;charset=utf-8',ext:to};
 if(to==='txt')return {output:rows.map(row=>cols.map(c=>String(row[c]??'')).join(' | ')).join('\n'),count:rows.length,skipped:0,mime:'text/plain;charset=utf-8',ext:'txt'};
 throw Error('Unsupported output format');
}
function render(kind){
 const weather=kind==='convert-weather';
 const root=mk('div','ms22-workspace');root.dataset.ms22Converter=kind;
 const controls=mk('section','ms22-side'),output=mk('section','ms22-main');root.append(controls,output);
 const h=mk('h3','',tr(weather?'تبدیل داده‌های ایستگاهی':'تبدیل فایل‌های اسنادی'));h.dataset.ms22Text=weather?'تبدیل داده‌های ایستگاهی':'تبدیل فایل‌های اسنادی';controls.append(h);
 const note=mk('p','ms22-note',tr(weather?'مبدل ایستگاهی فقط CSV/TSV/JSON با مختصات واقعی و GeoJSON نوع Point را تبدیل می‌کند؛ GRIB/NetCDF/GeoTIFF هنوز پشتیبانی نمی‌شوند.':'مبدل اسنادی از CSV، TSV، JSON و متن ساده پشتیبانی می‌کند. تبدیل PDF/Word به کتابخانه یا سرویس معتبر مجزا نیاز دارد.'));note.dataset.ms22Text=weather?'مبدل ایستگاهی فقط CSV/TSV/JSON با مختصات واقعی و GeoJSON نوع Point را تبدیل می‌کند؛ GRIB/NetCDF/GeoTIFF هنوز پشتیبانی نمی‌شوند.':'مبدل اسنادی از CSV، TSV، JSON و متن ساده پشتیبانی می‌کند. تبدیل PDF/Word به کتابخانه یا سرویس معتبر مجزا نیاز دارد.';controls.append(note);
 const file=mk('input');file.type='file';file.id='ms22File';file.accept=weather?'.csv,.tsv,.json,.geojson,text/csv,application/json':'.csv,.tsv,.json,.txt,text/plain,text/csv,application/json';label(controls,'فایل ورودی',file);
 const from=mk('select');from.id='ms22From';
 const fromOpts=weather?['auto','csv','tsv','json','geojson']:['auto','csv','tsv','json','txt'];
 const makeOption=(v)=>{const opt=mk('option','',v==='auto'?tr('خودکار'):v.toUpperCase());opt.value=v;return opt};
 from.replaceChildren(...fromOpts.map(makeOption));label(controls,'فرمت ورودی',from);
 const to=mk('select');to.id='ms22To';to.replaceChildren(...(weather?['geojson','csv','json','tsv']:['json','csv','tsv','txt']).map(makeOption));label(controls,'فرمت خروجی',to);
 const run=mk('button','ms22-primary',tr('اجرا و پیش‌نمایش'));run.type='button';run.id='ms22Convert';run.dataset.ms22Text='اجرا و پیش‌نمایش';controls.append(run);
 const download=mk('button','ms22-secondary',tr('دانلود نتیجه'));download.type='button';download.id='ms22Download';download.disabled=true;download.dataset.ms22Text='دانلود نتیجه';controls.append(download);
 const cap=mk('p','ms22-note',tr('حداکثر ۵ مگابایت، ۳۰هزار ردیف و ۱۰۰ ستون.'));cap.dataset.ms22Text='حداکثر ۵ مگابایت، ۳۰هزار ردیف و ۱۰۰ ستون.';controls.append(cap);
 const privacy=mk('p','ms22-note',tr('همه پردازش‌ها در همین مرورگر انجام می‌شود. هیچ فایلی به سرور ارسال نمی‌شود.'));privacy.dataset.ms22Text='همه پردازش‌ها در همین مرورگر انجام می‌شود. هیچ فایلی به سرور ارسال نمی‌شود.';controls.append(privacy);
 const title=mk('h3','',tr('نتیجه'));title.dataset.ms22Text='نتیجه';output.append(title);
 const status=mk('p','ms22-status',tr('خروجی هنوز ساخته نشده است.'));status.id='ms22Status';status.setAttribute('role','status');status.dataset.ms22Status='1';output.append(status);
 const preview=mk('pre','ms22-preview');preview.id='ms22Preview';output.append(preview);
 let result=null,filename='';
 const statusSet=(text,err=false)=>{status.textContent=text;status.classList.toggle('ms22-error',err)};
 const detected=(f)=>{const ext=f.name.toLowerCase().split('.').pop();return ['csv','tsv','json','geojson','txt'].includes(ext)?ext:null};
 file.addEventListener('change',()=>{result=null;download.disabled=true;preview.textContent='';statusSet(tr('خروجی هنوز ساخته نشده است.'))});
 run.addEventListener('click',async()=>{
  result=null;download.disabled=true;preview.textContent='';
  const f=file.files?.[0];if(!f){statusSet(tr('لطفاً یک فایل انتخاب کنید.'),true);return}
  if(f.size>LIMIT){statusSet('File exceeds 5 MB',true);return}
  const format=from.value==='auto'?detected(f):from.value;
  if(!format){statusSet(tr('فرمت فایل مشخص نیست.'),true);return}
  try{
    const data=await f.text();if(data.length>2*LIMIT)throw Error('Decoded text too large');
    const converted=convertText(data,format,to.value,kind);
    if(converted.output.length>LIMIT*4)throw Error('Converted result exceeds output limit');
    if(!root.isConnected||file.files?.[0]!==f)return;
    result=converted;filename=f.name.replace(/\.[^.]+$/,'').replace(/[^\p{L}\p{N}_.-]/gu,'_').slice(0,80)+'.'+converted.ext;
    preview.textContent=converted.output.slice(0,12000)+(converted.output.length>12000?'\n…':'');
    statusSet(`${tr('تعداد رکوردها')}: ${converted.count} · ${tr('ردیف‌های حذف‌شده')}: ${converted.skipped}`);
    download.disabled=false;
  }catch(e){statusSet(tr('خطا در پردازش فایل: ')+(e?.message||String(e)),true)}
 });
 download.addEventListener('click',()=>{
  if(!result)return;const blob=new Blob([result.ext==='json'||result.ext==='geojson'?result.output:'\ufeff'+result.output],{type:result.mime});const url=URL.createObjectURL(blob);
  const link=mk('a');link.href=url;link.download=filename;document.body.append(link);link.click();link.remove();
  setTimeout(()=>URL.revokeObjectURL(url),4000);
 });
 const onLang=()=>{if(!root.isConnected)return;root.querySelectorAll('[data-ms22-text]').forEach(n=>n.textContent=tr(n.dataset.ms22Text));const auto=from.querySelector('option[value="auto"]');if(auto)auto.textContent=tr('خودکار');controls.dir=output.dir=isEn()?'ltr':'rtl';if(result)statusSet(`${tr('تعداد رکوردها')}: ${result.count} · ${tr('ردیف‌های حذف‌شده')}: ${result.skipped}`);else if(!status.classList.contains('ms22-error'))statusSet(tr('خروجی هنوز ساخته نشده است.'));
    const container=root.closest('#ms7Custom');if(container){
      const t=container.querySelector('h2.ms7-title'),p=container.querySelector('p.ms7-description'),back=container.lastElementChild;
      const routeTitle=weather?'مبدل فایل‌های هواشناسی':'مبدل فایل‌های اسنادی';
      if(t)t.textContent=tr(routeTitle);
      if(p)p.textContent=tr('ابزار مرورگری محلی؛ اجرای این بخش در همین صفحه انجام می‌شود.');
      if(back&&back.tagName==='BUTTON')back.textContent=tr('بازگشت به مدل‌های هواشناسی');
      document.title=tr(routeTitle)+' | MetStat';
    }
  };
 document.addEventListener('langchange',onLang);Promise.resolve().then(onLang);
 // Release the handler when navigating away without a polling timer.
 root.addEventListener('ms22-dispose',()=>document.removeEventListener('langchange',onLang),{once:true});
 return root;
}
window.MetStatR5Converters={render,convertText,rowsFrom,csvRead,asGeojson,version:'stage22-r5-local-converters'};
})();
