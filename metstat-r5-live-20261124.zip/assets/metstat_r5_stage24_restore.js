/* MetStat R5 Stage25 — verified-byte archive route adapter; leaves native module sources unchanged.
 * Only preapproved first-party HTML with SHA-256 equality can be mounted. */
(function(){'use strict';

 const ARCHIVE_EN={"isohyet":"Station rainfall / isohyet maps","toolbox-full":"Meteorological toolbox","verify-forecast":"Forecast verification","bulletin-maps":"Bulletin weather maps","convert-unit":"Meteorological unit conversion","toolbox-spatial":"Station precipitation IDW"};
 const liveEnglish=()=>((typeof LANG!=='undefined'&&LANG==='en')||document.documentElement.lang.toLowerCase().startsWith('en'));
 const message=(name)=>({
  loading:['در حال بررسی نسخه اصلی ماژول…','Checking the verified module…'],
  failed:['این ماژول در فایل‌های نصب‌شده پیدا نشد یا با نسخه بررسی‌شده مطابقت ندارد. برای جلوگیری از نمایش نسخه اشتباه باز نشد.','The module is missing or its revision does not match the verified version. Loading was blocked.'],
  gis:['مرزهای نقشه همبارش با نسخه تأییدشده مطابقت ندارند؛ ماژول برای جلوگیری از نمایش نقشه نادرست متوقف شد.','Isohyet boundary data failed integrity verification. The map was stopped.']
 })[name][liveEnglish()?1:0];
 const MODULES={"isohyet":{"path":"/online/station_isohyet_v26.html","sha256":"faae6460663df2170a68898c51f1e19f9a7f80080dacd7cc8f106a8f25cec629","title":"موتور همبارش ایستگاهی","navFa":"تهیه نقشه‌های همبارش از داده‌های ایستگاهی"},"toolbox-full":{"path":"/online/meteo_toolbox_v22.html","sha256":"7d2037068e621e79925ab6b64a5cba5232773fed450f62e826b534e98d930d87","title":"جعبه‌ابزار کامل هواشناسی","navFa":"جعبه‌ابزار کامل هواشناسی"},"verify-forecast":{"path":"/online/forecast_verification_v22.html","sha256":"8393def632f1adb74fa81ee9649f6c7092a1a569fb7918edee2a820f1e5a841c","title":"پایش دقت مدل‌ها","navFa":"پایش دقت مدل‌ها"},"bulletin-maps":{"path":"/online/bulletin_maps_v21.html","sha256":"081145bec35d883c1cd5a398823ac45bd50fa97f64361d9a56b79b38ecc2e6bd","title":"نقشه‌های بولتن","navFa":"نقشه‌های بولتن"},"toolbox-spatial":{"path":"/online/meteo_toolbox_v22.html","sha256":"7d2037068e621e79925ab6b64a5cba5232773fed450f62e826b534e98d930d87","title":"درون‌یابی بارش ایستگاهی IDW","navFa":"درون‌یابی ایستگاهی IDW","tab":"spatial"},"convert-unit":{"path":"/online/meteo_toolbox_v22.html","sha256":"7d2037068e621e79925ab6b64a5cba5232773fed450f62e826b534e98d930d87","title":"تبدیل واحدهای هواشناسی","navFa":"تبدیل واحدهای هواشناسی","tab":"calc","category":"تبدیل واحد"}};
  const INTEGRITY=Object.freeze({
    layers:'sha256-sytJHHEF93x9I3Z92Hc/N+257aSAuQZ6Ks5vTWFjgLg=',
    atlas:'sha256-sSFhSwrd9p7EuztLe4+fAx93PmnFo1x+zFjwW/SLcz0='
  });
  // Transform only the hash-verified archived rain HTML, never the original engines.
  function pinIsohyetDependencies(html){
    const layerTag='<script src="../assets/map_layers.js"></script>';
    const atlasFetch="fetch('atlas_stations_v28.json',{cache:'no-cache'})";
    if(html.split(layerTag).length!==2||html.split(atlasFetch).length!==2)
      throw Error('Archived isohyet dependency signatures changed');
    html=html.replace(layerTag,'<script src="../assets/map_layers.js" integrity="'+INTEGRITY.layers+'" crossorigin="anonymous" onload="document.documentElement.dataset.ms26Layers=\'ok\'" onerror="document.documentElement.dataset.ms26Layers=\'failed\'"></script>');
    html=html.replace(atlasFetch,"fetch('atlas_stations_v28.json',{cache:'no-cache',integrity:'"+INTEGRITY.atlas+"'})");
    return html;
  }
const verify=async(path,expected)=>{
   if(!window.crypto||!crypto.subtle)throw Error('Secure context required for file verification');
   const response=await fetch(path,{cache:'no-store',redirect:'error',credentials:'same-origin'});
   if(!response.ok)throw Error('HTTP '+response.status);
   const type=response.headers.get('content-type')||'';
   if(!/(?:text\/html|application\/xhtml\+xml)/i.test(type))throw Error('Unexpected content type: '+type);
   const bytes=await response.arrayBuffer();
   // Render the EXACT bytes that passed integrity verification: never fetch the URL a second time.
   if(bytes.byteLength>2*1024*1024)throw Error('Archived module exceeds size limit');
   const digest=await crypto.subtle.digest('SHA-256',bytes);
   const actual=[...new Uint8Array(digest)].map(x=>x.toString(16).padStart(2,'0')).join('');
   if(actual!==expected)throw Error('File revision is different from audited archive');
   const html=new TextDecoder('utf-8',{fatal:true}).decode(bytes);
   if(!/<head(?:\s[^>]*)?>/i.test(html))throw Error('Verified document has no head');
   const directory=new URL('.',new URL(path,document.baseURI)).href;
   // srcdoc inherits this site's origin. Preserve original relative assets/API paths.
   const base='<base href="'+directory.replace(/&/g,'&amp;').replace(/"/g,'&quot;')+'">';
   return html.replace(/<head(\s[^>]*)?>/i,match=>match+base);
 };
 function create(route,label){
   if(!Object.prototype.hasOwnProperty.call(MODULES,route))return null;
   const spec=MODULES[route];
   const root=document.createElement('section');root.className='ms23-archive-module';root.setAttribute('data-ms23-module',route);
   const banner=document.createElement('p');banner.className='ms23-loading';banner.setAttribute('role','status');
   banner.dataset.msArchiveState='loading';banner.textContent=message('loading');root.append(banner);
   const frame=document.createElement('iframe');frame.className='ms23-module-frame';frame.title=liveEnglish()?ARCHIVE_EN[route]:(MODULES[route].title||label);frame.dataset.ms24Route=route;
   frame.loading='eager';frame.referrerPolicy='same-origin';
   frame.addEventListener('load',()=>{
     if(!root.isConnected)return;
     try{
       const d=frame.contentDocument;if(!d||!d.body)return;
       // The rain polygon script is not allowed to run if its SRI fails.
       if(route==='isohyet'&&d.documentElement.dataset.ms26Layers!=='ok'){
         const error=document.createElement('p');error.className='ms23-loading ms23-error';
         error.setAttribute('role','alert');error.dataset.msArchiveState='gis';error.textContent=message('gis');
         frame.remove();root.replaceChildren(error);return;
       }
       d.body.classList.add('embed');
       const style=d.createElement('style');style.setAttribute('data-ms23-fit','');
       style.textContent='html,body{min-width:0}body>.shell,body>.layout{max-width:none}';d.head.append(style);
       d.documentElement.lang=document.documentElement.lang||'fa';
       d.documentElement.dir=document.documentElement.dir||'rtl';
       d.dispatchEvent(new Event('langchange'));
       // Reuse the existing real toolbox calculators and IDW engine, not copied widgets.
       if(spec.tab){const tab=d.querySelector('[data-tab="'+spec.tab+'"]');if(tab&&!tab.classList.contains('active'))tab.click();}
       if(spec.category){const cat=[...d.querySelectorAll('#calcGroups button[data-calc]')].find(b=>b.dataset.calc===spec.category);if(cat)cat.click();}
     }catch(_){/* No cross-origin frame is allowed by the verified route table. */}
   });
   Promise.resolve().then(()=>verify(spec.path,spec.sha256)).then(verifiedHtml=>{
     if(!root.isConnected)return;
     frame.srcdoc=spec.path.endsWith('/station_isohyet_v26.html')?pinIsohyetDependencies(verifiedHtml):verifiedHtml;root.append(frame);banner.remove();
   }).catch(e=>{
     if(!root.isConnected)return;
     banner.dataset.msArchiveState='failed';banner.textContent=message('failed');
     banner.classList.add('ms23-error');console.warn('MetStat Stage23 module unavailable:',route,String(e));
   });
   return root;
 }
 // One page-level language bridge, no polling.
 document.addEventListener('langchange',()=>{
   for(const status of document.querySelectorAll('[data-ms-archive-state]')){
     const key=status.dataset.msArchiveState;
     if(['loading','failed','gis'].includes(key))status.textContent=message(key);
   }
   for(const frame of document.querySelectorAll('iframe.ms23-module-frame')){
     const route=frame.dataset.ms24Route;
     if(Object.prototype.hasOwnProperty.call(MODULES,route))frame.title=liveEnglish()?ARCHIVE_EN[route]:MODULES[route].title;
     if(!frame.isConnected)continue;
     try{const d=frame.contentDocument;if(!d||!d.documentElement)continue;
       d.documentElement.lang=document.documentElement.lang||'fa';
       d.documentElement.dir=document.documentElement.dir||'rtl';
       d.dispatchEvent(new Event('langchange'));
     }catch(_){/* preserve functionality when browser blocks iframe document access */}
   }
 });
 const NAV_EN=ARCHIVE_EN;
 document.addEventListener('click',(event)=>{
   if(!event.target.closest('#ms7Nav [data-group]'))return;
   const en=(typeof LANG!=='undefined'?LANG==='en':document.documentElement.lang.startsWith('en'));
   for(const b of document.querySelectorAll('#ms7Fly button[data-dest]')){
     if(!Object.prototype.hasOwnProperty.call(NAV_EN,b.dataset.dest))continue;
     b.textContent=en?NAV_EN[b.dataset.dest]:MODULES[b.dataset.dest].navFa;
   }
 });
 window.MetStatR5ArchiveModules=Object.freeze({create, routes:Object.freeze(Object.keys(MODULES))});
})();