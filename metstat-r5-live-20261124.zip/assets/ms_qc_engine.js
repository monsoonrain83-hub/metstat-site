/* MetStat standalone observation QC engine; no changes to production application. */
(function(root){'use strict';
function rad(x){return x*Math.PI/180}
function km(a,b,c,d){let dl=rad(c-a),dn=rad(d-b),z=Math.sin(dl/2)**2+Math.cos(rad(a))*Math.cos(rad(c))*Math.sin(dn/2)**2;return 12742*Math.asin(Math.min(1,Math.sqrt(z)))}
function number(s){if(s===null||s===undefined||String(s).trim()==='')return NaN;return Number(String(s).trim())}
function check(rows,opts){opts=opts||{};let radius=Number(opts.radiusKm)||50,minPeers=Math.max(2,Number(opts.minPeers)||3),seen=new Map(),out=[];
rows.forEach((r,i)=>{let station=String(r.station||'').trim(),lat=number(r.lat),lon=number(r.lon),rain=number(r.rain_mm),flags=[];if(!station)flags.push('MISSING_STATION');if(!Number.isFinite(lat)||lat < -90||lat > 90||!Number.isFinite(lon)||lon < -180||lon > 180)flags.push('INVALID_COORD');if(!Number.isFinite(rain))flags.push('INVALID_RAIN');else if(rain<0)flags.push('NEGATIVE_RAIN');if(station){let k=station.toLowerCase();if(seen.has(k))flags.push('DUPLICATE_STATION');else seen.set(k,i)}out.push({station,lat,lon,rain_mm:rain,flags,neighbors:0,peerMedian:NaN})});
// Buddy check only flags candidates, never deletes or replaces measured values.
out.forEach((r,i)=>{if(!Number.isFinite(r.rain_mm)||r.rain_mm<0||!Number.isFinite(r.lat)||!Number.isFinite(r.lon)||Math.abs(r.lat)>90||Math.abs(r.lon)>180)return;let peers=[];out.forEach((p,j)=>{if(i===j||!Number.isFinite(p.rain_mm)||p.rain_mm<0||!Number.isFinite(p.lat)||!Number.isFinite(p.lon)||Math.abs(p.lat)>90||Math.abs(p.lon)>180)return;if(km(r.lat,r.lon,p.lat,p.lon)<=radius)peers.push(p.rain_mm)});r.neighbors=peers.length;if(peers.length>=minPeers){peers.sort((a,b)=>a-b);let m=peers[Math.floor((peers.length-1)/2)];r.peerMedian=m;let deviation=Math.abs(r.rain_mm-m);if(deviation>=Number(opts.absoluteDiffMm||40)&&deviation>=Number(opts.relativeFactor||4)*Math.max(2,m))r.flags.push('SPATIAL_OUTLIER_CANDIDATE')}});return out}
root.MetStatQC={check,km};if(typeof module!=='undefined'&&module.exports)module.exports=root.MetStatQC;
})(typeof window!=='undefined'?window:globalThis);
