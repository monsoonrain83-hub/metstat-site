/* ===== آزمایشگاه محاسبات هواشناسی — ثابت‌ها (فاز ۱) =====
   مرجع: MetPy (BSD-3، Unidata) metpy.constants — مقادیر عیناً با MetPy ۱٫۷+ هم‌خوان‌اند تا آزمون رگرسیون ممکن باشد.
   قرارداد واحدها (همه‌جا در MET): فشار hPa، دمای ورودی/خروجی عمومی °C، دمای داخلی K (پسوند K)، ارتفاع m، باد m/s، نسبت اختلاط kg/kg.
   مقدار مفقود = null/NaN؛ هیچ تابعی مقدار مفقود را صفر نمی‌کند. خروجی شاخص‌ها: {v:عدد|null, why:دلیل}. */
(function(root){
  "use strict";
  const MET = root.MET = root.MET || {};
  MET.C = Object.freeze({
    Rd: 287.04749097718457, Rv: 461.52311572606084,        // J/(kg·K) ثابت گاز هوای خشک / بخار آب
    Cp_d: 1004.6662184201462, Cp_v: 1860.078011865639, Cp_l: 4219.400000000001, Cp_i: 2090.0,   // J/(kg·K)
    Lv: 2500840.0, Lf: 333700.0, Ls: 2834540.0,            // J/kg گرمای نهان تبخیر/ذوب/تصعید در T0
    epsilon: 0.6219569100577033,                           // Mw/Md
    kappa: 0.28571428571428564,                            // Rd/Cp_d
    T0: 273.16, zeroC: 273.15,                             // K (نقطهٔ سه‌گانه / صفر سلسیوس)
    P0: 1000.0, es0: 6.112,                                // hPa (فشار مرجع پتانسیل / فشار بخار اشباع در T0)
    g: 9.80665, rhoL: 999.97495                            // m/s² ، kg/m³
  });
  MET.VERSION = "met-1.1.0-phase2";
  MET.REF = "MetPy (BSD-3-Clause, Unidata); Romps 2017 (LCL); Bolton 1980 (Td, θe)";
  // نتیجهٔ ناموفق/ناکافی — همیشه با دلیل؛ هرگز صفر
  MET.nil = function(why){ return {v:null, why:why}; };
  MET.ok = function(v, extra){ const o = {v:v, why:null}; if(extra) Object.assign(o, extra); return o; };
  MET.isNum = function(x){ return typeof x === "number" && isFinite(x); };
})(typeof globalThis !== "undefined" ? globalThis : this);
/* ===== ترمودینامیک پایه (توابع خالص، بدون DOM) =====
   مرجع: MetPy metpy.calc.thermo — فرمول‌ها عیناً: فشار بخار اشباع (Ambaum 2020 / Romps 2017)، Td (Bolton 1980)،
   LCL (Romps 2017، شاخهٔ −۱ تابع W لامبرت)، θe (Bolton 1980 تقریب)، دمای مجازی، آدیاباتیک خشک/مرطوب.
   ورودی‌ها: فشار hPa، دما K (پسوند K). فرضیات: هوا گاز ایدهآل؛ بخار اشباع نسبت به آب (liquid) مگر مشخص شود. */
(function(){
  "use strict";
  const M = globalThis.MET, C = M.C;
  const LN = Math.log, EXP = Math.exp;
  const T = {};
  T.cToK = c => c + C.zeroC;  T.kToC = k => k - C.zeroC;
  T.latentVap = Tk => C.Lv - (C.Cp_l - C.Cp_v) * (Tk - C.T0);
  T.latentSub = Tk => C.Ls - (C.Cp_i - C.Cp_v) * (Tk - C.T0);
  T.esLiquid = function(Tk){ const L = T.latentVap(Tk), hp = (C.Cp_l - C.Cp_v) / C.Rv, ex = ((C.Lv / C.T0 - L / Tk) / C.Rv);
    return C.es0 * Math.pow(C.T0 / Tk, hp) * EXP(ex); };
  T.esSolid = function(Tk){ const L = T.latentSub(Tk), hp = (C.Cp_i - C.Cp_v) / C.Rv, ex = ((C.Ls / C.T0 - L / Tk) / C.Rv);
    return C.es0 * Math.pow(C.T0 / Tk, hp) * EXP(ex); };
  T.es = function(Tk, phase){ phase = phase || "liquid";
    if(phase === "liquid") return T.esLiquid(Tk);
    if(phase === "solid") return T.esSolid(Tk);
    return Tk > C.T0 ? T.esLiquid(Tk) : T.esSolid(Tk); };
  T.mixingRatio = (e, p) => C.epsilon * e / (p - e);
  T.satMixingRatio = function(p, Tk, phase){ const e = T.es(Tk, phase); return e >= p ? NaN : T.mixingRatio(e, p); };
  T.vaporPressure = (p, w) => p * w / (C.epsilon + w);
  T.dewpointFromE = function(e){ const v = LN(e / C.es0); return C.zeroC + 243.5 * v / (17.67 - v); };      // K
  T.dewpointFromRH = (Tk, rh) => T.dewpointFromE(rh * T.es(Tk, "liquid"));                                  // rh 0..1
  T.rhFromDewpoint = (Tk, Tdk, phase) => T.es(Tdk, phase || "liquid") / T.es(Tk, phase || "liquid");
  T.specHumFromMixing = w => w / (1 + w);
  T.specHumFromDewpoint = (p, Tdk, phase) => T.specHumFromMixing(T.satMixingRatio(p, Tdk, phase));
  T.moistGasConst = q => C.Rd + q * (C.Rv - C.Rd);
  T.moistCp = q => C.Cp_d + q * (C.Cp_v - C.Cp_d);
  T.exner = p => Math.pow(p / C.P0, C.kappa);
  T.theta = (p, Tk) => Tk / T.exner(p);
  T.dryLapse = (p, Tk0, p0) => Tk0 * Math.pow(p / p0, C.kappa);
  T.virtualT = (Tk, w) => Tk * ((w + C.epsilon) / (C.epsilon * (1 + w)));
  T.virtualTFromDewpoint = (p, Tk, Tdk) => T.virtualT(Tk, T.satMixingRatio(p, Tdk));
  // θe (Bolton 1980، همان تقریب MetPy): ورودی Tk, Tdk برحسب K
  T.thetaE = function(p, Tk, Tdk){ const r = T.satMixingRatio(p, Tdk), e = T.es(Tdk);
    const tL = 56 + 1 / (1 / (Tdk - 56) + LN(Tk / Tdk) / 800);
    const thL = T.theta(p - e, Tk) * Math.pow(Tk / tL, 0.28 * r);
    return thL * EXP(r * (1 + 0.448 * r) * (3036 / tL - 1.78)); };
  // شاخهٔ −۱ تابع W لامبرت، x ∈ [−1/e, 0): تکرار هالی
  T.lambertWm1 = function(x){
    if(!(x < 0) || x < -1 / Math.E - 1e-15) return NaN;
    if(x <= -1 / Math.E) return -1;
    let w;
    if(x < -0.25){ const p = -Math.sqrt(2 * (Math.E * x + 1)); w = -1 + p - p * p / 3 + 11 / 72 * p * p * p; }
    else { const l1 = LN(-x), l2 = LN(-l1); w = l1 - l2 + l2 / l1; }
    for(let i = 0; i < 60; i++){
      const ew = EXP(w), f = w * ew - x, wp1 = w + 1;
      const d = ew * wp1 - (w + 2) * f / (2 * wp1);
      const nw = w - f / d;
      if(Math.abs(nw - w) <= 1e-15 * Math.max(1, Math.abs(nw))){ w = nw; break; }
      w = nw;
    }
    return w;
  };
  // LCL (Romps 2017، معادلات 22a–22f). ورودی: p hPa، Tk، Tdk (K). خروجی {p,Tk} یا null
  T.lcl = function(p, Tk, Tdk){
    if(!(Tdk <= Tk + 1e-9)) return null;
    const q = T.specHumFromDewpoint(p, Tdk);
    if(!isFinite(q)) return null;
    const ratio = T.moistCp(q) / T.moistGasConst(q), dC = C.Cp_l - C.Cp_v;
    const a = ratio + dC / C.Rv, b = -(C.Lv + dC * C.T0) / (C.Rv * Tk), c = b / a;
    const rh = T.rhFromDewpoint(Tk, Tdk, "liquid");
    const w = T.lambertWm1(Math.pow(rh, 1 / a) * c * EXP(c));
    const tl = c / w * Tk, pl = p * Math.pow(tl / Tk, ratio);
    return isFinite(tl) && isFinite(pl) ? {p: pl, Tk: tl} : null;
  };
  // شیب آدیاباتیک مرطوب dT/dp (K/hPa)، آهنگ MetPy
  function dTdp(p, t){
    const rs = T.satMixingRatio(p, t);
    const num = C.Rd * t + C.Lv * rs, den = C.Cp_d + C.Lv * C.Lv * rs * C.epsilon / (C.Rd * t * t);
    return num / den / p;
  }
  // پروفایل آدیاباتیک مرطوب: pArr کاهشی (از p0 به بالا)؛ RK4 با گام ≤ ۲ hPa (خطا ≪ ۰٫۰۰۱ K)
  T.moistLapse = function(pArr, Tk0, p0){
    const out = new Array(pArr.length); let p = p0, t = Tk0;
    for(let i = 0; i < pArr.length; i++){
      const pt = pArr[i], n = Math.max(1, Math.ceil(Math.abs(pt - p) / 2)), h = (pt - p) / n;
      for(let k = 0; k < n; k++){
        const k1 = dTdp(p, t), k2 = dTdp(p + h / 2, t + h / 2 * k1), k3 = dTdp(p + h / 2, t + h / 2 * k2), k4 = dTdp(p + h, t + h * k3);
        t += h / 6 * (k1 + 2 * k2 + 2 * k3 + k4); p += h;
      }
      p = pt; out[i] = t;
    }
    return out;
  };
  M.thermo = T;
})();
/* ===== پروفایل قائم: اعتبارسنجی، درون‌یابی، لایه =====
   قرارداد: p (hPa) نزولی از سطح زمین؛ T و Td برحسب °C در ورودی خام و K در پروفایل پاک‌شده (Tk, Tdk)؛ z (m) اختیاری.
   قاعدهٔ داده: ردیف‌های ناقص (NaN) حذف و در dropped گزارش می‌شوند — هرگز با صفر پر نمی‌شوند.
   Td > T به‌اندازهٔ بیش از ۱ °C ⇒ ردیف رد می‌شود؛ ≤۱ °C ⇒ Td=T (اشباع) و در issues ثبت می‌شود. فشار تکراری ⇒ خطا. */
(function(){
  "use strict";
  const M = globalThis.MET, C = M.C, P = {};
  const fin = x => typeof x === "number" && isFinite(x);
  P.clean = function(raw){
    const issues = [], n = raw && raw.p ? raw.p.length : 0, rows = [];
    if(!n) return {ok:false, why:"empty_profile", issues:["no_pressure_levels"]};
    let dropped = 0;
    for(let i = 0; i < n; i++){
      const p = raw.p[i], t = raw.T[i], td = raw.Td[i];
      if(!fin(p) || !fin(t) || !fin(td) || p <= 0){ dropped++; continue; }
      if(t < -100 || t > 70){ dropped++; issues.push("temperature_out_of_range@" + p); continue; }
      let tdd = td;
      if(td > t){ if(td - t > 1){ dropped++; issues.push("dewpoint_exceeds_temperature@" + p); continue; } tdd = t; issues.push("dewpoint_clipped_to_T@" + p); }
      rows.push({p:p, Tk:t + C.zeroC, Tdk:tdd + C.zeroC, z: raw.z && fin(raw.z[i]) ? raw.z[i] : null,
                 u: raw.u && fin(raw.u[i]) ? raw.u[i] : null, v: raw.v && fin(raw.v[i]) ? raw.v[i] : null});
    }
    rows.sort((a, b) => b.p - a.p);
    for(let i = 1; i < rows.length; i++) if(rows[i].p === rows[i - 1].p) return {ok:false, why:"duplicate_pressure", issues:issues.concat(["duplicate@" + rows[i].p])};
    if(rows.length < 3) return {ok:false, why:"too_few_valid_levels", issues:issues, dropped:dropped};
    return {ok:true, prof:{p:rows.map(r => r.p), Tk:rows.map(r => r.Tk), Tdk:rows.map(r => r.Tdk), z:rows.map(r => r.z), u:rows.map(r => r.u), v:rows.map(r => r.v)}, dropped:dropped, issues:issues};
  };
  // درون‌یابی خطی نسبت به p (مثل MetPy interpolate_1d): p نزولی؛ خارج بازه ⇒ NaN
  P.interpLin = function(x, p, y){
    if(!(x <= p[0] && x >= p[p.length - 1])) return NaN;
    for(let i = 0; i < p.length - 1; i++){
      if(x <= p[i] && x >= p[i + 1]){ if(p[i] === p[i + 1]) return y[i]; const f = (x - p[i]) / (p[i + 1] - p[i]); return y[i] + f * (y[i + 1] - y[i]); }
    }
    return NaN;
  };
  // درون‌یابی نسبت به ln p (مثل MetPy log_interpolate_1d)
  P.interpLog = function(x, p, y){
    if(!(x <= p[0] && x >= p[p.length - 1])) return NaN;
    const lx = Math.log(x);
    for(let i = 0; i < p.length - 1; i++){
      if(x <= p[i] && x >= p[i + 1]){ const a = Math.log(p[i]), b = Math.log(p[i + 1]); if(a === b) return y[i]; return y[i] + (lx - a) / (b - a) * (y[i + 1] - y[i]); }
    }
    return NaN;
  };
  // لایهٔ فشاری [bottom, bottom−depth]؛ interpolate=true مرزها را اضافه می‌کند (درون‌یابی لگاریتمی). خروجی نزولی.
  P.layer = function(prof, vars, bottom, depth, interpolate){
    const p = prof.p, pmax = p[0], pmin = p[p.length - 1];
    if(bottom == null) bottom = pmax;
    const top = bottom - depth, eps = 1e-6;
    if(bottom > pmax + eps || top < pmin - eps) return null;
    const idx = []; for(let i = 0; i < p.length; i++) if(p[i] <= bottom + eps && p[i] >= top - eps) idx.push(i);
    let ps = idx.map(i => p[i]);
    if(interpolate !== false){
      if(!ps.some(q => Math.abs(q - top) < eps)) ps.push(top);
      if(!ps.some(q => Math.abs(q - bottom) < eps)) ps.push(bottom);
      ps.sort((a, b) => b - a);
      const out = {p:ps}; for(const k of vars) out[k] = ps.map(q => P.interpLog(q, p, prof[k])); return out;
    }
    const out = {p:ps}; for(const k of vars) out[k] = idx.map(i => prof[k][i]); return out;
  };
  P.trapz = function(y, x){ let s = 0; for(let i = 0; i < x.length - 1; i++) s += (x[i + 1] - x[i]) * (y[i] + y[i + 1]) / 2; return s; };
  M.profile = P;
})();
/* ===== پارسل، LCL/LFC/EL، CAPE/CIN =====
   مرجع: MetPy metpy.calc.thermo (parcel_profile, lfc, el, cape_cin, mixed_parcel, most_unstable_parcel) — منطق عیناً بازنویسی شده
   (شامل رفتار شناخته‌شدهٔ MetPy: LCL/LFC روی دمای مجازی سنجیده می‌شوند)؛ اختلاف عددی مجاز با MetPy: CAPE/CIN ≤ ۱٪ یا ۵ J/kg.
   قرارداد: CAPE ≥ 0، CIN ≤ 0 (J/kg)؛ انتگرال Rd∫(Tv_parcel−Tv_env) d ln p بر پایهٔ ذوزنقه؛ دمای مجازی برای محیط از Td محیط.
   محدودیت: پارسل بدون اختلاط (entrainment)، آدیاباتیک برگشت‌پذیر مرطوب؛ بدون فاز یخ؛ پروفایل باید تا ≥ ۱۰۰ hPa نباشد ولی هرچه بالاتر، EL دقیق‌تر. */
(function(){
  "use strict";
  const M = globalThis.MET, C = M.C, T = M.thermo, PF = M.profile, Q = {};
  const isclose = (a, b) => Math.abs(a - b) <= 1e-8 + 1e-5 * Math.abs(b);
  const lessOrClose = (a, b) => a < b || isclose(a, b), greaterOrClose = (a, b) => a > b || isclose(a, b);
  const sgn = x => x > 0 ? 1 : x < 0 ? -1 : 0;
  // جدا کردن ردیف‌های NaN هم‌زمان (مثل _remove_nans)
  function rmNaN(){ const arrs = Array.from(arguments), n = arrs[0].length, keep = [];
    for(let i = 0; i < n; i++) if(arrs.every(a => !Number.isNaN(a[i]))) keep.push(i);
    return arrs.map(a => keep.map(i => a[i])); }
  // نقاط تقاطع دو منحنی (MetPy find_intersections). x بر حسب p (log_x=true)
  function intersections(x, a, b, direction, logx){
    const xs = logx ? x.map(Math.log) : x.slice(), n = xs.length, X = [], Y = [], S = [];
    const d = a.map((v, i) => v - b[i]);
    for(let i = 0; i < n - 1; i++){
      if(sgn(d[i + 1]) - sgn(d[i]) === 0) continue;
      const dy0 = d[i], dy1 = d[i + 1], x0 = xs[i], x1 = xs[i + 1];
      const ix = (dy1 * x0 - dy0 * x1) / (dy1 - dy0), iy = ((ix - x0) / (x1 - x0)) * (a[i + 1] - a[i]) + a[i];
      X.push(logx ? Math.exp(ix) : ix); Y.push(iy); S.push(sgn(d[i + 1]));
    }
    const dup = X.map((v, i) => i === X.length - 1 ? true : X[i + 1] !== v);
    const ox = [], oy = [];
    for(let i = 0; i < X.length; i++){
      if(!dup[i]) continue;
      if(direction === "increasing" && !(S[i] > 0)) continue;
      if(direction === "decreasing" && !(S[i] < 0)) continue;
      ox.push(X[i]); oy.push(Y[i]);
    }
    return [ox, oy];
  }
  // پروفایل پارسل از ردیف اول: خروجی {pLower,pLcl,pUpper,tLower,tLcl,tUpper}. p نزولی، T0/Td0 (K) دمای پارسل در p[0]
  function parcelHelper(p, T0, Td0){
    const L = T.lcl(p[0], T0, Td0); if(!L) return null;
    const pl = L.p, lower = p.filter(q => q >= pl); lower.push(pl);
    const tl = lower.map(q => T.dryLapse(q, T0, p[0]));
    if(greaterOrClose(Math.min.apply(null, p), pl)) return {pLower:lower.slice(0, -1), pLcl:pl, pUpper:[], tLower:tl.slice(0, -1), tLcl:L.Tk, tUpper:[]};
    const up = p.filter(q => q < pl);
    const tu = T.moistLapse(up, tl[tl.length - 1], pl);
    return {pLower:lower.slice(0, -1), pLcl:pl, pUpper:up, tLower:tl.slice(0, -1), tLcl:L.Tk, tUpper:tu};
  }
  function insertLcl(p, y, pl){ const v = PF.interpLin(pl, p, y); let loc = 0; while(loc < p.length && p[loc] >= pl) loc++; const o = y.slice(); o.splice(loc, 0, v); return o; }
  // پروفایل پارسل با LCL: ورودی پروفایل پاک‌شده یا {p,Tk,Tdk} با پارسل از ردیف اول
  Q.parcelProfileWithLcl = function(prof){
    const h = parcelHelper(prof.p, prof.Tk[0], prof.Tdk[0]); if(!h) return null;
    const p = h.pLower.concat([h.pLcl], h.pUpper), tp = h.tLower.concat([h.tLcl], h.tUpper);
    return {p:p, Tk:insertLcl(prof.p, prof.Tk, h.pLcl), Tdk:insertLcl(prof.p, prof.Tdk, h.pLcl), Tp:tp, pLcl:h.pLcl, tLcl:h.tLcl};
  };
  Q.parcelProfile = function(p, T0, Td0){ const h = parcelHelper(p, T0, Td0); return h ? h.tLower.concat(h.tUpper) : null; };
  function capeCinCore(p, Tk, Tdk, Tp, whichLfc, whichEl){
    [p, Tk, Tdk, Tp] = rmNaN(p, Tk, Tdk, Tp);
    const L0 = T.lcl(p[0], Tk[0], Tdk[0]); if(!L0) return null;
    const w0 = T.satMixingRatio(p[0], Tdk[0]);
    const w = p.map((q, i) => q > L0.p ? w0 : T.satMixingRatio(q, Tp[i]));
    const Tenv = p.map((q, i) => T.virtualTFromDewpoint(q, Tk[i], Tdk[i]));
    const Tpar = Tp.map((t, i) => T.virtualT(t, w[i]));
    const lf = lfcCore(p, Tenv, Tdk, Tpar, whichLfc);
    if(lf === null) return {cape:0, cin:0, lfc:null, el:null, lcl:{p:L0.p, Tk:L0.Tk}, why:"no_lfc"};
    const lfcP = lf.p;
    const e = elCore(p, Tenv, Tdk, Tpar, whichEl);
    const elP = e === null ? p[p.length - 1] : e.p;
    let y = Tpar.map((t, i) => t - Tenv[i]), x = p.slice();
    const cr = intersections(x.slice(1), y.slice(1), y.slice(1).map(() => 0), "all", true);
    x = x.concat(cr[0]); y = y.concat(cr[1]);
    const ord = x.map((v, i) => i).sort((a, b) => x[a] - x[b]); x = ord.map(i => x[i]); y = ord.map(i => y[i]);
    const keep = x.map((v, i) => i === x.length - 1 ? true : (x[i + 1] - v) > 1e-6); x = x.filter((v, i) => keep[i]); y = y.filter((v, i) => keep[i]);
    let xs = [], ys = [];
    for(let i = 0; i < x.length; i++) if(lessOrClose(x[i], lfcP) && greaterOrClose(x[i], elP)){ xs.push(Math.log(x[i])); ys.push(y[i]); }
    const cape = C.Rd * PF.trapz(ys, xs);
    xs = []; ys = [];
    for(let i = 0; i < x.length; i++) if(greaterOrClose(x[i], lfcP)){ xs.push(Math.log(x[i])); ys.push(y[i]); }
    let cin = C.Rd * PF.trapz(ys, xs); if(cin > 0) cin = 0;
    return {cape:cape, cin:cin, lfc:lf, el:e, lcl:{p:L0.p, Tk:L0.Tk}, why:null};
  }
  function lfcCore(p, T_, Td, Tp, which){
    [p, T_, Td, Tp] = rmNaN(p, T_, Td, Tp);
    const Ld = Td[0];
    const inc = isclose(Tp[0], T_[0]) ? intersections(p.slice(1), Tp.slice(1), T_.slice(1), "increasing", true) : intersections(p, Tp, T_, "increasing", true);
    const L = T.lcl(p[0], Tp[0], Ld);
    let x = inc[0], y = inc[1];
    if(!L) return null;
    if(x.length === 0){
      let all = true; for(let i = 0; i < p.length; i++) if(p[i] < L.p && !lessOrClose(Tp[i], T_[i])) { all = false; break; }
      return all ? null : {p:L.p, Tk:L.Tk};
    }
    const idx = x.map(v => v < L.p);
    if(!idx.some(Boolean)){
      const el = intersections(p.slice(1), Tp.slice(1), T_.slice(1), "decreasing", true)[0];
      if(el.length && Math.min.apply(null, el) > L.p) return null;
      return {p:L.p, Tk:L.Tk};
    }
    return multiple(x, y, idx, which, p, T_, Td, Tp, "LFC");
  }
  function elCore(p, T_, Td, Tp, which){
    [p, T_, Td, Tp] = rmNaN(p, T_, Td, Tp);
    if(Tp[Tp.length - 1] > T_[T_.length - 1]) return null;
    const r = intersections(p.slice(1), Tp.slice(1), T_.slice(1), "decreasing", true), x = r[0], y = r[1];
    const L = T.lcl(p[0], T_[0], Td[0]); if(!L) return null;
    if(x.length > 0 && x[x.length - 1] < L.p){ const idx = x.map(v => v < L.p); return multiple(x, y, idx, which, p, T_, Td, Tp, "EL"); }
    return null;
  }
  function multiple(xs, ys, idx, which, p, T_, Td, Tp, kind){
    const pl = xs.filter((v, i) => idx[i]), tl = ys.filter((v, i) => idx[i]);
    which = which || "top";
    if(which === "bottom") return {p:pl[0], Tk:tl[0]};
    if(which === "top") return {p:pl[pl.length - 1], Tk:tl[tl.length - 1]};
    if(which === "wide"){
      let lfcL, elL;
      if(kind === "LFC"){ lfcL = pl; elL = intersections(p.slice(1), Tp.slice(1), T_.slice(1), "decreasing", true)[0]; }
      else { elL = pl; lfcL = intersections(p, Tp, T_, "increasing", true)[0]; }
      const n = Math.min(lfcL.length, elL.length); let best = -Infinity, bi = 0;
      for(let i = 0; i < n; i++){ const d = lfcL[i] - elL[i]; if(d > best){ best = d; bi = i; } }
      return {p:pl[bi], Tk:tl[bi]};
    }
    if(which === "most_cape"){
      const combos = [["top","top"],["top","bottom"],["bottom","top"],["bottom","bottom"]]; let best = -Infinity, pick = combos[0];
      for(const c of combos){ const r = capeCinCore(p, T_, Td, Tp, c[0], c[1]); /* همان ترتیب MetPy: lfc سپس el */ if(r && r.cape > best){ best = r.cape; pick = c; } }
      const side = kind === "LFC" ? pick[0] : pick[1];
      return side === "top" ? {p:pl[pl.length - 1], Tk:tl[tl.length - 1]} : {p:pl[0], Tk:tl[0]};
    }
    return null;
  }
  Q.capeCinFromProfile = capeCinCore;
  // LFC و EL بر دمای واقعی (نه مجازی) — همان فراخوانی عمومی MetPy lfc()/el() با پارسل سطحی؛ LFC/EL داخل CAPE بر پایهٔ Tv هستند
  Q.lfcEl = function(prof, which){ const w = Q.parcelProfileWithLcl(prof); if(!w) return M.nil("lcl_failed");
    const l = lfcCore(w.p, w.Tk, w.Tdk, w.Tp, (which && which.lfc) || "top"), e = elCore(w.p, w.Tk, w.Tdk, w.Tp, (which && which.el) || "top");
    return M.ok(l ? l.p : null, {lfc:l, el:e, why: l ? null : "no_lfc"}); };
  // پارسل سطحی (SB)
  Q.sbCapeCin = function(prof, opts){ opts = opts || {};
    const w = Q.parcelProfileWithLcl(prof); if(!w) return M.nil("lcl_failed");
    const r = capeCinCore(w.p, w.Tk, w.Tdk, w.Tp, opts.whichLfc || "bottom", opts.whichEl || "top");
    return r ? Object.assign(M.ok(r.cape), {cin:r.cin, lfc:r.lfc, el:r.el, lcl:r.lcl, note:r.why, parcel:"SB"}) : M.nil("cape_failed"); };
  // پارسل مخلوط لایهٔ پایین ۱۰۰ hPa (ML): θ و r میانگین انتگرال‌گیری‌شده در فشار
  Q.mixedParcel = function(prof, depth){ depth = depth || 100;
    const th = prof.p.map((q, i) => T.theta(q, prof.Tk[i])), r = prof.p.map((q, i) => T.satMixingRatio(q, prof.Tdk[i]));
    const lay = PF.layer({p:prof.p, th:th, r:r}, ["th", "r"], null, depth, true); if(!lay) return null;
    const dp = Math.abs(lay.p[0] - lay.p[lay.p.length - 1]);
    const mth = PF.trapz(lay.th, lay.p) / -dp, mr = PF.trapz(lay.r, lay.p) / -dp;
    const p0 = prof.p[0], tk = mth * T.exner(p0), e = T.vaporPressure(p0, mr);
    return {p:p0, Tk:tk, Tdk:T.dewpointFromE(e)}; };
  Q.mlCapeCin = function(prof, opts){ opts = opts || {}; const depth = opts.depth || 100;
    const mp = Q.mixedParcel(prof, depth); if(!mp) return M.nil("layer_outside_profile");
    const p0 = prof.p[0], sel = prof.p.map((q, i) => i).filter(i => prof.p[i] < p0 - depth);
    const pp = [mp.p].concat(sel.map(i => prof.p[i])), tt = [mp.Tk].concat(sel.map(i => prof.Tk[i])), dd = [mp.Tdk].concat(sel.map(i => prof.Tdk[i]));
    const w = Q.parcelProfileWithLcl({p:pp, Tk:tt, Tdk:dd}); if(!w) return M.nil("lcl_failed");
    const r = capeCinCore(w.p, w.Tk, w.Tdk, w.Tp, opts.whichLfc || "bottom", opts.whichEl || "top");
    return r ? Object.assign(M.ok(r.cape), {cin:r.cin, lfc:r.lfc, el:r.el, lcl:r.lcl, note:r.why, parcel:"ML"}) : M.nil("cape_failed"); };
  // پارسل ناپایدارترین (MU): بیشینهٔ θe در ۳۰۰ hPa پایینی
  Q.muCapeCin = function(prof, opts){ opts = opts || {}; const depth = opts.depth || 300;
    const lay = PF.layer(prof, ["Tk", "Tdk"], null, depth, false); if(!lay || !lay.p.length) return M.nil("layer_outside_profile");
    let bi = 0, best = -Infinity;
    for(let i = 0; i < lay.p.length; i++){ const te = T.thetaE(lay.p[i], lay.Tk[i], lay.Tdk[i]); if(te > best){ best = te; bi = i; } }
    const start = prof.p.indexOf(lay.p[bi]);
    const sub = {p:prof.p.slice(start), Tk:prof.Tk.slice(start), Tdk:prof.Tdk.slice(start)};
    const w = Q.parcelProfileWithLcl(sub); if(!w) return M.nil("lcl_failed");
    const r = capeCinCore(w.p, w.Tk, w.Tdk, w.Tp, opts.whichLfc || "bottom", opts.whichEl || "top");
    return r ? Object.assign(M.ok(r.cape), {cin:r.cin, lfc:r.lfc, el:r.el, lcl:r.lcl, note:r.why, parcel:"MU", startP:lay.p[bi]}) : M.nil("cape_failed"); };
  M.parcel = Q;
})();
/* ===== شاخص‌های ناپایداری (فاز ۱) =====
   مرجع: MetPy thermo/indices. هر تابع {v, why} برمی‌گرداند؛ مقدار مفقود هرگز صفر نمی‌شود.
   سطوح ۸۵۰/۷۰۰/۵۰۰ hPa باید در بازهٔ پروفایل باشند (درون‌یابی خطی در p، مثل MetPy)؛ در ایران مرتفع سطح ۸۵۰ ممکن است زیر زمین باشد ⇒ why="level_below_ground_850". */
(function(){
  "use strict";
  const M = globalThis.MET, C = M.C, T = M.thermo, PF = M.profile, I = {};
  function at(prof, lev, key){ return PF.interpLin(lev, prof.p, prof[key]); }
  function need(prof, levels){ for(const l of levels){ if(!(l <= prof.p[0] + 1e-9)) return "level_below_ground_" + l; if(!(l >= prof.p[prof.p.length - 1] - 1e-9)) return "level_above_profile_top_" + l; } return null; }
  I.kIndex = function(prof){ const w = need(prof, [850, 700, 500]); if(w) return M.nil(w);
    const t850 = at(prof, 850, "Tk"), t700 = at(prof, 700, "Tk"), t500 = at(prof, 500, "Tk"), d850 = at(prof, 850, "Tdk"), d700 = at(prof, 700, "Tdk");
    return M.ok((t850 - t500) + (d850 - C.zeroC) - (t700 - d700)); };      // Td850 مطلق (°C)؛ سایر جمله‌ها اختلاف
  I.verticalTotals = function(prof){ const w = need(prof, [850, 500]); if(w) return M.nil(w); return M.ok(at(prof, 850, "Tk") - at(prof, 500, "Tk")); };
  I.crossTotals = function(prof){ const w = need(prof, [850, 500]); if(w) return M.nil(w); return M.ok(at(prof, 850, "Tdk") - at(prof, 500, "Tk")); };
  I.totalTotals = function(prof){ const w = need(prof, [850, 500]); if(w) return M.nil(w); return M.ok((at(prof, 850, "Tk") - at(prof, 500, "Tk")) + (at(prof, 850, "Tdk") - at(prof, 500, "Tk"))); };
  // شاخص بالابری LI = T500(محیط) − T500(پارسل سطحی)؛ بدون اصلاح دمای مجازی (مثل MetPy). منفی = ناپایدار
  I.liftedIndex = function(prof){ const w = need(prof, [500]); if(w) return M.nil(w);
    const tp = M.parcel.parcelProfile(prof.p, prof.Tk[0], prof.Tdk[0]); if(!tp) return M.nil("lcl_failed");
    return M.ok(PF.interpLin(500, prof.p, prof.Tk) - PF.interpLin(500, prof.p, tp)); };
  // شوالتر: پارسل از ۸۵۰ hPa تا ۵۰۰ (T500 − Tparcel)
  I.showalter = function(prof){ const w = need(prof, [850, 500]); if(w) return M.nil(w);
    const t850 = at(prof, 850, "Tk"), d850 = at(prof, 850, "Tdk"), t500 = at(prof, 500, "Tk");
    const tp = M.parcel.parcelProfile([850, 500], t850, d850); if(!tp) return M.nil("lcl_failed");
    return M.ok(t500 - tp[tp.length - 1]); };
  // آب قابل بارش (mm): −(1/(g ρw)) ∫ r dp ، r از Td اشباع؛ لایهٔ پیش‌فرض: کل پروفایل. لایهٔ ناقص ⇒ null
  I.pwat = function(prof, bottom, top){
    const pmax = prof.p[0], pmin = prof.p[prof.p.length - 1];
    bottom = bottom == null ? pmax : bottom; top = top == null ? pmin : top;
    if(bottom > pmax + 1e-9 || top < pmin - 1e-9 || top >= bottom) return M.nil("layer_outside_profile");
    const lay = PF.layer({p:prof.p, Tdk:prof.Tdk}, ["Tdk"], bottom, bottom - top, true); if(!lay) return M.nil("layer_outside_profile");
    const w = lay.p.map((q, i) => T.mixingRatio(T.es(lay.Tdk[i]), q));
    if(w.some(x => !isFinite(x))) return M.nil("nonfinite_mixing_ratio");
    return M.ok(-PF.trapz(w, lay.p) * 100 / (C.g * C.rhoL) * 1000, {unit:"mm"}); };  // hPa→Pa ×100 ؛ m→mm ×1000
  M.indices = I;
})();
/* ===== باد: برش، میانگین، حرکت توفان Bunkers، SRH، زاویهٔ بحرانی، دادهٔ هودوگراف (فاز ۲) =====
   مرجع: MetPy indices.bulk_shear / bunkers_storm_motion / critical_angle، kinematics.storm_relative_helicity؛ Bunkers et al. 2000 (Wea. Forecasting)؛ Davies-Jones et al. 1990 (SRH).
   قرارداد: باد m/s؛ جهت «از» (meteorological) درجه؛ ارتفاع z متر از سطح دریا (ژئوپتانسیل)، ارتفاع‌های لایه AGL نسبت به پایین‌ترین ردیف معتبر.
   نیمکرهٔ شمالی: توفان راست‌گرد Bunkers = میانگین باد ۰–۶ km + ۷٫۵ m/s عمود (راست) بر برش ۵٫۵–۶ km منهای ۰–۰٫۵ km.
   داده‌ی ناکافی: ردیف بدون u,v,z نادیده؛ اگر لایه از بالای پروفایل بیرون زند ⇒ null (why=layer_exceeds_profile_top). */
(function(){
  "use strict";
  const M = globalThis.MET, PF = M.profile, W = {};
  const fin = x => typeof x === "number" && isFinite(x);
  const isclose = (a, b) => Math.abs(a - b) <= 1e-8 + 1e-5 * Math.abs(b);
  W.KT = 0.514444444444;     // m/s در هر گره (دقیق: 1852/3600)
  W.components = function(speed, dirDeg){ const r = dirDeg * Math.PI / 180; return {u: -speed * Math.sin(r), v: -speed * Math.cos(r)}; };
  W.direction = function(u, v){ if(u === 0 && v === 0) return 0; let d = 90 - Math.atan2(-v, -u) * 180 / Math.PI; d = ((d % 360) + 360) % 360; return d <= 0 ? d + 360 : d; };
  W.speed = (u, v) => Math.hypot(u, v);
  // پروفیل باد: ردیف‌هایی که p,z,u,v همه معتبرند؛ p نزولی. خروجی {p,z,u,v,zAgl}
  W.windProfile = function(prof){
    const idx = []; for(let i = 0; i < prof.p.length; i++) if(fin(prof.p[i]) && fin(prof.z && prof.z[i]) && fin(prof.u && prof.u[i]) && fin(prof.v && prof.v[i])) idx.push(i);
    if(idx.length < 3) return null;
    const o = {p: idx.map(i => prof.p[i]), z: idx.map(i => prof.z[i]), u: idx.map(i => prof.u[i]), v: idx.map(i => prof.v[i])};
    for(let i = 1; i < o.z.length; i++) if(!(o.z[i] > o.z[i - 1])) return null;     // ارتفاع باید اکیداً صعودی باشد
    o.zAgl = o.z.map(z => z - o.z[0]); return o;
  };
  const interpZ = (x, z, y) => { if(x < z[0] - 1e-9 || x > z[z.length - 1] + 1e-9) return NaN; for(let i = 0; i < z.length - 1; i++) if(x >= z[i] && x <= z[i + 1]){ const f = (x - z[i]) / (z[i + 1] - z[i]); return y[i] + f * (y[i + 1] - y[i]); } return NaN; };
  const pAtZ = (zq, w) => interpZ(zq, w.z, w.p);                           // np.interp(height → pressure)
  // لایه با کران ارتفاعی (مثل MetPy get_layer با height): بازهٔ فشاری معادل، مرزها با درون‌یابی لگاریتمی
  function layerP(w, bottomAgl, depth){
    const zb = w.z[0] + bottomAgl, zt = zb + depth;
    if(zt > w.z[w.z.length - 1] + 1e-9) return null;
    const pb = bottomAgl === 0 ? w.p[0] : pAtZ(zb, w), pt = pAtZ(zt, w);
    if(!fin(pb) || !fin(pt)) return null;
    let ps = w.p.filter(q => q <= pb + 1e-9 && q >= pt - 1e-9);
    if(!ps.some(q => isclose(pt, q))) ps.push(pt);
    if(!ps.some(q => isclose(pb, q))) ps.push(pb);
    ps.sort((a, b) => b - a);
    return {p: ps, u: ps.map(q => PF.interpLog(q, w.p, w.u)), v: ps.map(q => PF.interpLog(q, w.p, w.v))};
  }
  const meanW = function(w, bottomAgl, depth){ const L = layerP(w, bottomAgl, depth); if(!L) return null;
    const dp = L.p[L.p.length - 1] - L.p[0]; return {u: PF.trapz(L.u, L.p) / dp, v: PF.trapz(L.v, L.p) / dp}; };
  // برش بردار بین بالا و پایین لایه (لایه با پایه/ضخامت بر حسب متر AGL)
  W.bulkShear = function(prof, bottom, depth){
    const w = W.windProfile(prof); if(!w) return M.nil("insufficient_wind_levels");
    const L = layerP(w, bottom || 0, depth); if(!L) return M.nil("layer_exceeds_profile_top");
    const du = L.u[L.u.length - 1] - L.u[0], dv = L.v[L.v.length - 1] - L.v[0];
    return M.ok(Math.hypot(du, dv), {du: du, dv: dv, unit: "m/s"}); };
  W.bunkers = function(prof){
    const w = W.windProfile(prof); if(!w) return M.nil("insufficient_wind_levels");
    const mean = meanW(w, 0, 6000), w05 = meanW(w, 0, 500), w55 = meanW(w, 5500, 500);
    if(!mean || !w05 || !w55) return M.nil("layer_exceeds_profile_top");
    const sh = {u: w55.u - w05.u, v: w55.v - w05.v}, mag = Math.hypot(sh.u, sh.v);
    if(!(mag > 0)) return M.nil("zero_shear");
    const dev = {u: sh.v * (7.5 / mag), v: -sh.u * (7.5 / mag)};
    return M.ok(null, {right: {u: mean.u + dev.u, v: mean.v + dev.v}, left: {u: mean.u - dev.u, v: mean.v - dev.v}, mean: mean, unit: "m/s"}); };
  // SRH: لایهٔ [bottom, bottom+depth] متر AGL؛ حرکت توفان (m/s) پیش‌فرض صفر؛ خروجی مثبت، منفی، کل (m²/s²)
  W.srh = function(prof, depth, storm, bottom){
    const w = W.windProfile(prof); if(!w) return M.nil("insufficient_wind_levels");
    bottom = bottom || 0; const top = bottom + depth;
    if(top > w.zAgl[w.zAgl.length - 1] + 1e-9) return M.nil("layer_exceeds_profile_top");
    const zs = w.zAgl.filter(z => z >= bottom - 1e-9 && z <= top + 1e-9);
    if(!zs.some(z => z === top)) zs.push(top);
    if(!zs.some(z => z === bottom)) zs.push(bottom);
    zs.sort((a, b) => a - b);
    const su = storm ? storm.u : 0, sv = storm ? storm.v : 0;
    const u = zs.map(z => interpZ(z, w.zAgl, w.u) - su), v = zs.map(z => interpZ(z, w.zAgl, w.v) - sv);
    let pos = 0, neg = 0;
    for(let i = 0; i < zs.length - 1; i++){ const t = u[i + 1] * v[i] - u[i] * v[i + 1]; if(t > 0) pos += t; else if(t < 0) neg += t; }
    return M.ok(pos + neg, {pos: pos, neg: neg, unit: "m2/s2"}); };
  // زاویهٔ بحرانی (°): میان بردار برش ۰–۵۰۰ m و بردار «باد سطح → حرکت توفان» (Esterheld & Giuliano 2008)
  W.criticalAngle = function(prof, storm){
    const w = W.windProfile(prof); if(!w) return M.nil("insufficient_wind_levels");
    const L = layerP(w, 0, 500); if(!L) return M.nil("layer_exceeds_profile_top");
    const shr = {u: L.u[L.u.length - 1] - L.u[0], v: L.v[L.v.length - 1] - L.v[0]}, sm = {u: storm.u - w.u[0], v: storm.v - w.v[0]};
    const n = Math.hypot(shr.u, shr.v) * Math.hypot(sm.u, sm.v); if(!(n > 0)) return M.nil("zero_vector");
    return M.ok(Math.acos(Math.max(-1, Math.min(1, (shr.u * sm.u + shr.v * sm.v) / n))) * 180 / Math.PI, {unit: "deg"}); };
  // دادهٔ هودوگراف: نقاط (u,v) هر پروفیل تا maxH متر AGL + نشانگر هر کیلومتر
  W.hodograph = function(prof, maxH){
    const w = W.windProfile(prof); if(!w) return M.nil("insufficient_wind_levels"); maxH = maxH || 10000;
    if(maxH > w.zAgl[w.zAgl.length - 1]) maxH = w.zAgl[w.zAgl.length - 1];
    const pts = []; for(let i = 0; i < w.zAgl.length; i++) if(w.zAgl[i] <= maxH) pts.push({z: w.zAgl[i], u: w.u[i], v: w.v[i]});
    const marks = []; for(let km = 1; km * 1000 <= maxH; km++) marks.push({km: km, u: interpZ(km * 1000, w.zAgl, w.u), v: interpZ(km * 1000, w.zAgl, w.v)});
    return M.ok(pts.length, {points: pts, marks: marks}); };
  M.wind = W;
})();
/* ===== کارگاه خشکسالی و تغییر اقلیم — هستهٔ علمی (بدون DOM؛ در Node هم آزموده می‌شود) =====
   روش‌ها (بازنویسی مستقل از فرمول‌های منتشرشده؛ هیچ کدی از پروژه‌های AGPL/بی‌مجوز کپی نشده است):
   • SPI: McKee, Doesken & Kleist (1993)؛ برازش گاما به روش Thom (۱۹۵۸) با جرم صفر (Edwards & McKee 1997).
   • SPEI: Vicente-Serrano, Beguería & López-Moreno (2010)؛ لوگ‌لجستیک سه‌پارامتری با گشتاورهای وزنی احتمالی (Singh 1993).
   • ET0 هارگریوز–سامانی (۱۹۸۵) و تورنت‌وایت (۱۹۴۸)؛ تابش فرازمینی Ra از FAO-56 (Allen و همکاران ۱۹۹۸، معادلهٔ ۲۱).
   • رخداد خشکسالی: نظریهٔ ران‌ها (Yevjevich 1967؛ McKee 1993): آغاز با شاخص ≤ آستانهٔ آغاز، پایان با شاخص > آستانهٔ پایان.
   • SDF: بیشینهٔ سالانهٔ کمبود تجمعی برای مدت‌های مختلف + گامبل با گشتاورهای L (Hosking 1990).
   قراردادها: سری ماهانه با نمایه ۰ = ماه ۱ سال آغاز؛ مقدار مفقود NaN؛ هرگز با صفر پر نمی‌شود. ماه‌ها شمسی‌اند (همان پایگاه اطلس). */
(function(root){
  "use strict";
  const MET = root.MET = root.MET || {}, D = MET.dr = {};
  const fin = x => typeof x === "number" && isFinite(x);
  /* ---------- توابع ویژه ---------- */
  const G = [0.99999999999980993, 676.5203681218851, -1259.1392167224028, 771.32342877765313, -176.61502916214059, 12.507343278686905, -0.13857109526572012, 9.9843695780195716e-6, 1.5056327351493116e-7];
  function lgamma(z){ if(z < 0.5) return Math.log(Math.PI / Math.abs(Math.sin(Math.PI * z))) - lgamma(1 - z);
    z -= 1; let a = G[0]; const t = z + 7.5; for(let i = 1; i < 9; i++) a += G[i] / (z + i); return 0.5 * Math.log(2 * Math.PI) + (z + 0.5) * Math.log(t) - t + Math.log(a); }
  const gamma = z => (z < 0.5 ? Math.PI / (Math.sin(Math.PI * z) * gamma(1 - z)) : Math.exp(lgamma(z)));
  function gammaPQ(a, x){ // [P, Q] تابع گامای ناقص تنظیم‌شده (Numerical Recipes: سری / کسر مسلسل)
    if(!(x > 0)) return [0, 1]; if(!(a > 0)) return [NaN, NaN]; const lg = lgamma(a);
    if(x < a + 1){ let ap = a, sum = 1 / a, del = sum; for(let n = 0; n < 1000; n++){ ap += 1; del *= x / ap; sum += del; if(Math.abs(del) < Math.abs(sum) * 1e-16) break; } const P = sum * Math.exp(-x + a * Math.log(x) - lg); return [P, 1 - P]; }
    let b = x + 1 - a, c = 1e300, d = 1 / b, h = d; for(let i = 1; i < 1000; i++){ const an = -i * (i - a); b += 2; d = an * d + b; if(Math.abs(d) < 1e-300) d = 1e-300; c = b + an / c; if(Math.abs(c) < 1e-300) c = 1e-300; d = 1 / d; const del = d * c; h *= del; if(Math.abs(del - 1) < 1e-16) break; }
    const Q = Math.exp(-x + a * Math.log(x) - lg) * h; return [1 - Q, Q]; }
  const gammaP = (a, x) => gammaPQ(a, x)[0];
  function erfc(x){ const z = Math.abs(x), q = gammaPQ(0.5, z * z)[1]; return x >= 0 ? q : 2 - q; }   // erfc(x) = Q(½, x²)
  const normCdf = z => 0.5 * erfc(-z / Math.SQRT2);
  function normInv(p){ // Acklam + یک گام هالی ⇒ دقت ~1e-15
    if(!(p > 0 && p < 1)) return p === 0 ? -Infinity : p === 1 ? Infinity : NaN;
    const a = [-3.969683028665376e+01, 2.209460984245205e+02, -2.759285104469687e+02, 1.383577518672690e+02, -3.066479806614716e+01, 2.506628277459239e+00],
      b = [-5.447609879822406e+01, 1.615858368580409e+02, -1.556989798598866e+02, 6.680131188771972e+01, -1.328068155288572e+01],
      c = [-7.784894002430293e-03, -3.223964580411365e-01, -2.400758277161838e+00, -2.549732539343734e+00, 4.374664141464968e+00, 2.938163982698783e+00],
      d = [7.784695709041462e-03, 3.224671290700398e-01, 2.445134137142996e+00, 3.754408661907416e+00]; let x;
    if(p < 0.02425){ const q = Math.sqrt(-2 * Math.log(p)); x = (((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) / ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1); }
    else if(p > 1 - 0.02425){ const q = Math.sqrt(-2 * Math.log(1 - p)); x = -(((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) / ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1); }
    else { const q = p - 0.5, r = q * q; x = (((((a[0] * r + a[1]) * r + a[2]) * r + a[3]) * r + a[4]) * r + a[5]) * q / (((((b[0] * r + b[1]) * r + b[2]) * r + b[3]) * r + b[4]) * r + 1); }
    const e = normCdf(x) - p, u = e * Math.sqrt(2 * Math.PI) * Math.exp(x * x / 2); return x - u / (1 + x * u / 2); }
  D.sp = {lgamma, gamma, gammaP, gammaPQ, erfc, normCdf, normInv};
  const ZMAX = 3.09;   // برش احتمال به [0٫001, 0٫999] مانند پیاده‌سازی‌های مرجع SPI/SPEI
  const zOf = p => { if(!fin(p)) return NaN; const q = Math.min(0.999, Math.max(0.001, p)); return normInv(q); };

  /* ---------- برازش‌ها ---------- */
  D.fitGamma = function(x){ // x: مقادیر مثبت (جرم صفر جدا شمرده می‌شود)
    const pos = x.filter(v => v > 0), n = x.length; if(pos.length < 10) return null;
    const m = pos.reduce((s, v) => s + v, 0) / pos.length, lm = pos.reduce((s, v) => s + Math.log(v), 0) / pos.length, A = Math.log(m) - lm; if(!(A > 0)) return null;
    const alpha = (1 + Math.sqrt(1 + 4 * A / 3)) / (4 * A); return {alpha, beta: m / alpha, q: (n - pos.length) / n}; };
  D.cdfGamma = (f, v) => f.q + (1 - f.q) * (v > 0 ? gammaP(f.alpha, v / f.beta) : 0);
  D.fitLogLogistic = function(x){ // گشتاورهای وزنی احتمالی ناریب w_s = E[x(1−F)^s] (Landwehr و همکاران ۱۹۷۹؛ Singh 1993)
    const n = x.length; if(n < 15) return null; const s = x.slice().sort((a, b) => a - b); let w0 = 0, w1 = 0, w2 = 0;
    for(let i = 0; i < n; i++){ const j = i + 1; w0 += s[i]; w1 += s[i] * (n - j) / (n - 1); w2 += s[i] * (n - j) * (n - j - 1) / ((n - 1) * (n - 2)); }
    w0 /= n; w1 /= n; w2 /= n;
    const beta = (2 * w1 - w0) / (6 * w1 - w0 - 6 * w2), g1 = gamma(1 + 1 / beta), g2 = gamma(1 - 1 / beta);
    const alpha = (w0 - 2 * w1) * beta / (g1 * g2), gam = w0 - alpha * g1 * g2; if(!(alpha > 0) || !fin(beta) || !fin(gam) || beta <= 1) return null; return {alpha, beta, gamma: gam}; };
  D.cdfLogLogistic = (f, v) => { const t = (f.alpha) / (v - f.gamma); return (v - f.gamma) > 0 ? 1 / (1 + Math.pow(t, f.beta)) : 0.0000001; };

  /* ---------- تبخیر–تعرق مرجع ---------- */
  const MD = [31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29];                 // روزهای ماه شمسی (اسفند ۲۹؛ کبیسه نادیده)
  const MID = [95, 126, 157, 188, 219, 250, 281, 311, 341, 6, 36, 66];        // روز میلادی سال (DOY) میانهٔ هر ماه شمسی
  D.daysInMonth = (m, jy) => m === 12 ? (D.isLeapJ(jy) ? 30 : 29) : MD[m - 1];
  D.isLeapJ = jy => [1, 5, 9, 13, 17, 22, 26, 30].indexOf(((jy % 33) + 33) % 33) >= 0;
  D.midDoy = m => MID[m - 1];
  D.Ra = function(latDeg, doy){ // MJ m⁻² day⁻¹ (FAO-56، معادلهٔ ۲۱)
    const phi = latDeg * Math.PI / 180, dr = 1 + 0.033 * Math.cos(2 * Math.PI * doy / 365), dec = 0.409 * Math.sin(2 * Math.PI * doy / 365 - 1.39);
    const ws = Math.acos(Math.max(-1, Math.min(1, -Math.tan(phi) * Math.tan(dec))));
    return 24 * 60 / Math.PI * 0.0820 * dr * (ws * Math.sin(phi) * Math.sin(dec) + Math.cos(phi) * Math.cos(dec) * Math.sin(ws)); };
  D.hargreaves = function(tmax, tmin, latDeg, m, days){ // mm/ماه
    if(!fin(tmax) || !fin(tmin) || tmax < tmin) return NaN; const tm = (tmax + tmin) / 2, ra = D.Ra(latDeg, MID[m - 1]) * 0.408;
    return Math.max(0, 0.0023 * ra * (tm + 17.8) * Math.sqrt(tmax - tmin)) * days; };
  D.dayLength = function(latDeg, doy){ const phi = latDeg * Math.PI / 180, dec = 0.409 * Math.sin(2 * Math.PI * doy / 365 - 1.39); return 24 / Math.PI * Math.acos(Math.max(-1, Math.min(1, -Math.tan(phi) * Math.tan(dec)))); };
  D.thornthwaiteClim = function(tClim12, latDeg){ // tClim12: میانگین بلندمدت دمای ۱۲ ماه (°C) ⇒ تابع (T,m,days)
    let I = 0; for(const t of tClim12) if(fin(t) && t > 0) I += Math.pow(t / 5, 1.514); if(!(I > 0)) return null;
    const a = 6.75e-7 * I ** 3 - 7.71e-5 * I ** 2 + 1.792e-2 * I + 0.49239;
    return (T, m, days) => { if(!fin(T)) return NaN; if(T <= 0) return 0; const N = D.dayLength(latDeg, MID[m - 1]);
      const e = T < 26.5 ? 16 * Math.pow(10 * T / I, a) : -415.85 + 32.24 * T - 0.43 * T * T; return Math.max(0, e * (N / 12) * (days / 30)); }; };

  /* ---------- شاخص استاندارد (SPI/SPEI) ---------- */
  D.accumulate = function(x, k){ const o = new Float64Array(x.length).fill(NaN); for(let t = k - 1; t < x.length; t++){ let s = 0, ok = true; for(let j = 0; j < k; j++){ const v = x[t - j]; if(!fin(v)){ ok = false; break; } s += v; } if(ok) o[t] = s; } return o; };
  /* series: ماهانه؛ opts: {scale، method:"spi"|"spei"، ref:[سال‌نمایهٔ آغاز، پایان] (شامل)، minYears} ⇒ {z, fits, nref} */
  D.standardize = function(series, opts){
    const k = opts.scale || 1, meth = opts.method || "spi", n = series.length, acc = D.accumulate(series, k), z = new Float64Array(n).fill(NaN), fits = new Array(12).fill(null);
    const y0 = opts.ref ? opts.ref[0] : 0, y1 = opts.ref ? opts.ref[1] : Math.floor((n - 1) / 12), minY = opts.minYears || 20, nref = new Array(12).fill(0);
    for(let m = 0; m < 12; m++){
      const ref = []; for(let y = y0; y <= y1; y++){ const t = y * 12 + m; if(t >= 0 && t < n && fin(acc[t])) ref.push(acc[t]); } nref[m] = ref.length; if(ref.length < minY) continue;
      const f = meth === "spei" ? D.fitLogLogistic(ref) : D.fitGamma(ref); fits[m] = f; if(!f) continue;
      for(let t = m; t < n; t += 12){ const v = acc[t]; if(!fin(v)) continue; const p = meth === "spei" ? D.cdfLogLogistic(f, v) : D.cdfGamma(f, v); z[t] = zOf(p); } }
    return {z, fits, nref}; };
  D.SPI_CLASSES = [[2, "extremely_wet", "بسیار شدید تر", "Extremely wet"], [1.5, "very_wet", "خیلی تر", "Very wet"], [1, "moderately_wet", "نسبتاً تر", "Moderately wet"], [-1, "normal", "نزدیک نرمال", "Near normal"],
    [-1.5, "moderate_dry", "خشکی متوسط", "Moderately dry"], [-2, "severe_dry", "خشکی شدید", "Severely dry"], [-Infinity, "extreme_dry", "خشکی بسیار شدید", "Extremely dry"]];
  D.classOf = function(z){ if(!fin(z)) return null; if(z >= 2) return D.SPI_CLASSES[0]; if(z >= 1.5) return D.SPI_CLASSES[1]; if(z >= 1) return D.SPI_CLASSES[2]; if(z > -1) return D.SPI_CLASSES[3]; if(z > -1.5) return D.SPI_CLASSES[4]; if(z > -2) return D.SPI_CLASSES[5]; return D.SPI_CLASSES[6]; };

  /* ---------- رخدادهای خشکسالی (نظریهٔ ران‌ها) ---------- */
  D.events = function(z, o){ o = o || {}; const on = o.onset != null ? o.onset : -1, off = o.end != null ? o.end : 0, minDur = o.minDur || 1, ev = []; let cur = null;
    for(let t = 0; t < z.length; t++){ const v = z[t];
      if(!fin(v)){ if(cur){ cur.cut = true; ev.push(cur); cur = null; } continue; }
      if(!cur){ if(v <= on) cur = {start: t, end: t, sev: -v, peak: v, tPeak: t, n: 1, cut: false}; }
      else if(v > off){ ev.push(cur); cur = null; }
      else { cur.end = t; cur.n++; cur.sev += -v; if(v < cur.peak){ cur.peak = v; cur.tPeak = t; } } }
    if(cur){ cur.open = true; ev.push(cur); }
    return ev.filter(e => e.n >= minDur).map(e => Object.assign(e, {dur: e.end - e.start + 1, intensity: e.sev / e.n})); };

  /* ---------- شدت–مدت–بسامد (SDF) ---------- */
  D.gumbelFitL = function(x){ const n = x.length; if(n < 8) return null; const s = x.slice().sort((a, b) => a - b); let b0 = 0, b1 = 0; for(let i = 0; i < n; i++){ b0 += s[i]; b1 += s[i] * i / (n - 1); } b0 /= n; b1 /= n;
    const l1 = b0, l2 = 2 * b1 - b0, alpha = l2 / Math.LN2; if(!(alpha > 0)) return null; return {xi: l1 - 0.5772156649 * alpha, alpha}; };
  D.gumbelQ = (f, T) => f.xi - f.alpha * Math.log(-Math.log(1 - 1 / T));
  /* z: SPI یا SPEI یک‌ماهه (ماهانه)؛ مدت‌ها به ماه؛ برمی‌گرداند {durs, T, table[مدت][T] , n} و سری بیشینهٔ سالانه */
  D.sdf = function(z, durs, Ts){ durs = durs || [1, 3, 6, 12, 24]; Ts = Ts || [2, 5, 10, 25, 50]; const ny = Math.floor(z.length / 12), res = {durs, T: Ts, table: [], annual: [], n: []};
    for(const d of durs){ const ann = [];
      for(let y = 0; y < ny; y++){ let best = NaN; for(let t = y * 12; t < y * 12 + 12; t++){ if(t - d + 1 < 0) continue; let s = 0, ok = true; for(let j = 0; j < d; j++){ const v = z[t - j]; if(!fin(v)){ ok = false; break; } s += Math.max(0, -v); } if(ok && (!(best >= 0) || s > best)) best = s; } if(fin(best)) ann.push(best); }
      res.annual.push(ann); res.n.push(ann.length); const f = D.gumbelFitL(ann); res.table.push(f ? Ts.map(T => D.gumbelQ(f, T)) : Ts.map(() => null)); }
    return res; };

  /* ---------- ناحیه‌ای ---------- */
  D.areaFraction = function(zs, thr){ // zs: آرایهٔ سری‌های ایستگاهی هم‌طول؛ سهم ایستگاه‌های با z ≤ thr در هر ماه (فقط ایستگاه‌های دارای داده)
    const n = zs.length ? zs[0].length : 0, o = new Float64Array(n).fill(NaN), cnt = new Int32Array(n);
    for(let t = 0; t < n; t++){ let a = 0, b = 0; for(const z of zs){ const v = z[t]; if(fin(v)){ b++; if(v <= thr) a++; } } cnt[t] = b; if(b >= 5) o[t] = a / b; } return {frac: o, n: cnt}; };

  /* ---------- روند و تغییر (برای فاز تغییر اقلیم و آمار خشکسالی) ---------- */
  D.sen = function(xs, ys){ const sl = []; for(let i = 0; i < xs.length; i++) for(let j = i + 1; j < xs.length; j++) if(xs[j] !== xs[i] && fin(ys[i]) && fin(ys[j])) sl.push((ys[j] - ys[i]) / (xs[j] - xs[i]));
    if(sl.length < 3) return null; sl.sort((a, b) => a - b); const m = sl.length >> 1, slope = sl.length % 2 ? sl[m] : (sl[m - 1] + sl[m]) / 2, r = ys.filter(fin).map((y, i) => y - slope * xs[i]).sort((a, b) => a - b); return {slope, icpt: r[r.length >> 1]}; };
  D.mannKendall = function(y){ const v = y.filter(fin), n = v.length; if(n < 8) return null; let S = 0; for(let i = 0; i < n - 1; i++) for(let j = i + 1; j < n; j++) S += Math.sign(v[j] - v[i]);
    const tie = {}; v.forEach(a => tie[a] = (tie[a] || 0) + 1); let tt = 0; for(const k in tie){ const t = tie[k]; if(t > 1) tt += t * (t - 1) * (2 * t + 5); }
    const vr = (n * (n - 1) * (2 * n + 5) - tt) / 18, Z = S > 0 ? (S - 1) / Math.sqrt(vr) : S < 0 ? (S + 1) / Math.sqrt(vr) : 0; return {S, Z, p: 2 * (1 - normCdf(Math.abs(Z))), n}; };

  /* ---------- تغییر اقلیم مشاهده‌ای (فاز ۲) ---------- */
  D.senCI = function(xs, ys, alpha){ // بازهٔ اطمینان شیب سن؛ همان روش scipy.stats.theilslopes (با اصلاح گره‌ها در y)
    const sl = [], n = ys.filter(fin).length; for(let i = 0; i < xs.length; i++) for(let j = i + 1; j < xs.length; j++) if(xs[j] !== xs[i] && fin(ys[i]) && fin(ys[j])) sl.push((ys[j] - ys[i]) / (xs[j] - xs[i]));
    if(sl.length < 3) return null; sl.sort((a, b) => a - b); const nt = sl.length, tie = {}; ys.filter(fin).forEach(a => tie[a] = (tie[a] || 0) + 1); let tt = 0; for(const k in tie){ const t = tie[k]; if(t > 1) tt += t * (t - 1) * (2 * t + 5); }
    const sig = Math.sqrt((n * (n - 1) * (2 * n + 5) - tt) / 18), z = normInv(1 - (alpha || 0.05) / 2), Rh = Math.min(Math.round((nt + z * sig) / 2), nt - 1), Rl = Math.max(Math.round((nt - z * sig) / 2) - 1, 0);
    const a = sl[Math.max(0, Math.min(nt - 1, Rl))], b = sl[Math.max(0, Math.min(nt - 1, Rh))]; return {lo: Math.min(a, b), hi: Math.max(a, b)}; };
  D.mkTFPW = function(xs, ys){ // من–کندال با پیش‌سفیدسازی بی‌اثرکنندهٔ روند (Yue و همکاران ۲۰۰۲)؛ فقط اگر خودهمبستگی مرتبهٔ ۱ معنی‌دار باشد
    const X = [], Y = []; for(let i = 0; i < ys.length; i++) if(fin(ys[i])){ X.push(xs[i]); Y.push(ys[i]); } const n = Y.length; if(n < 10) return null;
    const raw = D.mannKendall(Y), sn = D.sen(X, Y); if(!raw || !sn) return null; const b = sn.slope, d = Y.map((v, i) => v - b * X[i]), mu = d.reduce((a, c) => a + c, 0) / n;
    let num = 0, den = 0; for(let i = 0; i < n; i++){ den += (d[i] - mu) ** 2; if(i < n - 1 && X[i + 1] - X[i] === 1) num += (d[i] - mu) * (d[i + 1] - mu); } const r1 = den > 0 ? num / den : 0;
    if(Math.abs(r1) * Math.sqrt(n) < 1.96) return {r1, pw: false, p: raw.p, Z: raw.Z, pRaw: raw.p, n};
    const o = []; for(let i = 1; i < n; i++) o.push(X[i] - X[i - 1] === 1 ? d[i] - r1 * d[i - 1] + b * X[i] : NaN); const mk = D.mannKendall(o); if(!mk) return {r1, pw: false, p: raw.p, Z: raw.Z, pRaw: raw.p, n};
    return {r1, pw: true, p: mk.p, Z: mk.Z, pRaw: raw.p, n}; };
  D.pettitt = function(y){ // آزمون نقطهٔ تغییر ناپارامتری پتیت (۱۹۷۹): شاخص آخرین مقدار بخش اول، آماره K و مقدار p تقریبی
    const v = y.filter(fin), n = v.length; if(n < 10) return null; let best = 0, bt = 0, U = 0; const sg = (a, b) => a > b ? 1 : a < b ? -1 : 0;
    const Us = new Float64Array(n); for(let t = 0; t < n - 1; t++){ let u = 0; for(let i = 0; i <= t; i++) for(let j = t + 1; j < n; j++) u += sg(v[j], v[i]); Us[t] = u; if(Math.abs(u) > best){ best = Math.abs(u); bt = t; } }
    const p = Math.min(1, 2 * Math.exp(-6 * best * best / (n * n * n + n * n))); let m1 = 0, m2 = 0; for(let i = 0; i <= bt; i++) m1 += v[i]; for(let i = bt + 1; i < n; i++) m2 += v[i];
    return {t: bt, K: best, p, mean1: m1 / (bt + 1), mean2: m2 / (n - bt - 1), n}; };
  D.runMean = function(a, w){ const o = new Float64Array(a.length).fill(NaN), h = w >> 1, need = Math.ceil(w * 0.7); for(let i = 0; i < a.length; i++){ let s = 0, c = 0; for(let j = Math.max(0, i - h); j <= Math.min(a.length - 1, i + h); j++) if(fin(a[j])){ s += a[j]; c++; } if(c >= need && i - h >= 0 && i + h < a.length) o[i] = s / c; } return o; };

  /* ---------- پیش‌نگری CMIP6 (فاز ۳) ---------- */
  D.quantile = function(a, q){ const v = Array.from(a).filter(fin).sort((x, y) => x - y), n = v.length; if(!n) return NaN; if(n === 1) return v[0]; const h = (n - 1) * q, i = Math.floor(h), f = h - i; return i + 1 < n ? v[i] + f * (v[i + 1] - v[i]) : v[n - 1]; };   // = numpy.percentile (linear)
  D.bilW = function(g, lat, lon){ // وزن‌های دوخطی: {i:[۴ شاخص سلول], w:[۴ وزن]} یا null بیرون از شبکه
    const fy = (lat - g.lat0) / g.dlat, fx = (lon - g.lon0) / g.dlon; if(!(fy >= 0 && fx >= 0 && fy <= g.nlat - 1 && fx <= g.nlon - 1)) return null; const i = Math.min(g.nlat - 2, Math.floor(fy)), j = Math.min(g.nlon - 2, Math.floor(fx)), ty = fy - i, tx = fx - j;
    return {i: [i * g.nlon + j, i * g.nlon + j + 1, (i + 1) * g.nlon + j, (i + 1) * g.nlon + j + 1], w: [(1 - ty) * (1 - tx), (1 - ty) * tx, ty * (1 - tx), ty * tx]}; };
  D.bilinear = function(g, lat, lon){ const W = D.bilW(g, lat, lon); return function(vals){ if(!W) return NaN; let s = 0; for(let q = 0; q < 4; q++){ const v = vals[W.i[q]]; if(!fin(v)) return NaN; s += W.w[q] * v; } return s; }; };
})(typeof globalThis !== "undefined" ? globalThis : this);
/* ===== فرادادهٔ شاخص‌ها: ورودی، واحد، فرمول، خروجی، دادهٔ ناکافی، محدودیت تفسیر =====
   مصرف‌کننده: کارت شاخص در صفحهٔ آزمایشگاه (فاز ۳). متن علمی جدا از رنگ‌بندی است؛ این فایل هیچ رنگی نمی‌داند. */
(function(){
  "use strict";
  const M = globalThis.MET;
  M.meta = {
    CAPE: {fa:"انرژی پتانسیل همرفتی در دسترس", en:"Convective Available Potential Energy", unit:"J/kg", range:"≥ 0",
      inputs:"پروفایل p (hPa)، T و Td (°C) از سطح تا ≥ ۱۰۰ hPa؛ نوع پارسل SB/ML(۱۰۰ hPa)/MU(۳۰۰ hPa)",
      formula:"CAPE = Rd ∫ (Tv,parcel − Tv,env) d ln p بین LFC و EL (دمای مجازی؛ ذوزنقه)", ref:"MetPy cape_cin; Moncrieff & Miller 1976",
      insufficient:"LCL قابل‌حل نیست، پروفایل < ۳ سطح معتبر، یا فشار تکراری ⇒ v=null (نه صفر). «بدون LFC» = CAPE صفر معتبر با note=no_lfc",
      limits:"بدون آمیختگی با محیط، بدون بار آبی/یخ؛ وابسته به انتخاب پارسل و شمارش LFC/EL چندگانه (پیش‌فرض MetPy: LFC پایین، EL بالا)"},
    CIN: {fa:"بازدارندگی همرفتی", en:"Convective Inhibition", unit:"J/kg", range:"≤ 0",
      inputs:"همان CAPE", formula:"CIN = Rd ∫ (Tv,parcel − Tv,env) d ln p از سطح پارسل تا LFC (منفی)", ref:"MetPy cape_cin",
      insufficient:"مانند CAPE", limits:"مقدار به نقطهٔ شروع پارسل بسیار حساس است"},
    LCL: {fa:"تراز چگالش بالابرده", en:"Lifted Condensation Level", unit:"hPa / K", range:"p ≤ p سطح",
      inputs:"p، T، Td پارسل (Td ≤ T)", formula:"حل بسته با تابع W لامبرت (شاخهٔ −۱)", ref:"Romps 2017, J. Atmos. Sci.; MetPy lcl",
      insufficient:"Td > T ⇒ null", limits:"فرض رطوبت نسبت به آب مایع"},
    LI: {fa:"شاخص بالابری", en:"Lifted Index", unit:"K", range:"منفی = ناپایدار",
      inputs:"T500 محیط و پارسل سطحی بالارفته تا ۵۰۰ hPa", formula:"LI = T500,env − T500,parcel", ref:"Galway 1956; MetPy lifted_index",
      insufficient:"۵۰۰ hPa خارج از پروفایل ⇒ null", limits:"بدون اصلاح دمای مجازی؛ پارسل سطحی ممکن است نمایندهٔ لایهٔ مرزی نباشد"},
    K: {fa:"شاخص K", en:"K-index", unit:"°C", range:"≥ ۳۰ پتانسیل بالا", inputs:"T850، T700، T500، Td850، Td700",
      formula:"K = (T850 − T500) + Td850 − (T700 − Td700)", ref:"George 1960; MetPy k_index",
      insufficient:"هر سطح خارج از پروفایل (مثلاً ۸۵۰ زیر زمین در مناطق مرتفع) ⇒ null با why=level_below_ground_850", limits:"برای همرفت جرم‌هوایی؛ نه سامانه‌های شدید"},
    TT: {fa:"توتال‌توتال", en:"Total Totals", unit:"°C", range:"≥ ۴۴ احتمال تندری", inputs:"T850، Td850، T500",
      formula:"TT = VT + CT = (T850 − T500) + (Td850 − T500)", ref:"Miller 1972; MetPy total_totals_index",
      insufficient:"۸۵۰ یا ۵۰۰ خارج از پروفایل ⇒ null", limits:"وابسته به ۸۵۰ hPa؛ نامناسب برای ارتفاع‌های بالا"},
    SHOWALTER: {fa:"شاخص شوالتر", en:"Showalter Index", unit:"K", range:"منفی = ناپایدار", inputs:"پارسل از ۸۵۰ hPa تا ۵۰۰",
      formula:"SI = T500,env − T500,parcel(850→500)", ref:"Showalter 1953; MetPy showalter_index", insufficient:"مانند K", limits:"فقط لایهٔ ۸۵۰–۵۰۰"},
    SHEAR: {fa:"برش باد لایه‌ای", en:"Bulk wind shear", unit:"m/s", range:"≥ 0", inputs:"u،v (m/s) و z (m)؛ لایه بر حسب متر AGL (۰–۱، ۰–۳، ۰–۶ km)",
      formula:"S = |V(بالا) − V(پایین)| با درون‌یابی لگاریتمی در فشار", ref:"MetPy bulk_shear",
      insufficient:"لایه از بالای پروفایل بیرون زند یا < ۳ ردیف با u,v,z معتبر ⇒ null", limits:"۰–۶ km: ≥ ۱۸ m/s برای ابرسلول مناسب‌تر است (Rasmussen & Blanchard 1998، راهنمای تجربی نه حد قطعی)"},
    BUNKERS: {fa:"حرکت توفان بانکرز (راست‌گرد/چپ‌گرد)", en:"Bunkers storm motion", unit:"m/s", range:"بردار (u,v)",
      inputs:"u،v،z تا ≥ ۶ km AGL", formula:"میانگین ۰–۶ km (وزن فشار) ± ۷٫۵ m/s عمود بر برش (میانگین ۵٫۵–۶ km منهای ۰–۰٫۵ km)",
      ref:"Bunkers et al. 2000; MetPy bunkers_storm_motion", insufficient:"پروفایل کوتاه‌تر از ۶ km ⇒ null", limits:"نیمکرهٔ شمالی؛ برای سامانه‌های غیرابرسلولی نمایندهٔ حرکت واقعی نیست"},
    SRH: {fa:"هلیسیتی نسبی توفان", en:"Storm-relative helicity", unit:"m²/s²", range:"مثبت = چرخش ساعتگرد در برش",
      inputs:"u،v،z و حرکت توفان (پیش‌فرض: Bunkers راست‌گرد)", formula:"SRH = Σ [(u_{i+1}−c_x)(v_i−c_y) − (u_i−c_x)(v_{i+1}−c_y)] روی لایه", ref:"Davies-Jones et al. 1990; MetPy storm_relative_helicity",
      insufficient:"لایه فراتر از بالای پروفایل ⇒ null", limits:"حساس به وضوح قائم و حرکت توفان؛ مثبت و منفی جدا گزارش می‌شوند"},
    CRITICAL: {fa:"زاویهٔ بحرانی", en:"Critical angle", unit:"درجه", range:"۰–۱۸۰", inputs:"برش ۰–۵۰۰ m و بردار باد سطحی تا حرکت توفان", formula:"زاویهٔ بین دو بردار",
      ref:"Esterheld & Giuliano 2008; MetPy critical_angle", insufficient:"برش صفر ⇒ null", limits:"مقادیر ~۹۰° برای ابرسلول چرخان مساعد گزارش شده؛ آستانهٔ قطعی نیست"},
    LFC: {fa:"تراز همرفت آزاد", en:"Level of Free Convection", unit:"hPa", range:"p < p LCL",
      inputs:"پروفایل T و Td و پارسل انتخابی", formula:"پایین‌ترین تراز که پارسل از محیط (دمای مجازی) گرم‌تر می‌شود", ref:"MetPy lfc; Wallace & Hobbs 2006",
      insufficient:"LCL حل‌نشدنی ⇒ null؛ «بدون LFC» = پارسل هرگز گرم‌تر نمی‌شود (نه داده‌ی ناکافی)", limits:"با چند تقاطع، پایین‌ترین انتخاب می‌شود"},
    EL: {fa:"تراز تعادل", en:"Equilibrium Level", unit:"hPa", range:"p < p LFC",
      inputs:"همان LFC", formula:"بالاترین تراز که پارسل دوباره با محیط (دمای مجازی) برابر می‌شود", ref:"MetPy el",
      insufficient:"بدون LFC ⇒ EL ندارد", limits:"اگر پارسل تا بالای پروفایل گرم‌تر بماند، EL = بالای پروفایل (کران پایین واقعی)"},
    VT: {fa:"ورتیکال‌توتال", en:"Vertical Totals", unit:"°C", range:"≥ ۲۶ ناپایداری", inputs:"T850، T500", formula:"VT = T850 − T500", ref:"Miller 1972; MetPy vertical_totals",
      insufficient:"۸۵۰ یا ۵۰۰ خارج از پروفایل ⇒ null", limits:"وابسته به ۸۵۰ hPa"},
    CT: {fa:"کراس‌توتال", en:"Cross Totals", unit:"°C", range:"≥ ۱۸ مساعد", inputs:"Td850، T500", formula:"CT = Td850 − T500", ref:"Miller 1972; MetPy cross_totals",
      insufficient:"۸۵۰ یا ۵۰۰ خارج از پروفایل ⇒ null", limits:"وابسته به ۸۵۰ hPa"},
    EIL: {fa:"لایهٔ مؤثر ورودی", en:"Effective inflow layer", unit:"hPa / m AGL", range:"base ≥ top",
      inputs:"پارسل از هر تراز (از سطح به بالا)", formula:"لایهٔ پیوسته‌ای که پارسل هر تراز آن CAPE ≥ 100 J/kg و CIN > −250 J/kg دارد (ابتدا باید پارسل MU هم این شرط را داشته باشد)",
      ref:"Thompson et al. 2007; SHARPpy effective_inflow_layer", insufficient:"پارسل MU محاسبه‌نشدنی ⇒ null؛ «بدون لایهٔ مؤثر» = نتیجهٔ معتبر (SCP/STP مؤثر = ۰)", limits:"وابسته به وضوح قائم؛ سقف جست‌وجو تا اولین تراز ناقض"},
    ESRH: {fa:"هلیسیتی نسبی مؤثر", en:"Effective SRH", unit:"m²/s²", range:"مثبت = چرخش ساعتگرد", inputs:"u،v،z، لایهٔ مؤثر، حرکت توفان", formula:"SRH روی لایهٔ مؤثر نسبت به Bunkers راست‌گرد ۰–۶ km (ساده‌سازی: نه نسخهٔ لایهٔ مؤثر Bunkers)",
      ref:"Thompson et al. 2007; Bunkers et al. 2000", insufficient:"بدون باد/ارتفاع ⇒ null؛ بدون لایهٔ مؤثر ⇒ ۰ با note", limits:"حساس به حرکت توفان؛ ساده‌سازی اعلام‌شده"},
    EBWD: {fa:"برش مؤثر", en:"Effective bulk wind difference", unit:"m/s", range:"≥ 0", inputs:"u،v،z، پایهٔ لایهٔ مؤثر، ارتفاع EL پارسل MU", formula:"برش بین پایهٔ لایهٔ مؤثر و ۵۰٪ ارتفاع EL (AGL)",
      ref:"Thompson et al. 2007", insufficient:"بدون EL (پارسل تا بالای پروفایل می‌رود) ⇒ بالای پروفایل به‌جای EL (کران پایین، با note)", limits:"پروفایل کوتاه ⇒ برش کمتر از واقعی"},
    SCP: {fa:"شاخص ترکیبی ابرسلول", en:"Supercell Composite Parameter", unit:"—", range:"≥ 1 مساعد", inputs:"MUCAPE، ESRH، EBWD (و MUCIN برای جملهٔ اختیاری)",
      formula:"SCP = (MUCAPE/1000)·(ESRH/50)·(EBWD/20) ؛ EBWD<10 ⇒ ۰، >20 ⇒ ۲۰. نسخهٔ SPC: × (−40/MUCIN) اگر MUCIN < −40", ref:"Thompson et al. 2004; MetPy supercell_composite",
      insufficient:"باد/ارتفاع ناکافی ⇒ null", limits:"شاخص ترکیبی است نه احتمال؛ مقدار منفی = SRH منفی (چرخش پادساعتگرد)"},
    STPF: {fa:"شاخص گردباد شدید (لایهٔ ثابت)", en:"Significant Tornado Parameter (fixed layer)", unit:"—", range:"≥ 1 مساعد", inputs:"SBCAPE، ارتفاع LCL سطحی، SRH 0–1 km، برش 0–6 km",
      formula:"STP = (SBCAPE/1500)·((2000−LCL)/1000)·(SRH₀₋₁/150)·(BWD₀₋₆/20) ؛ LCL ∈ [1000,2000] m کلیپ؛ BWD<12.5 ⇒ ۰، >30 ⇒ ۳۰", ref:"Thompson et al. 2003/2004; MetPy significant_tornado",
      insufficient:"باد تا ۶ km نرسد ⇒ null", limits:"طراحی‌شده برای توفان‌های ابرسلولی؛ نمایندهٔ احتمال گردباد نیست"},
    STPE: {fa:"شاخص گردباد شدید (لایهٔ مؤثر)", en:"Significant Tornado Parameter (effective layer)", unit:"—", range:"≥ 1 مساعد", inputs:"MLCAPE، ارتفاع MLLCL، ESRH، EBWD، MLCIN",
      formula:"STP = (MLCAPE/1500)·(ESRH/150)·(EBWD/20)·LCLterm·CINterm ؛ EBWD<12.5 ⇒ ۰، >30 ⇒ ۱٫۵؛ CIN > −50 ⇒ ۱، < −200 ⇒ ۰، میان‌ش خطی", ref:"Thompson et al. 2012; SHARPpy stp_cin",
      insufficient:"باد ناکافی ⇒ null؛ بدون لایهٔ مؤثر ⇒ ۰", limits:"ساده‌سازی حرکت توفان (Bunkers ۰–۶ km)"},
    SHIP: {fa:"پارامتر تگرگ درشت", en:"Significant Hail Parameter", unit:"—", range:"> 1 مساعد، > 4 زیاد", inputs:"MUCAPE، نسبت اختلاط پارسل MU، نرخ کاهش دما ۷۰۰–۵۰۰، T500، برش ۰–۶ km، ارتفاع انجماد",
      formula:"SHIP = MUCAPE·MUmr·LR75·(−T500)·S06 / 4.2×10⁷ با کلیپ: S06 ∈ [7,27]، MUmr ∈ [11,13.6]، T500 ≤ −5.5؛ ضرایب: MUCAPE<1300، LR75<5.8، FZL<2400 m", ref:"Johnson & Sugden 2014 (SPC); SHARPpy ship",
      insufficient:"ترازهای ۷۰۰/۵۰۰ یا ارتفاع/باد ناکافی ⇒ null", limits:"آستانه‌های تجربیِ آمریکا؛ در اقلیم‌های دیگر واسنجی نشده"},
    LR75: {fa:"نرخ کاهش دما ۷۰۰–۵۰۰", en:"700–500 hPa lapse rate", unit:"K/km", range:"≥ 6.5 ناپایدار شرطی", inputs:"T700، T500 و ارتفاع هر دو تراز", formula:"LR = (T700 − T500)/(z500 − z700)", ref:"SPC",
      insufficient:"۷۰۰ زیر زمین یا نبود ارتفاع ⇒ null", limits:"در مناطق مرتفع ۷۰۰ hPa ممکن است زیر زمین باشد"},
    FZL: {fa:"تراز انجماد", en:"Freezing level", unit:"m AGL", range:"≥ 0", inputs:"T و ارتفاع", formula:"اولین عبور دما از ۰ °C از سطح به بالا (درون‌یابی در ln p)", ref:"—",
      insufficient:"ارتفاع نامعلوم ⇒ null؛ سطح زیر صفر ⇒ ۰ با note", limits:"فقط اولین عبور؛ وارونگی‌های چندگانه نادیده"},
    PWAT: {fa:"آب قابل بارش", en:"Precipitable Water", unit:"mm", range:"≥ 0", inputs:"p، Td (لایه)",
      formula:"PW = −(1/(g ρw)) ∫ r dp، r = ε e(Td)/(p − e)", ref:"MetPy precipitable_water",
      insufficient:"لایهٔ درخواستی خارج از پروفایل ⇒ null", limits:"لایهٔ ناقص (بدون سطوح بالا) کمتر از واقعیت است"}
  };
})();
/* ===== پارامترهای ترکیبی توفان شدید (فاز ۴): لایهٔ مؤثر، SCP، STP ثابت و مؤثر، SHIP =====
   فرمول‌ها: Thompson et al. 2003/2004/2012 (SCP, STP)، Johnson & Sugden 2014 / SPC (SHIP)؛ تطبیق عددی با MetPy (supercell_composite, significant_tornado).
   پیاده‌سازی مستقل (کد کپی نشده). هر جزء جداگانه برمی‌گردد تا قابل بازرسی باشد. ورودی ناکافی ⇒ null با علت؛ «بدون لایهٔ مؤثر» = صفر معتبر با note.
   ساده‌سازی اعلام‌شده: حرکت توفان = Bunkers ۰–۶ km (نه نسخهٔ لایهٔ مؤثر)؛ ارتفاع LCL از ارتفاع محیط در فشار LCL درون‌یابی می‌شود. */
(function(){
  "use strict";
  const M = globalThis.MET, C = M.C, PF = M.profile, T = M.thermo, W = M.wind, V = {};
  const fin = x => typeof x === "number" && isFinite(x);
  const clip = (x, a, b) => Math.min(Math.max(x, a), b);
  /* ---- فرمول‌های خالص (قابل آزمون با MetPy) ---- */
  V.scpFormula = function(mucape, esrh, ebwd, mucin){
    const sh = ebwd > 20 ? 20 : (ebwd < 10 ? 0 : ebwd), t = {cape: mucape / 1000, srh: esrh / 50, shear: sh / 20};
    const base = t.cape * t.srh * t.shear;
    let cinT = 1; if(fin(mucin) && mucin < -40) cinT = -40 / mucin;          // جملهٔ CIN نسخهٔ SPC
    return {v: base, withCin: base * cinT, terms: t, cinTerm: cinT};
  };
  V.stpFixedFormula = function(sbcape, lclAgl, srh01, bwd6){
    const lt = lclAgl < 1000 ? 1 : (lclAgl > 2000 ? 0 : (2000 - lclAgl) / 1000), b = bwd6 > 30 ? 30 : (bwd6 < 12.5 ? 0 : bwd6), t = {cape: sbcape / 1500, lcl: lt, srh: srh01 / 150, shear: b / 20};
    return {v: t.cape * t.lcl * t.srh * t.shear, terms: t};
  };
  V.stpEffFormula = function(mlcape, esrh, ebwd, mllclAgl, mlcin){
    const b = ebwd < 12.5 ? 0 : (ebwd > 30 ? 1.5 : ebwd / 20), lt = mllclAgl < 1000 ? 1 : (mllclAgl > 2000 ? 0 : (2000 - mllclAgl) / 1000), ct = mlcin > -50 ? 1 : (mlcin < -200 ? 0 : (mlcin + 200) / 150), t = {cape: mlcape / 1500, srh: esrh / 150, shear: b, lcl: lt, cin: ct};
    return {v: Math.max(t.cape * t.srh * t.shear * t.lcl * t.cin, 0), terms: t};
  };
  V.shipFormula = function(mucape, mumr, lr75, t500c, shr06, frzH){
    const sh = clip(shr06, 7, 27), mr = clip(mumr, 11, 13.6), t5 = t500c > -5.5 ? -5.5 : t500c; let s = -(mucape * mr * lr75 * t5 * sh) / 42000000;
    const adj = {cape: mucape < 1300 ? mucape / 1300 : 1, lr: lr75 < 5.8 ? lr75 / 5.8 : 1, frz: (fin(frzH) && frzH < 2400) ? frzH / 2400 : 1};
    return {v: s * adj.cape * adj.lr * adj.frz, terms: {shear: sh, mr: mr, t500: t5}, adj: adj};
  };
  /* ---- لایهٔ مؤثر ورودی: CAPE ≥ 100 و CIN > −250 از پارسل هر تراز (مثل SHARPpy/SPC) ---- */
  V.effectiveLayer = function(prof, mu, opts){
    opts = opts || {}; const ec = opts.cape == null ? 100 : opts.cape, ei = opts.cin == null ? -250 : opts.cin;
    if(!mu || mu.v == null) return M.nil("mu_parcel_failed");
    if(!(mu.v >= ec && mu.cin > ei)) return M.ok(null, {none: true, why: "no_effective_inflow"});
    const ok = i => { const r = M.parcel.sbCapeCin({p: prof.p.slice(i), Tk: prof.Tk.slice(i), Tdk: prof.Tdk.slice(i)}); return r && r.v != null && r.v >= ec && r.cin > ei; };
    let ib = -1; for(let i = 0; i < prof.p.length - 1; i++) if(ok(i)){ ib = i; break; }
    if(ib < 0) return M.ok(null, {none: true, why: "no_effective_inflow"});
    let it = ib; for(let i = ib + 1; i < prof.p.length - 1; i++){ if(ok(i)) it = i; else break; }
    const zs = prof.z && fin(prof.z[0]) ? prof.z[0] : null, hz = i => (zs != null && fin(prof.z[i])) ? prof.z[i] - zs : null;
    return M.ok(prof.p[ib], {none: false, baseP: prof.p[ib], topP: prof.p[it], baseAgl: hz(ib), topAgl: hz(it), baseIdx: ib, topIdx: it});
  };
  const interpAt = (prof, p, key) => PF.interpLin(p, prof.p, prof[key]);
  const nilw = (w) => M.nil(w);
  V.compute = function(res){
    const prof = res.prof, P = res.parcels, I = res.items, out = {}, z0 = prof.z && fin(prof.z[0]) ? prof.z[0] : null, hAgl = p => { const z = M.lab.heightAtP(prof, p); return fin(z) && z0 != null ? z - z0 : null; };
    const sb = P.SB, ml = P.ML, mu = P.MU, bk = I.BUNKERS, hasWind = res.hasWind;
    const lclAgl = q => q && q.lcl ? hAgl(q.lcl.p) : null;
    /* لایهٔ مؤثر و کمیت‌های وابسته */
    const eil = V.effectiveLayer(prof, mu); out.EIL = eil;
    let elNote = null, elAgl = mu && mu.el ? hAgl(mu.el.p) : null;
    if(mu && mu.v != null && mu.v > 0 && !mu.el){ elAgl = hAgl(prof.p[prof.p.length - 1]); elNote = "el_at_profile_top"; }   // پارسل تا بالای پروفایل شناور می‌ماند: ارتفاع بالای پروفایل = کران پایین EL
    out.muEl = elAgl;
    let esrh = nilw("insufficient_wind_levels"), ebwd = nilw("insufficient_wind_levels");
    if(!eil || eil.v === null && eil.none){ esrh = M.ok(0, {note: "no_effective_inflow"}); ebwd = M.ok(0, {note: "no_effective_inflow"}); }
    else if(eil.v != null && hasWind && bk && bk.right){
      if(eil.baseAgl == null || eil.topAgl == null) { esrh = nilw("no_height_data"); ebwd = nilw("no_height_data"); }
      else {
        const depth = Math.max(eil.topAgl - eil.baseAgl, 1);
        esrh = W.srh(prof, depth, bk.right, eil.baseAgl);
        if(elAgl == null) ebwd = nilw(mu && mu.el === null ? "no_el" : "no_height_data");
        else { const d = 0.5 * elAgl - eil.baseAgl; ebwd = d > 0 ? W.bulkShear(prof, eil.baseAgl, d) : nilw("el_below_effective_base"); if(ebwd.v != null && elNote) ebwd.note = elNote; }
      }
    } else if(eil.v != null && !hasWind){ esrh = nilw("insufficient_wind_levels"); ebwd = nilw("insufficient_wind_levels"); }
    out.ESRH = esrh; out.EBWD = ebwd;
    /* SCP */
    if(mu && mu.v != null && esrh.v != null && ebwd.v != null){ const f = V.scpFormula(mu.v, esrh.v, ebwd.v, mu.cin); out.SCP = M.ok(f.v, {withCin: f.withCin, terms: f.terms, cinTerm: f.cinTerm, note: (esrh.note || ebwd.note || null)}); }
    else out.SCP = nilw(mu && mu.v != null ? (esrh.why || ebwd.why) : "mu_parcel_failed");
    /* STP ثابت (SBCAPE، LCL سطحی، SRH 0–1 km، برش 0–6 km) */
    const s01 = I.SRH.s01, sh6 = I.SHEAR.s06, sbl = lclAgl(sb);
    if(sb && sb.v != null && sbl != null && s01.v != null && sh6.v != null){ const f = V.stpFixedFormula(sb.v, sbl, s01.v, sh6.v); out.STPF = M.ok(f.v, {terms: f.terms, lclAgl: sbl}); }
    else out.STPF = nilw(!(sb && sb.v != null) ? "cape_failed" : (sbl == null ? "no_height_data" : (s01.v == null ? s01.why : sh6.why)));
    /* STP مؤثر (MLCAPE، MLLCL، ESRH، EBWD، MLCIN) */
    const mll = lclAgl(ml);
    if(ml && ml.v != null && mll != null && esrh.v != null && ebwd.v != null){ const f = V.stpEffFormula(ml.v, esrh.v, ebwd.v, mll, ml.cin); out.STPE = M.ok(f.v, {terms: f.terms, lclAgl: mll, note: (esrh.note || ebwd.note || null)}); }
    else out.STPE = nilw(!(ml && ml.v != null) ? "cape_failed" : (mll == null ? "no_height_data" : (esrh.why || ebwd.why)));
    /* SHIP */
    const lv = [700, 500]; let lr = nilw("level_out_of_profile"), t5 = null, frz = nilw("no_height_data");
    if(lv.every(l => l <= prof.p[0] + 1e-9 && l >= prof.p[prof.p.length - 1] - 1e-9)){
      const z7 = M.lab.heightAtP(prof, 700), z5 = M.lab.heightAtP(prof, 500), T7 = interpAt(prof, 700, "Tk"), T5 = interpAt(prof, 500, "Tk"); t5 = T5 - C.zeroC;
      lr = (fin(z7) && fin(z5) && z5 > z7) ? M.ok((T7 - T5) / ((z5 - z7) / 1000), {unit: "K/km"}) : nilw("no_height_data");
    } else lr = nilw(prof.p[0] < 700 ? "level_below_ground_700" : "level_above_profile_top_500");
    out.LR75 = lr;
    // تراز انجماد (AGL): اولین عبور دما از ۰ °C از سطح به بالا (درون‌یابی در ln p)
    if(prof.Tk[0] <= C.zeroC) frz = M.ok(0, {note: "surface_below_freezing"});
    else { let found = null; for(let i = 0; i < prof.p.length - 1; i++) if(prof.Tk[i + 1] <= C.zeroC){ const f = (prof.Tk[i] - C.zeroC) / (prof.Tk[i] - prof.Tk[i + 1]), pz = Math.exp(Math.log(prof.p[i]) + f * (Math.log(prof.p[i + 1]) - Math.log(prof.p[i]))); const h = hAgl(pz); found = h; break; }
      frz = found != null ? M.ok(found) : (prof.p[prof.p.length - 1] <= 500 && z0 != null && !prof.Tk.some(x => x <= C.zeroC) ? M.ok(Infinity, {note: "no_freezing_in_profile"}) : nilw("no_height_data")); }
    out.FZL = frz;
    let mumr = null; if(mu && mu.v != null && fin(mu.startP)){ const td = interpAt(prof, mu.startP, "Tdk"); mumr = T.satMixingRatio(mu.startP, td) * 1000; }
    if(mu && mu.v != null && mumr != null && lr.v != null && t5 != null && sh6.v != null && frz.v != null){ const f = V.shipFormula(mu.v, mumr, lr.v, t5, sh6.v, frz.v); out.SHIP = M.ok(f.v, {terms: f.terms, adj: f.adj, mumr: mumr, t500: t5, frz: frz.v}); }
    else out.SHIP = nilw(!(mu && mu.v != null) ? "mu_parcel_failed" : (lr.v == null ? lr.why : (sh6.v == null ? sh6.why : (frz.v == null ? frz.why : "no_height_data"))));
    return out;
  };
  M.severe = V;
})();
/* ===== آزمایشگاه محاسبات: ورود دادهٔ سونداژ (متن/CSV/Open-Meteo) و تحلیل کامل پروفایل (فاز ۳) =====
   بدون DOM: در Node هم آزموده می‌شود. قرارداد داده: خام {p(hPa),T(°C),Td(°C),z(m),u,v(m/s)} → MET.profile.clean → تحلیل.
   قاعدهٔ داده: ردیف ناقص حذف و گزارش می‌شود، هرگز با صفر پر نمی‌شود؛ شاخصی که ورودی‌اش کافی نیست null با علت برمی‌گرداند.
   Open-Meteo (CC BY 4.0، open-meteo.com): فقط خوانده می‌شود؛ ترازهای زیر سطح زمین (p > فشار سطحی) حذف می‌شوند، نه برون‌یابی. */
(function(){
  "use strict";
  const M = globalThis.MET, C = M.C, T = M.thermo, PF = M.profile, W = M.wind, IO = {}, L = {};
  const fin = x => typeof x === "number" && isFinite(x);
  const num = s => { if(s == null) return NaN; s = String(s).trim().replace(/٫/g, ".").replace(/,/g, "."); if(s === "" || /^(nan|null|na|n\/a|-+)$/i.test(s)) return NaN; const v = Number(s); return isFinite(v) ? v : NaN; };
  /* ---------- پارس سونداژ ---------- */
  const ALIAS = {p:["pres", "pressure", "p", "press", "p_hpa", "pressure_hpa"], z:["hght", "height", "z", "hgt", "alt", "altitude", "h", "geopotential_height", "z_m"],
    T:["temp", "temperature", "t", "tdry", "t_c", "temp_c", "temperature_c"], Td:["dwpt", "dewpoint", "td", "dew", "dewp", "td_c", "dwpt_c", "dewpoint_c"],
    dir:["drct", "wdir", "dir", "winddir", "wind_direction", "direction"], spd_kt:["sknt", "wspd_kt", "kt", "knot", "knots"], spd:["sped", "wspd", "wind_speed", "speed", "ws", "spd", "windspeed"],
    u:["u", "uwind", "u_wind", "ugrd"], v:["v", "vwind", "v_wind", "vgrd"], rh:["relh", "rh", "humidity"]};
  function colMap(names){ const map = {}; names.forEach((n, i) => { const k = String(n).trim().toLowerCase().replace(/\(.*?\)/g, "").replace(/\s+/g, "_").replace(/_+$/, "");
    for(const key in ALIAS) if(ALIAS[key].indexOf(k) >= 0 && map[key] == null) map[key] = i; }); return map; }
  // windUnit برای ستون سرعت عمومی: "ms" | "kt" | "kmh"
  IO.parse = function(text, opts){
    opts = opts || {}; const issues = [];
    if(typeof text !== "string" || !text.trim()) return {ok:false, why:"empty_input"};
    const lines = text.replace(/\r/g, "").split("\n");
    // سرایند: خطی که هم pres و هم یکی از temp/hght دارد
    let h = -1; for(let i = 0; i < lines.length && i < 60; i++){ const s = lines[i].toLowerCase(); if(/\bpres\b|\bpressure\b|(^|[,;\s])p([,;\s]|$)/.test(s) && /\btemp\b|\bt\b|temperature|hght|height|\bz\b/.test(s) && !/^\s*[-\d.]/.test(s)){ h = i; break; } }
    if(h < 0) return {ok:false, why:"header_not_found"};
    const head = lines[h]; let rows = [], names, mode;
    if(/[,;\t]/.test(head)){ const sep = head.indexOf(";") >= 0 ? ";" : (head.indexOf("\t") >= 0 ? "\t" : ","); mode = "csv"; names = head.split(sep);
      for(let i = h + 1; i < lines.length; i++){ const ln = lines[i]; if(!ln.trim() || /^\s*[-=]+\s*$/.test(ln)) continue; if(/[A-Za-z]{3,}/.test(ln) && !/^\s*[-\d.]/.test(ln)) continue; rows.push(ln.split(sep)); } }
    else {
      const names0 = head.trim().split(/\s+/); names = names0;
      // Wyoming: ستون‌های ثابت ۷ نویسه‌ای (پس از خط خط‌چین)
      const hasUnits = /hpa/i.test(lines[h + 1] || ""), dash = /^-{10,}/.test((lines[h + 1] || "").trim()) || /^-{10,}/.test((lines[h + 2] || "").trim());
      const wy = /^\s*PRES\s+HGHT/.test(head) && (hasUnits || dash); mode = wy ? "wyoming" : "table";
      let start = h + 1; while(start < lines.length && (/^\s*[-=]+\s*$/.test(lines[start]) || /hpa|\bm\b.*\bc\b/i.test(lines[start]) && !/^\s*\d/.test(lines[start]))) start++;
      for(let i = start; i < lines.length; i++){ const ln = lines[i]; if(!ln.trim()) { if(wy && rows.length) break; continue; } if(/^\s*[A-Za-z<]/.test(ln)) { if(wy) break; continue; } if(/^\s*[-=]+\s*$/.test(ln)) continue;
        if(wy){ const row = []; for(let c = 0; c < names.length; c++) row.push(ln.substr(c * 7, 7)); rows.push(row); } else rows.push(ln.trim().split(/\s+/)); } }
    const m = colMap(names); if(m.p == null) return {ok:false, why:"no_pressure_column"}; if(m.T == null && m.z == null) return {ok:false, why:"no_temperature_column"};
    if(m.T == null) return {ok:false, why:"no_temperature_column"}; if(m.Td == null && m.rh == null) return {ok:false, why:"no_dewpoint_column"};
    const wu = opts.windUnit || "ms", kmh = wu === "kmh" ? 1 / 3.6 : 1, f = wu === "kt" ? W.KT : kmh;
    const raw = {p:[], T:[], Td:[], z:[], u:[], v:[]}; let nWind = 0;
    for(const r of rows){ const p = num(r[m.p]); if(!fin(p)) continue; const t = num(r[m.T]); let td = m.Td != null ? num(r[m.Td]) : NaN;
      if(!fin(td) && m.rh != null && fin(t)){ const rh = num(r[m.rh]); if(fin(rh) && rh > 0 && rh <= 100) td = T.dewpointFromRH(t + C.zeroC, rh / 100) - C.zeroC; }
      let u = NaN, v = NaN;
      if(m.u != null && m.v != null){ u = num(r[m.u]) * (wu === "kt" ? W.KT : f); v = num(r[m.v]) * (wu === "kt" ? W.KT : f); }
      else if(m.dir != null){ const d = num(r[m.dir]); let s = NaN; if(m.spd_kt != null) s = num(r[m.spd_kt]) * W.KT; else if(m.spd != null) s = num(r[m.spd]) * f;
        if(fin(d) && fin(s) && d >= 0 && d <= 360 && s >= 0){ const c = W.components(s, d); u = c.u; v = c.v; } }
      if(fin(u) && fin(v)) nWind++;
      raw.p.push(p); raw.T.push(t); raw.Td.push(td); raw.z.push(m.z != null ? num(r[m.z]) : NaN); raw.u.push(u); raw.v.push(v); }
    if(!raw.p.length) return {ok:false, why:"no_data_rows"};
    if(m.z == null) issues.push("no_height_column"); if(!nWind) issues.push("no_wind_data");
    return {ok:true, raw:raw, mode:mode, columns:Object.keys(m), rows:raw.p.length, issues:issues};
  };
  /* ---------- Open-Meteo ---------- */
  IO.OM_LEVELS = [1000, 975, 950, 925, 900, 850, 800, 700, 600, 500, 400, 300, 250, 200, 150, 100, 70, 50, 30];
  IO.omUrl = function(lat, lon, o){ o = o || {}; const lv = IO.OM_LEVELS, h = ["temperature_2m", "dew_point_2m", "surface_pressure", "wind_speed_10m", "wind_direction_10m"];
    for(const l of lv){ h.push("temperature_" + l + "hPa", "relative_humidity_" + l + "hPa", "geopotential_height_" + l + "hPa", "wind_speed_" + l + "hPa", "wind_direction_" + l + "hPa"); }
    return "https://api.open-meteo.com/v1/forecast?latitude=" + lat + "&longitude=" + lon + "&hourly=" + h.join(",") + "&wind_speed_unit=ms&timezone=GMT&forecast_days=" + (o.days || 3) + (o.model ? "&models=" + o.model : ""); };
  // خروجی JSON → {times:[...], at(i):{raw,issues}} ؛ ساعت i را به سونداژ خام تبدیل می‌کند
  IO.omToRaw = function(j, i){
    if(!j || !j.hourly || !j.hourly.time) return {ok:false, why:"bad_response"};
    const H = j.hourly, g = (k) => H[k] ? H[k][i] : null, raw = {p:[], T:[], Td:[], z:[], u:[], v:[]}, issues = [];
    const ps = g("surface_pressure"), t2 = g("temperature_2m"), d2 = g("dew_point_2m"), s10 = g("wind_speed_10m"), w10 = g("wind_direction_10m"), elev = j.elevation;
    if(!fin(ps) || !fin(t2) || !fin(d2)) return {ok:false, why:"surface_data_missing"};
    const wc = (s, d) => (fin(s) && fin(d)) ? W.components(s, d) : {u:NaN, v:NaN};
    const c10 = wc(s10, w10);
    raw.p.push(ps); raw.T.push(t2); raw.Td.push(d2); raw.z.push(fin(elev) ? elev : NaN); raw.u.push(c10.u); raw.v.push(c10.v);   // z سطح = ارتفاع مدل (elevation)؛ باد ۱۰ متری
    if(!fin(elev)) issues.push("no_elevation");
    let below = 0;
    for(const l of IO.OM_LEVELS){
      if(l >= ps - 1e-6){ below++; continue; }                                  // ترازهای زیر/روی سطح زمین
      const t = g("temperature_" + l + "hPa"), rh = g("relative_humidity_" + l + "hPa"), z = g("geopotential_height_" + l + "hPa"), s = g("wind_speed_" + l + "hPa"), d = g("wind_direction_" + l + "hPa");
      if(!fin(t) || !fin(rh) || rh <= 0) continue;
      const td = T.dewpointFromRH(t + C.zeroC, Math.min(1, rh / 100)) - C.zeroC, c = wc(s, d);
      raw.p.push(l); raw.T.push(t); raw.Td.push(td); raw.z.push(fin(z) ? z : NaN); raw.u.push(c.u); raw.v.push(c.v);
    }
    // ترازی که ارتفاعش زیر ارتفاع سطح باشد نامعتبر است
    if(fin(elev)) for(let k = 1; k < raw.p.length; k++) if(fin(raw.z[k]) && raw.z[k] <= elev){ raw.z[k] = NaN; issues.push("level_height_below_surface@" + raw.p[k]); }
    return {ok:true, raw:raw, belowGround:below, issues:issues, time:H.time[i], lat:j.latitude, lon:j.longitude, elevation:elev};
  };
  IO.omTimes = j => (j && j.hourly && j.hourly.time) ? j.hourly.time.slice() : [];

  /* ---------- تحلیل ---------- */
  function parcelSetup(prof, type){
    if(type === "ML"){ const mp = M.parcel.mixedParcel(prof, 100); if(!mp) return null; const p0 = prof.p[0], sel = prof.p.map((q, i) => i).filter(i => prof.p[i] < p0 - 100);
      return {p:[mp.p].concat(sel.map(i => prof.p[i])), Tk:[mp.Tk].concat(sel.map(i => prof.Tk[i])), Tdk:[mp.Tdk].concat(sel.map(i => prof.Tdk[i]))}; }
    if(type === "MU"){ const lay = PF.layer(prof, ["Tk", "Tdk"], null, 300, false); if(!lay || !lay.p.length) return null; let bi = 0, best = -Infinity;
      for(let i = 0; i < lay.p.length; i++){ const te = T.thetaE(lay.p[i], lay.Tk[i], lay.Tdk[i]); if(te > best){ best = te; bi = i; } }
      const s = prof.p.indexOf(lay.p[bi]); return {p:prof.p.slice(s), Tk:prof.Tk.slice(s), Tdk:prof.Tdk.slice(s)}; }
    return {p:prof.p, Tk:prof.Tk, Tdk:prof.Tdk};
  }
  const CAPEFN = {SB:"sbCapeCin", ML:"mlCapeCin", MU:"muCapeCin"};
  L.analyze = function(raw, opts){
    opts = opts || {}; const type = CAPEFN[opts.parcel] ? opts.parcel : "SB";
    const cl = PF.clean(raw); if(!cl.ok) return {ok:false, why:cl.why, issues:cl.issues, dropped:cl.dropped};
    const prof = cl.prof, I = M.indices, out = {ok:true, prof:prof, parcelType:type, dropped:cl.dropped, issues:cl.issues.slice(), items:{}, parcels:{}};
    out.surface = {p:prof.p[0], T:prof.Tk[0] - C.zeroC, Td:prof.Tdk[0] - C.zeroC, z:prof.z[0]};
    out.top = prof.p[prof.p.length - 1];
    for(const t of ["SB", "ML", "MU"]){ try{ out.parcels[t] = M.parcel[CAPEFN[t]](prof); }catch(e){ out.parcels[t] = M.nil("exception:" + e.message); } }
    const P = out.parcels[type], it = out.items;
    it.CAPE = P && P.v != null ? M.ok(P.v, {note:P.note}) : M.nil(P ? P.why : "cape_failed");
    it.CIN = P && P.v != null ? M.ok(P.cin) : M.nil(P ? P.why : "cape_failed");
    it.LCL = P && P.lcl ? M.ok(P.lcl.p, {Tk:P.lcl.Tk, z:L.heightAtP(prof, P.lcl.p)}) : M.nil(P && P.why || "lcl_failed");
    const lf = P && P.lfc ? P.lfc.p : null, el = P && P.el ? P.el.p : null;
    out.lfc = lf; out.el = el;
    it.LI = I.liftedIndex(prof); it.K = I.kIndex(prof); it.TT = I.totalTotals(prof); it.SHOWALTER = I.showalter(prof); it.PWAT = I.pwat(prof);
    it.VT = I.verticalTotals(prof); it.CT = I.crossTotals(prof);
    const sh = (b, d) => W.bulkShear(prof, b, d);
    it.SHEAR = {s01:sh(0, 1000), s03:sh(0, 3000), s06:sh(0, 6000), v:null, why:null};
    const bk = W.bunkers(prof); it.BUNKERS = bk;
    if(bk.right){ const st = bk.right; it.SRH = {s01:W.srh(prof, 1000, st), s03:W.srh(prof, 3000, st), v:null}; it.CRITICAL = W.criticalAngle(prof, st); }
    else { it.SRH = {s01:M.nil(bk.why), s03:M.nil(bk.why), v:null}; it.CRITICAL = M.nil(bk.why); }
    it.SHEAR.v = it.SHEAR.s06.v; it.SHEAR.why = it.SHEAR.s06.why; it.SRH.v = it.SRH.s03.v;
    out.hodo = W.hodograph(prof, 10000);
    out.hasWind = !!W.windProfile(prof);
    if(M.severe){ try{ out.severe = M.severe.compute(out); }catch(e){ out.severe = {error: e.message}; } }
    return out;
  };
  L.heightAtP = function(prof, p){ if(!prof.z || !prof.z.length) return null; const idx = []; for(let i = 0; i < prof.p.length; i++) if(fin(prof.z[i])) idx.push(i); if(idx.length < 2) return null;
    const pp = idx.map(i => Math.log(prof.p[i])), zz = idx.map(i => prof.z[i]); const x = Math.log(p);
    if(x > pp[0] + 1e-9 || x < pp[pp.length - 1] - 1e-9) return null; for(let i = 0; i < pp.length - 1; i++) if(x <= pp[i] && x >= pp[i + 1]){ const f = (x - pp[i]) / (pp[i + 1] - pp[i]); return zz[i] + f * (zz[i + 1] - zz[i]); } return null; };
  // منحنی پارسل برای رسم Skew-T (K)
  L.parcelCurve = function(prof, type){ const s = parcelSetup(prof, type); if(!s) return null; const w = M.parcel.parcelProfileWithLcl(s); if(!w) return null; return {p:w.p, Tk:w.Tp, pLcl:w.pLcl, tLcl:w.tLcl}; };
  // متن علت داده‌ی ناکافی
  L.whyText = function(why, en){
    if(!why) return ""; let m;
    if((m = /^level_below_ground_(\d+)/.exec(why))) return en ? "Level " + m[1] + " hPa is below the ground surface" : "تراز " + m[1] + " hPa زیر سطح زمین است";
    if((m = /^level_above_profile_top_(\d+)/.exec(why))) return en ? "Level " + m[1] + " hPa is above the profile top" : "تراز " + m[1] + " hPa بالاتر از بالای پروفایل است";
    const D = {lcl_failed:["LCL قابل‌محاسبه نیست (Td > T یا رطوبت نامعتبر)", "LCL cannot be solved (Td > T or invalid humidity)"], cape_failed:["محاسبهٔ CAPE ممکن نشد", "CAPE could not be computed"],
      layer_outside_profile:["لایهٔ لازم خارج از پروفایل است", "Required layer lies outside the profile"], layer_exceeds_profile_top:["لایه از بالای پروفایل (ارتفاع) بیرون می‌زند", "Layer exceeds the profile top (height)"],
      insufficient_wind_levels:["باد یا ارتفاع کافی نیست (کمتر از ۳ سطح با u،v،z)", "Not enough wind/height levels (< 3 with u, v, z)"], zero_shear:["برش صفر است", "Shear is zero"], zero_vector:["بردار صفر است", "Zero vector"],
      no_lfc:["پارسل به LFC نمی‌رسد (CAPE صفر معتبر)", "Parcel never reaches an LFC (valid zero CAPE)"], nonfinite_mixing_ratio:["نسبت اختلاط نامعتبر", "Invalid mixing ratio"],
      mu_parcel_failed:["پارسل ناپایدارترین محاسبه نشد", "Most-unstable parcel failed"], no_height_data:["ارتفاع (z) کافی نیست", "Not enough height (z) data"], no_el:["EL پیدا نشد", "No EL found"],
      el_below_effective_base:["EL پایین‌تر از پایهٔ لایهٔ مؤثر است", "EL is below the effective-layer base"], no_effective_inflow:["لایهٔ مؤثر ورودی وجود ندارد (CAPE<100 یا CIN<−250): مقدار صفر معتبر", "No effective inflow layer (CAPE<100 or CIN<−250): valid zero"],
      level_out_of_profile:["ترازهای ۷۰۰/۵۰۰ hPa در پروفایل نیستند", "700/500 hPa levels not in the profile"], el_at_profile_top:["EL بالای پروفایل است؛ بالای پروفایل به‌جای EL (کران پایین)", "EL is above the profile; profile top used instead (lower bound)"],
      surface_below_freezing:["سطح زیر صفر است", "Surface is below freezing"], no_freezing_in_profile:["دما تا بالای پروفایل زیر صفر نمی‌رود", "Temperature never reaches freezing"]};
    return D[why] ? D[why][en ? 1 : 0] : why;
  };
  L.ioWhyText = function(why, en){ const D = {empty_input:["ورودی خالی است", "Input is empty"], header_not_found:["سطر عنوان ستون‌ها (مثلاً PRES HGHT TEMP DWPT DRCT SKNT) پیدا نشد", "Column header row (e.g. PRES HGHT TEMP DWPT DRCT SKNT) not found"],
      no_pressure_column:["ستون فشار (PRES) نیست", "No pressure (PRES) column"], no_temperature_column:["ستون دما (TEMP) نیست", "No temperature (TEMP) column"], no_dewpoint_column:["ستون نقطهٔ شبنم (DWPT) یا رطوبت نسبی نیست", "No dew-point (DWPT) or RH column"],
      no_data_rows:["ردیف داده‌ای پیدا نشد", "No data rows found"], too_few_valid_levels:["کمتر از ۳ سطح معتبر", "Fewer than 3 valid levels"], duplicate_pressure:["فشار تکراری در پروفایل", "Duplicate pressure in profile"], empty_profile:["پروفایل خالی", "Empty profile"],
      bad_response:["پاسخ Open-Meteo نامعتبر است", "Invalid Open-Meteo response"], surface_data_missing:["دادهٔ سطحی (فشار/دما/شبنم) برای این ساعت موجود نیست", "Surface data (pressure/T/Td) missing for this hour"]};
    return D[why] ? D[why][en ? 1 : 0] : why; };
  M.io = IO; M.lab = L; M.VERSION = "met-1.3.0-phase4";
})();
/* ===== Skew-T log-p و هودوگراف (SVG خالص، بدون کتابخانه) — فاز ۳ =====
   الهام ساختار: skewt-js (MIT) — کد کپی نشده؛ محورها و منحنی‌ها با هستهٔ MET محاسبه می‌شوند.
   رنگ‌ها فقط نمایشی‌اند و به محاسبه راه ندارند. خروجی SVG مستقل است (استایل درون‌خطی) تا ذخیره به‌صورت SVG/PNG وفادار بماند. */
(function(){
  "use strict";
  const M = globalThis.MET, C = M.C, T = M.thermo, PF = M.profile, W = M.wind, S = {};
  const fin = x => typeof x === "number" && isFinite(x);
  const f1 = x => (Math.round(x * 10) / 10).toString(), f0 = x => Math.round(x).toString();
  const esc = s => String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;");
  const G = {W:640, H:600, ML:46, MR:78, MT:14, MB:34, pb:1050, Tmin:-35, Trange:80, k:0.8};
  G.pw = G.W - G.ML - G.MR; G.ph = G.H - G.MT - G.MB;
  function geom(pTop){
    const g = Object.assign({}, G); g.pt = pTop || 100; g.sx = g.pw / g.Trange; const lr = Math.log(g.pb / g.pt);
    g.y = p => g.MT + g.ph * (Math.log(p / g.pt) / lr);                         // بالاتر = فشار کمتر
    g.yb = g.MT + g.ph;
    g.x = (tc, p) => g.ML + (tc - g.Tmin) * g.sx + (g.yb - g.y(p)) * g.k;      // tc ‎°C
    g.pFromY = y => g.pt * Math.exp(lr * (y - g.MT) / g.ph);
    return g;
  }
  const poly = (pts, st, fill) => '<polyline points="' + pts.map(q => f1(q[0]) + "," + f1(q[1])).join(" ") + '" fill="' + (fill || "none") + '" ' + st + "/>";
  function barb(x, y, u, v, len){
    const spd = Math.hypot(u, v) / W.KT, dir = W.direction(u, v);
    if(spd < 2.5) return '<circle cx="' + f1(x) + '" cy="' + f1(y) + '" r="3" fill="none" stroke="#222" stroke-width="1"/>';
    let s = Math.round(spd / 5) * 5, d = "", yy = 0; const step = 4.5, bl = 11;
    d += "M0,0 L0," + (-len);
    while(s >= 50){ d += " M0," + (-len + yy) + " L" + bl + "," + (-len + yy + 3) + " L0," + (-len + yy + 6) + " Z"; yy += 7; s -= 50; }
    if(yy) yy += 1;
    while(s >= 10){ d += " M0," + (-len + yy) + " l" + bl + ",-4"; yy += step; s -= 10; }
    if(s >= 5){ if(yy === 0) yy += step; d += " M0," + (-len + yy) + " l" + (bl / 2) + ",-2"; }
    return '<g transform="translate(' + f1(x) + "," + f1(y) + ") rotate(" + f1(dir) + ')"><path d="' + d + '" stroke="#222" stroke-width="1.1" fill="#222"/></g>';
  }
  /* res = MET.lab.analyze(...)؛ o = {en, parcel:"SB"|"ML"|"MU", showMoist, showMix} */
  S.svg = function(res, o){
    o = o || {}; const en = !!o.en, prof = res.prof, g = geom(100);
    const clip = '<clipPath id="skc"><rect x="' + g.ML + '" y="' + g.MT + '" width="' + g.pw + '" height="' + g.ph + '"/></clipPath>';
    let b = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + g.W + " " + g.H + '" font-family="Vazirmatn,Tahoma,sans-serif" font-size="10" style="width:100%;height:auto;display:block;background:#fff" role="img" aria-label="Skew-T log-p"><defs>' + clip + "</defs>";
    b += '<rect width="' + g.W + '" height="' + g.H + '" fill="#fff"/><rect x="' + g.ML + '" y="' + g.MT + '" width="' + g.pw + '" height="' + g.ph + '" fill="#fbfcfd" stroke="#888"/>';
    b += '<g clip-path="url(#skc)">';
    // زیر سطح زمین
    const yg = g.y(prof.p[0]); if(yg < g.yb) b += '<rect x="' + g.ML + '" y="' + f1(yg) + '" width="' + g.pw + '" height="' + f1(g.yb - yg) + '" fill="#c9c2b6" opacity=".55"/>';
    // ایزوترم‌ها
    for(let t = -140; t <= 60; t += 10){ b += '<line x1="' + f1(g.x(t, g.pb)) + '" y1="' + f1(g.y(g.pb)) + '" x2="' + f1(g.x(t, g.pt)) + '" y2="' + f1(g.y(g.pt)) + '" stroke="' + (t === 0 ? "#6aa0d8" : "#d4dae0") + '" stroke-width="' + (t === 0 ? 1.1 : 0.7) + '"/>'; }
    // ایزوبارها
    for(let p = 1000; p >= 100; p -= 50){ const major = p % 100 === 0; b += '<line x1="' + g.ML + '" x2="' + (g.ML + g.pw) + '" y1="' + f1(g.y(p)) + '" y2="' + f1(g.y(p)) + '" stroke="' + (major ? "#b8c0c8" : "#e4e8ec") + '" stroke-width="' + (major ? 0.8 : 0.5) + '"/>'; }
    const pg = []; for(let p = g.pb; p >= g.pt - 1e-9; p -= 25) pg.push(p);
    // آدیاباتیک خشک
    for(let th = 250; th <= 520; th += 10){ const pts = pg.map(p => [g.x(T.dryLapse(p, th, 1000) - C.zeroC, p), g.y(p)]); b += poly(pts, 'stroke="#e6c9a8" stroke-width="0.7"'); }
    // آدیاباتیک اشباع
    if(o.showMoist !== false) for(let t0 = -10; t0 <= 36; t0 += 5){ const pp = []; for(let p = 1000; p >= g.pt - 1e-9; p -= 25) pp.push(p); const tk = T.moistLapse(pp, t0 + C.zeroC, 1000);
      if(tk) b += poly(pp.map((p, i) => [g.x(tk[i] - C.zeroC, p), g.y(p)]), 'stroke="#a8d4b8" stroke-width="0.7" stroke-dasharray="3 2"'); }
    // نسبت اختلاط
    if(o.showMix !== false) for(const w of [1, 2, 4, 8, 12, 16, 20]){ const pts = []; for(let p = g.pb; p >= 600; p -= 25) pts.push([g.x(T.dewpointFromE(T.vaporPressure(p, w / 1000)) - C.zeroC, p), g.y(p)]);
      b += poly(pts, 'stroke="#b9d9a3" stroke-width="0.7" stroke-dasharray="1 3"'); b += '<text x="' + f1(pts[pts.length - 1][0]) + '" y="' + f1(pts[pts.length - 1][1] - 2) + '" fill="#7fae62" font-size="8" text-anchor="middle">' + w + "</text>"; }
    // پارسل و سایه‌ی CAPE/CIN
    const pc = M.lab.parcelCurve(prof, o.parcel || res.parcelType);
    if(pc){
      const envT = p => PF.interpLog(p, prof.p, prof.Tk), P = pc.p, d = P.map((p, i) => pc.Tk[i] - envT(p));
      const lfc = res.lfc, seg = (i, j) => [g.x(pc.Tk[i] - C.zeroC, P[i]), g.y(P[i])];
      if(fin(lfc)) for(let i = 0; i < P.length - 1; i++){
        let a = {p:P[i], tp:pc.Tk[i], te:envT(P[i]), d:d[i]}, c = {p:P[i + 1], tp:pc.Tk[i + 1], te:envT(P[i + 1]), d:d[i + 1]};
        if(!fin(a.d) || !fin(c.d)) continue;
        const parts = []; if(a.d * c.d < 0){ const f = a.d / (a.d - c.d), pm = Math.exp(Math.log(a.p) + f * (Math.log(c.p) - Math.log(a.p))), tm = envT(pm); parts.push([a, {p:pm, tp:tm, te:tm, d:0}]); parts.push([{p:pm, tp:tm, te:tm, d:0}, c]); } else parts.push([a, c]);
        for(const [s0, s1] of parts){ const m = (s0.d + s1.d) / 2, pm = Math.sqrt(s0.p * s1.p); if(m === 0) continue; const pos = m > 0; if(pos && pm > lfc + 1e-6) continue; if(!pos && pm < lfc - 1e-6) continue;
          const q = [[g.x(s0.tp - C.zeroC, s0.p), g.y(s0.p)], [g.x(s1.tp - C.zeroC, s1.p), g.y(s1.p)], [g.x(s1.te - C.zeroC, s1.p), g.y(s1.p)], [g.x(s0.te - C.zeroC, s0.p), g.y(s0.p)]];
          b += '<polygon points="' + q.map(z => f1(z[0]) + "," + f1(z[1])).join(" ") + '" fill="' + (pos ? "#e8503a" : "#3a78e8") + '" opacity=".28"/>'; }
      }
    }
    // منحنی‌های محیط
    const lineOf = key => poly(prof.p.map((p, i) => [g.x(prof[key][i] - C.zeroC, p), g.y(p)]), 'stroke="' + (key === "Tk" ? "#d22" : "#1a8a3a") + '" stroke-width="2.2" stroke-linejoin="round"');
    b += lineOf("Tdk") + lineOf("Tk");
    if(pc) b += poly(pc.p.map((p, i) => [g.x(pc.Tk[i] - C.zeroC, p), g.y(p)]), 'stroke="#111" stroke-width="1.6" stroke-dasharray="5 3"');
    b += "</g>";
    // ترازهای LCL/LFC/EL
    const mark = (p, lab, col) => { if(!fin(p) || p < g.pt || p > g.pb) return ""; const y = g.y(p); return '<line x1="' + (g.ML + g.pw - 36) + '" x2="' + (g.ML + g.pw) + '" y1="' + f1(y) + '" y2="' + f1(y) + '" stroke="' + col + '" stroke-width="1.4"/><text x="' + (g.ML + g.pw - 38) + '" y="' + f1(y - 2) + '" text-anchor="end" fill="' + col + '" font-size="9.5" font-weight="700">' + lab + " " + f0(p) + "</text>"; };
    b += mark(res.items.LCL.v, "LCL", "#0a7") + mark(res.lfc, "LFC", "#a50") + mark(res.el, "EL", "#70a");
    // برچسب محورها
    for(let p = 1000; p >= 100; p -= 100) b += '<text x="' + (g.ML - 4) + '" y="' + f1(g.y(p) + 3) + '" text-anchor="end" fill="#444">' + p + "</text>";
    b += '<text x="10" y="' + f1(g.MT + g.ph / 2) + '" fill="#444" transform="rotate(-90 10 ' + f1(g.MT + g.ph / 2) + ')" text-anchor="middle">hPa</text>';
    for(let t = -30; t <= 40; t += 10) b += '<text x="' + f1(g.x(t, g.pb)) + '" y="' + (g.yb + 12) + '" text-anchor="middle" fill="#444">' + t + "</text>";
    b += '<text x="' + f1(g.ML + g.pw / 2) + '" y="' + (g.H - 6) + '" text-anchor="middle" fill="#444">' + (en ? "Temperature at 1050 hPa (°C)" : "°C (دما در تراز ۱۰۵۰ hPa)") + "</text>";
    // بارب باد
    const wi = []; for(let i = 0; i < prof.p.length; i++) if(fin(prof.u[i]) && fin(prof.v[i])) wi.push(i);
    if(wi.length){ const bx = g.W - g.MR / 2 + 6; b += '<line x1="' + f1(bx) + '" x2="' + f1(bx) + '" y1="' + g.MT + '" y2="' + g.yb + '" stroke="#ddd"/>'; let last = -99;
      for(const i of wi){ const y = g.y(prof.p[i]); if(y < g.MT || y > g.yb || Math.abs(y - last) < 15) continue; last = y; b += barb(bx, y, prof.u[i], prof.v[i], 22); } }
    // تیتر پارسل
    b += '<text x="' + (g.ML + 6) + '" y="' + (g.MT + 12) + '" fill="#111" font-weight="700">' + esc(o.title || "") + "</text>";
    b += '<g id="skCur" style="display:none"><line id="skCl" x1="' + g.ML + '" x2="' + (g.ML + g.pw) + '" y1="0" y2="0" stroke="#e0a000" stroke-width="1.2"/><circle id="skCT" r="3.5" fill="#d22" stroke="#fff"/><circle id="skCD" r="3.5" fill="#1a8a3a" stroke="#fff"/></g>';
    b += '<rect id="skHit" x="' + g.ML + '" y="' + g.MT + '" width="' + g.pw + '" height="' + g.ph + '" fill="transparent" style="touch-action:pan-y;cursor:crosshair"/>';
    return b + "</svg>";
  };
  // اتصال رویداد نشانگر؛ info(div) متن را می‌گیرد
  S.attach = function(host, res, infoEl, o){
    o = o || {}; const svg = host.querySelector("svg"); if(!svg) return; const g = geom(100), prof = res.prof;
    const hit = svg.querySelector("#skHit"), cur = svg.querySelector("#skCur"), cl = svg.querySelector("#skCl"), cT = svg.querySelector("#skCT"), cD = svg.querySelector("#skCD");
    const wi = []; for(let i = 0; i < prof.p.length; i++) if(fin(prof.u[i]) && fin(prof.v[i])) wi.push(i);
    function at(ev){
      const r = svg.getBoundingClientRect(), sc = g.W / r.width, y = (ev.clientY - r.top) * sc; const p = Math.max(Math.min(g.pFromY(y), prof.p[0]), prof.p[prof.p.length - 1]);
      const t = PF.interpLog(p, prof.p, prof.Tk), td = PF.interpLog(p, prof.p, prof.Tdk); if(!fin(t) || !fin(td)) return;
      const yy = g.y(p); cur.style.display = ""; cl.setAttribute("y1", yy); cl.setAttribute("y2", yy);
      cT.setAttribute("cx", g.x(t - C.zeroC, p)); cT.setAttribute("cy", yy); cD.setAttribute("cx", g.x(td - C.zeroC, p)); cD.setAttribute("cy", yy);
      const z = M.lab.heightAtP(prof, p), rh = T.rhFromDewpoint(t, td) * 100; let w = "";
      if(wi.length > 1){ const pp = wi.map(i => prof.p[i]), u = PF.interpLog(p, pp, wi.map(i => prof.u[i])), v = PF.interpLog(p, pp, wi.map(i => prof.v[i])); if(fin(u) && fin(v)) w = " · " + f0(W.direction(u, v)) + "°/" + f1(Math.hypot(u, v)) + " m/s"; }
      if(infoEl) infoEl.textContent = f0(p) + " hPa" + (fin(z) ? " · " + f0(z) + " m" : "") + " · T " + f1(t - C.zeroC) + " °C · Td " + f1(td - C.zeroC) + " °C · RH " + f0(rh) + "%" + w;
    }
    hit.addEventListener("pointermove", at); hit.addEventListener("pointerdown", at);
  };
  /* ---------- هودوگراف ---------- */
  S.hodograph = function(res, o){
    o = o || {}; const en = !!o.en, H = res.hodo; if(!H || H.v == null) return null;
    const pts = H.points; let mx = 0; pts.forEach(p => { mx = Math.max(mx, Math.hypot(p.u, p.v)); });
    const items = res.items, bk = items.BUNKERS; ["right", "left", "mean"].forEach(k => { if(bk && bk[k]) mx = Math.max(mx, Math.hypot(bk[k].u, bk[k].v)); });
    const R = Math.max(30, Math.ceil((mx + 2) / 10) * 10), S0 = 300, c = S0 / 2, k = (c - 14) / R, X = u => c + u * k, Y = v => c - v * k;
    let b = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + S0 + " " + S0 + '" font-family="Vazirmatn,Tahoma,sans-serif" font-size="9" style="width:100%;height:auto;display:block;background:#fff" role="img" aria-label="hodograph"><rect width="' + S0 + '" height="' + S0 + '" fill="#fff"/>';
    for(let r = 10; r <= R; r += 10) b += '<circle cx="' + c + '" cy="' + c + '" r="' + f1(r * k) + '" fill="none" stroke="#d4dae0"/><text x="' + f1(c + 2) + '" y="' + f1(c - r * k - 1) + '" fill="#889">' + r + "</text>";
    b += '<line x1="6" x2="' + (S0 - 6) + '" y1="' + c + '" y2="' + c + '" stroke="#aab"/><line y1="6" y2="' + (S0 - 6) + '" x1="' + c + '" x2="' + c + '" stroke="#aab"/>';
    const col = z => z < 3000 ? "#d22" : z < 6000 ? "#1a8a3a" : z < 9000 ? "#c80" : "#70a";
    for(let i = 0; i < pts.length - 1; i++) b += '<line x1="' + f1(X(pts[i].u)) + '" y1="' + f1(Y(pts[i].v)) + '" x2="' + f1(X(pts[i + 1].u)) + '" y2="' + f1(Y(pts[i + 1].v)) + '" stroke="' + col((pts[i].z + pts[i + 1].z) / 2) + '" stroke-width="2.2"/>';
    H.marks.forEach(m => { if(fin(m.u) && fin(m.v)) b += '<circle cx="' + f1(X(m.u)) + '" cy="' + f1(Y(m.v)) + '" r="7" fill="#fff" stroke="' + col(m.km * 1000 - 1) + '"/><text x="' + f1(X(m.u)) + '" y="' + f1(Y(m.v) + 3) + '" text-anchor="middle" font-weight="700" fill="#222">' + m.km + "</text>"; });
    if(bk && bk.right){ const pt = (q, lab, shape) => '<g><' + (shape === "t" ? 'polygon points="' + f1(X(q.u)) + "," + f1(Y(q.v) - 6) + " " + f1(X(q.u) - 5.5) + "," + f1(Y(q.v) + 4) + " " + f1(X(q.u) + 5.5) + "," + f1(Y(q.v) + 4) + '"' : 'rect x="' + f1(X(q.u) - 4.5) + '" y="' + f1(Y(q.v) - 4.5) + '" width="9" height="9"') + ' fill="#111" opacity=".85"/><text x="' + f1(X(q.u) + 8) + '" y="' + f1(Y(q.v) + 3) + '" font-weight="700">' + lab + "</text></g>";
      b += pt(bk.right, "RM", "t") + pt(bk.left, "LM", "t") + '<circle cx="' + f1(X(bk.mean.u)) + '" cy="' + f1(Y(bk.mean.v)) + '" r="3.5" fill="none" stroke="#111" stroke-width="1.5"/><text x="' + f1(X(bk.mean.u) + 6) + '" y="' + f1(Y(bk.mean.v) - 4) + '">' + (en ? "mean" : "میانگین") + "</text>"; }
    b += '<text x="' + (S0 - 6) + '" y="' + (S0 - 6) + '" text-anchor="end" fill="#667">m/s</text>';
    return b + "</svg>";
  };
  // ذخیره: SVG یا PNG
  S.download = function(svgEl, name, png){
    const xml = new XMLSerializer().serializeToString(svgEl), blob = new Blob([xml], {type:"image/svg+xml;charset=utf-8"});
    const save = (bl, fn) => { const a = document.createElement("a"); a.href = URL.createObjectURL(bl); a.download = fn; document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 500); };
    if(!png) return save(blob, name + ".svg");
    const vb = svgEl.viewBox.baseVal, sc = 2, img = new Image(); img.onload = () => { const cv = document.createElement("canvas"); cv.width = vb.width * sc; cv.height = vb.height * sc; const cx = cv.getContext("2d"); cx.fillStyle = "#fff"; cx.fillRect(0, 0, cv.width, cv.height); cx.drawImage(img, 0, 0, cv.width, cv.height); cv.toBlob(b2 => save(b2, name + ".png")); };
    img.src = "data:image/svg+xml;charset=utf-8," + encodeURIComponent(xml);
  };
  M.skewt = S;
})();
/* نمونهٔ آزمایشگاه: سونداژ OUN ۲۲ مه ۲۰۱۱ ۱۲Z (دادهٔ آزمونی MetPy، دانشگاه وایومینگ) */
(function(){ globalThis.MET.SAMPLE = "72357 OUN Norman Observations at 12Z 22 May 2011\n\n-----------------------------------------------------------------------------\n   PRES   HGHT   TEMP   DWPT   RELH   MIXR   DRCT   SKNT   THTA   THTE   THTV\n    hPa     m      C      C      %    g/kg    deg   knot     K      K      K \n-----------------------------------------------------------------------------\n 1000.0     36                                                               \n  966.0    345   22.2   21.0     93  16.50    180      7  298.3  346.4  301.2\n  953.0    462   21.4   20.7     96  16.42    184     16  298.6  346.6  301.6\n  936.9    610   20.8   20.5     98  16.52    190     28  299.5  347.9  302.5\n  925.0    720   20.4   20.4    100  16.61    200     33  300.2  349.0  303.1\n  904.5    914   19.3   19.3    100  15.81    205     36  300.9  347.6  303.8\n  896.0    995   18.8   18.8    100  15.49    209     38  301.3  347.0  304.1\n  890.0   1054   20.0   20.0    100  16.84    212     40  303.1  353.2  306.1\n  886.0   1093   22.2   19.0     82  15.87    214     41  305.7  353.5  308.6\n  873.3   1219   23.2   13.3     54  11.12    220     45  308.0  342.0  310.1\n  873.0   1222   23.2   13.2     53  11.04    220     45  308.1  341.8  310.1\n  850.0   1454   22.0    6.0     35   6.94    210     37  309.2  330.8  310.5\n  846.0   1495   21.8    3.8     31   5.97    210     37  309.4  328.1  310.5\n  813.8   1829   19.2   -1.7     24   4.16    210     34  310.1  323.4  310.8\n  802.0   1955   18.2   -3.8     22   3.62    214     32  310.3  322.0  311.0\n  785.0   2134   16.5   -4.7     23   3.46    220     29  310.4  321.6  311.1\n  757.1   2438   13.7   -6.2     25   3.20    230     30  310.6  321.0  311.2\n  730.1   2743   10.9   -7.7     26   2.96    240     31  310.7  320.4  311.3\n  700.0   3096    7.6   -9.4     29   2.69    245     30  310.9  319.7  311.4\n  653.3   3658    2.3  -10.9     37   2.56    250     26  311.1  319.5  311.6\n  639.0   3839    0.6  -11.4     40   2.52    251     31  311.1  319.4  311.6\n  606.0   4262   -2.9  -12.9     46   2.35    255     42  311.8  319.6  312.3\n  605.6   4267   -2.9  -12.9     46   2.35    255     42  311.9  319.6  312.3\n  584.0   4555   -4.5  -14.5     46   2.14    255     54  313.3  320.4  313.7\n  582.7   4572   -4.4  -14.4     46   2.17    255     55  313.6  320.9  314.0\n  582.0   4582   -4.3  -14.3     46   2.18    255     55  313.8  321.1  314.2\n  577.0   4650   -3.7  -24.7     18   0.90    256     52  315.3  318.5  315.5\n  571.0   4733   -3.3  -36.3      6   0.30    258     49  316.7  317.9  316.8\n  561.0   4873   -3.9  -31.9      9   0.47    260     44  317.6  319.4  317.7\n  560.7   4877   -3.9  -31.8      9   0.48    260     44  317.6  319.4  317.7\n  539.4   5182   -6.3  -27.4     17   0.75    255     41  318.4  321.1  318.5\n  539.0   5187   -6.3  -27.3     17   0.76    255     41  318.4  321.1  318.5\n  500.0   5770  -11.1  -29.1     21   0.69    260     48  319.4  322.0  319.6\n  478.9   6096  -13.7  -31.3     21   0.59    265     46  320.2  322.4  320.3\n  453.0   6515  -17.1  -34.1     21   0.47    263     44  321.1  322.8  321.1\n  443.0   6681  -18.3  -32.3     28   0.58    263     43  321.6  323.8  321.7\n  406.3   7315  -23.9  -37.0     29   0.39    260     40  322.4  323.9  322.5\n  400.0   7430  -24.9  -37.9     29   0.37    255     38  322.5  323.9  322.6\n  389.3   7620  -26.6  -39.3     29   0.33    250     35  322.8  324.0  322.8\n  327.3   8839  -37.9  -48.1     34   0.15    230     28  323.7  324.3  323.8\n  313.4   9144  -40.7  -50.3     35   0.12    235     26  323.9  324.4  323.9\n  300.0   9449  -43.5  -52.5     36   0.10    230     24  323.9  324.4  324.0\n  286.0   9769  -46.3  -55.3     35   0.07    240     28  324.4  324.7  324.4\n  250.0  10650  -52.1  -62.1     29   0.04    255     41  328.5  328.6  328.5\n  249.0  10676  -52.3  -62.3     29   0.04    255     41  328.6  328.7  328.6\n  220.0  11473  -54.1  -64.1     28   0.03    261     54  337.6  337.8  337.6\n  210.0  11770  -55.9  -65.9     27   0.03    263     58  339.3  339.4  339.3\n  200.0  12080  -56.5  -66.5     27   0.02    265     63  343.1  343.2  343.1\n  197.0  12176  -56.5  -66.5     27   0.03    265     64  344.6  344.7  344.6\n  196.5  12192  -56.5  -66.5     27   0.03    265     64  344.9  345.0  344.9\n  190.0  12405  -56.5  -66.5     27   0.03    265     63  348.2  348.3  348.2\n  181.0  12711  -57.9  -67.9     27   0.02    265     61  350.8  350.9  350.8\n  173.0  12996  -56.9  -66.9     27   0.03    264     60  357.0  357.1  357.0\n  159.0  13526  -59.3  -69.3     26   0.02    261     58  361.6  361.8  361.6\n  155.0  13685  -58.9  -68.9     26   0.02    260     57  365.0  365.1  365.0\n  154.2  13716  -59.0  -69.0     26   0.02    260     57  365.3  365.4  365.3\n  150.0  13890  -59.5  -69.5     26   0.02    260     51  367.4  367.5  367.4\n  148.0  13974  -59.9  -69.9     26   0.02    254     48  368.1  368.2  368.1\n  146.9  14021  -59.2  -69.2     26   0.02    250     47  370.0  370.2  370.0\n  146.0  14059  -58.7  -68.7     26   0.03    252     46  371.6  371.7  371.6\n  142.0  14233  -57.9  -67.9     27   0.03    262     40  376.0  376.1  376.0\n  140.0  14323  -56.7  -66.7     27   0.03    267     38  379.6  379.8  379.6\n  137.0  14460  -56.5  -66.5     27   0.04    275     33  382.3  382.5  382.3\n  133.3  14630  -57.7  -67.7     27   0.03    285     28  383.2  383.4  383.2\n  127.0  14935  -59.8  -69.8     26   0.02    275     17  384.8  384.9  384.8\n  126.0  14986  -60.1  -70.1     26   0.02    273     17  385.1  385.2  385.1\n  120.9  15240  -61.0  -71.0     25   0.02    260     16  387.9  388.1  387.9\n  111.0  15771  -62.9  -72.9     25   0.02    233     18  394.0  394.1  394.0\n  109.0  15882  -64.3  -73.3     28   0.02    227     18  393.4  393.5  393.4\n  104.0  16170  -63.3  -73.3     25   0.02    212     19  400.6  400.8  400.6\n  100.0  16410  -64.3  -74.3     24   0.02    200     20  403.2  403.3  403.2\n"; })();
/* مراکز استان و شهرستان برای منوی کشویی آزمایشگاه (r53).
   همان ۴۸۵ نقطهٔ id_seats.json (مرکز استان=۱، نقطهٔ مهم روستایی=۲)؛ استان هر نقطه با نقطه‌در‌چندضلعی روی لایهٔ Ostan.shp
   پیدا شده (البرز دستی از تهران جدا شد). ساختار: [نام استان، نام انگلیسی، [[نام، عرض، طول، نوع]…]] */
(function(M){ M.places = [["مرکزی","Markazi",[["اراک",34.095,49.698,1],["آشتیان",34.523,50.006,0],["تفرش",34.693,50.016,0],["خمین",33.639,50.08,0],["دلیجان",33.99,50.684,0],["ساوه",35.021,50.357,0],["شازند",33.931,49.406,0],["محلات",33.911,50.453,0],["مامونیه",35.305,50.499,0],["کمیجان",34.721,49.327,0],["خنداب",34.393,49.184,0],["فرمهین",34.504,49.684,0]]],["گیلان","Gilan",[["آستارا",38.431,48.87,0],["آستانه اشرفیه",37.263,49.943,0],["بندر انزلی",37.473,49.458,0],["هشتپر",37.797,48.905,0],["رشت",37.276,49.589,1],["رودبار",36.821,49.426,0],["رودسر",37.137,50.292,0],["صومعه سرا",37.301,49.315,0],["فومن",37.224,49.312,0],["لنگرود",37.195,50.153,0],["لاهیجان",37.204,50.009,0],["شفت",37.17,49.4,0],["املش",37.097,50.187,0],["رضوانشهر",37.549,49.137,0],["سیاهکل",37.153,49.871,0],["ماسال",37.363,49.133,0],["خمام",37.39,49.658,0]]],["مازندران","Mazandaran",[["آمل",36.47,52.351,0],["بابل",36.551,52.679,0],["بهشهر",36.692,53.553,0],["تنکابن",36.816,50.874,0],["رامسر",36.918,50.648,0],["ساری",36.563,53.06,1],["پل سفید",36.118,53.055,0],["قائم شهر",36.467,52.868,0],["نور",36.572,52.015,0],["نوشهر",36.649,51.496,0],["بابلسر",36.699,52.65,0],["محمودآباد",36.632,52.263,0],["نکا",36.651,53.299,0],["چالوس",36.655,51.42,0],["جویبار",36.641,52.912,0],["فریدونکنار",36.685,52.519,0],["عباس آباد",36.728,51.106,0],["سورک",36.595,53.208,0],["کیاکلا",36.58,52.813,0],["شیرگاه",36.299,52.89,0],["کلاردشت",36.511,51.173,0]]],["آذربایجان شرقی","East Azerbaijan",[["اهر",38.477,47.07,0],["تبریز",38.08,46.292,1],["سراب",37.941,47.537,0],["مراغه",37.392,46.239,0],["مرند",38.433,45.775,0],["میاندوآب",36.967,46.11,0],["میانه",37.421,47.715,0],["هشترود",37.478,47.051,0],["بناب",37.34,46.056,0],["بستان آباد",37.846,46.835,0],["شبستر",38.18,45.703,0],["کلیبر",38.865,47.039,0],["هریس",38.248,47.117,0],["جلفا",38.938,45.633,0],["ملکان",37.143,46.103,0],["آذرشهر",37.759,45.978,0],["اسکو",37.915,46.123,0],["قره آغاج",37.219,47.217,0],["ورزقان",38.675,46.112,0],["عجب شیر",37.478,45.894,0],["خمارلو",39.159,47.033,0],["هوراند",38.861,47.368,0],["لیلان",38.669,46.211,0],["ترکمانچای",37.585,47.39,0],["باروق",36.958,46.325,0]]],["آذربایجان غربی","West Azerbaijan",[["ارومیه",37.553,45.076,1],["پیرانشهر",36.701,45.141,0],["خوی",38.55,44.952,0],["سردشت",36.155,45.479,0],["سلماس",38.197,44.765,0],["ماکو",39.29,44.46,0],["مهاباد",36.763,45.722,0],["نقده",36.955,45.388,0],["بوکان",36.521,46.209,0],["شاهین دژ",36.679,46.567,0],["تکاب",36.401,47.113,0],["اشنویه",37.04,45.098,0],["سیه چشمه",39.065,44.384,0],["پلدشت",39.348,45.071,0],["قره ضیاءالدین",38.892,45.026,0],["شوط",39.219,44.77,0],["میرآباد",36.405,45.372,0]]],["کرمانشاه","Kermanshah",[["اسلام آباد غرب",34.109,46.53,0],["کرمانشاه",34.314,47.065,1],["پاوه",35.043,46.356,0],["سرپل ذهاب",34.461,45.863,0],["سنقر",34.782,47.599,0],["قصر شیرین",34.516,45.579,0],["کنگاور",34.504,47.965,0],["گیلانغرب",34.142,45.92,0],["جوانرود",34.807,46.491,0],["کامیاران",34.795,46.937,0],["صحنه",34.481,47.691,0],["تازه آباد",34.739,46.15,0],["کرند",34.284,46.242,0],["روانسر",34.715,46.653,0]]],["خوزستان","Khuzestan",[["آبادان",30.339,48.304,0],["اندیمشک",32.462,48.354,0],["اهواز",31.319,48.684,1],["ایذه",31.83,49.868,0],["بندر ماهشهر",30.557,49.189,0],["بهبهان",30.596,50.242,0],["خرمشهر",30.441,48.184,0],["دزفول",32.381,48.406,0],["سوسنگرد",31.564,48.19,0],["رامهرمز",31.28,49.604,0],["شادگان",30.649,48.665,0],["شوشتر",32.05,48.848,0],["مسجدسلیمان",31.936,49.304,0],["شوش",32.194,48.244,0],["باغ ملک",31.524,49.886,0],["امیدیه",30.763,49.702,0],["لالی",32.33,49.093,0],["هندیجان",30.236,49.712,0],["رامشیر",30.893,49.408,0],["گتوند",32.246,48.813,0],["قلعه خواجه",32.206,49.445,0],["هفتگل",31.447,49.53,0],["هویزه",31.462,48.074,0],["ملاثانی",31.585,48.886,0],["حمیدیه",31.483,48.433,0],["آغاجاری",30.701,49.831,0],["کوت عبداله",31.239,48.656,0],["الوان",32.112,48.459,0],["دهدز",31.71,50.288,0],["صیدون",31.367,50.083,0]]],["فارس","Fars",[["آباده",31.161,52.651,0],["استهبان",29.127,54.042,0],["اقلید",30.899,52.697,0],["جهرم",28.5,53.56,0],["داراب",28.752,54.541,0],["سپیدان",30.26,51.985,0],["شیراز",29.61,52.531,1],["فسا",28.938,53.648,0],["فیروزآباد",28.845,52.572,0],["کازرون",29.619,51.654,0],["لار",27.683,54.342,0],["مرودشت",29.874,52.803,0],["نورآباد ممسنی",30.114,51.522,0],["نی ریز",29.199,54.328,0],["لامرد",27.334,53.179,0],["بوانات",30.455,53.651,0],["ارسنجان",29.912,53.309,0],["صفاشهر",30.613,53.195,0],["حاجی آباد",28.357,54.423,0],["قیر",28.483,53.035,0],["مهر",27.552,52.882,0],["فراشبند",28.86,52.095,0],["سعادت شهر",30.079,53.135,0],["خنج",27.891,53.434,0],["سروستان",29.273,53.22,0],["مصیری",30.245,51.522,0],["گراش",27.67,54.136,0],["کوار",29.205,52.69,0],["خرامه",29.499,53.312,0],["زرقان",29.772,52.719,0],["بیضا",29.972,52.401,0],["کره ای",30.033586,53.718248,0],["قائمیه",29.619,51.654,0],["باب انار",28.975,53.217,0],["آباده طشک",29.811,53.727,0],["اوز",27.762,54.004,0],["جویم",28.255,53.981,0],["توحید",27.828,52.858,0],["فورگ",28.292,55.21,2]]],["کرمان","Kerman",[["بافت",29.233,56.602,0],["بم",29.106,58.357,0],["جیرفت",28.678,57.741,0],["رفسنجان",30.407,55.994,0],["زرند",30.813,56.564,0],["سیرجان",29.451,55.681,0],["شهربابک",30.116,55.119,0],["کرمان",30.283,57.079,1],["کهنوج",27.94,57.7,0],["بردسیر",29.923,56.574,0],["راور",31.266,56.805,0],["عنبرآباد",28.476,57.848,0],["منوجان",27.399,57.497,0],["کوهبنان",31.41,56.283,0],["رودبار",28.029,57.996,0],["قلعه گنج",27.524,57.881,0],["محمدآباد",28.669,59.073,0],["رابر",29.291,56.913,0],["فهرج",28.95,58.885,0],["انار",30.871,55.27,0],["نرماشیر",28.952,58.698,0],["فاریاب",28.099,57.232,0],["ارزوئیه",28.453,56.36,0],["گنبکی",28.722,58.864,0],["زهکلوت",27.793,58.587,0]]],["خراسان رضوی","Razavi Khorasan",[["تایباد",34.74,60.776,0],["تربت حیدریه",35.274,59.219,0],["تربت جام",35.244,60.623,0],["درگز",37.444,59.108,0],["سبزوار",36.213,57.682,0],["فاروج",37.231,58.219,0],["سرایان",33.86,58.522,0],["فردوس",34.019,58.172,0],["بشرویه",33.868,57.429,0],["قوچان",37.106,58.51,0],["کاشمر",35.238,58.466,0],["گناباد",34.353,58.684,0],["مشهد",36.298,59.606,1],["نیشابور",36.213,58.796,0],["چناران",36.645,59.121,0],["خواف",34.572,60.144,0],["سرخس",36.545,61.158,0],["فریمان",35.707,59.85,0],["بردسکن",35.262,57.971,0],["رشتخوار",34.975,59.625,0],["کلات",36.995,59.765,0],["خلیل آباد",35.254,58.286,0],["فیض آباد",35.019,58.783,0],["بجستان",34.516,58.184,0],["طرقبه",36.31,59.373,0],["فیروزه",36.286,58.586,0],["جغتای",36.636,57.073,0],["دولت آباد",35.282,59.52,0],["نقاب",36.708,57.421,0],["باخرز",35.099,60.159,0],["سلطان آباد",36.404,58.039,0],["داورزن",36.351,56.875,0],["صالح آباد",36.19,57.698,0],["ریوش",35.475,58.457,0],["خرو",35.463,58.057,0],["ششتمد",35.96,57.767,0],["گلبهار",36.57,59.19,0],["عشق آباد",36.876,58.403,0]]],["اصفهان","Isfahan",[["اردستان",33.379,52.37,0],["اصفهان",32.652,51.675,1],["خمینی شهر",32.686,51.536,0],["خوانسار",33.221,50.315,0],["سمیرم",31.417,51.567,0],["داران",32.987,50.411,0],["فریدون شهر",32.942,50.12,0],["فلاورجان",32.555,51.51,0],["شهرضا",32.009,51.864,0],["کاشان",34.002,51.439,0],["گلپایگان",33.454,50.288,0],["زرین شهر",32.391,51.377,0],["نائین",32.86,53.087,0],["نجف آباد",32.635,51.365,0],["نطنز",33.511,51.918,0],["شاهین شهر",32.858,51.553,0],["مبارکه",32.346,51.502,0],["آران و بیدگل",34.058,51.483,0],["تیران",32.703,51.154,0],["چادگان",32.768,50.629,0],["دهاقان",31.94,51.647,0],["دولت آباد",32.8,51.696,0],["خور",33.775,55.083,0],["بوئین و میاندشت",33.076,50.164,0],["تودشک",32.721,52.671,0],["نیک آباد",32.303,52.206,0],["ورزنه",33.542,50.501,0],["هرند",32.565,52.437,0]]],["سیستان و بلوچستان","Sistan & Baluchestan",[["ایرانشهر",27.202,60.685,0],["چاه بهار",25.292,60.643,0],["خاش",28.221,61.216,0],["زابل",31.031,61.495,0],["زاهدان",29.496,60.863,1],["سراوان",27.371,62.331,0],["نیک شهر",26.226,60.214,0],["راسک",26.237,61.399,0],["کنارک",25.36,60.4,0],["زهک",30.894,61.68,0],["دوست محمد",31.145,61.792,0],["گلمورتی",27.482,59.447,0],["مهرستان",27.131,61.674,0],["سوران",27.285,61.996,0],["ادیمی",31.111,61.412,0],["محمدآباد",31.128,61.568,0],["میرجاوه",29.015,61.45,0],["قصرقند",26.232,60.739,0],["فنوج",26.575,59.641,0],["بمپور",27.194,60.456,0],["نوک آباد",28.54,60.76,0],["نگور",25.389,61.138,0],["سرباز",26.632,61.258,0],["جالق",27.603,62.71,0],["اسپکه",26.84,60.173,0],["زرآباد",25.583,59.362,0]]],["کردستان","Kurdistan",[["بانه",35.998,45.885,0],["بیجار",35.867,47.605,0],["سقز",36.25,46.273,0],["سنندج",35.315,46.999,1],["قروه",35.166,47.806,0],["مریوان",35.518,46.183,0],["دیواندره",35.914,47.024,0],["سروآباد",35.313,46.367,0],["چهاربرج",36.441,46.689,0],["دهگلان",35.278,47.418,0]]],["همدان","Hamadan",[["تویسرکان",34.551,48.444,0],["ملایر",34.302,48.822,0],["نهاوند",34.191,48.374,0],["همدان",34.799,48.515,1],["کبودرآهنگ",35.209,48.723,0],["اسدآباد",34.782,48.12,0],["بهار",34.907,48.441,0],["رزن",35.386,49.033,0],["فامنین",35.116,48.973,0],["قروه درگزین",35.31,49.1,0]]],["چهارمحال و بختیاری","Chaharmahal & Bakhtiari",[["بروجن",31.965,51.287,0],["شهرکرد",32.326,50.857,1],["فارسان",32.257,50.561,0],["لردگان",31.513,50.827,0],["اردل",32.0,50.662,0],["چلگرد",32.467,50.122,0],["شلمزار",32.047,50.816,0],["سامان",32.45,50.911,0],["بن",32.54,50.745,0],["آلونی",31.553,51.06,0],["مال خلیفه",31.291,51.26,0],["فرخ شهر",32.272,50.98,0]]],["لرستان","Lorestan",[["الیگودرز",33.404,49.692,0],["بروجرد",33.897,48.752,0],["خرم آباد",33.488,48.356,1],["نورآباد دلفان",34.073,47.972,0],["دورود",33.492,49.062,0],["کوهدشت",33.533,47.61,0],["ازنا",33.456,49.456,0],["پلدختر",33.152,47.71,0],["الشتر",33.864,48.263,0],["هرسین",34.272,47.586,0],["سراب دوره",33.564,48.022,0],["چقابل",33.282,47.51,0],["معمولان",33.379,47.96,0]]],["ایلام","Ilam",[["ایلام",33.637,46.423,1],["دره‌شهر",33.144,47.38,0],["دهلران",32.694,47.268,0],["سرابله",33.768,46.566,0],["مهران",33.122,46.165,0],["آبدانان",32.993,47.42,0],["ایوان",33.827,46.31,0],["ارکواز",33.383,46.598,0],["لومار",33.565,46.814,0],["بدره",33.306,47.037,0],["چوار",33.695,46.298,0]]],["کهکیلویه و بویراحمد","Kohgiluyeh & Boyer-Ahmad",[["یاسوج",30.668,51.588,1],["دهدشت",30.793,50.565,0],["گچساران",30.359,50.798,0],["سی سخت",30.864,51.456,0],["لیکک",30.895,50.093,0],["چرام",30.756,50.745,0],["باشت",30.361,51.157,0],["لنده",30.982,50.421,0],["مارگون",30.992,51.083,0]]],["بوشهر","Bushehr",[["بوشهر",28.969,50.837,1],["اهرم",28.883,51.275,0],["برازجان",29.27,51.219,0],["خورموج",28.654,51.38,0],["بندر دیر",27.84,51.938,0],["بندرکنگان",27.834,52.063,0],["بندرگناوه",29.579,50.517,0],["بندردیلم",30.054,50.159,0],["جم",27.83,52.325,0],["عسلویه",27.474,52.608,0]]],["زنجان","Zanjan",[["ابهر",36.147,49.218,0],["قیدار",36.119,48.591,0],["زنجان",36.676,48.496,1],["زرین آباد",36.426,48.282,0],["خرمدره",36.208,49.195,0],["آب بر",36.926,48.958,0],["ماه نشان",36.744,47.672,0],["سلطانیه",36.433,48.795,0]]],["سمنان","Semnan",[["دامغان",36.168,54.343,0],["سمنان",35.577,53.392,1],["شاهرود",36.418,54.976,0],["گرمسار",35.218,52.341,0],["مهدی شهر",35.711,53.354,0],["آرادان",35.249,52.494,0],["میامی",36.411,55.65,0],["سرخه",35.463,53.214,0]]],["یزد","Yazd",[["ابرکوه",31.129,53.282,0],["اردکان",32.31,54.017,0],["بافق",31.604,55.402,0],["تفت",31.744,54.203,0],["مهریز",31.584,54.443,0],["یزد",31.897,54.367,1],["میبد",32.25,54.017,0],["اشکذر",31.997,54.209,0],["هرات",30.054,54.373,0],["بهاباد",31.871,56.024,0],["مروست",30.478,54.212,0],["زارچ",31.991,54.232,0],["طبس",33.596,56.924,0],["عشق آباد",34.366,56.93,0]]],["هرمزگان","Hormozgan",[["ابوموسی",25.875,55.03,0],["بندرعباس",27.186,56.281,1],["بندر لنگه",26.562,54.884,0],["قشم",26.949,56.269,0],["میناب",27.131,57.087,0],["بندر جاسک",25.645,57.776,0],["دهبارز",27.442,57.192,0],["حاجی آباد",28.309,55.902,0],["بستک",27.199,54.367,0],["خمیر",26.952,55.585,0],["پارسیان",27.209,53.041,0],["سیریک",26.506,57.122,0],["سردشت",26.456,57.903,0]]],["تهران","Tehran",[["تهران",35.75,51.515,1],["دماوند",35.718,52.07,0],["ری",35.594,51.44,0],["تجریش",35.804,51.426,0],["ورامین",35.324,51.646,0],["شهریار",35.659,51.058,0],["چهارباغ",35.839,50.848,0],["اسلامشهر",35.552,51.235,0],["رباط کریم",35.485,51.083,0],["پاکدشت",35.479,51.683,0],["فیروزکوه",35.757,52.771,0],["قدس",35.721,51.109,0],["ملارد",35.666,50.977,0],["پیشوا",35.308,51.727,0],["گلستان",35.518,51.182,0],["پردیس",35.747,51.812,0],["قرچک",35.429,51.578,0]]],["اردبیل","Ardabil",[["اردبیل",38.25,48.293,1],["بیله سوار",39.38,48.355,0],["خلخال",37.618,48.529,0],["مشگین شهر",38.399,47.682,0],["گرمی",39.022,48.08,0],["پارس آباد",39.648,47.917,0],["گیوی",37.686,48.342,0],["نمین",38.427,48.484,0],["نیر",38.035,47.999,0],["سرعین",38.15,48.071,0],["اصلاندوز",39.444,47.406,0],["تازه کندانگوت",39.044,47.745,0]]],["قم","Qom",[["قم",34.64,50.876,1],["جعفریه",34.775,50.517,0],["کهک",34.394,50.864,0]]],["قزوین","Qazvin",[["بوئین زهرا",35.767,50.058,0],["تاکستان",36.071,49.696,0],["قزوین",36.269,50.004,1],["آبیک",36.04,50.531,0],["الوند",36.189,50.064,0],["آوج",35.58,49.223,0]]],["گلستان","Golestan",[["بندر گز",36.774,53.948,0],["بندر ترکمن",36.901,54.072,0],["علی آباد",36.91,54.867,0],["کردکوی",36.793,54.112,0],["گرگان",36.843,54.444,1],["گنبد کاووس",37.25,55.167,0],["مینودشت",37.23,55.372,0],["آق قلا",37.014,54.455,0],["کلاله",37.379,55.493,0],["گلوگاه",36.727,53.809,0],["آزادشهر",37.086,55.172,0],["رامیان",37.016,55.141,0],["مراوه",37.904,55.956,0],["گمیش تپه",37.072,54.077,0],["گالیکش",37.273,55.434,0]]],["خراسان شمالی","North Khorasan",[["اسفراین",37.076,57.51,0],["بجنورد",37.475,57.329,1],["جاجرم",36.95,56.38,0],["شیروان",37.397,57.93,0],["آشخانه",37.562,56.921,0],["گرمه",36.987,56.289,0],["راز",37.934,57.113,0],["صفی آباد",36.695,57.928,0],["پیش قلعه",37.652,57.002,0]]],["خراسان جنوبی","South Khorasan",[["بیرجند",32.866,59.221,1],["اسدیه",32.943,59.72,0],["سربیشه",32.576,59.798,0],["قاین",33.727,59.184,0],["نهبندان",31.542,60.036,0],["حاجی آباد",33.605,59.993,0],["خوسف",32.781,58.89,0]]],["البرز","Alborz",[["کرج",35.833,50.992,1],["هشتگرد",35.962,50.68,0],["نظرآباد",35.954,50.606,0],["طالقان",36.174,50.769,0],["اشتهارد",35.725,50.366,0],["فردیس",35.729,50.985,0]]]]; })(window.MET = window.MET || {});
/* ===== نرمال اقلیمی ۱۹۹۱–۲۰۲۰ برای متئوگرام (r71) =====
   منبع: بازتحلیل ERA5 از Open-Meteo Archive API (CC BY 4.0)، یک درخواست ۳۰ ساله برای هر نقطه (شبکهٔ ۰٫۲۵°)، محاسبه در مرورگر و ذخیره در localStorage.
   برای هر روز سال: میانگین دمای روزانه، میانگین کمینه و بیشینهٔ روزانه، و میانگین بارش روزانه، با پنجرهٔ ±۷ روز (۱۵ روز × ۳۰ سال).
   نرمال «مقدار توصیفی گذشته» است؛ پیش‌بینی نیست. ۲۹ فوریه با ۲۸ فوریه یکی گرفته می‌شود. */
(function(M){
  "use strict";
  const fin = x => typeof x === "number" && isFinite(x), r1 = x => Math.round(x * 10) / 10, W = 7, Y0 = 1991, Y1 = 2020;
  const MD = (() => { const a = []; for(let m = 0; m < 12; m++){ const n = new Date(Date.UTC(2001, m + 1, 0)).getUTCDate(); for(let d = 1; d <= n; d++) a.push([m + 1, d]); } return a; })();   // ۳۶۵ روز
  const doyOf = (m, d) => { let k = 0; for(let i = 0; i < m - 1; i++) k += new Date(Date.UTC(2001, i + 1, 0)).getUTCDate(); return k + Math.min(d, new Date(Date.UTC(2001, m, 0)).getUTCDate()) - 1; };
  const grid = x => Math.round(x * 4) / 4, key = (la, lo) => "mgclim1:" + grid(la).toFixed(2) + "," + grid(lo).toFixed(2);
  function build(j){
    const D = j && j.daily; if(!D || !D.time) throw new Error("no daily");
    const ser = {tm:D.temperature_2m_mean, tx:D.temperature_2m_max, tn:D.temperature_2m_min, pr:D.precipitation_sum}, byDoy = {tm:[], tx:[], tn:[], pr:[]};
    for(const k in byDoy) for(let i = 0; i < 365; i++) byDoy[k].push([]);
    D.time.forEach((s, i) => { const y = +s.slice(0, 4); if(y < Y0 || y > Y1) return; const m = +s.slice(5, 7), d = +s.slice(8, 10); if(m === 2 && d === 29) return; const q = doyOf(m, d); for(const k in ser){ const v = ser[k] && ser[k][i]; if(fin(v)) byDoy[k][q].push(v); } });
    const out = {v:1, la:j.latitude, lo:j.longitude, el:j.elevation, tm:[], tx:[], tn:[], p10:[], p90:[], pr:[], n:0};
    const win = (k, q) => { const a = []; for(let o = -W; o <= W; o++){ const b = byDoy[k][(q + o + 365) % 365]; for(const v of b) a.push(v); } return a; };
    for(let q = 0; q < 365; q++){
      const a = win("tm", q).sort((x, y) => x - y), mean = L => L.reduce((s, v) => s + v, 0) / (L.length || 1);
      if(a.length < 100){ for(const k of ["tm", "tx", "tn", "p10", "p90", "pr"]) out[k].push(null); continue; }
      out.n = Math.max(out.n, a.length); out.tm.push(r1(mean(a))); out.p10.push(r1(a[Math.floor(a.length * 0.1)])); out.p90.push(r1(a[Math.floor(a.length * 0.9)]));
      out.tx.push(r1(mean(win("tx", q)))); out.tn.push(r1(mean(win("tn", q)))); out.pr.push(Math.round(mean(win("pr", q)) * 100) / 100);
    }
    return out;
  }
  const MEMC = new Map();
  async function get(lat, lon, signal){
    const k = key(lat, lon); if(MEMC.has(k)) return MEMC.get(k);
    try{ const c = JSON.parse(localStorage.getItem(k) || "null"); if(c && c.v === 1){ MEMC.set(k, c); return c; } }catch(e){}
    const u = "https://archive-api.open-meteo.com/v1/archive?latitude=" + grid(lat).toFixed(2) + "&longitude=" + grid(lon).toFixed(2) + "&start_date=" + Y0 + "-01-01&end_date=" + Y1 + "-12-31&daily=temperature_2m_mean,temperature_2m_max,temperature_2m_min,precipitation_sum&timezone=Asia%2FTehran";
    const r = await fetch(u, {signal}); const j = await r.json().catch(() => null); if(!r.ok || !j) throw new Error("HTTP " + r.status + (j && j.reason ? " " + j.reason : ""));
    const c = build(j); MEMC.set(k, c); try{ localStorage.setItem(k, JSON.stringify(c)); }catch(e){} return c;
  }
  const at = (c, k, s) => { if(!c) return null; const m = +s.slice(5, 7), d = +s.slice(8, 10); const v = c[k][doyOf(m, d)]; return fin(v) ? v : null; };
  M.clim = {get, at, build, doyOf, years:[Y0, Y1]};
})(globalThis.MET);
/* ===== متئوگرام چندمدلی (r53) — آزمایشگاه محاسبات =====
   داده: Open-Meteo (CC BY 4.0)، برای هر مدل یک درخواست جدا (اگر یک مدل برای این نقطه داده نداشت بقیه از دست نمی‌روند).
   همهٔ زمان‌ها به وقت ایران (timezone=Asia/Tehran). مقدار مفقود null می‌ماند و رسم نمی‌شود؛ هیچ مقداری ساخته یا صفر نمی‌شود.
   میانه فقط جایی رسم می‌شود که دست‌کم ۲ مدل مقدار دارند. نمودارها SVG خودمان است (نه کپی سایتی)؛ حالت برجسته با سایه و
   ستون‌های سه‌بعدی فقط جنبهٔ نمایشی دارد و روی مقدارها اثری ندارد. */
(function(M){
  "use strict";
  const MODELS = [
    ["ecmwf_ifs025", "ECMWF IFS", "#b91c1c"], ["ecmwf_aifs025_single", "ECMWF AIFS", "#f97316"], ["gfs_seamless", "GFS", "#2563eb"],
    ["icon_seamless", "ICON", "#059669"], ["gem_seamless", "GEM", "#7c3aed"],
    ["ukmo_seamless", "UKMO", "#0891b2"], ["jma_seamless", "JMA", "#ca8a04"], ["cma_grapes_global", "CMA", "#65a30d"],
    ["bom_access_global", "ACCESS-G", "#64748b"], ["kma_seamless", "KMA", "#0d9488"],
    ["meteofrance_arpege_world", "ARPEGE", "#db2777"]
  ];
  const HV = ["temperature_2m", "relative_humidity_2m", "wind_speed_10m", "wind_direction_10m", "wind_gusts_10m", "precipitation", "cloud_cover"];
  const KEY = {temperature_2m:"t", relative_humidity_2m:"rh", wind_speed_10m:"ws", wind_direction_10m:"wd", wind_gusts_10m:"wg", precipitation:"pr", cloud_cover:"cc"};
  const fin = x => typeof x === "number" && isFinite(x);
  function url(lat, lon, id){
    return "https://api.open-meteo.com/v1/forecast?latitude=" + lat.toFixed(4) + "&longitude=" + lon.toFixed(4) + "&hourly=" + HV.join(",") +
      "&daily=precipitation_sum&models=" + id + "&forecast_days=16&timezone=Asia%2FTehran&wind_speed_unit=kmh&timeformat=iso8601";
  }
  /* r55: کش ۳۰ دقیقه‌ای + تلاش دوباره روی ۴۲۹ (محدودیت Open-Meteo) تا درخواست کمتر شود */
  const MEM = new Map(), TTL = 30 * 60e3, sleep = ms => new Promise(r => setTimeout(r, ms));
  function cacheGet(u){ const n = Date.now(); const m = MEM.get(u); if(m && n - m.t < TTL) return m.j; try{ const x = JSON.parse(sessionStorage.getItem("mgc:" + u) || "null"); if(x && n - x.t < TTL){ MEM.set(u, x); return x.j; } }catch(e){} return null; }
  function cachePut(u, j){ const x = {t:Date.now(), j}; MEM.set(u, x); try{ sessionStorage.setItem("mgc:" + u, JSON.stringify(x)); }catch(e){ try{ Object.keys(sessionStorage).filter(k => k.indexOf("mgc:") === 0).forEach(k => sessionStorage.removeItem(k)); }catch(e2){} } }
  async function cget(u, signal){
    const c = cacheGet(u); if(c) return {ok:true, status:200, j:c};
    let r, j = null;
    for(let k = 0; k < 3; k++){
      r = await fetch(u, {signal}); j = null; try{ j = await r.json(); }catch(e){}
      if(r.status !== 429 || (j && /daily|hourly/i.test(j.reason || ""))) break;     // ۴۲۹ دقیقه‌ای: صبر و تلاش دوباره؛ ساعتی/روزانه: بی‌فایده
      await sleep(2500 * (k + 1));
    }
    if(r.ok && j && !j.error) cachePut(u, j);
    return {ok:r.ok, status:r.status, j};
  }
  async function fetchOne(lat, lon, id, signal){
    try{
      const q = await cget(url(lat, lon, id), signal), r = q, j = q.j;
      if(!r.ok || !j || j.error) return {id, ok:false, why:r.status === 429 ? "HTTP 429" : ((j && j.reason) || ("HTTP " + r.status))};
      const H = j.hourly || {}, D = j.daily || {}, g = (o, k) => o[k + "_" + id] || o[k] || null;
      if(!Array.isArray(H.time)) return {id, ok:false, why:"no hourly"};
      const s = {}; for(const v of HV){ const a = g(H, v); s[KEY[v]] = Array.isArray(a) ? a.map(x => fin(x) ? x : null) : null; }
      const dp = g(D, "precipitation_sum");
      const any = s.t && s.t.some(fin);
      return {id, ok:!!any, why:any ? "" : "no data", time:H.time, s, dtime:Array.isArray(D.time) ? D.time : [], dpr:Array.isArray(dp) ? dp.map(x => fin(x) ? x : null) : null, elev:j.elevation};
    }catch(e){ return {id, ok:false, why:e.name === "AbortError" ? "timeout" : e.message}; }
  }
  /* دریافت همه و هم‌ترازکردن روی یک محور زمانی مشترک (اجتماع زمان‌ها) */
  async function fetchAll(lat, lon){
    const ac = new AbortController(), to = setTimeout(() => ac.abort(), 90000);
    try{
      const R = new Array(MODELS.length); let nx = 0;
      await Promise.all([0, 1, 2, 3].map(async () => { while(nx < MODELS.length){ const i = nx++; R[i] = await fetchOne(lat, lon, MODELS[i][0], ac.signal); } }));   // حداکثر ۴ درخواست هم‌زمان
      const ok = R.filter(r => r.ok);
      const T = [...new Set([].concat(...ok.map(r => r.time)))].sort(), Ti = new Map(T.map((x, i) => [x, i]));
      const DT = [...new Set([].concat(...ok.map(r => r.dtime)))].sort(), Di = new Map(DT.map((x, i) => [x, i]));
      const mods = ok.map(r => { const m = MODELS.find(q => q[0] === r.id), o = {id:r.id, name:m[1], color:m[2], s:{}, dpr:new Array(DT.length).fill(null)};
        for(const k of Object.values(KEY)){ const a = new Array(T.length).fill(null), src = r.s[k]; if(src) r.time.forEach((x, i) => { a[Ti.get(x)] = src[i]; }); o.s[k] = a; }
        if(r.dpr) r.dtime.forEach((x, i) => { o.dpr[Di.get(x)] = r.dpr[i]; });
        /* بارش تجمعی: جمع ساعتی تا جایی که مدل داده دارد؛ بعد از آخرین مقدار null */
        let acc = 0, last = -1; o.s.pr.forEach((v, i) => { if(fin(v)) last = i; }); o.s.pc = o.s.pr.map((v, i) => { if(i > last) return null; if(fin(v)) acc += v; return +acc.toFixed(2); });
        return o; });
      const elev = (ok.find(r => fin(r.elev)) || {}).elev;
      return {lat, lon, elev, T, DT, mods, fail:R.filter(r => !r.ok).map(r => ({id:r.id, name:(MODELS.find(q => q[0] === r.id) || [])[1], why:r.why}))};
    } finally { clearTimeout(to); }
  }
  const median = a => { const v = a.filter(fin).sort((x, y) => x - y), n = v.length; if(n < 2) return null; return n % 2 ? v[(n - 1) / 2] : (v[n / 2 - 1] + v[n / 2]) / 2; };
  function niceTicks(lo, hi, n){
    if(!(hi > lo)){ hi = lo + 1; }
    const raw = (hi - lo) / n, p = Math.pow(10, Math.floor(Math.log10(raw))), f = raw / p, st = (f < 1.5 ? 1 : f < 3 ? 2 : f < 7 ? 5 : 10) * p;
    const a = Math.floor(lo / st) * st, b = Math.ceil(hi / st) * st, out = []; for(let v = a; v <= b + st * 1e-6; v += st) out.push(+v.toFixed(6)); return out;
  }
  function shade(hex, f){ const n = parseInt(hex.slice(1), 16); let r = n >> 16, g = (n >> 8) & 255, b = n & 255;
    const m = c => Math.round(f >= 0 ? c + (255 - c) * f : c * (1 + f)); return "rgb(" + m(r) + "," + m(g) + "," + m(b) + ")"; }
  /* ---------- زمان محلی (رشته‌های Open-Meteo به وقت ایران‌اند؛ بدون تبدیل منطقهٔ زمانی مرورگر) ---------- */
  const pt = s => { const y = +s.slice(0, 4), mo = +s.slice(5, 7), d = +s.slice(8, 10), h = +(s.slice(11, 13) || 0); return new Date(Date.UTC(y, mo - 1, d, h)); };
  const FMT = {
    fa:{wd:new Intl.DateTimeFormat("fa-IR", {weekday:"short", timeZone:"UTC"}), dm:new Intl.DateTimeFormat("fa-IR-u-ca-persian", {day:"numeric", month:"short", timeZone:"UTC"}), full:new Intl.DateTimeFormat("fa-IR-u-ca-persian", {weekday:"long", day:"numeric", month:"long", hour:"2-digit", minute:"2-digit", timeZone:"UTC", hour12:false}), day:new Intl.DateTimeFormat("fa-IR-u-ca-persian", {weekday:"long", day:"numeric", month:"long", timeZone:"UTC"})},
    en:{wd:new Intl.DateTimeFormat("en-GB", {weekday:"short", timeZone:"UTC"}), dm:new Intl.DateTimeFormat("en-GB", {day:"numeric", month:"short", timeZone:"UTC"}), full:new Intl.DateTimeFormat("en-GB", {weekday:"short", day:"numeric", month:"short", hour:"2-digit", minute:"2-digit", timeZone:"UTC", hour12:false}), day:new Intl.DateTimeFormat("en-GB", {weekday:"long", day:"numeric", month:"long", timeZone:"UTC"})}
  };
  function nowLocal(){ const p = new Intl.DateTimeFormat("en-CA", {timeZone:"Asia/Tehran", year:"numeric", month:"2-digit", day:"2-digit", hour:"2-digit", hour12:false}).formatToParts(new Date()), g = k => (p.find(x => x.type === k) || {}).value;
    return g("year") + "-" + g("month") + "-" + g("day") + "T" + String(+g("hour") % 24).padStart(2, "0") + ":00"; }
  const PARAMS = {
    t:{fa:"دما", en:"Temperature", u:"°C", k:"t", d:1},
    w:{fa:"باد", en:"Wind", u:"km/h", k:"ws", d:0},
    wg:{fa:"تندباد (گاست)", en:"Wind gusts", u:"km/h", k:"wg", d:0, lo:0},
    rh:{fa:"رطوبت نسبی", en:"Relative humidity", u:"%", k:"rh", d:0, lo:0, hi:100},
    cc:{fa:"ابرناکی", en:"Cloud cover", u:"%", k:"cc", d:0, lo:0, hi:100},
    pd:{fa:"بارش روزانه", en:"Daily precipitation", u:"mm", bar:true, d:1, lo:0},
    pc:{fa:"بارش تجمعی", en:"Accumulated precipitation", u:"mm", k:"pc", d:1, lo:0}
  };
  /* ---------- بازهٔ نمایش: از ۰۰ امروز تا N روز ---------- */
  function view(D, days){
    if(!days || days >= 16) return D;
    const nw = nowLocal(), d0 = nw.slice(0, 10) + "T00:00"; let a = D.T.findIndex(x => x >= d0); if(a < 0) a = 0;
    const b = Math.min(D.T.length, a + days * 24); let da = D.DT.findIndex(x => x.slice(0, 10) >= d0.slice(0, 10)); if(da < 0) da = 0; const db = Math.min(D.DT.length, da + days);
    const mods = D.mods.map(m => { const o = Object.assign({}, m), s = {}; for(const k in m.s) s[k] = m.s[k].slice(a, b); o.s = s; o.dpr = m.dpr.slice(da, db);
      let acc = 0, last = -1; s.pr.forEach((v, i) => { if(fin(v)) last = i; }); s.pc = s.pr.map((v, i) => { if(i > last) return null; if(fin(v)) acc += v; return +acc.toFixed(2); }); return o; });
    return Object.assign({}, D, {T:D.T.slice(a, b), DT:D.DT.slice(da, db), mods});
  }
  /* ---------- برازش و روند (روی میانهٔ مدل‌ها؛ فقط نمایشی و توصیفی، نه پیش‌بینی) ---------- */
  function lsq(X, y){ /* کمترین مربعات: X ماتریس n×k */
    const n = y.length, k = X[0].length, A = Array.from({length:k}, () => new Array(k + 1).fill(0));
    for(let i = 0; i < n; i++) for(let r = 0; r < k; r++){ for(let c = 0; c < k; c++) A[r][c] += X[i][r] * X[i][c]; A[r][k] += X[i][r] * y[i]; }
    for(let c = 0; c < k; c++){ let p = c; for(let r = c + 1; r < k; r++) if(Math.abs(A[r][c]) > Math.abs(A[p][c])) p = r; if(Math.abs(A[p][c]) < 1e-12) return null; [A[c], A[p]] = [A[p], A[c]];
      for(let r = 0; r < k; r++) if(r !== c){ const f = A[r][c] / A[c][c]; for(let q = c; q <= k; q++) A[r][q] -= f * A[c][q]; } }
    return A.map((row, i) => row[k] / row[i]);
  }
  function trendFits(ser){ /* ser: آرایهٔ ساعتی (null مجاز) */
    const idx = []; ser.forEach((v, i) => { if(fin(v)) idx.push(i); }); if(idx.length < 24) return null;
    const t = idx.map(i => i / 24), y = idx.map(i => ser[i]);
    const lin = lsq(t.map(x => [1, x]), y); if(!lin) return null;
    const per = lsq(t.map(x => [1, x, Math.cos(2 * Math.PI * x), Math.sin(2 * Math.PI * x), Math.cos(4 * Math.PI * x), Math.sin(4 * Math.PI * x)]), y);
    const f1 = i => lin[0] + lin[1] * i / 24, f2 = per ? (i => { const x = i / 24; return per[0] + per[1] * x + per[2] * Math.cos(2 * Math.PI * x) + per[3] * Math.sin(2 * Math.PI * x) + per[4] * Math.cos(4 * Math.PI * x) + per[5] * Math.sin(4 * Math.PI * x); }) : null;
    let ssr = 0, sst = 0; const m = y.reduce((a, b) => a + b, 0) / y.length; y.forEach((v, j) => { ssr += (v - f1(idx[j])) ** 2; sst += (v - m) ** 2; });
    let ssr2 = 0; if(f2) y.forEach((v, j) => { ssr2 += (v - f2(idx[j])) ** 2; });
    const amp = per ? Math.hypot(per[2], per[3]) : null;
    return {lin:f1, per:f2, slope:lin[1], r2lin:sst > 0 ? 1 - ssr / sst : null, r2per:f2 && sst > 0 ? 1 - ssr2 / sst : null, amp, mean:m};
  }
  function movAvg(ser, w){ const h = Math.floor(w / 2); return ser.map((_, i) => { let s = 0, c = 0; for(let j = i - h; j <= i + h; j++){ if(j >= 0 && j < ser.length && fin(ser[j])){ s += ser[j]; c++; } } return c >= w * 0.75 ? s / c : null; }); }
  const esc = s => String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  let UID = 0;
  /* ---------- رسم ---------- */
  function render(host, D, pk, st){
    D = view(D, st.range); st.fitInfo = null; const en = st.en, L = en ? "en" : "fa", F = FMT[L], P = PARAMS[pk], vis = D.mods.filter(m => !st.hidden.has(m.id)), showMed = !st.hidden.has("median");
    const uid = "mg" + (++UID), box = host.getBoundingClientRect(), phone = (box.width || 900) < 640;
    const nT = D.T.length, nD = D.DT.length, perDay = phone ? 66 : 58;
    const W = Math.max(Math.round(box.width || 900), (P.bar ? nD : nT / 24) * perDay + 60), H = phone ? 320 : 380;
    const ml = 46, mr = 14, mt = 40, mb = 30, pw = W - ml - mr, ph = H - mt - mb;
    /* داده‌های این پارامتر */
    let series, xs, med, xi;
    if(P.bar){ series = vis.map(m => m.dpr); const gw = pw / Math.max(1, nD); xi = i => ml + gw * (i + 0.5); xs = gw;
      med = D.DT.map((_, i) => median(D.mods.map(m => m.dpr[i]))); }
    else { series = vis.map(m => m.s[P.k]); xi = i => ml + (nT > 1 ? pw * i / (nT - 1) : 0);
      med = D.T.map((_, i) => median(D.mods.map(m => m.s[P.k][i]))); }
    let lo = Infinity, hi = -Infinity; for(const a of series.concat(showMed ? [med] : [])) for(const v of a) if(fin(v)){ if(v < lo) lo = v; if(v > hi) hi = v; }
    const CL = st.clim && D.clim ? D.clim : null, cat = (k, i) => M.clim.at(CL, k, D.T[i]);
    if(CL && pk === "t") for(let i = 0; i < nT; i++){ const a = cat("tn", i), b = cat("tx", i); if(fin(a) && a < lo) lo = a; if(fin(b) && b > hi) hi = b; }
    const empty = !(hi >= lo); if(empty){ lo = 0; hi = 1; }
    if(P.lo != null) lo = Math.min(P.lo, lo); if(pk === "rh") hi = Math.min(100, hi);
    if(P.bar || pk === "pc") hi = Math.max(hi, 1);
    if(pk === "wg") hi = Math.max(hi, 66);   /* r94: تا آستانهٔ خطر ۶۰ km/h همیشه دیده شود */
    const pad = (hi - lo) * 0.08; let ticks = niceTicks(P.lo === 0 ? lo : lo - pad, hi + pad, phone ? 5 : 7); if(pk === "rh") ticks = ticks.filter(v => v >= 0 && v <= 100);
    const y0 = ticks[0], y1 = ticks[ticks.length - 1], yv = v => mt + ph - (v - y0) / (y1 - y0 || 1) * ph;
    const o = [];
    o.push('<svg xmlns="http://www.w3.org/2000/svg" class="mgSvg" width="' + W + '" height="' + H + '" viewBox="0 0 ' + W + " " + H + '" font-family="Vazirmatn,Tahoma,sans-serif" direction="ltr">');
    o.push('<defs><linearGradient id="' + uid + 'bg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#f8fbff"/><stop offset="1" stop-color="#eaf1fb"/></linearGradient>' +
      '<filter id="' + uid + 'sh" x="-5%" y="-20%" width="110%" height="140%"><feDropShadow dx="0" dy="1.6" stdDeviation="1.3" flood-color="#0f172a" flood-opacity=".28"/></filter>' +
      '<filter id="' + uid + 'in"><feOffset dy="2"/><feGaussianBlur stdDeviation="3" result="b"/><feComposite in="SourceGraphic" in2="b" operator="over"/></filter>' +
      '<linearGradient id="' + uid + 'sp" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#6366f1" stop-opacity=".22"/><stop offset="1" stop-color="#6366f1" stop-opacity=".06"/></linearGradient>');
    vis.forEach((m, i) => o.push('<linearGradient id="' + uid + "g" + i + '" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="' + shade(m.color, 0.35) + '"/><stop offset=".55" stop-color="' + m.color + '"/><stop offset="1" stop-color="' + shade(m.color, -0.15) + '"/></linearGradient>'));
    o.push("</defs>");
    o.push('<rect x="0" y="0" width="' + W + '" height="' + H + '" rx="14" fill="#fff"/>');
    o.push('<rect x="' + ml + '" y="' + mt + '" width="' + pw + '" height="' + ph + '" rx="8" fill="url(#' + uid + 'bg)" stroke="#dbe4f0"/>');
    /* شب‌ها (۱۸ تا ۰۶) کم‌رنگ و جداکنندهٔ روزها با برچسب روز هفته و تاریخ */
    if(!P.bar){
      let s0 = -1; for(let i = 0; i <= nT; i++){ const h = i < nT ? +D.T[i].slice(11, 13) : -1, night = h >= 18 || (h >= 0 && h < 6);
        if(night && s0 < 0) s0 = i; if((!night || i === nT) && s0 >= 0){ const xa = xi(s0), xb = xi(Math.min(i, nT - 1)); o.push('<rect x="' + xa.toFixed(1) + '" y="' + mt + '" width="' + Math.max(0, xb - xa).toFixed(1) + '" height="' + ph + '" fill="#1e3a8a" opacity=".045"/>'); s0 = -1; } }
      D.T.forEach((s, i) => { if(s.slice(11, 13) !== "00") return; const x = xi(i); o.push('<line x1="' + x.toFixed(1) + '" x2="' + x.toFixed(1) + '" y1="' + mt + '" y2="' + (mt + ph) + '" stroke="#94a3b8" stroke-width=".8" opacity=".55"/>');
        if(i + 12 < nT || i === 0){ const d = pt(s), xc = xi(Math.min(i + 12, nT - 1)); o.push('<text x="' + xc.toFixed(1) + '" y="16" text-anchor="middle" font-size="11.5" font-weight="700" fill="#334155">' + esc(F.wd.format(d)) + '</text><text x="' + xc.toFixed(1) + '" y="30" text-anchor="middle" font-size="10.5" fill="#64748b">' + esc(F.dm.format(d)) + "</text>"); } });
    } else {
      D.DT.forEach((s, i) => { const d = pt(s), x = xi(i); if(i) o.push('<line x1="' + (x - xs / 2).toFixed(1) + '" x2="' + (x - xs / 2).toFixed(1) + '" y1="' + mt + '" y2="' + (mt + ph) + '" stroke="#cbd5e1" stroke-width=".8"/>');
        o.push('<text x="' + x.toFixed(1) + '" y="16" text-anchor="middle" font-size="11.5" font-weight="700" fill="#334155">' + esc(F.wd.format(d)) + '</text><text x="' + x.toFixed(1) + '" y="30" text-anchor="middle" font-size="10.5" fill="#64748b">' + esc(F.dm.format(d)) + "</text>"); });
    }
    /* محور عمودی */
    for(const v of ticks){ const y = yv(v); o.push('<line x1="' + ml + '" x2="' + (ml + pw) + '" y1="' + y.toFixed(1) + '" y2="' + y.toFixed(1) + '" stroke="#cbd5e1" stroke-width="' + (v === 0 && pk === "t" ? 1.4 : .7) + '"' + (v === 0 && pk === "t" ? ' stroke-dasharray="4 3"' : "") + "/>");
      o.push('<text x="' + (ml - 6) + '" y="' + (y + 4).toFixed(1) + '" text-anchor="end" font-size="11" fill="#475569">' + (+v.toFixed(2)) + "</text>"); }
    o.push('<text x="8" y="' + (mt - 6) + '" font-size="11" font-weight="700" fill="#475569">' + esc(P.u) + "</text>");
    /* r94: تندباد ≥ ۶۰ km/h = محدودهٔ خطر (قرمز شفاف + خط قرمز)؛ دمای زیر صفر = آبی بسیار کم‌رنگ */
    if(!empty && !P.bar){
      if(pk === "wg" && y1 > 40){ const ya = yv(Math.min(60, y1)), yb = yv(40); o.push('<rect x="' + ml + '" y="' + ya.toFixed(1) + '" width="' + pw + '" height="' + Math.max(0, yb - ya).toFixed(1) + '" fill="#f97316" opacity=".10"/><line x1="' + ml + '" x2="' + (ml + pw) + '" y1="' + yb.toFixed(1) + '" y2="' + yb.toFixed(1) + '" stroke="#f97316" stroke-width="1" stroke-dasharray="4 3" opacity=".7"/>'); }   // r113: ۴۰–۶۰ km/h نارنجی کم‌رنگ
      if(pk === "wg" && y1 > 60){ const yy = yv(60); o.push('<rect x="' + ml + '" y="' + mt + '" width="' + pw + '" height="' + Math.max(0, yy - mt).toFixed(1) + '" fill="#dc2626" opacity=".10"/><line x1="' + ml + '" x2="' + (ml + pw) + '" y1="' + yy.toFixed(1) + '" y2="' + yy.toFixed(1) + '" stroke="#dc2626" stroke-width="1.6"/><text x="' + (ml + pw - 4) + '" y="' + (yy - 4).toFixed(1) + '" text-anchor="end" font-size="10.5" font-weight="700" fill="#b91c1c">' + (en ? "Danger zone: 60 km/h and above" : "محدودهٔ خطر: ۶۰ کیلومتر بر ساعت و بالاتر") + "</text>"); }
      if(pk === "t" && y0 < 0){ const yy = yv(0); o.push('<rect x="' + ml + '" y="' + Math.max(mt, yy).toFixed(1) + '" width="' + pw + '" height="' + Math.max(0, mt + ph - Math.max(mt, yy)).toFixed(1) + '" fill="#3b82f6" opacity=".09"/><text x="' + (ml + pw - 4) + '" y="' + (Math.min(mt + ph - 4, yy + 12)).toFixed(1) + '" text-anchor="end" font-size="10.5" fill="#1d4ed8" font-weight="700">' + (en ? "Below freezing" : "زیر صفر") + "</text>"); } }
    /* «اکنون» */
    if(!P.bar){ const nw = nowLocal(), k = D.T.indexOf(nw); if(k >= 0){ const x = xi(k); o.push('<line x1="' + x.toFixed(1) + '" x2="' + x.toFixed(1) + '" y1="' + mt + '" y2="' + (mt + ph) + '" stroke="#dc2626" stroke-width="1.2" stroke-dasharray="3 3"/><text x="' + (x + 3).toFixed(1) + '" y="' + (mt + 12) + '" font-size="10" fill="#dc2626">' + (en ? "now" : "اکنون") + "</text>"); } }
    if(CL && pk === "t" && !empty){ /* نوار «دامنهٔ شبانه‌روزی نرمال» (میانگین کمینه تا میانگین بیشینهٔ ۱۹۹۱–۲۰۲۰) و خط میانگین روزانه */
      const up = [], dn = [], mid = []; for(let i = 0; i < nT; i++){ const a = cat("tn", i), b = cat("tx", i), c = cat("tm", i); if(fin(a) && fin(b)){ up.push(xi(i).toFixed(1) + "," + yv(b).toFixed(1)); dn.push(xi(i).toFixed(1) + "," + yv(a).toFixed(1)); } if(fin(c)) mid.push((mid.length ? "L" : "M") + xi(i).toFixed(1) + " " + yv(c).toFixed(1)); }
      if(up.length > 1) o.push('<polygon points="' + up.concat(dn.reverse()).join(" ") + '" fill="#f59e0b" opacity=".14" stroke="#d97706" stroke-width=".6" stroke-opacity=".5" stroke-dasharray="3 3"/>');
      if(mid.length) o.push('<path d="' + mid.join("") + '" fill="none" stroke="#b45309" stroke-width="1.6" stroke-dasharray="6 4" opacity=".85"/>'); }
    if(empty) o.push('<text x="' + (ml + pw / 2) + '" y="' + (mt + ph / 2) + '" text-anchor="middle" font-size="14" fill="#64748b">' + (en ? "No data for the selected models" : "برای مدل‌های انتخابی داده‌ای نیست") + "</text>");
    else if(P.bar){
      /* ستون‌های سه‌بعدی: هر روز یک گروه، هر مدل یک ستون */
      const n = Math.max(1, vis.length), bw = Math.max(1.5, xs * 0.82 / n), dep = Math.min(5, Math.max(1.2, bw * 0.45)), base = yv(Math.max(0, y0));
      D.DT.forEach((_, i) => { const gx = xi(i) - bw * n / 2;
        vis.forEach((m, j) => { const v = m.dpr[i]; if(!fin(v)) return; const x = gx + j * bw, y = yv(v), h = base - y; if(h < 0.5){ o.push('<rect x="' + x.toFixed(1) + '" y="' + (base - 1).toFixed(1) + '" width="' + (bw - .4).toFixed(1) + '" height="1" fill="' + m.color + '" opacity=".5"/>'); return; }
          const w = bw - Math.min(.6, bw * .15);
          o.push('<g><rect x="' + x.toFixed(1) + '" y="' + y.toFixed(1) + '" width="' + w.toFixed(1) + '" height="' + h.toFixed(1) + '" fill="url(#' + uid + "g" + j + ')"/>' +
            '<polygon points="' + [x, y, x + dep, y - dep, x + w + dep, y - dep, x + w, y].map(q => q.toFixed(1)).join(" ") + '" fill="' + shade(m.color, 0.5) + '"/>' +
            '<polygon points="' + [x + w, y, x + w + dep, y - dep, x + w + dep, base - dep, x + w, base].map(q => q.toFixed(1)).join(" ") + '" fill="' + shade(m.color, -0.35) + '"/></g>'); });
        const mv = med[i]; if(showMed && fin(mv)){ const y = yv(mv), xa = gx - 2, xb = gx + bw * n + dep + 2; o.push('<line x1="' + xa.toFixed(1) + '" x2="' + xb.toFixed(1) + '" y1="' + y.toFixed(1) + '" y2="' + y.toFixed(1) + '" stroke="#fff" stroke-width="5" stroke-linecap="round"/><line x1="' + xa.toFixed(1) + '" x2="' + xb.toFixed(1) + '" y1="' + y.toFixed(1) + '" y2="' + y.toFixed(1) + '" stroke="#0f172a" stroke-width="2.6" stroke-linecap="round" filter="url(#' + uid + 'sh)"/>');
          if(mv >= 0.1) o.push('<text x="' + xi(i).toFixed(1) + '" y="' + (y - dep - 5).toFixed(1) + '" text-anchor="middle" font-size="10.5" font-weight="700" fill="#0f172a" paint-order="stroke" stroke="#fff" stroke-width="3">' + mv.toFixed(1) + "</text>"); } });
    } else {
      /* محدودهٔ پراکندگی مدل‌ها (کمینه تا بیشینه) */
      const env = []; for(let i = 0; i < nT; i++){ const v = series.map(a => a[i]).filter(fin); env.push(v.length >= 2 ? [Math.min(...v), Math.max(...v)] : null); }
      let seg = []; const flush = () => { if(seg.length > 1){ const up = seg.map(i => xi(i).toFixed(1) + "," + yv(env[i][1]).toFixed(1)), dn = seg.slice().reverse().map(i => xi(i).toFixed(1) + "," + yv(env[i][0]).toFixed(1)); o.push('<polygon points="' + up.concat(dn).join(" ") + '" fill="url(#' + uid + 'sp)"/>'); } seg = []; };
      env.forEach((e, i) => { if(e) seg.push(i); else flush(); }); flush();
      const path = a => { let d = "", pen = false; a.forEach((v, i) => { if(fin(v)){ d += (pen ? "L" : "M") + xi(i).toFixed(1) + " " + yv(v).toFixed(1); pen = true; } else pen = false; }); return d; };
      o.push('<g filter="url(#' + uid + 'sh)" fill="none" stroke-linejoin="round" stroke-linecap="round">');
      vis.forEach((m, j) => { const d = path(series[j]); if(d) o.push('<path d="' + d + '" stroke="' + m.color + '" stroke-width="' + (phone ? 1.5 : 1.7) + '" opacity=".9"/>'); });
      o.push("</g>");
      if(showMed){ const d = path(med); if(d) o.push('<path d="' + d + '" fill="none" stroke="#fff" stroke-width="6.5" stroke-linejoin="round" stroke-linecap="round" opacity=".9"/><path d="' + d + '" fill="none" stroke="#0f172a" stroke-width="3.2" stroke-linejoin="round" stroke-linecap="round" filter="url(#' + uid + 'sh)"/>'); }
      /* روند و برازش (دما و رطوبت): روی میانهٔ مدل‌ها، یا میانگین مدل‌های نمایان اگر میانه خاموش است */
      if((pk === "t" || pk === "rh") && st.fit && (st.fit.trend || st.fit.per || st.fit.ma)){
        const base = med.some(fin) ? med : D.T.map((_, i) => { const v = vis.map(m => m.s[P.k][i]).filter(fin); return v.length ? v.reduce((a, b) => a + b, 0) / v.length : null; }), F2 = trendFits(base);
        if(F2){ const clampV = v => pk === "rh" ? Math.max(0, Math.min(100, v)) : v, line = (f, col, w, dash) => { let d = ""; for(let i = 0; i < nT; i++){ const v = f(i); if(fin(v)) d += (d ? "L" : "M") + xi(i).toFixed(1) + " " + yv(clampV(v)).toFixed(1); }
            o.push('<path d="' + d + '" fill="none" stroke="#fff" stroke-width="' + (w + 3) + '" stroke-linecap="round" stroke-linejoin="round" opacity=".85"/><path d="' + d + '" fill="none" stroke="' + col + '" stroke-width="' + w + '" stroke-linecap="round" stroke-linejoin="round"' + (dash ? ' stroke-dasharray="' + dash + '"' : "") + "/>"); };
          if(st.fit.ma){ const mv = movAvg(base, 24); line(i => mv[i], "#0ea5e9", 2.4, "7 4"); }
          if(st.fit.per && F2.per) line(F2.per, "#16a34a", 2.2);
          if(st.fit.trend) line(F2.lin, "#e11d48", 2.6, "10 5");
          st.fitInfo = F2; } }
      /* باد: پیکان جهت میانهٔ مدل‌ها (میانگین برداری) هر ۶ ساعت، بالای کادر */
      if(pk === "w"){ for(let i = 0; i < nT; i += (phone ? 12 : 6)){ let u = 0, v = 0, c = 0; for(const m of D.mods){ const s = m.s.ws[i], dd = m.s.wd[i]; if(fin(s) && fin(dd)){ const r = dd * Math.PI / 180; u += -s * Math.sin(r); v += -s * Math.cos(r); c++; } }
          if(c < 2) continue; const dir = (Math.atan2(-u, -v) * 180 / Math.PI + 360) % 360, x = xi(i), y = mt + 14;
          o.push('<g transform="translate(' + x.toFixed(1) + "," + y + ") rotate(" + (dir + 180).toFixed(0) + ')"><path d="M0 -7 L4 3 L0 1 L-4 3 Z" fill="#0f172a" opacity=".75"/></g>'); } }
    }
    if(CL && pk === "pd" && !empty){ let sumN = 0, sumF = 0, n = 0; D.DT.forEach((ds, i) => { const c = M.clim.at(CL, "pr", ds); if(!fin(c)) return; const x = xi(i), y = yv(c); o.push('<line x1="' + (x - xs * 0.46).toFixed(1) + '" x2="' + (x + xs * 0.46).toFixed(1) + '" y1="' + y.toFixed(1) + '" y2="' + y.toFixed(1) + '" stroke="#b45309" stroke-width="2.2" stroke-dasharray="5 3"/>'); const f = med[i]; if(fin(f)){ sumN += c; sumF += f; n++; } });
      if(n) st.climInfo = {u:"mm", f:sumF, nrm:sumN, n, kind:"sum"}; }
    if(CL && pk === "t" && !empty){ let a = 0, n = 0; for(let d0 = 0; d0 < nD; d0++){ const ds = D.DT[d0]; let s = 0, c = 0; for(let i = 0; i < nT; i++) if(D.T[i].slice(0, 10) === ds.slice(0, 10) && fin(med[i])){ s += med[i]; c++; } const nm = M.clim.at(CL, "tm", ds); if(c >= 20 && fin(nm)){ a += s / c - nm; n++; } }
      if(n) st.climInfo = {u:"°C", anom:a / n, n, kind:"anom"}; }
    o.push('<line class="mgX" x1="0" x2="0" y1="' + mt + '" y2="' + (mt + ph) + '" stroke="#0f172a" stroke-width="1" opacity="0"/>');
    o.push('<text x="' + (W - 8) + '" y="' + (H - 8) + '" text-anchor="end" font-size="10" fill="#94a3b8">Open-Meteo.com · CC BY 4.0 · MetStat</text>');
    o.push("</svg>");
    host.innerHTML = '<div class="mgScroll">' + fsBoost(o.join("")) + '<div class="mgTip" hidden></div></div>';
    /* r98: راهنمای خطوط و رنگ‌ها — هر عنصر رسم‌شده روی نمودار توضیح داده می‌شود */
    { const li = (sw, tx) => '<span class="mgK">' + sw + "<span>" + tx + "</span></span>", ln = (c, w, d) => '<svg width="30" height="10" viewBox="0 0 30 10" aria-hidden="true"><path d="M1 5H29" stroke="' + c + '" stroke-width="' + w + '"' + (d ? ' stroke-dasharray="' + d + '"' : "") + ' stroke-linecap="round"/></svg>', bx = (c, op) => '<svg width="22" height="12" viewBox="0 0 22 12" aria-hidden="true"><rect width="22" height="12" rx="2" fill="' + c + '" opacity="' + op + '"/></svg>', K = [];
      if(!P.bar) K.push(li(ln("#475569", 2), en ? "Each coloured line = one model (colour shown in the list/tooltip)" : "هر خط رنگی = پیش‌بینی یک مدل (رنگ هر مدل در فهرست و کادر مقدار دیده می‌شود)"));
      else K.push(li(bx("#3b82f6", .85), en ? "Each coloured column = one model (daily total)" : "هر ستون رنگی = یک مدل (جمع روزانه)"));
      if(showMed) K.push(li(ln("#0f172a", 3.2), en ? "Median of the models (middle value; less affected by one outlier model)" : "میانهٔ مدل‌ها (مقدار میانی؛ کمتر از میانگین تحت‌تأثیر یک مدل دورافتاده است)"));
      if(!P.bar) K.push(li(bx("#6366f1", .25), en ? "Spread of the models (lowest to highest) — wider = more uncertainty" : "محدودهٔ پراکندگی مدل‌ها (کمترین تا بیشترین) — هرچه پهن‌تر، عدم‌قطعیت بیشتر"));
      if(!P.bar) K.push(li(ln("#dc2626", 1.4, "3 3"), en ? "Now" : "اکنون"));
      if(CL && pk === "t"){ K.push(li(bx("#f59e0b", .3), en ? "Normal daily range 1991–2020 (mean min to mean max)" : "دامنهٔ نرمال شبانه‌روزی ۱۹۹۱–۲۰۲۰ (میانگین کمینه تا میانگین بیشینه)")); K.push(li(ln("#b45309", 1.8, "6 4"), en ? "Normal daily mean" : "میانگین روزانهٔ نرمال")); }
      if(CL && pk === "pd") K.push(li(ln("#b45309", 2.2, "5 3"), en ? "Normal daily precipitation" : "بارش روزانهٔ نرمال"));
      if(pk === "t") K.push(li(bx("#3b82f6", .2), en ? "Blue tint = below 0 °C" : "سایهٔ آبی = زیر صفر درجه"));
      if(pk === "wg") K.push(li(ln("#f97316", 1.5), en ? "Strong gusts 40–60 km/h (light orange band)" : "تندباد قوی ۴۰ تا ۶۰ km/h (نوار نارنجی کم‌رنگ)"));
      if(pk === "wg") K.push(li(ln("#dc2626", 2), en ? "Dangerous gust threshold (60 km/h)" : "آستانهٔ تندباد خطرناک (۶۰ km/h)"));
      if(pk === "w") K.push(li('<span style="font-size:14px">▲</span>', en ? "Arrows = wind direction (median of models, every 6 h; points where the wind blows to)" : "پیکان = جهت باد (میانهٔ مدل‌ها، هر ۶ ساعت؛ جهت وزش باد را نشان می‌دهد)"));
      if((pk === "t" || pk === "rh") && st.fit){ if(st.fit.ma) K.push(li(ln("#0ea5e9", 2.4, "7 4"), en ? "24 h moving average" : "میانگین متحرک ۲۴ ساعته")); if(st.fit.per) K.push(li(ln("#16a34a", 2.2), en ? "Fitted daily cycle" : "برازش چرخهٔ شبانه‌روزی")); if(st.fit.trend) K.push(li(ln("#e11d48", 2.6, "10 5"), en ? "Linear trend" : "روند خطی")); }
      host.insertAdjacentHTML("beforeend", '<details class="mgKeyBox" open><summary>' + (en ? "Chart key" : "راهنمای نمودار") + '</summary><div class="mgKey">' + K.join("") + "</div></details>"); }
    const sc = host.querySelector(".mgScroll"), sv = sc.querySelector("svg"), tip = sc.querySelector(".mgTip"), xl = sv.querySelector(".mgX");
    /* خواندن مقدار: حرکت نشانگر یا لمس */
    function at(ev){
      const r = sv.getBoundingClientRect(), x = (ev.clientX - r.left) * W / r.width; if(x < ml - 4 || x > ml + pw + 4){ tip.hidden = true; xl.setAttribute("opacity", 0); return; }
      let i, lab;
      if(P.bar){ i = Math.max(0, Math.min(nD - 1, Math.floor((x - ml) / xs))); lab = F.day.format(pt(D.DT[i])); }
      else { i = Math.max(0, Math.min(nT - 1, Math.round((x - ml) / pw * (nT - 1)))); lab = F.full.format(pt(D.T[i])); }
      const X = xi(i); xl.setAttribute("x1", X); xl.setAttribute("x2", X); xl.setAttribute("opacity", .45);
      const rows = vis.map((m, j) => [m, series[j][i]]).filter(q => fin(q[1])).sort((a, b) => b[1] - a[1]);
      const fmt = v => v.toFixed(P.d);
      let h = '<b>' + esc(lab) + "</b>";
      if(showMed && fin(med[i])) h += '<div class="mgTr mgTm"><i style="background:#0f172a"></i><span>' + (en ? "Median" : "میانه") + "</span><b>" + fmt(med[i]) + " " + P.u + "</b></div>";
      h += rows.map(([m, v]) => { let ex = ""; if(pk === "w"){ const g = m.s.wg[i], d = m.s.wd[i]; ex = [fin(g) ? "<bdi>" + (en ? "G " : "تندباد ") + g.toFixed(0) + "</bdi>" : "", fin(d) ? '<bdi dir="ltr">' + d.toFixed(0) + "°</bdi>" : ""].filter(Boolean).join(" · "); }
        return '<div class="mgTr"><i style="background:' + m.color + '"></i><span>' + esc(m.name) + "</span><b>" + fmt(v) + " " + P.u + "</b><small>" + ex + "</small></div>"; }).join("") || '<div class="mgTr">' + (en ? "no value" : "بدون مقدار") + "</div>";
      tip.innerHTML = h; tip.hidden = false;
      const px = X * r.width / W + (r.left - sc.getBoundingClientRect().left) + sc.scrollLeft, tw = tip.offsetWidth, sw = sc.scrollLeft + sc.clientWidth;
      tip.style.left = Math.max(sc.scrollLeft + 4, Math.min(sw - tw - 4, px + 14 + tw > sw ? px - tw - 14 : px + 14)) + "px"; tip.style.top = (mt + 6) + "px";
    }
    sv.addEventListener("pointermove", at); sv.addEventListener("pointerdown", at);
    sv.addEventListener("pointerleave", e => { if(e.pointerType === "mouse"){ tip.hidden = true; xl.setAttribute("opacity", 0); } });
    /* روی گوشی کادر به «اکنون» اسکرول شود */
    if(sc.scrollWidth > sc.clientWidth && !P.bar){ const k = D.T.indexOf(nowLocal()); if(k > 0) sc.scrollLeft = Math.max(0, xi(k) - 40); }
    return sv;
  }
  /* r132: گلباد از سری ساعتی همهٔ مدل‌های دریافت‌شده (جهت = جایی که باد از آن می‌وزد؛ سرعت km/h).
     ۱۶ جهت × ۵ طبقهٔ سرعت؛ فراوانی ٪ از کل داده‌های معتبر (مدل×ساعت)؛ آرامش (<۱ km/h) جدا. فقط شمارش — هیچ فرمول فیزیکی تازه‌ای نیست. */
  const WR_CLS = [[1, 10, "#93c5fd"], [10, 20, "#3b82f6"], [20, 30, "#f59e0b"], [30, 40, "#ef4444"], [40, 1e9, "#7f1d1d"]];
  function windrose(D, o){
    o = o || {}; const en = !!o.en, n = Math.max(1, Math.min(16, +o.days || 7)) * 24, N = 16, bins = Array.from({length:N}, () => new Array(WR_CLS.length).fill(0));
    let tot = 0, calm = 0, i0 = 0; if(o.from){ const k = D.T.findIndex(x => x >= o.from); if(k > 0) i0 = k; }
    for(const m of D.mods){ const ws = m.s.ws, wd = m.s.wd; if(!ws || !wd) continue;
      for(let i = i0; i < Math.min(ws.length, i0 + n); i++){ const v = ws[i], d = wd[i]; if(!fin(v) || !fin(d)) continue; tot++; if(v < 1){ calm++; continue; }
        const c = WR_CLS.findIndex(q => v >= q[0] && v < q[1]); bins[Math.round((((d % 360) + 360) % 360) / 22.5) % N][c]++; } }
    if(!tot) return "";
    const W = 360, cx = W / 2, cy = W / 2 + 6, R = 130, sec = bins.map(b => b.reduce((a, c) => a + c, 0) / tot * 100), mx = Math.max(8, Math.ceil(Math.max(...sec) / 4) * 4), r = f => R * Math.sqrt(f / mx);
    const pt = (a, rr) => [cx + rr * Math.sin(a), cy - rr * Math.cos(a)], esc = x => String(x).replace(/&/g, "&amp;").replace(/</g, "&lt;");
    let g = "";
    for(const f of [mx / 4, mx / 2, mx * 3 / 4, mx]) g += '<circle cx="' + cx + '" cy="' + cy + '" r="' + r(f).toFixed(1) + '" fill="none" stroke="#cbd5e1" stroke-width="1"/><text x="' + (cx + 3) + '" y="' + (cy - r(f) - 2).toFixed(1) + '" font-size="9" fill="#64748b">' + +f.toFixed(1) + '%</text>';
    for(let k = 0; k < 8; k++){ const a = k * Math.PI / 4, q = pt(a, R + 2); g += '<line x1="' + cx + '" y1="' + cy + '" x2="' + q[0].toFixed(1) + '" y2="' + q[1].toFixed(1) + '" stroke="#e2e8f0"/>'; }
    for(let k = 0; k < N; k++){ let acc = 0; const a0 = (k - 0.42) * Math.PI / 8, a1 = (k + 0.42) * Math.PI / 8;
      for(let c = 0; c < WR_CLS.length; c++){ const f0 = acc, f1 = acc + bins[k][c] / tot * 100; acc = f1; if(!(f1 > f0)) continue; const r0 = r(f0), r1 = r(f1), A = pt(a0, r1), B = pt(a1, r1), C = pt(a1, r0), E = pt(a0, r0);
        g += '<path d="M' + E[0].toFixed(1) + ' ' + E[1].toFixed(1) + ' L' + A[0].toFixed(1) + ' ' + A[1].toFixed(1) + ' A' + r1.toFixed(1) + ' ' + r1.toFixed(1) + ' 0 0 1 ' + B[0].toFixed(1) + ' ' + B[1].toFixed(1) + ' L' + C[0].toFixed(1) + ' ' + C[1].toFixed(1) + ' A' + r0.toFixed(1) + ' ' + r0.toFixed(1) + ' 0 0 0 ' + E[0].toFixed(1) + ' ' + E[1].toFixed(1) + ' Z" fill="' + WR_CLS[c][2] + '" stroke="#fff" stroke-width=".6"/>'; } }
    const L = en ? ["N", "E", "S", "W"] : ["ش", "ق", "ج", "غ"];
    L.forEach((t, k) => { const q = pt(k * Math.PI / 2, R + 16); g += '<text x="' + q[0].toFixed(1) + '" y="' + (q[1] + 4).toFixed(1) + '" text-anchor="middle" font-size="13" font-weight="700" fill="#0f172a">' + t + '</text>'; });
    const lg = WR_CLS.map((q, i) => '<rect x="' + (10 + i * 66) + '" y="' + (W + 22) + '" width="10" height="10" fill="' + q[2] + '"/><text x="' + (24 + i * 66) + '" y="' + (W + 31) + '" font-size="10" fill="#0f172a">' + (q[1] > 1e8 ? "≥" + q[0] : q[0] + "–" + q[1]) + '</text>').join("");
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + W + ' ' + (W + 52) + '" width="100%" style="max-width:420px;direction:ltr" font-family="Vazirmatn,Tahoma,sans-serif">' +
      '<rect width="100%" height="100%" fill="#fff"/>' + g + lg +
      '<text x="10" y="' + (W + 46) + '" font-size="10" fill="#475569" style="unicode-bidi:plaintext">' + esc(en ? "Direction = where wind comes FROM · calm: " + (calm / tot * 100).toFixed(0) + "%" : "جهت = منشأ باد · آرامش: " + (calm / tot * 100).toFixed(0) + "٪") + '</text></svg>';
  }
  M.mg = {cget, MODELS, PARAMS, fetchAll, windrose, render, median, url, view, trendFits, movAvg, lsq};
})(globalThis.MET = globalThis.MET || {});
/* ===== Skew-T مدرن و پرجزئیات (r55) — دوبعدی و سه‌بعدی =====
   SVG خالص و مستقل (استایل درون‌خطی) تا ذخیرهٔ SVG/PNG وفادار بماند. محاسبه‌ها همه از هستهٔ MET (M.lab / M.thermo / M.analysis)؛ رنگ‌ها فقط نمایشی‌اند.
   نمایش سه‌بعدی یک تصویر شبه‌سه‌بعدی (تصویر مایل با زاویهٔ قابل‌چرخش) است: هر منحنی روی یک «شیشهٔ» جدا و پرده‌ای بیرون‌آمده؛ عمق فقط جنبهٔ نمایشی دارد و مقدار نمی‌سازد. */
(function(){
  "use strict";
  const M = globalThis.MET, C = M.C, T = M.thermo, PF = M.profile, W = M.wind, S = {};
  const fin = x => typeof x === "number" && isFinite(x);
  const f1 = x => (Math.round(x * 10) / 10).toString(), f0 = x => Math.round(x).toString();
  const esc = s => String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;");
  const G = {W:980, H:690, ML:66, MT:40, MB:46, pw:610, ph:604, pb:1050, pt:100, Tmin:-40, Trange:86, k:0.82};
  function geom(pTop){
    const g = Object.assign({}, G); g.pt = pTop || 100; g.sx = g.pw / g.Trange; const lr = Math.log(g.pb / g.pt);
    g.y = p => g.MT + g.ph * (Math.log(p / g.pt) / lr); g.yb = g.MT + g.ph;
    g.x = (tc, p) => g.ML + (tc - g.Tmin) * g.sx + (g.yb - g.y(p)) * g.k;
    g.pFromY = y => g.pt * Math.exp(lr * (y - g.MT) / g.ph); return g;
  }
  const pts = a => a.map(q => f1(q[0]) + "," + f1(q[1])).join(" ");
  const poly = (a, st, fill) => '<polyline points="' + pts(a) + '" fill="' + (fill || "none") + '" ' + st + "/>";
  const L = (en, fa, e) => en ? e : fa;
  const BC = {t:"#e11d48", td:"#16a34a", tw:"#0891b2", par:"#111827"};
  /* فشار در ارتفاع AGL داده‌شده (از z پروفایل) */
  function pAtZ(prof, zAgl){ const z0 = prof.z[0]; if(!fin(z0)) return null; const zt = z0 + zAgl; for(let i = 0; i < prof.p.length - 1; i++){ const a = prof.z[i], b = prof.z[i + 1]; if(fin(a) && fin(b) && a <= zt && b >= zt && b > a){ const f = (zt - a) / (b - a); return Math.exp(Math.log(prof.p[i]) + f * (Math.log(prof.p[i + 1]) - Math.log(prof.p[i]))); } } return null; }
  function levelP(prof, tc){ for(let i = 0; i < prof.p.length - 1; i++) if(prof.Tk[i] - C.zeroC > tc && prof.Tk[i + 1] - C.zeroC <= tc){ const f = (prof.Tk[i] - C.zeroC - tc) / (prof.Tk[i] - prof.Tk[i + 1]); return Math.exp(Math.log(prof.p[i]) + f * (Math.log(prof.p[i + 1]) - Math.log(prof.p[i]))); } return null; }
  const stull = (t, rh) => t * Math.atan(0.151977 * Math.sqrt(rh + 8.313659)) + Math.atan(t + rh) - Math.atan(rh - 1.676331) + 0.00391838 * Math.pow(rh, 1.5) * Math.atan(0.023101 * rh) - 4.686035;
  function twProf(prof){ return prof.p.map((p, i) => { const t = prof.Tk[i] - C.zeroC, rh = Math.min(99, Math.max(5, T.rhFromDewpoint(prof.Tk[i], prof.Tdk[i]) * 100)); return (t > -20 && t < 50) ? stull(t, rh) : null; }); }
  function barb(x, y, u, v, len, col){
    const spd = Math.hypot(u, v) / W.KT, dir = W.direction(u, v), c = col || "#1e293b";
    if(spd < 2.5) return '<circle cx="' + f1(x) + '" cy="' + f1(y) + '" r="3" fill="none" stroke="' + c + '" stroke-width="1"/>';
    let s = Math.round(spd / 5) * 5, d = "M0,0 L0," + (-len), yy = 0; const step = 4.5, bl = 11;
    while(s >= 50){ d += " M0," + (-len + yy) + " L" + bl + "," + (-len + yy + 3) + " L0," + (-len + yy + 6) + " Z"; yy += 7; s -= 50; }
    if(yy) yy += 1; while(s >= 10){ d += " M0," + (-len + yy) + " l" + bl + ",-4"; yy += step; s -= 10; } if(s >= 5){ if(yy === 0) yy += step; d += " M0," + (-len + yy) + " l" + (bl / 2) + ",-2"; }
    return '<g transform="translate(' + f1(x) + "," + f1(y) + ") rotate(" + f1(dir) + ')"><path d="' + d + '" stroke="' + c + '" stroke-width="1.25" fill="' + c + '"/></g>';
  }
  const spdCol = ms => { const k = ms / W.KT; return k < 15 ? "#64748b" : k < 30 ? "#0284c7" : k < 50 ? "#7c3aed" : k < 70 ? "#c2410c" : "#be123c"; };
  /* برچسب‌های ترازها با فاصله‌گذاری عمودی */
  function spread(items, minGap, lo, hi){ items.sort((a, b) => a.y - b.y); for(let i = 1; i < items.length; i++) if(items[i].y - items[i - 1].y < minGap) items[i].y = items[i - 1].y + minGap;
    const over = items.length ? items[items.length - 1].y - hi : 0; if(over > 0) for(let i = items.length - 1; i >= 0; i--){ items[i].y -= over; if(i && items[i].y - items[i - 1].y < minGap) continue; } items.forEach(it => { if(it.y < lo) it.y = lo; }); return items; }
  function marks(res, X, en, prof){
    const m = []; const add = (p, lab, col) => { if(fin(p)) m.push({p, lab, col}); };
    add(res.items.LCL.v, "LCL", "#0d9488"); add(res.lfc, "LFC", "#b45309"); add(res.el, "EL", "#7e22ce"); add(X.cclP, "CCL", "#0369a1"); add(X.fzlP, L(en, "۰°C", "0°C"), "#2563eb"); add(X.wbzP, "WBZ", "#0891b2");
    for(const t of [-10, -20, -30]){ add(levelP(prof, t), t + "°C", "#64748b"); } return m;
  }
  /* ---------- نمای دوبعدی ---------- */
  S.svg = function(res, o){
    o = o || {}; const en = !!o.en, prof = res.prof, g = geom(100), X = (M.analysis ? M.analysis.features(res) : {}), uid = "s2" + Math.floor(Math.random() * 1e6);
    const opt = Object.assign({moist:true, mix:true, wet:true, barbs:true, marks:true, panel:true, hail:true}, o.layers || {});
    const hasZ = fin(prof.z && prof.z[0]);
    let b = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + g.W + " " + g.H + '" font-family="Vazirmatn,Tahoma,sans-serif" font-size="10.5" style="width:100%;height:auto;display:block;background:#f1f5f9;direction:ltr" role="img" aria-label="Skew-T log-p">';
    b += '<defs><clipPath id="' + uid + 'c"><rect x="' + g.ML + '" y="' + g.MT + '" width="' + g.pw + '" height="' + g.ph + '"/></clipPath>' +
      '<linearGradient id="' + uid + 'bg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#e8f0fb"/><stop offset=".55" stop-color="#f8fafc"/><stop offset="1" stop-color="#fdf6e9"/></linearGradient>' +
      '<linearGradient id="' + uid + 'cp" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#f97316" stop-opacity=".62"/><stop offset="1" stop-color="#dc2626" stop-opacity=".30"/></linearGradient>' +
      '<linearGradient id="' + uid + 'ci" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#3b82f6" stop-opacity=".5"/><stop offset="1" stop-color="#1d4ed8" stop-opacity=".22"/></linearGradient>' +
      '<filter id="' + uid + 'gl" x="-5%" y="-5%" width="110%" height="110%"><feDropShadow dx="0" dy="1.4" stdDeviation="1.6" flood-color="#0f172a" flood-opacity=".32"/></filter>' +
      '<filter id="' + uid + 'ps" x="-10%" y="-30%" width="120%" height="170%"><feDropShadow dx="0" dy="1" stdDeviation="1" flood-color="#0f172a" flood-opacity=".25"/></filter></defs>';
    b += '<rect width="' + g.W + '" height="' + g.H + '" fill="#f1f5f9"/>';
    b += '<rect x="' + g.ML + '" y="' + g.MT + '" width="' + g.pw + '" height="' + g.ph + '" rx="10" fill="url(#' + uid + 'bg)" stroke="#cbd5e1" filter="url(#' + uid + 'ps)"/>';
    b += '<g clip-path="url(#' + uid + 'c)">';
    const yg = g.y(prof.p[0]); if(yg < g.yb) b += '<rect x="' + g.ML + '" y="' + f1(yg) + '" width="' + g.pw + '" height="' + f1(g.yb - yg) + '" fill="#a8a29e" opacity=".5"/><line x1="' + g.ML + '" x2="' + (g.ML + g.pw) + '" y1="' + f1(yg) + '" y2="' + f1(yg) + '" stroke="#78716c" stroke-width="1.5"/>';
    // منطقهٔ رشد تگرگ (−۱۰ تا −۳۰ °C)
    if(opt.hail){ const a = levelP(prof, -10), c = levelP(prof, -30); if(fin(a) && fin(c)) b += '<rect x="' + g.ML + '" y="' + f1(g.y(c)) + '" width="' + g.pw + '" height="' + f1(g.y(a) - g.y(c)) + '" fill="#60a5fa" opacity=".10"/><text x="' + (g.ML + 8) + '" y="' + f1(g.y(c) + 12) + '" font-size="9.5" fill="#3b82f6" opacity=".85">' + esc(L(en, "منطقهٔ رشد تگرگ (−۱۰ تا −۳۰ °C)", "Hail growth zone (−10 to −30 °C)")) + "</text>"; }
    for(let t = -140; t <= 60; t += 10){ const z = t === 0; b += '<line x1="' + f1(g.x(t, g.pb)) + '" y1="' + f1(g.y(g.pb)) + '" x2="' + f1(g.x(t, g.pt)) + '" y2="' + f1(g.y(g.pt)) + '" stroke="' + (z ? "#3b82f6" : "#cbd5e1") + '" stroke-width="' + (z ? 1.3 : 0.7) + '"' + (z ? ' stroke-dasharray="6 3"' : "") + "/>"; }
    for(let p = 1000; p >= 100; p -= 50){ const major = p % 100 === 0; b += '<line x1="' + g.ML + '" x2="' + (g.ML + g.pw) + '" y1="' + f1(g.y(p)) + '" y2="' + f1(g.y(p)) + '" stroke="' + (major ? "#94a3b8" : "#e2e8f0") + '" stroke-width="' + (major ? 0.9 : 0.5) + '"/>'; }
    const pg = []; for(let p = g.pb; p >= g.pt - 1e-9; p -= 25) pg.push(p);
    for(let th = 250; th <= 520; th += 10){ const q = pg.map(p => [g.x(T.dryLapse(p, th, 1000) - C.zeroC, p), g.y(p)]); b += poly(q, 'stroke="#f0c9a0" stroke-width="0.75"'); }
    if(opt.moist) for(let t0 = -10; t0 <= 36; t0 += 4){ const pp = []; for(let p = 1000; p >= g.pt - 1e-9; p -= 25) pp.push(p); const tk = T.moistLapse(pp, t0 + C.zeroC, 1000);
      if(tk){ b += poly(pp.map((p, i) => [g.x(tk[i] - C.zeroC, p), g.y(p)]), 'stroke="#86efac" stroke-width="0.8" stroke-dasharray="4 2.5"'); const j = Math.min(pp.length - 1, 11); b += '<text x="' + f1(g.x(tk[j] - C.zeroC, pp[j]) + 3) + '" y="' + f1(g.y(pp[j])) + '" font-size="8" fill="#16a34a" opacity=".8">' + t0 + "</text>"; } }
    if(opt.mix) for(const w of [0.4, 1, 2, 4, 7, 10, 14, 20, 28]){ const q = []; for(let p = g.pb; p >= 600; p -= 25) q.push([g.x(T.dewpointFromE(T.vaporPressure(p, w / 1000)) - C.zeroC, p), g.y(p)]); b += poly(q, 'stroke="#a3e635" stroke-width="0.8" stroke-dasharray="1.5 3.5"'); const e = q[q.length - 1]; b += '<text x="' + f1(e[0]) + '" y="' + f1(e[1] - 3) + '" fill="#65a30d" font-size="8.5" text-anchor="middle">' + w + "</text>"; }
    // CAPE/CIN
    const pc = M.lab.parcelCurve(prof, o.parcel || res.parcelType);
    if(pc){ const envT = p => PF.interpLog(p, prof.p, prof.Tk), P = pc.p, d = P.map((p, i) => pc.Tk[i] - envT(p)), lfc = res.lfc;
      if(fin(lfc)) for(let i = 0; i < P.length - 1; i++){ const a = {p:P[i], tp:pc.Tk[i], te:envT(P[i]), d:d[i]}, c = {p:P[i + 1], tp:pc.Tk[i + 1], te:envT(P[i + 1]), d:d[i + 1]}; if(!fin(a.d) || !fin(c.d)) continue;
        const parts = []; if(a.d * c.d < 0){ const f = a.d / (a.d - c.d), pm = Math.exp(Math.log(a.p) + f * (Math.log(c.p) - Math.log(a.p))), tm = envT(pm); parts.push([a, {p:pm, tp:tm, te:tm, d:0}]); parts.push([{p:pm, tp:tm, te:tm, d:0}, c]); } else parts.push([a, c]);
        for(const [s0, s1] of parts){ const m = (s0.d + s1.d) / 2, pm = Math.sqrt(s0.p * s1.p); if(m === 0) continue; const pos = m > 0; if(pos && pm > lfc + 1e-6) continue; if(!pos && pm < lfc - 1e-6) continue;
          const q = [[g.x(s0.tp - C.zeroC, s0.p), g.y(s0.p)], [g.x(s1.tp - C.zeroC, s1.p), g.y(s1.p)], [g.x(s1.te - C.zeroC, s1.p), g.y(s1.p)], [g.x(s0.te - C.zeroC, s0.p), g.y(s0.p)]]; b += '<polygon points="' + pts(q) + '" fill="url(#' + uid + (pos ? "cp" : "ci") + ')"/>'; } } }
    // ناحیهٔ اختلاف دما-شبنم (رطوبت): سایهٔ آبی کم‌رنگ
    { const a = prof.p.map((p, i) => [g.x(prof.Tk[i] - C.zeroC, p), g.y(p)]), c = prof.p.map((p, i) => [g.x(prof.Tdk[i] - C.zeroC, p), g.y(p)]).reverse(); b += '<polygon points="' + pts(a.concat(c)) + '" fill="#38bdf8" opacity=".10"/>'; }
    // منحنی‌ها
    if(opt.wet){ const tw = twProf(prof); const q = []; prof.p.forEach((p, i) => { if(fin(tw[i])) q.push([g.x(tw[i], p), g.y(p)]); }); if(q.length > 1) b += poly(q, 'stroke="' + BC.tw + '" stroke-width="1.5" stroke-dasharray="5 3"'); }
    b += '<g filter="url(#' + uid + 'gl)">' + poly(prof.p.map((p, i) => [g.x(prof.Tdk[i] - C.zeroC, p), g.y(p)]), 'stroke="' + BC.td + '" stroke-width="2.8" stroke-linejoin="round" stroke-linecap="round"') + poly(prof.p.map((p, i) => [g.x(prof.Tk[i] - C.zeroC, p), g.y(p)]), 'stroke="' + BC.t + '" stroke-width="3" stroke-linejoin="round" stroke-linecap="round"') + "</g>";
    if(pc) b += poly(pc.p.map((p, i) => [g.x(pc.Tk[i] - C.zeroC, p), g.y(p)]), 'stroke="' + BC.par + '" stroke-width="2" stroke-dasharray="7 3.5"');
    // ترازها: خط ریز + برچسب قرصی در لبهٔ راست
    const mk = opt.marks ? spread(marks(res, X, en, prof).filter(m => m.p >= g.pt && m.p <= g.pb).map(m => Object.assign(m, {y:g.y(m.p), y0:g.y(m.p)})), 14, g.MT + 8, g.yb - 8) : [];
    for(const m of mk) b += '<line x1="' + (g.ML + g.pw - 78) + '" x2="' + (g.ML + g.pw) + '" y1="' + f1(m.y0) + '" y2="' + f1(m.y0) + '" stroke="' + m.col + '" stroke-width="1.2" opacity=".7" stroke-dasharray="3 2"/>';
    b += "</g>";
    for(const m of mk){ const w = 12 + (m.lab.length + 5) * 5.6, x = g.ML + g.pw - w - 4; b += '<g filter="url(#' + uid + 'ps)"><rect x="' + f1(x) + '" y="' + f1(m.y - 8) + '" width="' + f1(w) + '" height="15" rx="7.5" fill="#fff" stroke="' + m.col + '"/><text x="' + f1(x + w / 2) + '" y="' + f1(m.y + 3) + '" text-anchor="middle" font-size="9.5" font-weight="700" fill="' + m.col + '"><tspan>' + esc(m.lab) + "</tspan> <tspan>" + f0(m.p) + "</tspan></text></g>"; }
    // محورها
    for(let p = 1000; p >= 100; p -= 100) b += '<text x="' + (g.ML - 6) + '" y="' + f1(g.y(p) + 3.5) + '" text-anchor="end" fill="#475569" font-weight="600">' + p + "</text>";
    b += '<text x="14" y="' + f1(g.MT + g.ph / 2) + '" fill="#475569" font-weight="700" transform="rotate(-90 14 ' + f1(g.MT + g.ph / 2) + ')" text-anchor="middle">hPa</text>';
    if(hasZ) for(let km = 1; km <= 14; km++){ const p = pAtZ(prof, km * 1000); if(!fin(p) || p < g.pt) continue; const y = g.y(p); b += '<line x1="' + g.ML + '" x2="' + (g.ML + 6) + '" y1="' + f1(y) + '" y2="' + f1(y) + '" stroke="#7c3aed" stroke-width="1.4"/><text x="' + (g.ML + 9) + '" y="' + f1(y + 3.5) + '" font-size="9" fill="#7c3aed" font-weight="700">' + km + " km</text>"; }
    for(let t = -40; t <= 40; t += 10) b += '<text x="' + f1(g.x(t, g.pb)) + '" y="' + (g.yb + 14) + '" text-anchor="middle" fill="#475569" font-weight="600">' + t + "</text>";
    b += '<text x="' + f1(g.ML + g.pw / 2) + '" y="' + (g.H - 10) + '" text-anchor="middle" fill="#475569" font-weight="700">' + esc(L(en, "دما در تراز ۱۰۵۰ hPa (°C)", "Temperature at 1050 hPa (°C)")) + "</text>";
    // بارب باد
    const wi = []; for(let i = 0; i < prof.p.length; i++) if(fin(prof.u[i]) && fin(prof.v[i])) wi.push(i);
    const bx = g.ML + g.pw + 24;
    if(opt.barbs && wi.length){ b += '<line x1="' + bx + '" x2="' + bx + '" y1="' + g.MT + '" y2="' + g.yb + '" stroke="#e2e8f0" stroke-width="1.2"/>'; let last = -99;
      for(const i of wi){ const y = g.y(prof.p[i]); if(y < g.MT || y > g.yb || Math.abs(y - last) < 15) continue; last = y; b += barb(bx, y, prof.u[i], prof.v[i], 23, spdCol(Math.hypot(prof.u[i], prof.v[i]))); }
      b += '<text x="' + bx + '" y="' + (g.MT - 10) + '" text-anchor="middle" font-size="9" fill="#64748b">' + esc(L(en, "باد (kt)", "wind (kt)")) + "</text>"; }
    b += '<text x="' + (g.ML) + '" y="' + (g.MT - 12) + '" font-size="13" font-weight="800" fill="#0f172a">' + esc(o.title || "Skew-T log-p") + "</text>";
    b += '<g id="skCur2" style="display:none"><line id="skCl2" x1="' + g.ML + '" x2="' + (g.ML + g.pw) + '" y1="0" y2="0" stroke="#f59e0b" stroke-width="1.2"/><circle id="skCT2" r="4" fill="' + BC.t + '" stroke="#fff" stroke-width="1.5"/><circle id="skCD2" r="4" fill="' + BC.td + '" stroke="#fff" stroke-width="1.5"/></g>';
    b += '<rect id="skHit2" x="' + g.ML + '" y="' + g.MT + '" width="' + g.pw + '" height="' + g.ph + '" fill="transparent" style="touch-action:pan-y;cursor:crosshair"/>';
    if(opt.panel) b += panel(res, X, g, en, uid);
    return b + "</svg>";
  };
  /* پنل کناری: شاخص‌ها + هودوگراف */
  const SEV = [["#16a34a", "#dcfce7"], ["#ca8a04", "#fef9c3"], ["#ea580c", "#ffedd5"], ["#dc2626", "#fee2e2"]];
  function panel(res, X, g, en, uid){
    const x0 = g.ML + g.pw + 54, w = g.W - x0 - 10; let y = g.MT, b = '<g>';
    b += '<rect x="' + x0 + '" y="' + y + '" width="' + w + '" height="' + (g.H - g.MT - 30) + '" rx="10" fill="#fff" stroke="#cbd5e1" filter="url(#' + uid + 'ps)"/>';
    y += 20; b += '<text x="' + (x0 + 12) + '" y="' + y + '" font-size="11.5" font-weight="800" fill="#0f172a">' + esc(L(en, "پارامترهای کلیدی", "Key parameters")) + " · " + res.parcelType + "</text>"; y += 8;
    const sev = (v, a) => v == null ? -1 : v < a[0] ? 0 : v < a[1] ? 1 : v < a[2] ? 2 : 3;
    const row = (lab, val, unit, s) => { y += 17; const c = s >= 0 ? SEV[s] : ["#64748b", "#f1f5f9"]; let r = '<text x="' + (x0 + 12) + '" y="' + y + '" font-size="10.5" fill="#475569">' + esc(lab) + '</text><rect x="' + (x0 + w - 98) + '" y="' + (y - 11.5) + '" width="86" height="15" rx="7.5" fill="' + c[1] + '"/><text x="' + (x0 + w - 55) + '" y="' + (y - 0.5) + '" font-size="10.5" font-weight="800" text-anchor="middle" fill="' + c[0] + '">' + (val != null ? esc(val) : "—") + (val != null && unit ? " " + esc(unit) : "") + "</text>"; return r; };
    const I = res.items, sv = res.severe || {}, v = k => k && fin(k.v) ? k.v : null, r1 = x => fin(x) ? f1(x) : null, r0 = x => fin(x) ? f0(x) : null;
    const cape = v(I.CAPE), cin = v(I.CIN);
    b += row("CAPE", r0(cape), "J/kg", sev(cape, [300, 1000, 2500])); b += row("CIN", r0(cin), "J/kg", cin == null ? -1 : cin > -25 ? 0 : cin > -100 ? 1 : cin > -200 ? 2 : 3);
    b += row("LCL", r0(I.LCL.v), "hPa", -1); b += row("LFC", r0(res.lfc), "hPa", -1); b += row("EL", r0(res.el), "hPa", -1);
    b += row("LI", r1(v(I.LI)), "°C", v(I.LI) == null ? -1 : v(I.LI) > 0 ? 0 : v(I.LI) > -4 ? 1 : v(I.LI) > -7 ? 2 : 3);
    b += row("K", r0(v(I.K)), "", sev(v(I.K), [20, 30, 35])); b += row("TT", r0(v(I.TT)), "", sev(v(I.TT), [44, 50, 55]));
    b += row("PW", r1(v(I.PWAT)), "mm", -1); b += row(L(en, "شیب ۷۰۰–۵۰۰", "LR 700–500"), r1(v(sv.LR75)), "K/km", sev(v(sv.LR75), [6, 7.5, 8.5]));
    b += row(L(en, "برش ۰–۶ km", "Shear 0–6 km"), r1(v(I.SHEAR.s06)), "m/s", sev(v(I.SHEAR.s06), [10, 18, 25])); b += row("SRH 0–3 km", r0(v(I.SRH.s03)), "m²/s²", sev(v(I.SRH.s03), [100, 250, 400]));
    b += row("SCP", r1(v(sv.SCP)), "", sev(v(sv.SCP), [1, 4, 10])); b += row("STP", r1(v(sv.STPE) != null ? v(sv.STPE) : v(sv.STPF)), "", sev(v(sv.STPE) != null ? v(sv.STPE) : v(sv.STPF), [1, 3, 6])); b += row("SHIP", r1(v(sv.SHIP)), "", sev(v(sv.SHIP), [1, 2, 4]));
    b += row(L(en, "تراز انجماد", "Freezing lvl"), fin(X.fzlAgl) ? f0(X.fzlAgl) : null, "m AGL", -1);
    y += 14; const h = M.skewt && M.skewt.hodograph ? M.skewt.hodograph(res, {en}) : null, hs = Math.min(w - 20, g.H - y - 44);
    if(h && hs > 90){ b += '<text x="' + (x0 + 12) + '" y="' + (y + 4) + '" font-size="11" font-weight="800" fill="#0f172a">' + esc(L(en, "هودوگراف", "Hodograph")) + "</text>"; b += h.replace(/^<svg[^>]*>/, '<svg x="' + f1(x0 + (w - hs) / 2) + '" y="' + (y + 10) + '" width="' + f1(hs) + '" height="' + f1(hs) + '" viewBox="0 0 300 300">'); }
    return b + "</g>";
  }
  S.attach = function(host, res, infoEl){
    const svg = host.querySelector("svg"); if(!svg) return; const g = geom(100), prof = res.prof, hit = svg.querySelector("#skHit2"), cur = svg.querySelector("#skCur2"), cl = svg.querySelector("#skCl2"), cT = svg.querySelector("#skCT2"), cD = svg.querySelector("#skCD2"); if(!hit) return;
    const wi = []; for(let i = 0; i < prof.p.length; i++) if(fin(prof.u[i]) && fin(prof.v[i])) wi.push(i); const tw = twProf(prof);
    function at(ev){ const r = svg.getBoundingClientRect(), sc = g.W / r.width, y = (ev.clientY - r.top) * sc; const p = Math.max(Math.min(g.pFromY(y), prof.p[0]), prof.p[prof.p.length - 1]);
      const t = PF.interpLog(p, prof.p, prof.Tk), td = PF.interpLog(p, prof.p, prof.Tdk); if(!fin(t) || !fin(td)) return; const yy = g.y(p); cur.style.display = ""; cl.setAttribute("y1", yy); cl.setAttribute("y2", yy);
      cT.setAttribute("cx", g.x(t - C.zeroC, p)); cT.setAttribute("cy", yy); cD.setAttribute("cx", g.x(td - C.zeroC, p)); cD.setAttribute("cy", yy);
      const z = M.lab.heightAtP(prof, p), rh = T.rhFromDewpoint(t, td) * 100, thE = T.thetaE(p, t, td), twv = PF.interpLog(p, prof.p, tw.map(x => fin(x) ? x : NaN)); let w = "";
      if(wi.length > 1){ const pp = wi.map(i => prof.p[i]), u = PF.interpLog(p, pp, wi.map(i => prof.u[i])), v = PF.interpLog(p, pp, wi.map(i => prof.v[i])); if(fin(u) && fin(v)) w = " · " + f0(W.direction(u, v)) + "°/" + f1(Math.hypot(u, v)) + " m/s"; }
      if(infoEl) infoEl.textContent = f0(p) + " hPa" + (fin(z) ? " · " + f0(z) + " m" : "") + " · T " + f1(t - C.zeroC) + " °C · Td " + f1(td - C.zeroC) + " °C · Tw " + (fin(twv) ? f1(twv) : "—") + " °C · RH " + f0(rh) + "%" + (fin(thE) ? " · θe " + f0(thE) + " K" : "") + w; }
    hit.addEventListener("pointermove", at); hit.addEventListener("pointerdown", at); };
  /* ---------- نمای سه‌بعدی (تصویر مایل با زاویهٔ قابل‌چرخش) ---------- */
  S.svg3d = function(res, o){
    o = o || {}; const en = !!o.en, prof = res.prof, g = geom(100), rot = fin(o.rot) ? o.rot : 38, a = rot * Math.PI / 180, uid = "s3" + Math.floor(Math.random() * 1e6), X = M.analysis ? M.analysis.features(res) : {};
    const DEP = 58, Zn = 3.6, ox = Math.cos(a) * DEP, oy = Math.sin(a) * DEP * 0.9, W3 = 980, H3 = 720, Hh = 430, SX = 5.2, SK = 0.55, PX = 70, tx0 = -40, tx1 = 45, pBot = prof.p[0], pTop = 100;
    const hh = p => Hh * Math.log(pBot / p) / Math.log(pBot / pTop), PYB = 70 + oy * Zn + Hh;
    const px = (tc, p, z) => PX + (tc - tx0) * SX + hh(p) * SK + ox * z, py = (p, z) => PYB - hh(p) - oy * z;
    const Pq = (tc, p, z) => [px(tc, p, z), py(p, z)];
    let b = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + W3 + " " + H3 + '" font-family="Vazirmatn,Tahoma,sans-serif" font-size="10.5" style="width:100%;height:auto;display:block;background:#0f172a;direction:ltr" role="img" aria-label="Skew-T 3D">';
    b += '<defs><linearGradient id="' + uid + 'bg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#0f172a"/><stop offset="1" stop-color="#1e293b"/></linearGradient>' +
      '<linearGradient id="' + uid + 'wl" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#38bdf8" stop-opacity=".10"/><stop offset="1" stop-color="#38bdf8" stop-opacity=".02"/></linearGradient>' +
      '<filter id="' + uid + 'gl"><feGaussianBlur stdDeviation="2.2" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs><rect width="' + W3 + '" height="' + H3 + '" fill="url(#' + uid + 'bg)"/>';
    // دیوار پشتی: ایزوبارها و ایزوترم‌ها (z = Zn)
    const wallP = [[px(tx0, pBot, Zn), py(pBot, Zn)], [px(tx1, pBot, Zn), py(pBot, Zn)], [px(tx1 + 0, pTop, Zn), py(pTop, Zn)], [px(tx0, pTop, Zn), py(pTop, Zn)]];
    b += '<polygon points="' + pts(wallP) + '" fill="url(#' + uid + 'wl)" stroke="#334155"/>';
    for(let p = 1000; p >= 100; p -= 100) if(p <= pBot) b += '<line x1="' + f1(px(tx0, p, Zn)) + '" y1="' + f1(py(p, Zn)) + '" x2="' + f1(px(tx1, p, Zn)) + '" y2="' + f1(py(p, Zn)) + '" stroke="#334155" stroke-width=".8"/>';
    for(let t = -40; t <= 40; t += 10){ const q1 = Pq(t, pBot, Zn), q2 = Pq(t + (g.yb - g.y(pTop)) * 0, pTop, Zn); b += '<line x1="' + f1(q1[0]) + '" y1="' + f1(q1[1]) + '" x2="' + f1(q2[0]) + '" y2="' + f1(q2[1]) + '" stroke="' + (t === 0 ? "#3b82f6" : "#273449") + '" stroke-width="' + (t === 0 ? 1.2 : .7) + '"/>'; }
    // کف
    const fl = [Pq(tx0, pBot, 0), Pq(tx1, pBot, 0), Pq(tx1, pBot, Zn), Pq(tx0, pBot, Zn)];
    b += '<polygon points="' + pts(fl) + '" fill="#78716c" opacity=".35" stroke="#57534e"/>';
    for(let t = -40; t <= 40; t += 10){ const q = Pq(t, pBot, 0); b += '<text x="' + f1(q[0]) + '" y="' + f1(q[1] + 14) + '" text-anchor="middle" fill="#94a3b8" font-size="10">' + t + "</text>"; }
    for(let p = 1000; p >= 100; p -= 100) if(p <= pBot){ const q = Pq(tx0, p, 0); b += '<text x="' + f1(q[0] - 6) + '" y="' + f1(q[1] + 3.5) + '" text-anchor="end" fill="#94a3b8" font-size="10">' + p + "</text>"; }
    // کنارهٔ چپ پایین (لبهٔ جلویی)
    b += '<line x1="' + f1(px(tx0, pBot, 0)) + '" y1="' + f1(py(pBot, 0)) + '" x2="' + f1(px(tx0, pTop, 0)) + '" y2="' + f1(py(pTop, 0)) + '" stroke="#475569"/>';
    // پرده‌ها: هر منحنی روی «شیشه» خودش؛ ترتیب از عقب به جلو
    const ribbon = (xs, ps, z0, thick, col, op) => { let s = ""; for(let i = 0; i < ps.length - 1; i++){ const q = [Pq(xs[i], ps[i], z0), Pq(xs[i + 1], ps[i + 1], z0), Pq(xs[i + 1], ps[i + 1], z0 + thick), Pq(xs[i], ps[i], z0 + thick)]; s += '<polygon points="' + pts(q) + '" fill="' + col + '" opacity="' + op + '"/>'; } return s; };
    const line3 = (xs, ps, z, col, w, glow) => { const q = ps.map((p, i) => Pq(xs[i], p, z)); return poly(q, 'stroke="' + col + '" stroke-width="' + w + '" stroke-linejoin="round" stroke-linecap="round"' + (glow ? ' filter="url(#' + uid + 'gl)"' : "")); };
    const Ts = prof.Tk.map(x => x - C.zeroC), Ds = prof.Tdk.map(x => x - C.zeroC), keep = prof.p.map((p, i) => i).filter(i => prof.p[i] >= pTop);
    const pcv = M.lab.parcelCurve(prof, o.parcel || res.parcelType);
    // CAPE/CIN به‌صورت حجم (منشور) روی صفحهٔ پارسل
    if(pcv && fin(res.lfc)){ const envT = p => PF.interpLog(p, prof.p, prof.Tk); const zP = 2.4, th = 0.7; let up = [], lo = [];
      const segs = []; let cur = null; for(let i = 0; i < pcv.p.length; i++){ const p = pcv.p[i], d = pcv.Tk[i] - envT(p); if(!fin(d) || p < pTop) continue; const pos = d > 0 && p <= res.lfc + 1e-6, neg = d < 0 && p >= res.lfc - 1e-6, kind = pos ? "p" : (neg ? "n" : null); if(kind && (!cur || cur.k !== kind)){ cur = {k:kind, p:[]}; segs.push(cur); } if(kind) cur.p.push([p, pcv.Tk[i] - C.zeroC, envT(p) - C.zeroC]); if(!kind) cur = null; }
      for(const s of segs){ if(s.p.length < 2) continue; const col = s.k === "p" ? "#f97316" : "#3b82f6"; for(const [z, op] of [[zP + th, .22], [zP, .55]]){ const poly2 = s.p.map(q => Pq(q[1], q[0], z)).concat(s.p.slice().reverse().map(q => Pq(q[2], q[0], z))); b += '<polygon points="' + pts(poly2) + '" fill="' + col + '" opacity="' + op + '" stroke="' + col + '" stroke-width=".6"/>'; }
        for(const q of [s.p[0], s.p[s.p.length - 1]]){ const a1 = Pq(q[1], q[0], zP), a2 = Pq(q[1], q[0], zP + th), b1 = Pq(q[2], q[0], zP), b2 = Pq(q[2], q[0], zP + th); b += '<polygon points="' + pts([a1, a2, b2, b1]) + '" fill="' + col + '" opacity=".4"/>'; } } }
    if(pcv){ const xs = pcv.Tk.map(x => x - C.zeroC); b += ribbon(xs, pcv.p, 2.4, 0.7, "#e2e8f0", 0.22) + line3(xs, pcv.p, 2.4, "#e2e8f0", 1.8) ; }
    b += ribbon(keep.map(i => Ds[i]), keep.map(i => prof.p[i]), 1.2, 0.7, "#22c55e", 0.30) + line3(keep.map(i => Ds[i]), keep.map(i => prof.p[i]), 1.2, "#4ade80", 2.4, true);
    b += ribbon(keep.map(i => Ts[i]), keep.map(i => prof.p[i]), 0, 0.7, "#fb7185", 0.34) + line3(keep.map(i => Ts[i]), keep.map(i => prof.p[i]), 0, "#fb7185", 3, true);
    // صفحهٔ باد: سرعت به‌صورت منحنی روی دیوار کناری
    let windTag = null; const wi = []; for(let i = 0; i < prof.p.length; i++) if(fin(prof.u[i]) && fin(prof.v[i]) && prof.p[i] >= pTop) wi.push(i);
    if(wi.length > 2){ const smax = Math.max(20, ...wi.map(i => Math.hypot(prof.u[i], prof.v[i]))), x0 = tx1 + 2, scx = 13 / smax;      // ۲۶ °C-معادل روی محور x
      const xs = wi.map(i => x0 + Math.hypot(prof.u[i], prof.v[i]) * scx), ps = wi.map(i => prof.p[i]); const base = ps.map(() => x0);
      b += '<polygon points="' + pts(ps.map((p, i) => Pq(xs[i], p, 0.6)).concat(ps.slice().reverse().map(p => Pq(x0, p, 0.6)))) + '" fill="#a78bfa" opacity=".35"/>' + line3(xs, ps, 0.6, "#c4b5fd", 2);
      windTag = L(en, "سرعت باد (تا " + f0(smax) + " m/s)", "wind speed (to " + f0(smax) + " m/s)"); }
    // اتصال ترازها: صفحه‌های افقی نیمه‌شفاف + برچسب
    const mk = marks(res, X, en, prof).filter(m => m.p >= pTop && m.p <= pBot);
    for(const m of mk){ const q = [Pq(tx0, m.p, 0), Pq(tx1, m.p, 0), Pq(tx1, m.p, Zn), Pq(tx0, m.p, Zn)]; b += '<polygon points="' + pts(q) + '" fill="' + m.col + '" opacity=".07"/><line x1="' + f1(q[1][0]) + '" y1="' + f1(q[1][1]) + '" x2="' + f1(q[2][0]) + '" y2="' + f1(q[2][1]) + '" stroke="' + m.col + '" stroke-width="1" opacity=".8"/>'; }
    const lab = spread(mk.map(m => Object.assign({}, m, {y:py(m.p, Zn)})), 15, 20, H3 - 40); for(const m of lab){ const x = px(tx1 + 17, m.p, Zn) + 8; b += '<text x="' + f1(x) + '" y="' + f1(m.y + 3.5) + '" fill="' + m.col + '" font-size="10.5" font-weight="700">' + esc(m.lab) + " " + f0(m.p) + "</text>"; }
    // برچسب پرده‌ها
    const tag = (txt, z, col) => { const q = Pq(tx0, pTop, z); return '<g><rect x="' + f1(q[0] + 4) + '" y="' + f1(q[1] - 20) + '" width="' + (txt.length * 6.4 + 14) + '" height="17" rx="8.5" fill="' + col + '" opacity=".92"/><text x="' + f1(q[0] + 11) + '" y="' + f1(q[1] - 8) + '" font-size="10.5" font-weight="700" fill="#0f172a">' + esc(txt) + "</text></g>"; };
    b += tag(L(en, "دما T", "Temperature T"), 0, "#fb7185") + tag(L(en, "شبنم Td", "Dew point Td"), 1.2, "#4ade80") + tag(L(en, "پارسل", "Parcel") + " " + res.parcelType, 2.4, "#e2e8f0") + (windTag ? tag(windTag, 0.6, "#c4b5fd").replace(/y="([\d.]+)"/g, (m0, v) => 'y="' + (+v + 24) + '"') : "");
    b += '<text x="20" y="28" fill="#e2e8f0" font-size="14" font-weight="800">' + esc(o.title || "Skew-T 3D") + '</text><text x="20" y="46" fill="#94a3b8" font-size="10.5">' + esc(L(en, "نمایش سه‌بعدی شبه‌مایل؛ زاویه را بچرخانید. عمق صرفاً نمایشی است.", "Oblique pseudo-3D view; rotate with the slider. Depth is purely visual.")) + "</text>";
    return b + "</svg>";
  };
  M.skewt2 = S;
})();
/* ===== تحلیل علمی خودکار (r55) — Skew-T و آزمایشگاه محاسبات =====
   روش: «سامانهٔ خبرهٔ شفاف» با دو لایه:
   (۱) قواعد آستانه‌ای از جزوهٔ Skew-T (۱۳۸۵: LI، SI، TT، KI، SWEAT، EI/CAPE، CINH، CAP، HEL، SHR، EHI، BRN، PW، L57، جدول مقادیر بحرانی)
       و مراجع استاندارد (SPC، Bunkers 2000، Thompson 2003/2012، Johnson & Sugden 2014)؛
   (۲) احتمال محیطی هر پدیده با مدل لجستیک کوچک روی ویژگی‌های فازی [۰..۱]. وزن‌ها در MET.analysis.WEIGHTS ثابت و قابل‌بازرسی‌اند
       (پیش‌فرض = دانش خبره). MET.analysis.train() همان وزن‌ها را با رگرسیون لجستیک از نمونه‌های برچسب‌دار (رخداد/عدم‌رخداد) یاد می‌گیرد؛
       وزن‌های یادگرفته با MET.analysis.setWeights() جایگزین می‌شوند. هیچ‌چیز بی‌صدا یاد گرفته نمی‌شود (کنترل‌شده، آفلاین).
   مهم: «احتمال» یعنی مساعد‌بودن محیط (نه احتمال وقوع در یک نقطهٔ مشخص)؛ ماشهٔ شروع (جبهه، توپوگرافی، همگرایی) در سونداژ نیست.
   بدون DOM: در Node هم آزموده می‌شود. مقدار مفقود هرگز صفر نمی‌شود؛ بخش بدون دادهٔ کافی با علت گزارش می‌شود. */
(function(){
  "use strict";
  const M = globalThis.MET, C = M.C, T = M.thermo, PF = M.profile, W = M.wind, A = {};
  const fin = x => typeof x === "number" && isFinite(x);
  const clip = (x, a, b) => Math.min(Math.max(x, a), b);
  const ramp = (x, a, b) => fin(x) ? clip((x - a) / (b - a), 0, 1) : null;     // a→۰ و b→۱ (a>b هم مجاز: معکوس)
  const sig = z => 1 / (1 + Math.exp(-z));
  /* ---------- وزن‌ها (قابل‌جایگزینی) ---------- */
  const W0 = {
    tstorm:  {b:-2.6, w:{cape:2.8, li:1.2, ki:0.9, tt:0.8, rh:0.7, pw:0.5, cin:-1.7, cap:-1.2, lfc:-0.9}},
    severe:  {b:-3.2, w:{cape:1.7, shear:1.6, scp:1.1, srh:0.7, lr:0.5, cin:-1.3, rh:0.2}},
    hail:    {b:-3.0, w:{ship:2.4, cape:0.9, lr:0.9, shear:0.8, fzl:0.7, cin:-0.8}},
    gust:    {b:-3.0, w:{dcape:1.6, dry:1.0, lr03:1.0, cape:0.8, wind:0.7, cin:-0.5}},
    rain:    {b:-2.5, w:{pw:1.5, warm:1.0, cape:0.9, rh:1.0, slow:0.8, cin:-0.6}},
    tornado: {b:-4.4, w:{stp:2.2, srh1:1.0, lcl:0.9, shear:0.8, cape:0.6}}
  };
  let WT = JSON.parse(JSON.stringify(W0));
  A.WEIGHTS = () => JSON.parse(JSON.stringify(WT));
  A.setWeights = w => { if(w && typeof w === "object"){ for(const k in W0) if(w[k] && fin(w[k].b) && w[k].w) WT[k] = {b:w[k].b, w:Object.assign({}, W0[k].w, w[k].w)}; } };
  A.resetWeights = () => { WT = JSON.parse(JSON.stringify(W0)); };
  const score = (k, f) => { const m = WT[k]; let s = m.b; for(const n in m.w){ const v = f[n]; if(fin(v)) s += m.w[n] * v; } return s; };
  /* آموزش لجستیک (گام‌های گرادیان با L2 کوچک): rows=[{f:{..}, y:0|1}] ؛ خروجی وزن جدید برای hazard */
  A.train = function(hazard, rows, o){
    o = o || {}; const keys = Object.keys(W0[hazard].w), lr = o.lr || 0.3, it = o.iter || 1500, l2 = o.l2 == null ? 0.01 : o.l2;
    if(!rows || rows.length < 20) return {ok:false, why:"need_at_least_20_samples"};
    const pos = rows.filter(r => r.y === 1).length; if(pos < 5 || rows.length - pos < 5) return {ok:false, why:"need_5_events_and_5_nonevents"};
    let b = WT[hazard].b; const w = {}; keys.forEach(k => { w[k] = WT[hazard].w[k]; });
    for(let n = 0; n < it; n++){ let gb = 0; const g = {}; keys.forEach(k => { g[k] = 0; });
      for(const r of rows){ let s = b; keys.forEach(k => { if(fin(r.f[k])) s += w[k] * r.f[k]; }); const e = sig(s) - r.y; gb += e; keys.forEach(k => { if(fin(r.f[k])) g[k] += e * r.f[k]; }); }
      b -= lr * gb / rows.length; keys.forEach(k => { w[k] -= lr * (g[k] / rows.length + l2 * (w[k] - W0[hazard].w[k])); }); }
    let ll = 0; for(const r of rows){ let s = b; keys.forEach(k => { if(fin(r.f[k])) s += w[k] * r.f[k]; }); const p = clip(sig(s), 1e-6, 1 - 1e-6); ll -= r.y * Math.log(p) + (1 - r.y) * Math.log(1 - p); }
    return {ok:true, weights:{b, w}, logloss:ll / rows.length, n:rows.length, events:pos};
  };
  /* ---------- ویژگی‌ها از نتیجهٔ MET.lab.analyze ---------- */
  function meanLayer(wp, z0, z1){ if(!wp) return null; const n = Math.max(2, Math.round((z1 - z0) / 100)); let u = 0, v = 0, c = 0;
    for(let i = 0; i <= n; i++){ const z = z0 + (z1 - z0) * i / n, zz = wp.zAgl; if(z > zz[zz.length - 1] + 1e-6) return null; let k = 0; while(k < zz.length - 2 && zz[k + 1] < z) k++; const f = (z - zz[k]) / ((zz[k + 1] - zz[k]) || 1); u += wp.u[k] + f * (wp.u[k + 1] - wp.u[k]); v += wp.v[k] + f * (wp.v[k + 1] - wp.v[k]); c++; }
    return {u:u / c, v:v / c}; }
  const stullTw = (t, rh) => t * Math.atan(0.151977 * Math.sqrt(rh + 8.313659)) + Math.atan(t + rh) - Math.atan(rh - 1.676331) + 0.00391838 * Math.pow(rh, 1.5) * Math.atan(0.023101 * rh) - 4.686035;
  A.features = function(res){
    const prof = res.prof, I = res.items, sv = res.severe || {}, X = {}, n = prof.p.length, has = p => p <= prof.p[0] + 1e-9 && p >= prof.p[n - 1] - 1e-9;
    const lin = (p, k) => has(p) ? PF.interpLin(p, prof.p, prof[k]) : NaN, tc = p => lin(p, "Tk") - C.zeroC, tdc = p => lin(p, "Tdk") - C.zeroC;
    const z0 = fin(prof.z && prof.z[0]) ? prof.z[0] : null, agl = p => { const z = M.lab.heightAtP(prof, p); return fin(z) && z0 != null ? z - z0 : null; };
    X.p0 = prof.p[0]; X.T0 = prof.Tk[0] - C.zeroC; X.Td0 = prof.Tdk[0] - C.zeroC; X.spread0 = X.T0 - X.Td0; X.z0 = z0; X.rh0 = T.rhFromDewpoint(prof.Tk[0], prof.Tdk[0]) * 100;
    X.top = prof.p[n - 1]; X.n = n; X.hasWind = !!res.hasWind;
    for(const l of [850, 700, 500, 300]){ X["T" + l] = tc(l); X["Td" + l] = tdc(l); }
    X.has850 = has(850); X.has500 = has(500);
    X.cape = I.CAPE.v, X.cin = I.CIN.v, X.lclP = I.LCL.v, X.lclAgl = I.LCL.v != null ? agl(I.LCL.v) : null; X.lfcP = res.lfc, X.elP = res.el;
    X.lfcAgl = res.lfc != null ? agl(res.lfc) : null; X.elAgl = res.el != null ? agl(res.el) : null; X.noLfc = I.CAPE.note === "no_lfc";
    X.li = I.LI.v; X.si = I.SHOWALTER.v; X.k = I.K.v; X.tt = I.TT.v; X.vt = I.VT.v; X.ct = I.CT.v; X.pwat = I.PWAT.v;
    X.s01 = I.SHEAR.s01.v; X.s03 = I.SHEAR.s03.v; X.s06 = I.SHEAR.s06.v; X.srh01 = I.SRH.s01.v; X.srh03 = I.SRH.s03.v;
    X.scp = sv.SCP && sv.SCP.v; X.stpf = sv.STPF && sv.STPF.v; X.stpe = sv.STPE && sv.STPE.v; X.ship = sv.SHIP && sv.SHIP.v; X.lr75 = sv.LR75 && sv.LR75.v; X.fzl = sv.FZL && sv.FZL.v;
    X.parcels = {}; for(const k of ["SB", "ML", "MU"]){ const q = res.parcels[k]; X.parcels[k] = q && q.v != null ? {cape:q.v, cin:q.cin, lfc:q.lfc ? q.lfc.p : null, el:q.el ? q.el.p : null, lcl:q.lcl ? q.lcl.p : null} : null; }
    /* ردهٔ همرفتی: میانگین RH از سطح تا ۵۰۰ hPa (وزن فشاری) */
    { const top = Math.max(500, X.top), ps = prof.p.filter(p => p >= top - 1e-9); if(ps.length > 1){ const rh = ps.map((p, i) => T.rhFromDewpoint(prof.Tk[prof.p.indexOf(p)], prof.Tdk[prof.p.indexOf(p)]) * 100); X.rhMean = PF.trapz(rh, ps) / (ps[ps.length - 1] - ps[0]); X.rhTopP = top; } }
    /* آهنگ کاهش دما لایه‌ها (K/km) */
    const lapse = (pa, pb) => { const za = M.lab.heightAtP(prof, pa), zb = M.lab.heightAtP(prof, pb); if(!fin(za) || !fin(zb) || zb <= za) return null; const ta = lin(pa, "Tk"), tb = lin(pb, "Tk"); return (ta - tb) / ((zb - za) / 1000); };
    if(z0 != null){ const p3 = (() => { const wz = z0 + 3000; for(let i = 0; i < n - 1; i++){ if(fin(prof.z[i]) && fin(prof.z[i + 1]) && prof.z[i] <= wz && prof.z[i + 1] >= wz){ const f = (wz - prof.z[i]) / (prof.z[i + 1] - prof.z[i]); return Math.exp(Math.log(prof.p[i]) + f * (Math.log(prof.p[i + 1]) - Math.log(prof.p[i]))); } } return null; })(); X.p3km = p3; X.lr03 = p3 ? lapse(prof.p[0], p3) : null; }
    X.lr7 = X.lr75; X.lrSfc700 = has(700) ? lapse(prof.p[0], 700) : null;
    /* وارونگی‌ها (زیر ۵۰۰ hPa): لایه‌های پیوستهٔ افزایش دما با ارتفاع */
    X.inv = []; { let a = -1; for(let i = 0; i < n - 1; i++){ if(prof.p[i] < 450) break; const up = prof.Tk[i + 1] > prof.Tk[i] + 0.05; if(up && a < 0) a = i; if((!up || i === n - 2) && a >= 0){ const b = up ? i + 1 : i; const dT = prof.Tk[b] - prof.Tk[a]; if(dT >= 0.5) X.inv.push({base:prof.p[a], top:prof.p[b], dT, surf:a === 0, baseAgl:agl(prof.p[a]), topAgl:agl(prof.p[b])}); a = -1; } } }
    /* تراز انجماد و دمای تر صفر (Stull 2011، تقریب) */
    X.fzlP = null; for(let i = 0; i < n - 1; i++) if(prof.Tk[i] > C.zeroC && prof.Tk[i + 1] <= C.zeroC){ const f = (prof.Tk[i] - C.zeroC) / (prof.Tk[i] - prof.Tk[i + 1]); X.fzlP = Math.exp(Math.log(prof.p[i]) + f * (Math.log(prof.p[i + 1]) - Math.log(prof.p[i]))); break; }
    X.fzlAgl = X.fzlP ? agl(X.fzlP) : null;
    const tw = prof.p.map((p, i) => { const t = prof.Tk[i] - C.zeroC, rh = clip(T.rhFromDewpoint(prof.Tk[i], prof.Tdk[i]) * 100, 5, 99); return (t > -20 && t < 50) ? stullTw(t, rh) : null; });
    X.Tw0 = tw[0]; X.wbzP = null; for(let i = 0; i < n - 1; i++) if(fin(tw[i]) && fin(tw[i + 1]) && tw[i] > 0 && tw[i + 1] <= 0){ const f = tw[i] / (tw[i] - tw[i + 1]); X.wbzP = Math.exp(Math.log(prof.p[i]) + f * (Math.log(prof.p[i + 1]) - Math.log(prof.p[i]))); break; }
    X.wbzAgl = X.wbzP ? agl(X.wbzP) : null;
    /* لایه‌های ابری (RH≥۸۵٪ پیوسته) و لایهٔ خشک (RH<۳۰٪) */
    const rhA = prof.p.map((p, i) => T.rhFromDewpoint(prof.Tk[i], prof.Tdk[i]) * 100); X.rhProf = rhA;
    X.clouds = []; { let a = -1; for(let i = 0; i <= n; i++){ const wet = i < n && rhA[i] >= 85; if(wet && a < 0) a = i; if(!wet && a >= 0){ X.clouds.push({base:prof.p[a], top:prof.p[i - 1], baseAgl:agl(prof.p[a]), topAgl:agl(prof.p[i - 1]), n:i - a}); a = -1; } } }
    X.dryMid = null; { const ps = prof.p.map((p, i) => i).filter(i => prof.p[i] <= X.p0 - 150 && prof.p[i] >= 400); if(ps.length){ X.dryMid = Math.min(...ps.map(i => rhA[i])); } }
    /* CCL و دمای همرفت Tc (PDF) */
    { const w0 = T.satMixingRatio(prof.p[0], prof.Tdk[0]); let ccl = null; for(let i = 0; i < n - 1; i++){ const f = i2 => T.dewpointFromE(T.vaporPressure(prof.p[i2], w0)); const d0 = prof.Tk[i] - f(i), d1 = prof.Tk[i + 1] - f(i + 1); if(d0 >= 0 && d1 < 0){ const fr = d0 / (d0 - d1); ccl = {p:Math.exp(Math.log(prof.p[i]) + fr * (Math.log(prof.p[i + 1]) - Math.log(prof.p[i]))), T:prof.Tk[i] + fr * (prof.Tk[i + 1] - prof.Tk[i])}; break; } }
      if(ccl){ X.cclP = ccl.p; X.cclAgl = agl(ccl.p); X.Tc = T.dryLapse(prof.p[0], ccl.T, ccl.p) - C.zeroC; } }
    /* ظرفیت CAP: بیشینهٔ اختلاف (محیط − پارسل سطحی) زیر LFC */
    X.capStr = null; { const pc = M.lab.parcelCurve(prof, "SB"); if(pc && X.lfcP != null){ let mx = 0; pc.p.forEach((p, i) => { if(p <= prof.p[0] - 5 && p >= X.lfcP){ const te = PF.interpLog(p, prof.p, prof.Tk); if(fin(te) && fin(pc.Tk[i])) mx = Math.max(mx, te - pc.Tk[i]); } }); X.capStr = mx; } }
    /* DCAPE تقریبی: ترازی با کمینهٔ θe در ۴۰۰ hPa اول؛ فرود آدیاباتیک اشباع تا سطح */
    X.dcape = null; { const lim = prof.p[0] - 400, idx = prof.p.map((p, i) => i).filter(i => prof.p[i] >= lim && prof.p[i] < prof.p[0] - 30); if(idx.length && fin(prof.z && prof.z[0])){ let bi = idx[0], bm = Infinity; idx.forEach(i => { const te = T.thetaE(prof.p[i], prof.Tk[i], prof.Tdk[i]); if(te < bm){ bm = te; bi = i; } });
        const tw0 = tw[bi]; if(fin(tw0)){ const pd = []; for(let p = prof.p[bi]; p <= prof.p[0]; p += 10) pd.push(p); if(pd[pd.length - 1] < prof.p[0]) pd.push(prof.p[0]); const tpar = T.moistLapse(pd, tw0 + C.zeroC, prof.p[bi]); let sum = 0;
          for(let k = 0; k < pd.length - 1; k++){ const te = PF.interpLog((pd[k] + pd[k + 1]) / 2, prof.p, prof.Tk), tp = (tpar[k] + tpar[k + 1]) / 2, dz = C.Rd * te / C.g * Math.log(pd[k + 1] / pd[k]); if(fin(te) && fin(tp)) sum += C.g * (te - tp) / te * dz; } X.dcape = Math.max(0, sum); X.dcapeP = prof.p[bi]; } } }
    /* باد */
    const wp = W.windProfile(prof); X.wp = !!wp;
    if(wp){ const m06 = meanLayer(wp, 0, 6000), m05 = meanLayer(wp, 0, 500); if(m06){ X.meanWind06 = Math.hypot(m06.u, m06.v); X.meanDir06 = W.direction(m06.u, m06.v); }
      if(m06 && m05 && fin(X.cape)){ const U = Math.hypot(m06.u - m05.u, m06.v - m05.v); if(U > 0) X.brn = X.cape / (0.5 * U * U); X.brnU = U; }
      const spdAt = p => { const u = PF.interpLog(p, prof.p, prof.u), v = PF.interpLog(p, prof.p, prof.v); return fin(u) && fin(v) ? Math.hypot(u, v) / W.KT : NaN; };
      const dirAt = p => { const u = PF.interpLog(p, prof.p, prof.u), v = PF.interpLog(p, prof.p, prof.v); return fin(u) && fin(v) ? W.direction(u, v) : NaN; };
      if(has(850) && has(500) && fin(X.Td850) && fin(X.tt)){ const t2 = Math.max(X.tt - 49, 0), sh = 125 * (Math.sin((dirAt(500) - dirAt(850)) * Math.PI / 180) + 0.2); X.sweat = 12 * Math.max(X.Td850, 0) + 20 * t2 + 2 * spdAt(850) + spdAt(500) + (spdAt(850) >= 15 && spdAt(500) >= 15 && dirAt(850) >= 130 && dirAt(850) <= 250 && dirAt(500) >= 210 && dirAt(500) <= 310 && dirAt(500) - dirAt(850) > 0 ? sh : 0); } }
    X.shr03 = X.s03 != null ? X.s03 / 3 : null;                    // m/s بر km = ‎×۱۰⁻³ s⁻¹ (SHR جزوه)
    X.ehi01 = fin(X.cape) && fin(X.srh01) ? X.cape * X.srh01 / 160000 : null; X.ehi03 = fin(X.cape) && fin(X.srh03) ? X.cape * X.srh03 / 160000 : null;
    X.wmax = fin(X.cape) ? Math.sqrt(2 * Math.max(X.cape, 0)) : null;
    X.pwMm = X.pwat;
    /* ویژگی‌های فازی [۰..۱] */
    const f = {};
    const cape = fin(X.cape) ? X.cape : 0;
    f.cape = ramp(cape, 0, 1800); f.li = ramp(X.li, 0, -6); f.ki = ramp(X.k, 15, 35); f.tt = ramp(X.tt, 44, 54);
    f.rh = ramp(X.rhMean, 35, 75); f.pw = ramp(X.pwMm, 10, 40); f.cin = ramp(fin(X.cin) ? -X.cin : 0, 20, 200); f.cap = ramp(X.capStr, 1, 6);
    f.lfc = ramp(X.lfcAgl, 1500, 5000); f.shear = ramp(X.s06, 8, 25); f.scp = ramp(X.scp, 0, 4); f.srh = ramp(X.srh03, 80, 300); f.lr = ramp(X.lr75, 6, 8.5);
    f.ship = ramp(X.ship, 0, 2); f.fzl = X.fzlAgl != null ? ramp(X.fzlAgl, 1500, 3200) * ramp(X.fzlAgl, 6000, 4200) : null; if(f.fzl == null && X.fzlAgl != null) f.fzl = 0;
    f.dcape = ramp(X.dcape, 300, 1300); f.dry = ramp(X.spread0, 8, 28); f.lr03 = ramp(X.lr03, 7, 9.5); f.wind = ramp(X.meanWind06, 6, 20);
    f.warm = X.lclAgl != null && X.fzlAgl != null ? ramp(X.fzlAgl - X.lclAgl, 1500, 4500) : null; f.slow = ramp(X.meanWind06, 14, 5);
    f.stp = ramp(fin(X.stpe) ? X.stpe : X.stpf, 0, 3); f.srh1 = ramp(X.srh01, 40, 200); f.lcl = ramp(X.lclAgl, 2200, 800);
    X.f = f; return X;
  };
  A.probs = function(X){
    const out = []; const R = (id, fa, en, k, note) => { const s = score(k, X.f), p = Math.round(sig(s) * 100); out.push({id, fa, en, p, lv:p < 10 ? 0 : p < 25 ? 1 : p < 50 ? 2 : p < 75 ? 3 : 4, drivers:drivers(k, X.f), note}); };
    const drivers = (k, f) => { const m = WT[k], arr = []; for(const n in m.w){ if(fin(f[n]) && Math.abs(m.w[n] * f[n]) >= 0.35) arr.push([n, m.w[n] * f[n]]); } return arr.sort((a, b) => Math.abs(b[1]) - Math.abs(a[1])).slice(0, 4); };
    R("tstorm", "رعدوبرق / همرفت عمیق", "Thunderstorms / deep convection", "tstorm");
    R("severe", "توفان شدید (ترکیبی)", "Severe convective storm (combined)", "severe", !X.hasWind ? "no_wind" : null);
    R("hail", "تگرگ", "Hail", "hail");
    R("gust", "تندبادهای همرفتی / ریزجهندهٔ خشک", "Convective wind gusts / microbursts", "gust");
    R("rain", "بارش سنگین / سیلاب لحظه‌ای", "Heavy rain / flash flooding", "rain");
    R("tornado", "گردباد (تورنادو، آستانهٔ پایین)", "Tornado (low-end threshold)", "tornado", !X.hasWind ? "no_wind" : null);
    return out;
  };
  A.LV = [["بسیار کم", "Very low"], ["کم", "Low"], ["متوسط", "Moderate"], ["زیاد", "High"], ["بسیار زیاد", "Very high"]];
  /* ---------- متن ---------- */
  const NM = {cape:"CAPE", li:"LI", ki:"KI", tt:"TT", rh:["رطوبت میانگین", "mean RH"], pw:["آب قابل بارش", "PW"], cin:"CIN", cap:["سرپوش", "cap"], lfc:["ارتفاع LFC", "LFC height"], shear:["برش ۰–۶km", "0–6 km shear"], scp:"SCP", srh:"SRH", lr:["آهنگ ۷۰۰–۵۰۰", "700–500 lapse"], ship:"SHIP", fzl:["تراز انجماد", "freezing level"], dcape:"DCAPE", dry:["لایهٔ زیرابری خشک", "dry sub-cloud layer"], lr03:["آهنگ ۰–۳km", "0–3 km lapse"], wind:["باد میانی", "mid-level wind"], warm:["ضخامت لایهٔ گرم", "warm-cloud depth"], slow:["حرکت کند", "slow motion"], stp:"STP", srh1:["SRH ۰–۱km", "SRH 0–1 km"], lcl:["LCL پایین", "low LCL"]};
  function make(res, o, kind){
    o = o || {}; const en = !!o.en, t = (fa, en_) => en ? en_ : fa, X = A.features(res), P = A.probs(X), S = [], B = (h, lines, id) => { lines = lines.filter(Boolean); if(lines.length) S.push({id:id || "", h, lines}); };
    const SEP = en ? "; " : "؛ ", CM = en ? ", " : "، ", num = (v, d) => fin(v) ? "⁦" + (Math.round(v * Math.pow(10, d || 0)) / Math.pow(10, d || 0)).toString() + "⁩" : "—";
    const hp = (p) => num(p, 0) + " hPa", lvl = (p, a) => fin(p) ? hp(p) + (fin(a) ? " (" + num(a, 0) + " m AGL)" : "") : "—";
    const cls = (v, arr) => { for(const [lim, fa, e] of arr) if(v < lim) return t(fa, e); return t(arr[arr.length - 1][1], arr[arr.length - 1][2]); };
    /* ۱) وضعیت سطح و ساختار کلی */
    const head = [];
    head.push(t("سونداژ از ", "Sounding from ") + hp(X.p0) + t(" (سطح) تا ", " (surface) to ") + hp(X.top) + t("، با ", ", with ") + num(X.n) + t(" تراز معتبر", " valid levels") + (fin(X.z0) ? t("؛ ارتفاع سطح ≈ ", "; surface elevation ≈ ") + num(X.z0) + " m" : "") + ".");
    head.push(t("دمای سطح ", "Surface temperature ") + num(X.T0, 1) + " °C" + t("، نقطهٔ شبنم ", ", dew point ") + num(X.Td0, 1) + " °C" + t("، رطوبت نسبی ", ", RH ") + num(X.rh0) + "%" + t("، گسترهٔ T−Td ", ", T−Td spread ") + num(X.spread0, 1) + " °C" +
      (X.spread0 > 20 ? t(" ← هوای سطحی بسیار خشک؛ پایهٔ ابر بلند و تبخیر بارش در زیر ابر (ویرگا) محتمل است.", " ← very dry surface air; high cloud base and sub-cloud rain evaporation (virga) likely.") : X.spread0 < 3 ? t(" ← هوای نزدیک اشباع؛ مه/ابر پست و رطوبت بالای سطح.", " ← near-saturated air; fog/low cloud and high surface humidity.") : ""));
    if(!X.has850) head.push(t("سطح ۸۵۰ hPa زیر سطح زمین است؛ شاخص‌های کلاسیک وابسته به ۸۵۰ (SI، TT، KI، SWEAT) در ارتفاع‌های بلند ایران تعریف‌پذیر نیستند و به‌جای آن CAPE/CIN و شاخص‌های پارسل مبنای قضاوت‌اند.", "The 850 hPa level is below ground; classical 850-based indices (SI, TT, KI, SWEAT) are undefined at high Iranian elevations, so parcel-based CAPE/CIN guide the assessment."));
    B(t("۱. وضعیت سطحی و ساختار کلی پروفایل", "1. Surface state and profile overview"), head, "overview");
    /* ۲) پایداری و آهنگ کاهش دما (جزوه: ELR در برابر DALR/MALR؛ L57) */
    const st = [];
    if(fin(X.lrSfc700)) st.push(t("آهنگ کاهش دما سطح→۷۰۰ hPa: ", "Lapse rate surface→700 hPa: ") + num(X.lrSfc700, 1) + " K/km" + (X.lrSfc700 > 9.8 ? t(" — بیش از آدیاباتیک خشک (فوق‌آدیاباتیک): ناپایداری مطلق، آمیختگی شدید همرفتی لایهٔ مرزی.", " — exceeds the dry adiabatic rate (super-adiabatic): absolute instability, vigorous boundary-layer mixing.") : X.lrSfc700 > 6.5 ? t(" — بین آدیاباتیک اشباع و خشک: ناپایداری مشروط.", " — between moist and dry adiabats: conditional instability.") : t(" — کمتر از آهنگ استاندارد: پایدار تا خنثی.", " — below standard lapse rate: stable to neutral.")));
    if(fin(X.lr75)) st.push(t("L57 (آهنگ ۷۰۰–۵۰۰ hPa): ", "L57 (700–500 hPa lapse rate): ") + num(X.lr75, 1) + " K/km — " + (X.lr75 < 5.5 ? t("هوا پایدار است (L57<5.5).", "stable (L57 < 5.5).") : X.lr75 < 9 ? t("ناپایداری شرطی (۵٫۵<L57<۹)؛ در حضور رطوبت کافی در لایهٔ مرزی ناپایدار می‌شود.", "conditionally unstable (5.5 < L57 < 9); becomes unstable with sufficient boundary-layer moisture.") : t("بسیار ناپایدار (L57>۹).", "very unstable (L57 > 9).")) + (X.lr75 >= 7.5 ? t(" مقادیر ≥۷٫۵ آهنگ‌های میان‌ترازی تند و مساعد برای تگرگ‌اند.", " Values ≥ 7.5 are steep mid-level lapse rates favourable for hail.") : ""));
    if(fin(X.lr03)) st.push(t("آهنگ ۰–۳ km: ", "0–3 km lapse rate: ") + num(X.lr03, 1) + " K/km" + (X.lr03 >= 8 ? t(" — پروفایل «V وارونه» (لایهٔ زیرابری خشک و عمیق): پتانسیل تندباد و ریزجهندهٔ خشک.", " — inverted-V type profile (deep dry sub-cloud layer): wet/dry microburst potential.") : ""));
    if(X.inv.length){ const s = X.inv.slice(0, 3).map(v => (v.surf ? t("وارونگی سطحی ", "surface inversion ") : t("وارونگی مرتفع ", "elevated inversion ")) + hp(v.base) + "→" + hp(v.top) + " (+" + num(v.dT, 1) + " K)").join(SEP); st.push(t("وارونگی/لایهٔ پایدار: ", "Inversions / stable layers: ") + s + t(". وارونگی مانع صعود پارسل و حبس آلاینده‌ها/رطوبت زیر خود می‌شود.", ". An inversion caps parcel ascent and traps pollutants/moisture beneath it.")); }
    else st.push(t("وارونگی قابل‌توجه (≥۰٫۵ K) زیر ۴۵۰ hPa دیده نمی‌شود.", "No notable inversion (≥ 0.5 K) found below 450 hPa."));
    if(fin(X.fzlP)) st.push(t("تراز صفر درجه: ", "Freezing level: ") + lvl(X.fzlP, X.fzlAgl) + (fin(X.wbzP) ? t("؛ دمای تر صفر (تقریب Stull): ", "; wet-bulb zero (Stull approx.): ") + lvl(X.wbzP, X.wbzAgl) : "") + ".");
    else if(X.T0 <= 0) st.push(t("دمای سطح زیر صفر است؛ کل ستون زیر انجماد در لایهٔ سطحی.", "Surface is at or below freezing."));
    if(fin(X.Tw0)) st.push(t("دمای تر سطحی ≈ ", "Surface wet-bulb ≈ ") + num(X.Tw0, 1) + " °C" + (X.T0 <= 4 && X.Tw0 <= 1 ? t(" — اگر بارشی رخ دهد، نوع آن به برف/آب‌نیم‌یخ متمایل است.", " — precipitation, if any, tends toward snow/sleet.") : X.Tw0 > 1 ? t(" — بارش، در صورت وقوع، به‌صورت باران است.", " — precipitation, if any, would fall as rain.") : ""));
    B(t("۲. پایداری، آهنگ کاهش دما و لایه‌بندی", "2. Stability, lapse rates and layering"), st, "stab");
    /* ۳) انرژی و پارسل */
    const en2 = [];
    if(fin(X.cape)){ const c = X.cape; en2.push(t("CAPE پارسل ", "CAPE of the ") + res.parcelType + ": " + num(c) + " J/kg — " + (c < 1 ? t("بدون انرژی مثبت (EI<1): صعود شناور وجود ندارد.", "no positive buoyancy (EI < 1): no free ascent.") : c < 1500 ? t("انرژی همرفتی مثبت؛ همرفت ضعیف تا متوسط.", "positive convective energy; weak to moderate convection.") : c < 2500 ? t("انرژی بزرگ (۱۵۰۰–۲۵۰۰): همرفت قوی.", "large energy (1500–2500): strong convection.") : t("انرژی بسیار زیاد (>۲۵۰۰): همرفت بسیار قوی/شدید.", "extreme energy (> 2500): very strong/severe convection.")));
      if(c > 0) en2.push(t("بیشینهٔ سرعت صعود نظری √(2·CAPE) ≈ ", "Theoretical maximum updraft √(2·CAPE) ≈ ") + num(X.wmax, 0) + " m/s.");
      en2.push("CIN: " + num(X.cin) + " J/kg — " + (!fin(X.cin) ? "—" : X.cin > -25 ? t("بازدارندگی ناچیز؛ شروع همرفت آسان.", "negligible inhibition; initiation is easy.") : X.cin > -100 ? t("بازدارندگی متوسط؛ به ماشه (گرمایش روزانه، همگرایی، کوه) نیاز است.", "moderate inhibition; needs a trigger (daytime heating, convergence, terrain).") : X.cin > -200 ? t("بازدارندگی قوی؛ همرفت سطحی بعید و شروع فقط با ماشهٔ قوی.", "strong inhibition; surface-based convection unlikely without a strong trigger.") : t("سرپوش بسیار قوی؛ همرفت سطحی عملاً مهار می‌شود.", "very strong cap; surface-based convection effectively suppressed.")));
      if(fin(X.capStr)) en2.push(t("شدت سرپوش (بیشینهٔ T_env−T_parcel زیر LFC) ≈ ", "Cap strength (max T_env−T_parcel below LFC) ≈ ") + num(X.capStr, 1) + " K" + (X.capStr > 2 ? t(" (CAP>2: طبق جزوه تا دست‌کم دو ساعت همرفت روی نمی‌دهد مگر با ماشه).", " (CAP > 2: per the handbook, no convection for at least 2 h without a trigger).") : "."));
      en2.push("LCL: " + lvl(X.lclP, X.lclAgl) + (X.lclAgl != null ? (X.lclAgl > 2500 ? t(" — پایهٔ ابر بسیار بلند (جوّ خشک)؛ ابرها کم‌بارش‌تر و تندباد محتمل‌تر.", " — very high cloud base (dry atmosphere): lower rain efficiency, gusts more likely.") : X.lclAgl < 1000 ? t(" — پایهٔ ابر پست (مرطوب)؛ مساعد بارش کارآمد.", " — low cloud base (moist): favourable for efficient rain.") : "") : ""));
      if(X.noLfc) en2.push(t("پارسل به LFC نمی‌رسد؛ CAPE صفر معتبر است (جو در برابر صعود پارسل پایدار).", "The parcel never reaches an LFC; CAPE is a valid zero (stable to parcel ascent)."));
      else { en2.push("LFC: " + lvl(X.lfcP, X.lfcAgl) + (fin(X.lfcP) ? (X.lfcP >= 600 ? t(" — پایین‌تر از تراز ۶۰۰ hPa؛ طبق تجربهٔ جزوه احتمال رعدوبرق وجود دارد.", " — below the 600 hPa level (higher pressure); per the handbook experience, thunderstorm occurrence is possible.") : t(" — LFC بالاتر از ۶۰۰ hPa؛ همرفت مرتفع/پایه‌بلند (ابرهای میانی) محتمل‌تر از رعدوبرق عمیق.", " — LFC above 600 hPa; elevated/high-based convection is likelier than deep thunderstorms.")) : "")); en2.push("EL: " + lvl(X.elP, X.elAgl) + (fin(X.elP) && fin(X.cape) ? t(" — بالاترین رشد ابر تا این تراز؛ هرچه EL بالاتر، سندان بلندتر و رعدوبرق شدیدتر.", " — cloud tops grow up to about this level; the higher the EL, the taller the anvil and the stronger the lightning.") : "")); }
      const pcs = X.parcels, ks = ["SB", "ML", "MU"].filter(k => pcs[k]); if(ks.length > 1) en2.push(t("حساسیت به نوع پارسل: ", "Parcel-type sensitivity: ") + ks.map(k => k + " " + num(pcs[k].cape) + "/" + num(pcs[k].cin)).join(" · ") + t(" (CAPE/CIN). اختلاف زیاد یعنی نتیجه به آمیختگی لایهٔ مرزی وابسته است.", " (CAPE/CIN). A large spread means the outcome depends on boundary-layer mixing."));
      if(fin(X.cclP) && fin(X.Tc)) en2.push(t("CCL ≈ ", "CCL ≈ ") + lvl(X.cclP, X.cclAgl) + t("؛ دمای همرفت Tc ≈ ", "; convective temperature Tc ≈ ") + num(X.Tc, 1) + " °C" + t(" — اگر بیشینهٔ دمای روز از Tc بیشتر شود همرفت سطحی (ابر کومولوس) شروع می‌شود، وگرنه همرفت خشک/بی‌ابر می‌ماند.", " — if the daytime maximum exceeds Tc, surface-based cumulus convection starts; otherwise convection stays dry/cloud-free."));
    } else en2.push(t("CAPE محاسبه نشد: ", "CAPE not computed: ") + M.lab.whyText(I_(res).CAPE.why, en));
    B(t("۳. انرژی همرفتی و پارسل", "3. Convective energy and parcel"), en2, "energy");
    function I_(r){ return r.items; }
    /* ۴) شاخص‌ها — با آستانه‌های جزوه */
    const ix = [];
    if(fin(X.li)) ix.push("LI = " + num(X.li, 1) + " °C: " + (X.li > 0 ? t("جو پایدار", "stable") : X.li > -4 ? t("کمی ناپایدار", "slightly unstable") : X.li > -7 ? t("نسبتاً ناپایدار", "fairly unstable") : X.li > -11 ? t("شدیداً ناپایدار", "highly unstable") : t("ناپایداری بسیار وخیم", "extremely unstable")) + t(" (آستانه‌های ۰/−۴/−۷/−۱۰)", " (thresholds 0/−4/−7/−10)"));
    if(fin(X.si)) ix.push("SI = " + num(X.si, 1) + " °C: " + (X.si > 3 ? t("پایدار", "stable") : X.si > 1 ? t("رعد و برق رگبار و گاهی محتمل نیست مگر ماشه قوی باشد", "showers possible, thunder rare") : X.si > -3 ? t("رگبار و گاهی رعد و برق", "showers and occasional thunder") : X.si > -6 ? t("رعد و برق زیاد", "thunderstorms likely") : t("رعد و برق شدید", "severe thunderstorms")) + t(" (شوالتر؛ برش ۸۵۰→۵۰۰)", " (Showalter; 850→500)"));
    if(fin(X.tt)) ix.push("TT = " + num(X.tt, 0) + ": " + (X.tt < 44 ? t("همرفت بعید", "convection unlikely") : X.tt < 51 ? t("همرفت محتمل", "convection possible") : X.tt < 53 ? t("توفان‌های شدید و جدا از هم محتمل", "isolated severe storms possible") : X.tt < 56 ? t("توفان‌های شدید پراکنده در مقیاس وسیع", "widely scattered severe storms") : t("توفان‌های شدید پراکنده", "numerous severe storms")) + t(" (VT=", " (VT=") + num(X.vt, 0) + ", CT=" + num(X.ct, 0) + ")");
    if(fin(X.k)) ix.push("KI = " + num(X.k, 0) + ": " + (X.k < 15 ? t("احتمال همرفت وجود ندارد", "no convection expected") : X.k < 26 ? t("پتانسیل اندک", "low potential") : X.k < 40 ? t("پتانسیل متوسط", "moderate potential") : t("پتانسیل بالا", "high potential")) + t(" (فقط پتانسیل؛ نه شدت)", " (potential only; not severity)"));
    if(fin(X.sweat)) ix.push("SWEAT = " + num(X.sweat, 0) + ": " + (X.sweat < 150 ? t("زیر آستانه", "below threshold") : X.sweat < 300 ? t("توفان شدید نسبتاً محتمل", "severe storms fairly likely") : X.sweat < 400 ? t("امکان توفان‌های شدید", "severe storms possible") : t("احتمال توفندهای شدید", "tornadic storms possible")));
    if(fin(X.pwMm)) ix.push("PW = " + num(X.pwMm, 1) + " mm (" + num(X.pwMm / 25.4, 2) + " in): " + (X.pwMm > 44.5 ? t("جو مرطوب (PW>۱٫۷۵ in)", "moist atmosphere (PW > 1.75 in)") : X.pwMm < 19 ? t("جو نسبتاً خشک (PW<۰٫۷۵ in)", "relatively dry atmosphere (PW < 0.75 in)") : t("رطوبت متوسط", "moderate moisture")));
    if(fin(X.rhMean)) ix.push(t("RH میانگین سطح→", "Mean RH surface→") + num(X.rhTopP) + " hPa = " + num(X.rhMean, 0) + "%: " + (X.rhMean <= 40 ? t("بسیار کم", "very low") : X.rhMean <= 60 ? t("کم", "low") : X.rhMean <= 80 ? t("متوسط", "moderate") : t("بسیار مرطوب", "very moist")));
    if(fin(X.dcape)) ix.push("DCAPE ≈ " + num(X.dcape, 0) + " J/kg " + t("(تقریب)", "(approx.)") + ": " + (X.dcape < 500 ? t("تندباد نزولی ضعیف", "weak downdraft winds") : X.dcape < 1000 ? t("تندباد نزولی متوسط تا قوی", "moderate-to-strong downdraft winds") : t("تندباد/ریزجهندهٔ شدید محتمل", "damaging downburst winds possible")) + (fin(X.dcape) ? t("؛ بیشینهٔ نظری ≈ ", "; theoretical max ≈ ") + num(Math.sqrt(2 * X.dcape), 0) + " m/s" : ""));
    B(t("۴. شاخص‌های ناپایداری (آستانه‌های جزوه و مراجع)", "4. Instability indices (handbook and literature thresholds)"), ix, "idx");
    /* جدول مقادیر بحرانی */
    const crit = [["RH", fin(X.rhMean) ? X.rhMean > 61 : null], ["L57", fin(X.lr75) ? X.lr75 > 5.5 : null], ["LI", fin(X.li) ? X.li < -5 : null], ["SI", fin(X.si) ? X.si < -5 : null], ["TT", fin(X.tt) ? X.tt > 44 : null], ["KI", fin(X.k) ? X.k > 26 : null], ["SWEAT", fin(X.sweat) ? X.sweat > 150 : null], ["EI(CAPE)", fin(X.cape) ? X.cape > 1500 : null], ["CAP", fin(X.capStr) ? X.capStr < 2 : null], ["HEL(SRH03)", fin(X.srh03) ? X.srh03 > 150 : null], ["SHR", fin(X.shr03) ? X.shr03 > 6 : null], ["EHI", fin(X.ehi03) ? X.ehi03 > 1 : null], ["BRN", fin(X.brn) ? X.brn > 8 : null], ["PW>1.75in", fin(X.pwMm) ? X.pwMm > 44.5 : null]];
    const avail = crit.filter(c => c[1] !== null), hit = avail.filter(c => c[1]);
    if(avail.length) B(t("۵. جدول مقادیر بحرانی جزوه", "5. Handbook critical-value table"), [t("از ", "Of ") + num(avail.length) + t(" معیار قابل‌محاسبه، ", " computable criteria, ") + num(hit.length) + t(" معیار از مقدار بحرانی عبور کرده است: ", " exceed their critical value: ") + (hit.map(c => c[0]).join(CM) || "—") + ".",
      t("هرچه تعداد معیارهای بحرانی بیشتر باشد، جو به آستانهٔ ناپایداری/توفان نزدیک‌تر است؛ معیارهای وابسته به ۸۵۰ hPa یا باد در صورت نبود داده شمرده نشده‌اند.", "The more criteria exceed critical values, the closer the atmosphere is to the instability/storm threshold; 850-hPa- or wind-dependent criteria are skipped when data are missing.")], "crit");
    /* ۶) باد و برش */
    const wd = [];
    if(X.hasWind){
      wd.push(t("برش بردار: ۰–۱ km = ", "Bulk shear: 0–1 km = ") + num(X.s01, 1) + " · 0–3 km = " + num(X.s03, 1) + " · 0–6 km = " + num(X.s06, 1) + " m/s" + (fin(X.s06) ? " — " + (X.s06 < 10 ? t("برش ضعیف: تک‌سلول/پالسی و کم‌دوام.", "weak shear: single-cell/pulse, short-lived.") : X.s06 < 18 ? t("برش متوسط: چندسلولی سازمان‌یافته.", "moderate shear: organised multicells.") : X.s06 < 25 ? t("برش قوی: امکان ابرسلول و خط توفان.", "strong shear: supercells and squall lines possible.") : t("برش بسیار قوی: ابرسلول بادوام محتمل.", "very strong shear: long-lived supercells likely.")) : ""));
      if(fin(X.shr03)) wd.push("SHR (0–3 km) = " + num(X.shr03, 1) + " ×10⁻³ s⁻¹: " + (X.shr03 <= 3 ? t("ضعیف", "weak") : X.shr03 <= 5 ? t("متوسط", "moderate") : X.shr03 <= 8 ? t("زیاد", "high") : t("خیلی زیاد", "very high")) + t(" (آستانه‌های جزوه ۳/۵/۸)", " (handbook 3/5/8)"));
      if(fin(X.srh03)) wd.push("SRH: " + t("۰–۱ km = ", "0–1 km = ") + num(X.srh01, 0) + t("، ۰–۳ km = ", ", 0–3 km = ") + num(X.srh03, 0) + " m²/s² — " + (X.srh03 > 400 ? t("امکان توفان‌های تورنادویی (HEL>۴۰۰)", "tornadic storms possible (HEL > 400)") : X.srh03 > 300 ? t("توفان شدید ابرسلولی", "severe supercell storms") : X.srh03 > 150 ? t("امکان ابرسلول (HEL>۱۵۰)", "supercell possible (HEL > 150)") : t("چرخندگی نسبی کم", "limited storm-relative rotation")));
      if(fin(X.ehi03)) wd.push("EHI = " + num(X.ehi03, 2) + t(" (۰–۳ km)", " (0–3 km)") + (fin(X.ehi01) ? " / " + num(X.ehi01, 2) + t(" (۰–۱ km)", " (0–1 km)") : "") + ": " + (X.ehi03 > 5 ? t("پتانسیل تورنادوهای قوی", "strong-tornado potential") : X.ehi03 > 1 ? t("پتانسیل ابرسلول و گردباد", "supercell/tornado potential") : t("زیر آستانهٔ ابرسلول", "below supercell threshold")));
      if(fin(X.brn)) wd.push("BRN = " + num(X.brn, 0) + ": " + (X.brn < 10 ? t("برش بسیار قوی نسبت به CAPE؛ ابرسلول محتمل، ولی ممکن است صعود را «پاره» کند اگر CAPE خیلی کم باشد", "very strong shear relative to CAPE; supercell likely (but too little CAPE can shear updrafts apart)") : X.brn < 45 ? t("بازهٔ مساعد ابرسلول (۱۰–۴۵)", "supercell-favourable range (10–45)") : t("برش ضعیف نسبت به CAPE؛ همرفت چندسلولی/نامنظم", "weak shear relative to CAPE; multicell/disorganised convection")));
      if(fin(X.meanWind06)) wd.push(t("باد میانگین ۰–۶ km: ", "0–6 km mean wind: ") + num(X.meanWind06, 1) + " m/s " + t("از جهت ", "from ") + num(X.meanDir06, 0) + "°" + (X.meanWind06 < 6 ? t(" — حرکت کند توفان؛ تجمع بارش و خطر سیلاب لحظه‌ای.", " — slow storm motion; rain accumulation and flash-flood risk.") : X.meanWind06 > 18 ? t(" — حرکت سریع؛ تندباد همراه و بارش کوتاه‌مدت.", " — fast motion; gusty with short-lived rain.") : ""));
      if(fin(X.cape) && fin(X.s06)){ const mode = X.cape < 300 ? t("همرفت کم‌انرژی/ضعیف", "low-energy/weak convection") : X.s06 < 10 ? t("تک‌سلول/پالسی", "single-cell / pulse storms") : X.s06 < 18 ? t("چندسلولی (خوشه‌ای)", "multicell clusters") : (X.srh03 > 150 && X.cape > 800 ? t("ابرسلول", "supercells") : t("خط توفان/سازمان‌یافته", "squall-line / organised mode")); wd.push(t("حالت محتمل همرفت: ", "Likely convective mode: ") + mode + "."); }
    } else wd.push(t("دادهٔ باد/ارتفاع کافی نیست؛ تحلیل برش، SRH، EHI، BRN و حالت همرفت ممکن نیست (مقداری ساخته نشد).", "Not enough wind/height data; shear, SRH, EHI, BRN and convective-mode analysis are unavailable (nothing was fabricated)."));
    B(t("۶. باد، برش و سازمان‌یافتگی توفان", "6. Wind, shear and storm organisation"), wd, "wind");
    /* ۷) ابر و رطوبت */
    const cl = [];
    if(X.clouds.length) cl.push(t("لایه‌های مرطوب/ابری (RH≥۸۵٪): ", "Moist/cloudy layers (RH ≥ 85%): ") + X.clouds.slice(0, 4).map(c => hp(c.base) + "→" + hp(c.top) + (fin(c.baseAgl) ? " (" + num(c.baseAgl, 0) + "–" + num(c.topAgl, 0) + " m AGL)" : "")).join(SEP) + ".");
    else cl.push(t("لایهٔ ابری قطعی (RH≥۸۵٪) در سونداژ دیده نمی‌شود؛ آسمان عمدتاً صاف تا کم‌ابر مگر همرفت محلی.", "No definite cloud layer (RH ≥ 85%) in the sounding; mostly clear to few clouds unless local convection."));
    if(fin(X.dryMid)) cl.push(t("کمینهٔ RH در میان‌تراز (۴۰۰ تا سطح−۱۵۰ hPa): ", "Minimum mid-level RH: ") + num(X.dryMid, 0) + "%" + (X.dryMid < 30 ? t(" — لایهٔ خشک میانی: ورود هوای خشک به ابر تبخیر و سرمایش و تندباد نزولی را تقویت می‌کند و ریزش گردوغبار را ممکن می‌سازد.", " — dry mid-level layer: entrainment strengthens evaporative cooling and downdrafts.") : ""));
    B(t("۷. ابر و رطوبت", "7. Cloud and moisture"), cl, "cloud");
    /* ۸) احتمالات */
    const pl = P.map(p => (en ? p.en : p.fa) + ": " + num(p.p) + "% (" + t(A.LV[p.lv][0], A.LV[p.lv][1]) + ")" + (p.drivers.length ? " ← " + p.drivers.map(d => ((NM[d[0]] && NM[d[0]].map ? NM[d[0]][en ? 1 : 0] : NM[d[0]]) || d[0]) + (d[1] < 0 ? "−" : "+")).join(" ") : ""));
    pl.push(t("«درصد» = مساعدبودن محیط برای پدیده (احتمال شرطی به وجود ماشه)، با مدل لجستیک شفاف با وزن‌های ثابت؛ برای تبدیل به احتمال وقوع باید با رصد واقعی واسنجی شود (MET.analysis.train).", "“Percent” = environmental favourability (conditional on a trigger) from a transparent logistic model with fixed weights; convert to occurrence probability only after calibration against observations (MET.analysis.train)."));
    B(t("۸. احتمالات محیطی", "8. Environmental probabilities"), pl, "prob");
    /* ۹) جمع‌بندی */
    const sm = []; const top = P.slice().sort((a, b) => b.p - a.p)[0];
    const stab = !fin(X.cape) || X.cape < 50 ? t("پایدار (همرفت عمیق بعید)", "stable (deep convection unlikely)") : X.cape < 500 ? t("ناپایداری ضعیف", "weakly unstable") : X.cape < 1500 ? t("ناپایداری متوسط", "moderately unstable") : t("ناپایداری قوی", "strongly unstable");
    sm.push(t("وضعیت کلی: ", "Overall: ") + stab + (fin(X.cin) && X.cin < -100 && X.cape > 300 ? t(" اما با سرپوش قوی (CIN=", " but strongly capped (CIN=") + num(X.cin) + ")" : "") + ".");
    sm.push(t("بیشترین مساعدت محیطی: ", "Highest environmental favourability: ") + (en ? top.en : top.fa) + " (" + num(top.p) + "%).");
    if(top.p < 10) sm.push(t("هیچ پدیدهٔ همرفتی شدید در این سونداژ مساعد نیست؛ هوای آرام/پایدار یا ابرناکی لایه‌ای است.", "No severe convective hazard is favoured by this sounding; calm/stable or stratiform conditions prevail."));
    sm.push(t("محدودیت‌ها: سونداژ خروجی مدل با تفکیک افقی ≈ ۹–۲۵ km و حدود ۱۹ تراز فشاری است؛ جزئیات لایهٔ مرزی، توپوگرافی کوچک‌مقیاس و ماشه‌های همدیدی را نمی‌بیند. برای تصمیم عملیاتی با نقشه‌ها و رصد تلفیق شود.", "Limitations: the sounding is model output (≈ 9–25 km, ~19 pressure levels); it cannot see fine boundary-layer structure, small-scale terrain or synoptic triggers. Combine with maps and observations for operational use."));
    B(t("۹. جمع‌بندی", "9. Summary"), sm, "sum");
    /* مرحلهٔ آزمایشگاه: خلاصهٔ متئوگرام چندمدلی */
    if(kind === "lab" && o.mg && o.mg.mods && o.mg.mods.length){ const ml = mgLines(o.mg, o, t, num); if(ml.length) B(t("۱۰. چشم‌انداز چندمدلی (متئوگرام)", "10. Multi-model outlook (meteogram)"), ml, "mg"); }
    return {ok:true, kind, en, X, probs:P, sections:S};
  }
  /* خلاصهٔ روزانهٔ متئوگرام: میانهٔ مدل‌ها و پراکندگی */
  function mgLines(D, o, t, num){
    const out = [], mods = D.mods, med = M.mg ? M.mg.median : null; if(!med) return out; const days = {}; D.T.forEach((s, i) => { const d = s.slice(0, 10); (days[d] = days[d] || []).push(i); });
    const keys = Object.keys(days).slice(0, o.mgDays || 5);
    out.push(t("مدل‌های دارای داده: ", "Models with data: ") + num(mods.length) + " (" + mods.map(m => m.name).join(CM) + ").");
    for(const d of keys){ const idx = days[d]; const tx = [], tn = [], gs = [], cc = [], pr = [];
      for(const m of mods){ const tv = idx.map(i => m.s.t[i]).filter(fin), gv = idx.map(i => m.s.wg[i]).filter(fin), cv = idx.map(i => m.s.cc[i]).filter(fin); if(tv.length >= 12){ tx.push(Math.max(...tv)); tn.push(Math.min(...tv)); } if(gv.length) gs.push(Math.max(...gv)); if(cv.length) cc.push(cv.reduce((a, b) => a + b, 0) / cv.length); const di = D.DT.indexOf(d); if(di >= 0 && fin(m.dpr[di])) pr.push(m.dpr[di]); }
      const mm = a => a.length >= 2 ? med(a) : (a.length ? a[0] : null), rg = a => a.length > 1 ? num(Math.min(...a), 0) + "–" + num(Math.max(...a), 0) : "";
      const parts = []; if(tx.length) parts.push("Tmax " + num(mm(tx), 1) + " °C (" + rg(tx) + ")"), parts.push("Tmin " + num(mm(tn), 1) + " °C (" + rg(tn) + ")");
      if(pr.length){ const pm = mm(pr), ag = pr.filter(v => v >= 1).length; parts.push(t("بارش ", "rain ") + num(pm, 1) + " mm (" + t("بیشینهٔ مدل‌ها ", "max model ") + num(Math.max(...pr), 1) + "; " + num(ag) + "/" + num(pr.length) + t(" مدل ≥۱ mm", " models ≥ 1 mm") + ")"); }
      if(gs.length) parts.push(t("تندباد ", "gust ") + num(mm(gs), 0) + " km/h"); if(cc.length) parts.push(t("ابرناکی ", "cloud ") + num(mm(cc), 0) + "%");
      if(parts.length) out.push(d + ": " + parts.join(" · ")); }
    const spreadT = []; mods.length > 1 && keys.length && (() => { const d = keys[0], idx = days[d]; const v = mods.map(m => Math.max(...idx.map(i => m.s.t[i]).filter(fin))).filter(fin); if(v.length > 1) spreadT.push(Math.max(...v) - Math.min(...v)); })();
    if(spreadT.length) out.push(t("پراکندگی مدل‌ها برای بیشینهٔ دمای امروز: ", "Model spread for today's max temperature: ") + num(spreadT[0], 1) + " °C" + (spreadT[0] > 4 ? t(" (عدم‌قطعیت زیاد)", " (high uncertainty)") : spreadT[0] < 2 ? t(" (توافق خوب)", " (good agreement)") : ""));
    out.push(t("هرچه پراکندگی مدل‌ها بیشتر باشد اطمینان به پیش‌بینی همان روز کمتر است؛ میانه اطمینان بیشتری از هر مدل منفرد دارد.", "The larger the model spread, the lower the confidence for that day; the median is usually more reliable than any single model."));
    return out;
  }
  A.skewt = (res, o) => make(res, o, "skewt");
  A.lab = (res, o) => make(res, o, "lab");
  /* ---------- خروجی HTML/متن ---------- */
  const esc = s => String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  A.html = function(a, en){
    const t = (fa, e) => en ? e : fa;
    let h = '<div class="anBox" dir="' + (en ? "ltr" : "rtl") + '"><h4 class="anH">' + esc(a.kind === "lab" ? t("تحلیل علمی آزمایشگاه محاسبات", "Scientific analysis — computation lab") : t("تحلیل علمی Skew-T", "Scientific analysis — Skew-T")) + "</h4>";
    h += '<div class="anProb">' + a.probs.map(p => '<div class="anP l' + p.lv + '"><span class="anPl">' + esc(en ? p.en : p.fa) + '</span><span class="anPb"><i style="width:' + p.p + '%"></i></span><b>' + p.p + "%</b></div>").join("") + "</div>";
    for(const s of a.sections){ h += '<section class="anS"><h5>' + esc(s.h) + "</h5>" + s.lines.map(l => "<p>" + esc(l) + "</p>").join("") + "</section>"; }
    return h + "</div>";
  };
  A.text = function(a){ return a.sections.map(s => s.h + "\n" + s.lines.map(l => "• " + l).join("\n")).join("\n\n"); };
  M.analysis = A;
})();
/* ===== رابط «آزمایشگاه محاسبات» (فاز ۳) — زبانهٔ پنجم صفحهٔ «تحلیل و هشدار» =====
   ورودی: چسباندن/بارگذاری سونداژ (Wyoming یا CSV) یا Open-Meteo؛ خروجی: Skew-T، هودوگراف، کارت هر شاخص.
   محاسبه در MET.lab است؛ این فایل فقط نمایش می‌دهد. رنگ‌بندی برچسب‌ها صرفاً نمایشی و جدا از محاسبه است. */
(function(){
  "use strict";
  const M = globalThis.MET, S = {res:null, parcel:"SB", src:"", om:null, omSel:0, tab:"om", busy:false, mg:null, mgP:"t", mgRange:+(typeof store!=="undefined"&&store.get?store.get("mg.range",15):15)||15, mgFit:{trend:false, per:false, ma:false}, skMode:"2d", skRot:38, an:null, mgHide:new Set(), mgClim:!!(typeof store!=="undefined"&&store.get&&store.get("mg.clim",0)), mgBusy:0, place:null};
  const E = () => typeof LANG !== "undefined" && LANG === "en";
  const t = (fa, en) => E() ? en : fa;
  const fin = x => typeof x === "number" && isFinite(x);
  const esc = s => String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  const fx = (x, d) => fin(x) ? x.toFixed(d == null ? 1 : d) : "—";
  let root = null;
  /* ---- برچسب رنگی نمایشی (آستانه‌ها راهنمای تجربی‌اند، نه حد قطعی) ---- */
  const BAND = {
    CAPE:v => v < 300 ? [0, "ضعیف", "Weak"] : v < 1000 ? [1, "متوسط", "Moderate"] : v < 2500 ? [2, "قوی", "Strong"] : [3, "بسیار قوی", "Extreme"],
    LI:v => v > 0 ? [0, "پایدار", "Stable"] : v > -3 ? [1, "ناپایداری ضعیف", "Marginal"] : v > -6 ? [2, "ناپایدار", "Unstable"] : [3, "بسیار ناپایدار", "Very unstable"],
    K:v => v < 20 ? [0, "کم", "Low"] : v < 30 ? [1, "متوسط", "Moderate"] : v < 35 ? [2, "زیاد", "High"] : [3, "بسیار زیاد", "Very high"],
    TT:v => v < 44 ? [0, "کم", "Low"] : v < 50 ? [1, "تندری محتمل", "Thunderstorms likely"] : v < 55 ? [2, "تندری شدید محتمل", "Severe possible"] : [3, "بسیار زیاد", "Very high"],
    SHEAR:v => v < 10 ? [0, "ضعیف", "Weak"] : v < 18 ? [1, "متوسط", "Moderate"] : v < 25 ? [2, "قوی", "Strong"] : [3, "بسیار قوی", "Very strong"],
    SCP:v => v < 1 ? [0, "زیر آستانه", "Below threshold"] : v < 4 ? [1, "مساعد", "Favourable"] : v < 10 ? [2, "قوی", "Strong"] : [3, "بسیار قوی", "Very strong"],
    STP:v => v < 1 ? [0, "زیر آستانه", "Below threshold"] : v < 3 ? [1, "مساعد", "Favourable"] : v < 6 ? [2, "قوی", "Strong"] : [3, "بسیار قوی", "Very strong"],
    SHIP:v => v < 1 ? [0, "زیر آستانه", "Below threshold"] : v < 2 ? [1, "مساعد", "Favourable"] : v < 4 ? [2, "قوی", "Strong"] : [3, "بسیار قوی", "Very strong"],
    SRH:v => v < 100 ? [0, "کم", "Low"] : v < 250 ? [1, "متوسط", "Moderate"] : v < 400 ? [2, "زیاد", "High"] : [3, "بسیار زیاد", "Very high"]
  };
  const bandTag = (k, v) => { if(!fin(v) || !BAND[k]) return ""; const b = BAND[k](v); return '<span class="labBand b' + b[0] + '" title="' + esc(t("رنگ‌بندی نمایشی؛ آستانه‌ها راهنمای تجربی‌اند", "Display only; thresholds are empirical guides")) + '">' + esc(b[E() ? 2 : 1]) + "</span>"; };
  const val = (v, u, d) => '<span dir="ltr" style="unicode-bidi:isolate"><span class="labV">' + fx(v, d) + '</span> <span class="labU">' + esc(u) + "</span></span>";
  const why = w => w ? '<div class="labWhy">' + esc(M.lab.whyText(w, E())) + "</div>" : "";
  /* ---- کارت ---- */
  function card(key, body, o){
    o = o || {}; const m = M.meta[o.meta || key] || {}, name = E() ? m.en : m.fa, bad = o.bad;
    const det = m.formula ? '<details class="labDet"><summary>' + esc(t("ورودی، فرمول و محدودیت‌ها", "Inputs, formula and limits")) + "</summary><dl>" +
      "<dt>" + esc(t("ورودی", "Inputs")) + "</dt><dd>" + esc(m.inputs || "") + "</dd><dt>" + esc(t("فرمول / الگوریتم", "Formula / algorithm")) + '</dt><dd dir="ltr" class="labF">' + esc(m.formula) + "</dd>" +
      "<dt>" + esc(t("واحد و بازه", "Unit and range")) + "</dt><dd>" + esc((m.unit || "") + (m.range ? " — " + m.range : "")) + "</dd>" +
      "<dt>" + esc(t("داده ناکافی", "Insufficient data")) + "</dt><dd>" + esc(m.insufficient || "") + "</dd><dt>" + esc(t("محدودیت تفسیر", "Limits")) + "</dt><dd>" + esc(m.limits || "") + "</dd>" +
      "<dt>" + esc(t("مرجع", "Reference")) + '</dt><dd dir="ltr">' + esc(m.ref || "") + "</dd></dl></details>" : "";
    return '<article class="labCard' + (bad ? " bad" : "") + '"><h4>' + esc(name || key) + (o.tag || "") + "</h4>" + body + det + "</article>";
  }
  const simple = (k, it, unit, d, band, extra) => it && it.v != null ? card(k, '<div class="labMain">' + val(it.v, unit, d) + (band ? bandTag(band, it.v) : "") + "</div>" + (extra || "")) :
    card(k, '<div class="labMain labNA">' + esc(t("داده ناکافی", "Insufficient data")) + "</div>" + why(it && it.why), {bad:true});
  function cardsHtml(r){
    const I = r.items, P = r.parcels[r.parcelType], z0 = r.surface.z, agl = p => { const z = M.lab.heightAtP(r.prof, p); return fin(z) && fin(z0) ? z - z0 : null; };
    let h = '<h3 class="labH">' + esc(t("شاخص‌های ترمودینامیکی", "Thermodynamic indices")) + "</h3><div class='labGrid'>";
    const note = I.CAPE.note === "no_lfc" ? '<div class="labWhy">' + esc(M.lab.whyText("no_lfc", E())) + "</div>" : "";
    h += simple("CAPE", I.CAPE, "J/kg", 0, "CAPE", '<div class="labSub">' + esc(t("پارسل", "Parcel")) + ": " + r.parcelType + "</div>" + note);
    h += simple("CIN", I.CIN, "J/kg", 0);
    h += I.LCL.v != null ? card("LCL", '<div class="labMain">' + val(I.LCL.v, "hPa", 0) + '</div><div class="labSub">' + (agl(I.LCL.v) != null ? fx(agl(I.LCL.v), 0) + " m AGL · " : "") + fx(I.LCL.Tk - 273.15, 1) + " °C</div>") : simple("LCL", I.LCL, "hPa", 0);
    if(I.CAPE.v != null){
      h += r.lfc != null ? card("LFC", '<div class="labMain">' + val(r.lfc, "hPa", 0) + "</div>" + (agl(r.lfc) != null ? '<div class="labSub">' + fx(agl(r.lfc), 0) + " m AGL</div>" : "")) : card("LFC", '<div class="labMain labNA">—</div>' + why("no_lfc"));
      h += r.el != null ? card("EL", '<div class="labMain">' + val(r.el, "hPa", 0) + "</div>" + (agl(r.el) != null ? '<div class="labSub">' + fx(agl(r.el), 0) + " m AGL</div>" : "")) : card("EL", '<div class="labMain labNA">—</div>' + why(r.lfc == null ? "no_lfc" : ""));
    } else { h += simple("LFC", I.CAPE, "hPa", 0); h += simple("EL", I.CAPE, "hPa", 0); }
    h += simple("LI", I.LI, "°C", 1, "LI") + simple("SHOWALTER", I.SHOWALTER, "°C", 1) + simple("K", I.K, "°C", 1, "K") + simple("TT", I.TT, "°C", 1, "TT") + simple("VT", I.VT, "°C", 1) + simple("CT", I.CT, "°C", 1) + simple("PWAT", I.PWAT, "mm", 1);
    h += "</div>";
    h += '<h3 class="labH">' + esc(t("باد و برش", "Wind and shear")) + "</h3>";
    if(!r.hasWind) h += '<div class="labNote">' + esc(t("دادهٔ باد یا ارتفاع کافی نیست (کمتر از ۳ سطح با u،v و z)؛ شاخص‌های باد محاسبه نمی‌شوند. چیزی با صفر جایگزین نشده است.", "Not enough wind/height data (< 3 levels with u, v, z); wind indices are not computed. Nothing was replaced with zero.")) + "</div>";
    h += "<div class='labGrid'>";
    const sh = I.SHEAR, row = (lab, it, u, d, k) => '<div class="labRow"><span>' + lab + '</span><span>' + (it.v != null ? val(it.v, u, d) + (k ? bandTag(k, it.v) : "") : '<span class="labNA">—</span>') + "</span></div>";
    h += card("SHEAR", row("0–1 km", sh.s01, "m/s", 1) + row("0–3 km", sh.s03, "m/s", 1) + row("0–6 km", sh.s06, "m/s", 1, "SHEAR") + (sh.s06.v == null ? why(sh.s06.why) : ""), {bad:sh.s06.v == null && sh.s03.v == null});
    const bk = I.BUNKERS, vec = q => q ? fx(W().speed(q.u, q.v), 1) + " m/s @ " + fx(W().direction(q.u, q.v), 0) + "°" : "—";
    h += bk.right ? card("BUNKERS", '<div class="labRow"><span>RM</span><span dir="ltr">' + vec(bk.right) + '</span></div><div class="labRow"><span>LM</span><span dir="ltr">' + vec(bk.left) + '</span></div><div class="labRow"><span>' + esc(t("میانگین ۰–۶ km", "Mean 0–6 km")) + '</span><span dir="ltr">' + vec(bk.mean) + "</span></div>") : card("BUNKERS", '<div class="labMain labNA">' + esc(t("داده ناکافی", "Insufficient data")) + "</div>" + why(bk.why), {bad:true});
    const sr = I.SRH, srr = (lab, it) => '<div class="labRow"><span>' + lab + "</span><span>" + (it.v != null ? val(it.v, "m²/s²", 0) + '<span class="labSub"> (+' + fx(it.pos, 0) + " / " + fx(it.neg, 0) + ")</span>" : '<span class="labNA">—</span>') + "</span></div>";
    h += card("SRH", srr("0–1 km", sr.s01) + srr("0–3 km", sr.s03) + (sr.s03.v != null ? bandTag("SRH", sr.s03.v) : "") + '<div class="labSub">' + esc(t("نسبت به حرکت راست‌گرد Bunkers", "Relative to Bunkers right-mover")) + "</div>" + (sr.s03.v == null ? why(sr.s03.why) : ""), {bad:sr.s03.v == null && sr.s01.v == null});
    h += simple("CRITICAL", I.CRITICAL, "°", 0);
    h += "</div>" + severeHtml(r);
    return h;
  }
  /* ---- پارامترهای توفان شدید (فاز ۴) ---- */
  function terms(o){ if(!o || !o.terms) return ""; const nm = {cape:"CAPE", srh:"SRH", shear:t("برش", "shear"), lcl:"LCL", cin:"CIN", mr:"MUmr", t500:"T500"};
    return '<div class="labSub" dir="ltr">' + Object.keys(o.terms).map(k => (nm[k] || k) + "=" + fx(o.terms[k], 2)).join(" · ") + "</div>"; }
  function severeHtml(r){
    const sv = r.severe; if(!sv || sv.error) return ""; let h = '<h3 class="labH">' + esc(t("پارامترهای ترکیبی توفان شدید", "Composite severe-storm parameters")) + '</h3><div class="labNote">' + esc(t("هر جزء فرمول جداگانه نشان داده می‌شود. حرکت توفان = Bunkers ۰–۶ km (ساده‌سازی). مقدار ۰ «بدون لایهٔ مؤثر» یک نتیجهٔ معتبر است، نه داده‌ی گمشده.", "Each formula term is shown. Storm motion = Bunkers 0–6 km (simplification). A 0 from “no effective inflow” is a valid result, not missing data.")) + "</div><div class='labGrid'>";
    const nt = it => it && it.note ? '<div class="labWhy">' + esc(M.lab.whyText(it.note, E())) + "</div>" : "";
    const sc = (k, it, band, extra, unit) => it && it.v != null ? card(k, '<div class="labMain">' + val(it.v, unit || "", unit ? 1 : 2) + (band ? bandTag(band, it.v) : "") + "</div>" + terms(it) + (extra || "") + nt(it)) : card(k, '<div class="labMain labNA">' + esc(t("داده ناکافی", "Insufficient data")) + "</div>" + why(it && it.why), {bad:true});
    const eil = sv.EIL;
    h += eil && eil.none ? card("EIL", '<div class="labMain labNA">—</div>' + why("no_effective_inflow")) : (eil && eil.v != null ? card("EIL", '<div class="labMain">' + val(eil.baseP, "hPa", 0) + " → " + val(eil.topP, "hPa", 0) + "</div>" + (eil.baseAgl != null ? '<div class="labSub">' + fx(eil.baseAgl, 0) + " → " + fx(eil.topAgl, 0) + " m AGL</div>" : "")) : card("EIL", '<div class="labMain labNA">' + esc(t("داده ناکافی", "Insufficient data")) + "</div>" + why(eil && eil.why), {bad:true}));
    h += sc("ESRH", sv.ESRH, null, "", "m²/s²");
    h += sc("EBWD", sv.EBWD, null, "", "m/s");
    h += sc("SCP", sv.SCP, "SCP", sv.SCP && sv.SCP.v != null ? '<div class="labSub">' + esc(t("با جملهٔ CIN (SPC)", "with CIN term (SPC)")) + ": " + fx(sv.SCP.withCin, 2) + "</div>" : "");
    h += sc("STPF", sv.STPF, "STP") + sc("STPE", sv.STPE, "STP") + sc("SHIP", sv.SHIP, "SHIP", sv.SHIP && sv.SHIP.v != null ? '<div class="labSub">' + esc(t("ضرایب تعدیل", "adjustments")) + ": CAPE ×" + fx(sv.SHIP.adj.cape, 2) + " · LR ×" + fx(sv.SHIP.adj.lr, 2) + " · FZL ×" + fx(sv.SHIP.adj.frz, 2) + "</div>" : "");
    h += simple("LR75", sv.LR75, "K/km", 1) + simple("FZL", sv.FZL, "m AGL", 0, null, sv.FZL && sv.FZL.note ? '<div class="labSub">' + esc(M.lab.whyText(sv.FZL.note, E())) + "</div>" : "");
    return h + "</div>";
  }
  const W = () => M.wind;
  /* ---- تحلیل علمی (آفلاین، قاعده‌محور + لجستیک کنترل‌شده) ---- */
  function anShow(kind){
    const box = root.querySelector("#labAn"); if(!S.res){ msg(t("ابتدا پروفایل را دریافت یا وارد کنید.", "Fetch or enter a profile first."), true); return; }
    let a; try{ a = kind === "lab" ? M.analysis.lab(S.res, {en:E(), mg:S.mg, mgDays:S.mgRange > 5 ? 5 : S.mgRange}) : M.analysis.skewt(S.res, {en:E()}); }catch(e){ console.warn(e); msg(t("تحلیل ناموفق بود.", "Analysis failed."), true); return; }
    S.an = {kind}; box.hidden = false;
    box.innerHTML = '<div class="anTop"><span></span><span><button type="button" id="anX">✕</button></span></div>' + M.analysis.html(a, E());
    box.querySelector("#anX").onclick = () => { S.an = null; box.hidden = true; }; if(typeof anTools === "function") anTools(box, () => M.analysis.text(a), E() ? "en" : "fa", t("تحلیل پروفایل جو", "Sounding analysis"));
    box.scrollIntoView({behavior:"smooth", block:"start"});
  }
  /* ---- رندر نتیجه ---- */
  function render(){
    const out = root.querySelector("#labOut"); if(!S.res){ out.hidden = true; return; } const r = S.res; out.hidden = false;
    const n = r.prof.p.length, iss = r.issues.length ? ' <span class="labSub">· ' + esc(t("هشدار کیفیت", "Quality notes")) + ": " + esc(r.issues.slice(0, 6).join("، ")) + (r.issues.length > 6 ? " …" : "") + "</span>" : "";
    root.querySelector("#labSum").innerHTML = "<b>" + esc(S.src) + "</b> — " + esc(t("سطوح معتبر", "valid levels")) + ": <b>" + n + "</b> (" + fx(r.surface.p, 0) + "→" + fx(r.top, 0) + " hPa) · " + esc(t("ردیف حذف‌شده", "dropped rows")) + ": " + r.dropped + iss;
    root.querySelectorAll("[data-par]").forEach(b => b.classList.toggle("on", b.dataset.par === S.parcel));
    const sk = root.querySelector("#labSk"), ttl = (S.place ? (E() ? S.place.en || S.place.name : S.place.name) + " · " : "") + S.parcel + " parcel" + (S.omTag && S.src && S.src.indexOf("Open-Meteo") === 0 ? " · " + S.omTag : "");
    root.querySelectorAll("[data-skm]").forEach(b => b.classList.toggle("on", b.dataset.skm === S.skMode)); root.querySelector("#skRotL").hidden = S.skMode !== "3d";
    try{
      if(S.skMode === "3d" && M.skewt2){ sk.innerHTML = M.skewt2.svg3d(r, {en:E(), parcel:S.parcel, title:ttl, rot:S.skRot}); }
      else if(S.skMode === "2d" && M.skewt2){ sk.innerHTML = M.skewt2.svg(r, {en:E(), parcel:S.parcel, title:ttl}); M.skewt2.attach(sk, r, root.querySelector("#labInfo")); }
      else { sk.innerHTML = M.skewt.svg(r, {en:E(), parcel:S.parcel, title:ttl}); M.skewt.attach(sk, r, root.querySelector("#labInfo")); }
    }catch(e){ console.warn("skewt", e); sk.innerHTML = M.skewt.svg(r, {en:E(), parcel:S.parcel, title:ttl}); M.skewt.attach(sk, r, root.querySelector("#labInfo")); }
    if(S.an) anShow(S.an.kind);
    const hd = M.skewt.hodograph(r, {en:E()}); root.querySelector("#labHodo").innerHTML = hd || '<div class="labNote">' + esc(t("هودوگراف: دادهٔ باد کافی نیست.", "Hodograph: not enough wind data.")) + "</div>";
    root.querySelector("#labCards").innerHTML = cardsHtml(r);
  }
  function analyze(raw, src, keepFirst){
    const res = M.lab.analyze(raw, {parcel:S.parcel});
    if(!res.ok){ S.res = null; render(); msg(t("تحلیل ممکن نشد: ", "Cannot analyse: ") + M.lab.ioWhyText(res.why, E()) + (res.issues && res.issues.length ? " (" + res.issues.slice(0, 3).join("، ") + ")" : ""), true); return false; }
    S.res = res; S.src = src; S.raw = raw; msg(""); render(); return true;
  }
  function msg(s, bad){ const e = root.querySelector("#labMsg"); e.textContent = s; e.className = "labMsg" + (bad ? " bad" : ""); e.hidden = !s; }
  /* ---- مدل و ران سونداژ (r57): کاربر مدل را انتخاب می‌کند و ران از meta.json خود Open-Meteo خوانده می‌شود؛ نشد ⇒ «ران نامشخص» (چیزی حدس زده نمی‌شود) ---- */
  const OM_MODELS = [["ecmwf_ifs025", "ECMWF IFS 0.25° (اروپا)", "ecmwf_ifs025", "ECMWF IFS 0.25°"], ["gfs_seamless", "GFS (آمریکا)", "ncep_gfs025", "GFS"], ["icon_seamless", "ICON (آلمان)", "dwd_icon", "ICON"],
    ["gem_seamless", "GEM (کانادا)", "cmc_gem_gdps", "GEM"], ["ukmo_seamless", "UKMO (بریتانیا)", "ukmo_global_deterministic_10km", "UKMO"], ["best_match", "خودکار (ترکیب Open-Meteo)", "", "Auto (Open-Meteo blend)"]];
  const runFmt = d => d.toISOString().slice(0, 10) + " " + String(d.getUTCHours()).padStart(2, "0") + "Z";
  async function omMeta(dom){
    if(!dom) return null; const ac = new AbortController(), to = setTimeout(() => ac.abort(), 8000);
    try{ const r = await fetch("https://api.open-meteo.com/data/" + dom + "/static/meta.json", {signal:ac.signal}); if(!r.ok) return null; const j = await r.json(); const ts = j && j.last_run_initialisation_time; return typeof ts === "number" && ts > 1e9 ? new Date(ts * 1000) : null; }
    catch(e){ return null; } finally{ clearTimeout(to); }
  }
  /* ---- Open-Meteo ---- */
  async function omFetch(){
    const lat = parseFloat(root.querySelector("#labLat").value), lon = parseFloat(root.querySelector("#labLon").value);
    if(!(lat >= -90 && lat <= 90) || !(lon >= -180 && lon <= 180)){ msg(t("مختصات نامعتبر است.", "Invalid coordinates."), true); return; }
    const btn = root.querySelector("#labOmGo"); btn.disabled = true; msg(t("در حال دریافت از Open-Meteo…", "Fetching from Open-Meteo…"));
    const ac = new AbortController(), to = setTimeout(() => ac.abort(), 60000);
    try{
      const mSel = root.querySelector("#labOmM"), mid = mSel ? mSel.value : "ecmwf_ifs025", mo = OM_MODELS.find(m => m[0] === mid) || OM_MODELS[0]; sset("lab.om.m", mid);
      const q = await M.mg.cget(M.io.omUrl(lat, lon, {model: mid === "best_match" ? "" : mid}), ac.signal); if(!q.ok) throw new Error("HTTP " + q.status);
      const j = q.j; if(!j || j.error) throw new Error((j && j.reason) || "api error");
      S.om = j; const rt = await omMeta(mo[2]); S.omTag = (E() ? mo[3] : mo[1].replace(/ \(.*\)$/, "")) + " · " + (rt ? t("ران ", "run ") + runFmt(rt) + " UTC" : t("ران: نامشخص (Open-Meteo اعلام نکرد)", "run: unknown (not reported)")); const times = M.io.omTimes(j), sel = root.querySelector("#labOmT"); const now = new Date().toISOString().slice(0, 13);
      sel.innerHTML = times.map((x, i) => '<option value="' + i + '">' + esc(x.replace("T", " ") + " UTC") + "</option>").join(""); let k = times.findIndex(x => x.slice(0, 13) >= now); if(k < 0) k = 0; sel.value = String(k);
      msg(""); root.querySelector("#labOmRow").hidden = false; omRun(); plCollapse(true);
    }catch(e){ S.om = null; msg(t("دریافت ناموفق: ", "Fetch failed: ") + (e.name === "AbortError" ? t("زمان انتظار تمام شد", "timeout") : /429/.test(e.message) ? t("HTTP 429 = سقف درخواست رایگان Open-Meteo پر شده؛ چند دقیقه (یا اگر ادامه داشت، چند ساعت) بعد دوباره امتحان کنید", "HTTP 429 = Open-Meteo free request limit reached; try again in a few minutes (or hours if it persists)") : e.message) + t(" — اتصال یا دسترسی مرورگر به api.open-meteo.com را بررسی کنید؛ می‌توانید سونداژ را دستی بچسبانید.", " — check connection / access to api.open-meteo.com; you can paste a sounding instead."), true); }
    finally{ clearTimeout(to); btn.disabled = false; }
  }
  /* ---- مقطع قائم (r138): خط بین دو نقطه، ۹ نقطه از Open-Meteo در یک درخواست؛ رطوبت نسبی (پلهٔ ۲۰٪)، همدماها، سطح زمین ---- */
  async function xsRun(){
    const box = root.querySelector("#xsOut"), g = id => parseFloat(root.querySelector(id).value);
    const a = {lat: g("#labLat"), lon: g("#labLon")}, b = {lat: g("#xsLat"), lon: g("#xsLon")};
    if(![a.lat, a.lon, b.lat, b.lon].every(Number.isFinite) || Math.abs(a.lat) > 90 || Math.abs(b.lat) > 90 || Math.abs(a.lon) > 180 || Math.abs(b.lon) > 180){ box.innerHTML = '<div class="labMsg bad">' + esc(t("مختصات نقطهٔ آغاز یا پایان نامعتبر است.", "Invalid start or end coordinates.")) + "</div>"; return; }
    const N = 9, la = [], lo = []; for(let k = 0; k < N; k++){ la.push((a.lat + (b.lat - a.lat) * k / (N - 1)).toFixed(3)); lo.push((a.lon + (b.lon - a.lon) * k / (N - 1)).toFixed(3)); }
    const LV = M.io.OM_LEVELS.filter(l => l >= 100), h = ["surface_pressure"]; for(const l of LV) h.push("temperature_" + l + "hPa", "relative_humidity_" + l + "hPa");
    const u = "https://api.open-meteo.com/v1/forecast?latitude=" + la.join(",") + "&longitude=" + lo.join(",") + "&hourly=" + h.join(",") + "&timezone=GMT&forecast_days=3" + (S.om && S.om.generationtime_ms != null ? "" : "");
    MXS.set(box, "load", t("در حال دریافت…", "Fetching…"));
    const ac = new AbortController(), to = setTimeout(() => ac.abort(), 60000);
    try{
      const q = await M.mg.cget(u, ac.signal); if(!q.ok) throw new Error("HTTP " + q.status);
      const J = Array.isArray(q.j) ? q.j : [q.j]; if(J.length !== N || !J.every(x => x && x.hourly)) throw new Error(t("پاسخ ناقص", "incomplete response"));
      const tm = J[0].hourly.time, ti = Math.min(tm.length - 1, Math.max(0, parseInt(root.querySelector("#labOmT").value, 10) || 0)), v = (j, k) => { const x = j.hourly[k] && j.hourly[k][ti]; return typeof x === "number" && isFinite(x) ? x : null; };
      const W = 760, Ht = 340, L = 46, R = 12, T = 22, B = 40, pw = W - L - R, ph = Ht - T - B, lp = Math.log, p0 = lp(1000), p1 = lp(100), X = k => L + pw * k / (N - 1), yy = p => T + ph * (lp(p) - p1) / (p0 - p1);
      const cols = ["#f4efe0", "#d6e6f2", "#a9cbe6", "#6fa6d4", "#3b78b8", "#1f4f8f"], cw = pw / (N - 1);
      let out = '<svg viewBox="0 0 ' + W + " " + Ht + '" width="100%" role="img" style="max-width:' + W + 'px;direction:ltr;font:10px sans-serif"><rect x="' + L + '" y="' + T + '" width="' + pw + '" height="' + ph + '" fill="#f4f1e6"/>';
      for(let k = 0; k < N; k++){ const ps = v(J[k], "surface_pressure");
        for(let m = 0; m < LV.length; m++){ const l = LV[m], rh = v(J[k], "relative_humidity_" + l + "hPa"); if(rh == null || (ps != null && l > ps)) continue;
          const up = m + 1 < LV.length ? LV[m + 1] : l * 0.95, dn = m > 0 ? LV[m - 1] : l * 1.03, ya = yy(Math.sqrt(l * up)), yb = yy(Math.sqrt(l * dn));
          out += '<rect x="' + (X(k) - cw / 2).toFixed(1) + '" y="' + ya.toFixed(1) + '" width="' + (cw + 0.6).toFixed(1) + '" height="' + (yb - ya + 0.6).toFixed(1) + '" fill="' + cols[Math.min(5, Math.floor(rh / 20))] + '"/>'; } }
      const iso = (thr, color) => { let pts = [], s2 = ""; for(let k = 0; k < N; k++){ let best = null; for(let m = LV.length - 1; m > 0; m--){ const A = v(J[k], "temperature_" + LV[m - 1] + "hPa"), Bv = v(J[k], "temperature_" + LV[m] + "hPa"); if(A == null || Bv == null) continue; if((A - thr) * (Bv - thr) <= 0 && A !== Bv){ const f = (A - thr) / (A - Bv); best = Math.exp(lp(LV[m - 1]) + f * (lp(LV[m]) - lp(LV[m - 1]))); break; } }
          if(best != null) pts.push(X(k).toFixed(1) + "," + yy(best).toFixed(1)); else { if(pts.length > 1) s2 += '<polyline points="' + pts.join(" ") + '" fill="none" stroke="' + color + '" stroke-width="1.6"/>'; pts = []; } }
        if(pts.length > 1) s2 += '<polyline points="' + pts.join(" ") + '" fill="none" stroke="' + color + '" stroke-width="1.6"/>'; return s2; };
      out += iso(0, "#c0392b") + iso(-20, "#7b2d8e") + iso(-40, "#3f3f3f");
      const sp = []; for(let k = 0; k < N; k++){ const ps = v(J[k], "surface_pressure"); if(ps != null) sp.push([X(k), yy(Math.min(1000, ps))]); }
      if(sp.length > 1) out += '<polygon points="' + sp.map(q => q[0].toFixed(1) + "," + q[1].toFixed(1)).join(" ") + " " + sp[sp.length - 1][0].toFixed(1) + "," + (T + ph) + " " + sp[0][0].toFixed(1) + "," + (T + ph) + '" fill="#8a6d3b" fill-opacity=".85"/>';
      for(const l of [1000, 850, 700, 500, 300, 200, 100]) out += '<text x="' + (L - 5) + '" y="' + (yy(l) + 3).toFixed(1) + '" text-anchor="end">' + l + '</text><line x1="' + L + '" x2="' + (L + pw) + '" y1="' + yy(l).toFixed(1) + '" y2="' + yy(l).toFixed(1) + '" stroke="#0002"/>';
      const rad = Math.PI / 180, dist = (p, q) => 6371 * 2 * Math.asin(Math.sqrt(Math.sin((q.lat - p.lat) * rad / 2) ** 2 + Math.cos(p.lat * rad) * Math.cos(q.lat * rad) * Math.sin((q.lon - p.lon) * rad / 2) ** 2)), D = dist(a, b);
      for(const k of [0, 2, 4, 6, 8]) out += '<text x="' + X(k).toFixed(1) + '" y="' + (Ht - 18) + '" text-anchor="' + (k === 8 ? "end" : k === 0 ? "start" : "middle") + '">' + Math.round(D * k / (N - 1)) + " km</text>";
      out += '<text x="' + L + '" y="' + (Ht - 5) + '">A (' + a.lat.toFixed(2) + ", " + a.lon.toFixed(2) + ')</text><text x="' + (L + pw) + '" y="' + (Ht - 5) + '" text-anchor="end">B (' + b.lat.toFixed(2) + ", " + b.lon.toFixed(2) + ")</text>";
      out += '<text x="' + L + '" y="14" font-weight="700">' + esc(t("مقطع قائم", "Vertical cross-section")) + " · " + esc(tm[ti].replace("T", " ") + " UTC") + "</text></svg>";
      const leg = cols.map((c, i) => '<span class="xsLg"><i style="background:' + c + '"></i>' + (i * 20) + (i < 5 ? "–" + (i * 20 + 20) : "") + "%</span>").join("");
      box.innerHTML = out + '<p class="labSub">' + esc(t("رطوبت نسبی (پله‌ای، بدون هم‌آمیزی): ", "Relative humidity (stepped, not blended): ")) + leg + " · " + esc(t("خط قرمز ۰°C، بنفش ‎−۲۰°C‎، خاکستری ‎−۴۰°C‎؛ قهوه‌ای = سطح زمین مدل.", "red 0 °C, purple −20 °C, grey −40 °C; brown = model terrain.")) + " " + esc(t("۹ نقطهٔ هم‌فاصله روی خط راست A–B (نه مدار بزرگ)؛ داده: Open-Meteo، مدل خودکار؛ تفکیک افقی همان شبکهٔ مدل است و کوهستان تیز را صاف می‌کند.", "9 equally spaced points on the straight A–B line (not a great circle); data: Open-Meteo, automatic model; horizontal resolution is that of the model grid and smooths sharp terrain.")) + "</p>";
    }catch(e){ MXS.set(box, "err", t("دریافت ناموفق: ", "Fetch failed: ") + (e.name === "AbortError" ? t("زمان انتظار تمام شد", "timeout") : e.message), xsRun); }
    finally{ clearTimeout(to); }
  }
  /* ---- مقطع زمان–ارتفاع (نقطه‌ای) از خروجی Open-Meteo: رطوبت نسبی، همدمای ۰°C، بادنما ---- */
  function thRender(){
    const xsP = root.querySelector("#labXS"); if(xsP){ const had = !xsP.hidden; xsP.hidden = !(S.om && S.om.hourly); if(!had && !xsP.hidden){ const la = parseFloat(root.querySelector("#labLat").value), lo = parseFloat(root.querySelector("#labLon").value); if(Number.isFinite(la) && Number.isFinite(lo)){ root.querySelector("#xsLat").value = la.toFixed(2); root.querySelector("#xsLon").value = Math.min(180, lo + 4).toFixed(2); } } }
    const box = root.querySelector("#labTH"); if(!box) return;
    const j = S.om; if(!j || !j.hourly || !j.hourly.time){ box.hidden = true; box.innerHTML = ""; return; }
    try{
      const H = j.hourly, tm = H.time, LV = M.io.OM_LEVELS.filter(l => l >= 100), n = Math.min(tm.length, 72);
      const W = 760, Ht = 340, L = 46, R = 12, T = 22, B = 34, pw = W - L - R, ph = Ht - T - B, lp = Math.log, p0 = lp(1000), p1 = lp(100);
      const X = i => L + pw * (n > 1 ? i / (n - 1) : 0.5);
      const yy = p => T + ph * (lp(p) - p1) / (p0 - p1); // 100 hPa top, 1000 bottom
      const col = rh => { const k = Math.round(Math.max(0, Math.min(1, rh / 100)) * 5) / 5; const c = [[245,240,225],[200,225,240],[110,170,215],[40,100,180]]; const f = k * 3, a = Math.min(2, Math.floor(f)), u = f - a; return "rgb(" + [0,1,2].map(q => Math.round(c[a][q] + (c[a+1][q] - c[a][q]) * u)).join(",") + ")"; };
      const g = (k, i) => { const v = H[k] && H[k][i]; return typeof v === "number" && isFinite(v) ? v : null; };
      let out = '<svg viewBox="0 0 ' + W + ' ' + Ht + '" width="100%" role="img" style="max-width:' + W + 'px;direction:ltr;font:10px sans-serif"><rect x="' + L + '" y="' + T + '" width="' + pw + '" height="' + ph + '" fill="#f4f1e6"/>';
      const cw = pw / Math.max(1, n - 1);
      for(let i = 0; i < n; i++){
        const ps = g("surface_pressure", i);
        for(let k = 0; k < LV.length; k++){
          const l = LV[k], rh = g("relative_humidity_" + l + "hPa", i); if(rh == null || (ps != null && l > ps)) continue;
          const up = k + 1 < LV.length ? LV[k + 1] : l * 0.95, dn = k > 0 ? LV[k - 1] : l * 1.03, ya = yy(Math.sqrt(l * up)), yb = yy(Math.sqrt(l * dn));
          out += '<rect x="' + (X(i) - cw / 2).toFixed(1) + '" y="' + ya.toFixed(1) + '" width="' + (cw + 0.6).toFixed(1) + '" height="' + (yb - ya + 0.6).toFixed(1) + '" fill="' + col(rh) + '"/>';
        }
      }
      // همدمای ۰°C: درون‌یابی خطی دما در log p
      let pts = [];
      for(let i = 0; i < n; i++){
        let best = null;
        for(let k = LV.length - 1; k > 0; k--){ const a = g("temperature_" + LV[k - 1] + "hPa", i), b = g("temperature_" + LV[k] + "hPa", i); if(a == null || b == null) continue; if(a > 0 && b <= 0){ const f = a / (a - b); best = Math.exp(lp(LV[k - 1]) + f * (lp(LV[k]) - lp(LV[k - 1]))); break; } }
        if(best != null) pts.push(X(i).toFixed(1) + "," + yy(best).toFixed(1)); else if(pts.length){ out += '<polyline points="' + pts.join(" ") + '" fill="none" stroke="#c0392b" stroke-width="2"/>'; pts = []; }
      }
      if(pts.length) out += '<polyline points="' + pts.join(" ") + '" fill="none" stroke="#c0392b" stroke-width="2"/>';
      // سطح زمین
      let sp = []; for(let i = 0; i < n; i++){ const ps = g("surface_pressure", i); if(ps != null) sp.push(X(i).toFixed(1) + "," + yy(Math.min(1000, ps)).toFixed(1)); }
      if(sp.length) out += '<polyline points="' + sp.join(" ") + '" fill="none" stroke="#6b4f2a" stroke-width="1.5" stroke-dasharray="4 3"/>';
      // بادنما (پیکان) هر ۶ ساعت روی ۵ تراز
      const step = Math.max(1, Math.round(n / 12));
      for(const l of [850, 700, 500, 300, 200]) for(let i = 0; i < n; i += step){
        const s = g("wind_speed_" + l + "hPa", i), d = g("wind_direction_" + l + "hPa", i); if(s == null || d == null) continue;
        const ps = g("surface_pressure", i); if(ps != null && l > ps) continue;
        const r = (d + 180) * Math.PI / 180, len = 6 + Math.min(14, s * 0.5), x = X(i), y = yy(l), dx = Math.sin(r) * len, dy = -Math.cos(r) * len;
        out += '<g stroke="#222" stroke-width="1.2"><line x1="' + x.toFixed(1) + '" y1="' + y.toFixed(1) + '" x2="' + (x + dx).toFixed(1) + '" y2="' + (y + dy).toFixed(1) + '"/><circle cx="' + x.toFixed(1) + '" cy="' + y.toFixed(1) + '" r="1.8" fill="#222"/></g>';
      }
      for(const l of [1000, 850, 700, 500, 300, 200, 100]) out += '<text x="' + (L - 5) + '" y="' + (yy(l) + 3).toFixed(1) + '" text-anchor="end">' + l + '</text><line x1="' + L + '" x2="' + (L + pw) + '" y1="' + yy(l).toFixed(1) + '" y2="' + yy(l).toFixed(1) + '" stroke="#0002"/>';
      const dstep = Math.max(1, Math.round(n / 6));
      for(let i = 0; i < n; i += dstep) out += '<text x="' + X(i).toFixed(1) + '" y="' + (Ht - B + 14) + '" text-anchor="middle">' + esc(tm[i].slice(5, 10) + " " + tm[i].slice(11, 13) + "Z") + '</text>';
      out += '<text x="12" y="' + (T + ph / 2) + '" transform="rotate(-90 12 ' + (T + ph / 2) + ')" text-anchor="middle">hPa</text></svg>';
      const wasOpen = box.querySelector("details") ? box.querySelector("details").open : window.innerWidth > 700;
      box.innerHTML = '<details' + (wasOpen ? ' open' : '') + '><summary><b>' + esc(t("مقطع زمان–ارتفاع در این نقطه (رطوبت نسبی)", "Point time–height section (relative humidity)")) + '</b></summary>' + out +
        '<div class="labSub">' + esc(t("رنگ: رطوبت نسبی (روشن = خشک، آبی تیره = اشباع) · خط قرمز: همدمای ۰°C · خط‌چین قهوه‌ای: فشار سطح · پیکان‌ها: جهت وزش باد در ترازهای ۸۵۰/۷۰۰/۵۰۰/۳۰۰/۲۰۰ hPa. این مقطع فقط بالای یک نقطه است (زمان در محور افقی)؛ مقطع مکانی نیست. داده: " , "Colour: relative humidity (pale = dry, dark blue = saturated) · red: 0 °C isotherm · dashed brown: surface pressure · arrows: wind direction (toward) at 850/700/500/300/200 hPa. This is a section above one point (time on x-axis), not a spatial cross-section. Data: ")) + esc(S.omTag || "Open-Meteo") + '</div></details>';
      box.hidden = false;
    }catch(e){ box.hidden = true; }
  }
  /* فرم نقطه پس از دریافت به یک نوار «تغییر نقطه» جمع می‌شود تا نتایج بالاتر بیایند */
  function plCollapse(on){ const f = root.querySelector("#labPlForm"), b = root.querySelector("#labPlSum"); if(!f || !b) return;
    const lat = root.querySelector("#labLat").value, lon = root.querySelector("#labLon").value, nm = S.place ? S.place.name : (lat + "°N " + lon + "°E");
    b.querySelector("#labPlName").textContent = nm; f.hidden = !!on; b.hidden = !on; }
  function omRun(){
    if(!S.om) return; thRender(); const i = parseInt(root.querySelector("#labOmT").value, 10), c = M.io.omToRaw(S.om, i);
    if(!c.ok){ S.res = null; render(); msg(M.lab.ioWhyText(c.why, E()), true); return; }
    analyze(c.raw, "Open-Meteo" + (S.omTag ? " · " + S.omTag : "") + " · " + fx(c.lat, 2) + "°N " + fx(c.lon, 2) + "°E · " + c.time.replace("T", " ") + " UTC" + (fin(c.elevation) ? " · " + fx(c.elevation, 0) + " m" : ""));
    if(S.res && c.belowGround) S.res.issues.push(c.belowGround + " " + t("تراز زیر سطح زمین حذف شد", "levels below ground removed")), render();
  }
  /* ---- ورودی متن/فایل ---- */
  function runText(){
    const txt = root.querySelector("#labTxt").value, wu = root.querySelector("#labWu").value, r = M.io.parse(txt, {windUnit:wu});
    if(!r.ok){ S.res = null; render(); msg(t("ورودی خوانده نشد: ", "Input not read: ") + M.lab.ioWhyText(r.why, E()), true); return; }
    const ok = analyze(r.raw, t("ورودی دستی", "Manual input") + " (" + r.mode + ", " + r.rows + " " + t("ردیف", "rows") + ")");
    if(ok && r.issues.length){ S.res.issues = S.res.issues.concat(r.issues); render(); }
  }
  /* ---- استان/مرکز شهرستان ---- */
  const coll = new Intl.Collator("fa");
  function provs(){ return (M.places || []).slice().sort((a, b) => coll.compare(a[0], b[0])); }
  function seatsOf(pv){ const p = (M.places || []).find(x => x[0] === pv); if(!p) return []; return p[2].slice().sort((a, b) => (b[3] === 1) - (a[3] === 1) || coll.compare(a[0], b[0])); }
  const sget = (k, d) => { try{ return store.get(k, d); }catch(e){ return d; } }, sset = (k, v) => { try{ store.set(k, v); }catch(e){} };
  function placeBind(){
    const ps = root.querySelector("#labProv"), ss = root.querySelector("#labSeat"); if(!ps || !ss) return;
    const P = provs(); let pv = sget("lab.prov", "فارس"); if(!P.some(p => p[0] === pv)) pv = (P[0] || [""])[0];
    ps.innerHTML = '<option value="">' + esc(t("— نقطهٔ دلخواه —", "— custom point —")) + "</option>" + P.map(p => '<option value="' + esc(p[0]) + '">' + esc(E() ? p[1] : p[0]) + "</option>").join("");
    const fillSeats = (sel) => { const L = seatsOf(ps.value); ss.innerHTML = L.length ? L.map(c => '<option value="' + esc(c[0]) + '">' + esc((E() ? (window.nameEn && nameEn(c[0])) || c[0] : c[0]) + (c[3] === 1 ? t(" (مرکز استان)", " (capital)") : "")) + "</option>").join("") : '<option value="">—</option>'; ss.disabled = !L.length; if(sel && L.some(c => c[0] === sel)) ss.value = sel; };
    ps.value = sget("lab.provOn", 1) ? pv : ""; fillSeats(sget("lab.seat", "استهبان"));
    const pick = () => { const c = seatsOf(ps.value).find(x => x[0] === ss.value); if(!c) return; sset("lab.prov", ps.value); sset("lab.seat", c[0]); sset("lab.provOn", 1);
      root.querySelector("#labLat").value = c[1]; root.querySelector("#labLon").value = c[2]; S.place = {name:c[0], prov:ps.value, en:(provs().find(p => p[0] === ps.value) || [])[1], lat:+c[1], lon:+c[2]}; omFetch(); mgFetch(); };
    ps.onchange = () => { if(!ps.value){ sset("lab.provOn", 0); fillSeats(""); return; } fillSeats(""); pick(); };
    ss.onchange = pick;
    root.querySelectorAll("#labLat,#labLon").forEach(i => i.addEventListener("input", () => { if(ps.value){ ps.value = ""; fillSeats(""); sset("lab.provOn", 0); } S.place = null; }));
  }
  /* ---- متئوگرام چندمدلی ---- */
  async function mgFetch(){
    if(!M.mg) return; const lat = parseFloat(root.querySelector("#labLat").value), lon = parseFloat(root.querySelector("#labLon").value);
    if(!(lat >= -90 && lat <= 90) || !(lon >= -180 && lon <= 180)) return;
    const my = ++S.mgBusy, sec = root.querySelector("#labMg"); sec.hidden = false; S.mgPend = {lat, lon};
    root.querySelector("#mgSt").textContent = t("در حال دریافت متئوگرام همهٔ مدل‌ها از Open-Meteo…", "Fetching the meteogram of all models from Open-Meteo…"); mgHead();
    try{ const D = await M.mg.fetchAll(lat, lon); if(my !== S.mgBusy) return; D.place = S.place; D.at = Date.now(); S.mg = D; mgRender(); }
    catch(e){ if(my !== S.mgBusy) return; root.querySelector("#mgSt").textContent = t("دریافت متئوگرام ناموفق: ", "Meteogram fetch failed: ") + e.message; }
  }
  function mgStamp(ms){ const d = new Date(ms), z = n => String(n).padStart(2, "0"), ir = new Date(ms + 210 * 6e4);   /* r193: زمان دریافت داده؛ UTC و وقت ایران */
    return d.getUTCFullYear() + "-" + z(d.getUTCMonth() + 1) + "-" + z(d.getUTCDate()) + " " + z(d.getUTCHours()) + ":" + z(d.getUTCMinutes()) + " UTC (" + z(ir.getUTCHours()) + ":" + z(ir.getUTCMinutes()) + (E() ? " Iran" : " وقت ایران") + ")"; }
  function mgHead(){
    const D = S.mg, pl = (D && D.place) || S.place, p = D || S.mgPend || {}, h = root.querySelector("#mgTitle"), sb = root.querySelector("#mgSub"); if(!h) return;
    h.textContent = t("متئوگرام چندمدلی", "Multi-model meteogram") + (pl ? " — " + pl.name + " (" + (E() ? pl.en || pl.prov : pl.prov) + ")" : "");
    sb.innerHTML = (fin(p.lat) ? '<bdi dir="ltr">' + fx(p.lat, 2) + "°N " + fx(p.lon, 2) + "°E</bdi>" : "") + (D && fin(D.elev) ? " · " + esc(t("ارتفاع مدل ", "model elevation ")) + '<bdi dir="ltr">' + fx(D.elev, 0) + " m</bdi>" : "") + " · " + esc(t(FA(S.mgRange) + " روز از امروز، ساعتی، به وقت ایران", "from today, " + S.mgRange + " days, hourly, Iran time")) + (D && D.at ? " · " + esc(t("به‌روزرسانی داده: ", "data updated: ")) + '<bdi dir="ltr">' + mgStamp(D.at) + "</bdi>" : "");
  }
  function mgRender(){
    const sec = root && root.querySelector("#labMg"); if(!sec || !S.mg){ if(sec && !S.mgPend) sec.hidden = true; return; }
    sec.hidden = false; mgHead(); const D = S.mg;
    root.querySelectorAll("[data-mgp]").forEach(b => b.classList.toggle("on", b.dataset.mgp === S.mgP));
    root.querySelector("#mgLeg").innerHTML = '<button type="button" class="mgChip mgMed' + (S.mgHide.has("median") ? " off" : "") + '" data-mgm="median"><i style="background:#0f172a"></i>' + esc(t("میانه", "Median")) + "</button>" +
      D.mods.map(m => '<button type="button" class="mgChip' + (S.mgHide.has(m.id) ? " off" : "") + '" data-mgm="' + m.id + '"><i style="background:' + m.color + '"></i>' + esc(m.name) + "</button>").join("") +
      (S.mgHide.size ? '<button type="button" class="mgChip mgAll" data-mgm="*">' + esc(t("نمایش همه", "Show all")) + "</button>" : "");
    const st = root.querySelector("#mgSt");
    st.textContent = t("مدل‌های دریافت‌شده: ", "Models received: ") + D.mods.length + t(" از ", " of ") + M.mg.MODELS.length + (D.fail.length ? " · " + t("بدون داده برای این نقطه: ", "no data for this point: ") + D.fail.map(f => f.name + " (" + (f.id === "bom_access_global" && !/429|timeout/.test(f.why) ? t("Open-Meteo در حال حاضر داده‌ی ACCESS-G را منتشر نمی‌کند (توقف موقت ارسال BOM)", "Open-Meteo is not currently serving ACCESS-G (BOM data feed temporarily suspended)") : f.why) + ")").join("، ") : "");
    if(!D.mods.length){ root.querySelector("#mgChart").innerHTML = '<div class="labMsg bad">' + esc(t("هیچ مدلی داده نداد؛ اتصال به api.open-meteo.com را بررسی کنید.", "No model returned data; check access to api.open-meteo.com.")) + "</div>"; return; }
    root.querySelectorAll("[data-mgr]").forEach(b => b.classList.toggle("on", +b.dataset.mgr === S.mgRange));
    const fitOk = S.mgP === "t" || S.mgP === "rh"; root.querySelector("#mgFits").hidden = !fitOk;
    root.querySelectorAll("[data-mgf]").forEach(b => b.classList.toggle("on", !!S.mgFit[b.dataset.mgf]));
    const climOk = S.mgP === "t" || S.mgP === "pd"; root.querySelector("#mgClimRow").hidden = !climOk; root.querySelectorAll("[data-mgc]").forEach(b => b.classList.toggle("on", !!S.mgClim));
    if(S.mgClim && climOk && !D.clim && !D.climErr && !D.climBusy && M.clim && fin(D.lat)){ D.climBusy = 1; M.clim.get(D.lat, D.lon).then(c => { D.clim = c; D.climBusy = 0; mgRender(); }).catch(e => { D.climBusy = 0; D.climErr = e.message; mgRender(); }); }
    const stt = {en:E(), hidden:S.mgHide, range:S.mgRange, fit:S.mgFit, clim:S.mgClim && climOk};
    M.mg.render(root.querySelector("#mgChart"), D, S.mgP, stt);
    { let wr = root.querySelector("#mgRose"); if(!wr){ wr = document.createElement("div"); wr.id = "mgRose"; wr.className = "labPanel"; root.querySelector("#mgChart").after(wr); }
      if(S.mgP === "w"){ let h = ""; try{ h = M.mg.windrose(D, {en:E(), days:S.mgRange}); }catch(e){ h = ""; } wr.hidden = !h; wr.innerHTML = h ? '<h4>' + esc(t("گلباد (همهٔ مدل‌ها، بازهٔ انتخاب‌شده)", "Wind rose (all models, selected range)")) + "</h4>" + h : ""; } else { wr.hidden = true; wr.innerHTML = ""; } }
    { const ci = root.querySelector("#mgClimInfo"), C = stt.climInfo; ci.hidden = !(S.mgClim && climOk); if(!ci.hidden){ ci.innerHTML = D.climErr ? esc(t("نرمال اقلیمی دریافت نشد: ", "Climate normal not available: ") + D.climErr) : (!D.clim ? esc(t("در حال دریافت نرمال اقلیمی ۳۰ ساله (ERA5)…", "Fetching the 30-year climate normal (ERA5)…")) :
          (C ? (C.kind === "anom" ? '<bdi dir="ltr">' + esc(t("میانگین دمای میانهٔ مدل‌ها نسبت به نرمال ۱۹۹۱–۲۰۲۰: ", "Model-median mean temperature vs the 1991–2020 normal: ")) + (C.anom >= 0 ? "+" : "−") + Math.abs(C.anom).toFixed(1) + " °C (" + C.n + esc(t(" روز", " days")) + ")</bdi>" :
            '<bdi dir="ltr">' + esc(t("بارش مجموع میانهٔ مدل‌ها: ", "Model-median total precipitation: ")) + C.f.toFixed(1) + " mm · " + esc(t("نرمال همین روزها: ", "normal for these days: ")) + C.nrm.toFixed(1) + " mm</bdi>") : "") +
          '<br><span class="labSub">' + esc(t("نوار نارنجی = میانگین کمینه تا بیشینهٔ روزانه در ۱۹۹۱–۲۰۲۰، خط‌چین = میانگین روزانه (ERA5، Open-Meteo Archive؛ ±۷ روز). نرمال توصیف گذشته است نه پیش‌بینی.", "Orange band = mean daily min to max in 1991–2020, dashed = mean daily (ERA5 via Open-Meteo Archive; ±7 days). A normal describes the past; it is not a forecast.")) + "</span>"); } }
    const fi = root.querySelector("#mgFitInfo"), F = stt.fitInfo; fi.hidden = !(fitOk && F);
    if(!fi.hidden){ const u = S.mgP === "t" ? "°C" : "%", sg = (F.slope >= 0 ? "+" : "−") + Math.abs(F.slope).toFixed(2);
      fi.innerHTML = '<bdi dir="ltr">' + esc(t("روند کلی (خط قرمز): ", "Overall trend (red line): ")) + sg + " " + u + "/" + esc(t("روز", "day")) + (F.r2lin != null ? " · R²=" + F.r2lin.toFixed(2) : "") + "</bdi>" +
        (F.amp != null ? ' · <bdi dir="ltr">' + esc(t("برازش دوره‌ای (سبز): دامنهٔ چرخهٔ شبانه‌روزی ", "Periodic fit (green): diurnal amplitude ")) + F.amp.toFixed(1) + " " + u + (F.r2per != null ? " · R²=" + F.r2per.toFixed(2) : "") + "</bdi>" : ""); }
  }
  let mgRz = 0; window.addEventListener("resize", () => { clearTimeout(mgRz); mgRz = setTimeout(() => { if(root && !root.hidden && S.mg) mgRender(); }, 200); });
  const PRESETS = [["استهبان", "Estahban", 29.13, 54.04], ["شیراز", "Shiraz", 29.59, 52.58], ["تهران", "Tehran", 35.69, 51.39], ["مشهد", "Mashhad", 36.30, 59.60], ["تبریز", "Tabriz", 38.08, 46.29], ["اهواز", "Ahvaz", 31.32, 48.67]];
  M.ui = Object.assign(M.ui || {}, {cardsHtml});
  /* ---- سونداژ مشاهده‌ای دانشگاه وایومینگ (r130): متن را GitHub Actions از weather.uwyo.edu می‌گیرد و روی هاست می‌گذارد؛ مرورگر مستقیم به وایومینگ وصل نمی‌شود (CORS) ---- */
  const WY_BASE = () => (typeof ON !== "undefined" && ON.base ? ON.base : "online/") + "data/soundings/";
  async function wyLoad(){
    if(S.wy) return; const info = root.querySelector("#labWyInfo"), st = root.querySelector("#labWyS"), tm = root.querySelector("#labWyT");
    try{
      const r = await fetch(WY_BASE() + "index.json?" + (Date.now() / 3e5 | 0), {cache:"no-store"}); if(!r.ok) throw new Error("HTTP " + r.status);
      const j = await r.json(); if(!j || !Array.isArray(j.stations) || !j.stations.length) throw new Error("empty");
      S.wy = j; st.innerHTML = j.stations.map((x, i) => '<option value="' + i + '">' + esc((E() ? x.en : x.fa) + " · " + x.id) + "</option>").join("");
      const fill = () => { const x = j.stations[+st.value] || {runs:[]}; tm.innerHTML = x.runs.map((q, i) => '<option value="' + i + '">' + esc(q.t) + "</option>").join(""); };
      st.onchange = fill; fill(); info.textContent = t("منبع: دانشگاه وایومینگ (سونداژ رادیوسوند). بروزرسانی: ", "Source: University of Wyoming (radiosonde). Updated: ") + (j.generated || "—");
    }catch(e){
      S.wy = null; info.textContent = t("فهرست سونداژها هنوز روی هاست نیست (گردش‌کار GitHub هنوز اجرا نشده یا فایل‌ها بارگذاری نشده): ", "Sounding list is not on the host yet (GitHub workflow not run or files not uploaded): ") + e.message;
    }
  }
  async function wyRun(){
    if(!S.wy){ await wyLoad(); if(!S.wy) return; }
    const x = S.wy.stations[+root.querySelector("#labWyS").value], q = x && x.runs[+root.querySelector("#labWyT").value]; if(!q){ msg(t("ایستگاه یا زمان انتخاب نشده.", "No station/time selected."), true); return; }
    msg(t("در حال دریافت سونداژ…", "Loading sounding…"));
    try{
      const r = await fetch(WY_BASE() + q.f, {cache:"no-store"}); if(!r.ok) throw new Error("HTTP " + r.status);
      const p = M.io.parse(await r.text(), {windUnit:"kt"});
      if(!p.ok){ S.res = null; render(); msg(t("خواندن سونداژ ممکن نشد: ", "Could not read sounding: ") + M.lab.ioWhyText(p.why, E()), true); return; }
      const ok = analyze(p.raw, t("سونداژ مشاهده‌ای وایومینگ · ", "Wyoming observed sounding · ") + (E() ? x.en : x.fa) + " (" + x.id + ") · " + q.t);
      if(ok && p.issues && p.issues.length){ S.res.issues = S.res.issues.concat(p.issues); render(); }
    }catch(e){ msg(t("دریافت ناموفق: ", "Fetch failed: ") + e.message, true); }
  }
  function shell(){
    const pr = PRESETS.map((p, i) => '<button type="button" class="labChip" data-pre="' + i + '">' + esc(E() ? p[1] : p[0]) + "</button>").join("");
    return '<div class="lab" dir="' + (E() ? "ltr" : "rtl") + '">' +
      '<section class="labIn"><h3>' + esc(t("آزمایشگاه محاسبات جوّ بالا", "Upper-air computation lab")) + '</h3><p class="labNote">' + esc(t("سونداژ یا پروفایل مدل را وارد کنید؛ شاخص‌ها با هستهٔ ترمودینامیک MET (سازگار با MetPy و آزموده‌شده) در مرورگر محاسبه می‌شوند. دادهٔ ناقص هرگز با صفر پر نمی‌شود.", "Enter a sounding or model profile; indices are computed in your browser with the MET thermodynamic core (MetPy-compatible, regression-tested). Missing data is never filled with zero.")) + "</p>" +
      '<div class="labSeg" role="tablist"><button type="button" data-tab="paste">' + esc(t("چسباندن / فایل", "Paste / file")) + '</button><button type="button" data-tab="om">Open-Meteo</button><button type="button" data-tab="wy">' + esc(t("سونداژ مشاهده‌ای (Wyoming)", "Observed (Wyoming)")) + '</button></div>' +
      '<div id="labWy" hidden><div class="labBtns"><label>' + esc(t("ایستگاه", "Station")) + ' <select id="labWyS"></select></label><label>' + esc(t("زمان", "Time")) + ' <select id="labWyT"></select></label><button type="button" id="labWyGo" class="labGo">' + esc(t("تحلیل", "Analyse")) + '</button></div><div class="labSub" id="labWyInfo"></div></div>' +
      '<div id="labPaste"><textarea id="labTxt" rows="9" dir="ltr" spellcheck="false" placeholder="PRES HGHT TEMP DWPT DRCT SKNT&#10;1000.0  36  22.2  21.0 180 7&#10;…"></textarea>' +
      '<div class="labBtns"><label class="labFile">' + esc(t("بارگذاری فایل", "Load file")) + '<input type="file" id="labFile" accept=".txt,.csv,.tsv,text/plain,text/csv" hidden></label>' +
      '<button type="button" id="labSample">' + esc(t("نمونه", "Sample")) + '</button><label>' + esc(t("یکای سرعت باد (ستون عمومی)", "Wind speed unit (generic column)")) + ' <select id="labWu"><option value="ms">m/s</option><option value="kt">kt</option><option value="kmh">km/h</option></select></label>' +
      '<button type="button" id="labRun" class="labGo">' + esc(t("تحلیل", "Analyse")) + '</button></div>' +
      '<p class="labSub">' + esc(t("قالب‌ها: متن Wyoming (ستون‌های PRES HGHT TEMP DWPT … DRCT SKNT) یا CSV با سرایند: pressure, height, temperature, dewpoint, wdir, wspd (یا u, v). دما و شبنم °C، فشار hPa، ارتفاع m.", "Formats: Wyoming text (PRES HGHT TEMP DWPT … DRCT SKNT) or CSV with header: pressure, height, temperature, dewpoint, wdir, wspd (or u, v). Temperature/dew point °C, pressure hPa, height m.")) + "</p></div>" +
      '<div id="labOm" hidden><div class="labPlSum" id="labPlSum" hidden><b id="labPlName"></b><button type="button" id="labPlChg">' + esc(t("تغییر نقطه", "Change point")) + '</button></div><div id="labPlForm"><div class="labBtns labPlace"><label>' + esc(t("استان", "Province")) + ' <select id="labProv"></select></label><label>' + esc(t("مرکز شهرستان", "County seat")) + ' <select id="labSeat"></select></label><label class="labWide">' + esc(t("مدل سونداژ", "Sounding model")) + ' <select id="labOmM">' + OM_MODELS.map(m => '<option value="' + m[0] + '">' + esc(E() ? m[3] : m[1]) + "</option>").join("") + '</select></label></div><p class="labSub">' + esc(t("با انتخاب شهر، پروفایل جوّ بالا و متئوگرام چندمدلی همان نقطه دریافت می‌شود؛ برای هر نقطهٔ دلخواه دیگر طول و عرض را بنویسید.", "Choosing a city fetches the upper-air profile and the multi-model meteogram for that point; for any other point type the latitude and longitude.")) + '</p><div class="labBtns labLL"><label>' + esc(t("عرض", "Lat")) + ' <input id="labLat" type="number" step="0.01" value="29.13" dir="ltr"></label><label>' + esc(t("طول", "Lon")) + ' <input id="labLon" type="number" step="0.01" value="54.04" dir="ltr"></label><button type="button" id="labOmGo" class="labGo">' + esc(t("دریافت متئوگرام و اسکیوتی", "Get meteogram & Skew-T")) + '</button></div></div><div class="labBtns labAn"><button type="button" data-an="skewt" class="labAnB">' + esc(t("تحلیل علمی اسکیوتی", "Scientific Skew-T analysis")) + '</button><button type="button" data-an="lab" class="labAnB">' + esc(t("تحلیل علمی آزمایشگاه محاسبات", "Scientific lab analysis")) + "</button></div>" +
      '<div class="labBtns" id="labOmRow" hidden><label>' + esc(t("زمان معتبر", "Valid time")) + ' <select id="labOmT"></select></label></div>' +
      '<div id="labTH" class="labPanel" hidden></div>' +
      '<details id="labXS" class="labPanel" hidden><summary>' + esc(t("مقطع قائم بین دو نقطه (آزمایشی)", "Vertical cross-section between two points (experimental)")) + '</summary><div class="labBtns"><label>' + esc(t("نقطهٔ B: عرض", "Point B lat")) + ' <input id="xsLat" type="number" step="0.01" value="30" dir="ltr"></label><label>' + esc(t("طول", "lon")) + ' <input id="xsLon" type="number" step="0.01" value="55" dir="ltr"></label><button type="button" id="xsGo" class="labGo">' + esc(t("رسم مقطع", "Draw section")) + '</button></div><p class="labSub">' + esc(t("نقطهٔ A همان نقطهٔ بالای صفحه است؛ زمان از «زمان معتبر».", "Point A is the point above; time from “Valid time”.")) + '</p><div id="xsOut"></div></details>' +
      '<p class="labSub">' + esc(t("دادهٔ مدل از ", "Model data from ")) + '<a href="https://open-meteo.com/" target="_blank" rel="noopener">Open-Meteo.com</a> (CC BY 4.0). ' + esc(t("خروجی مدل است نه رصد؛ ترازهای زیر سطح زمین حذف می‌شوند و باد سطح = ۱۰ متری.", "Model output, not observations; levels below ground are dropped; the surface wind is the 10 m wind.")) + "</p></div>" +
      '<div id="labMsg" class="labMsg" hidden></div></section>' +
      '<section id="labMg" class="labMgS" hidden><div class="mgHead"><button type="button" class="mgSaveB" data-mgdl="png">' + esc(t("ذخیره", "Save")) + '</button><h3 id="mgTitle"></h3><div id="mgSub" class="labSub"></div></div>' +
      '<div class="mgTabs" role="tablist">' + Object.entries(M.mg.PARAMS).map(([k, p]) => '<button type="button" data-mgp="' + k + '">' + esc(E() ? p.en : p.fa) + "</button>").join("") + "</div>" +
      '<div class="mgOpts"><div class="mgRng" role="group" aria-label="range">' + [3, 5, 10, 15].map(n => '<button type="button" data-mgr="' + n + '">' + esc(E() ? n + " days" : n.toLocaleString("fa-IR") + " روزه") + "</button>").join("") + "</div>" +
      '<div id="mgFits" class="mgRng" hidden><button type="button" data-mgf="trend">' + esc(t("روند کلی", "Overall trend")) + '</button><button type="button" data-mgf="per">' + esc(t("برازش دوره‌ای", "Periodic fit")) + '</button><button type="button" data-mgf="ma">' + esc(t("روند ۲۴ ساعته", "24 h trend")) + "</button></div></div>" +
      '<div id="mgClimRow" class="mgRng" hidden><button type="button" data-mgc="1">' + esc(t("نرمال اقلیمی ۱۹۹۱–۲۰۲۰", "Climate normal 1991–2020")) + '</button></div><div id="mgClimInfo" class="labSub" hidden></div><div id="mgFitInfo" class="labSub" hidden></div><div id="mgLeg" class="mgLeg"></div><div id="mgChart" class="mgChart"></div><div id="mgSt" class="labSub"></div>' +
      '<div class="labBtns"><button type="button" data-mgdl="svg">SVG</button><span class="labSub">' + esc(t("خط سیاه ضخیم = میانهٔ مدل‌ها (دست‌کم ۲ مدل)؛ نوار بنفش = پراکندگی (کمینه تا بیشینهٔ مدل‌ها)؛ نوار تیره = شب؛ زمان‌ها به وقت ایران. روی هر مدل در راهنما بزنید تا پنهان/نمایان شود.", "Thick black = model median (at least 2 models); violet band = spread (model min–max); shaded = night; times are Iran local time. Tap a model in the legend to hide/show it.")) + '</span></div></section>' +
      '<section id="labOut" hidden><div id="labSum" class="labSum"></div><div class="labBtns"><button type="button" data-an="skewt" class="labAnB">' + esc(t("تحلیل علمی اسکیوتی", "Scientific Skew-T analysis")) + '</button><button type="button" data-an="lab" class="labAnB">' + esc(t("تحلیل علمی آزمایشگاه محاسبات", "Scientific lab analysis")) + '</button></div><div id="labAn" class="anBox" hidden></div><div class="labTop"><div class="labPanel"><div class="labSeg2">' +
      ["SB", "ML", "MU"].map(k => '<button type="button" data-par="' + k + '">' + k + "</button>").join("") + '<span class="labSub">' + esc(t("نوع پارسل: سطحی / مخلوط ۱۰۰ hPa / ناپایدارترین ۳۰۰ hPa", "Parcel: surface / mixed 100 hPa / most unstable 300 hPa")) + '</span></div><div class="labSeg2 skModes"><button type="button" data-skm="2d">' + esc(t("مدرن ۲بعدی", "Modern 2D")) + '</button><button type="button" data-skm="3d">' + esc(t("سه‌بعدی", "3D")) + '</button><button type="button" data-skm="old">' + esc(t("کلاسیک", "Classic")) + '</button><label id="skRotL" class="labSub" hidden>' + esc(t("زاویه", "Angle")) + ' <input id="skRot" type="range" min="10" max="75" value="38"></label></div><div id="labSk"></div><div id="labInfo" class="labInfo">' + esc(t("برای خواندن مقادیر، روی نمودار بزنید یا نشانگر را حرکت دهید.", "Tap or hover on the chart to read values.")) + '</div>' +
      '<div class="labBtns"><button type="button" data-dl="svg">SVG</button><button type="button" data-dl="png">PNG</button><span class="labSub">' + esc(t("خطوط: دما قرمز، شبنم سبز، پارسل خط‌چین؛ سایهٔ قرمز = CAPE و آبی = CIN (روی دمای واقعی رسم می‌شود؛ مقدار عددی بر دمای مجازی است).", "Red = temperature, green = dew point, dashed = parcel; red shading = CAPE, blue = CIN (drawn on actual temperature; the numbers use virtual temperature).")) + "</span></div></div>" +
      '<div class="labPanel labHodoP"><h4>' + esc(t("هودوگراف", "Hodograph")) + '</h4><div id="labHodo"></div><div class="labSub">' + esc(t("رنگ: ۰–۳ km قرمز، ۳–۶ سبز، ۶–۹ نارنجی، بالاتر بنفش · RM/LM حرکت توفان راست/چپ‌گرد Bunkers", "Colour: 0–3 km red, 3–6 green, 6–9 orange, above purple · RM/LM = Bunkers right/left mover")) + "</div></div></div>" +
      '<div id="labCards"></div></section></div>';
  }
  /* r83: خروجی با قالب مشترک (لوگو، تیتر، مدل، زمان، منبع)؛ فقط دادهٔ مدل/سونداژ همان نمودار — چیزی از دادهٔ خام اطلس وارد نمی‌شود */
  function frameDl(sv, name, png, kind){
    const stamp = new Date().toISOString().slice(0, 10);
    if(typeof window.mtExport !== "function") return M.skewt.download(sv, name, png);
    let o;
    if(kind === "mg"){ const D = S.mg || {}, pl = D.place || S.place, mods = (D.mods || []).map(m => m.name).join(" · ");
      const pn = {t:t("دما ۲ متری", "2 m temperature"), rh:t("رطوبت نسبی", "Relative humidity"), ws:t("باد", "Wind"), pr:t("بارش", "Precipitation"), pd:t("بارش روزانه", "Daily precipitation"), cc:t("ابر", "Cloud cover")}[S.mgP] || "";
      o = {title:t("متئوگرام چندمدلی", "Multi-model meteogram") + (pl ? " — " + (E() ? pl.en || pl.name : pl.name) : ""), sub:[pn, fin(D.lat) ? fx(D.lat, 2) + "°N " + fx(D.lon, 2) + "°E" : "", t(FA(S.mgRange) + " روز از امروز، به وقت ایران", S.mgRange + " days from today, Iran time")].filter(Boolean).join(" · "),
        model:(D.mods || []).length + t(" مدل", " models"), upd:(D.at ? mgStamp(D.at) : t("دریافت: ", "fetched: ") + new Date().toISOString().slice(0, 16).replace("T", " ") + " UTC"), src:"Open-Meteo (CC BY 4.0) — " + mods,
        legend:((D.mods || []).length > 1 && !S.mgHide.has("median") ? [{c:"#0f172a", n:t("میانهٔ مدل‌ها", "Model median"), w:4}] : []).concat((D.mods || []).filter(m => !S.mgHide.has(m.id)).map(m => ({c:m.color, n:m.name})))};
    } else {
      const pl = S.place; o = {title:t("اسکیوتی (Skew-T) و تحلیل ترمودینامیکی", "Skew-T log-p & thermodynamic analysis") + (pl ? " — " + (E() ? pl.en || pl.name : pl.name) : ""), sub:[S.src || "", S.parcel ? (S.parcel + " parcel") : ""].filter(Boolean).join(" · "),
        model:(S.omTag || S.src || "").split(" · ")[0] || t("سونداژ", "Sounding"), upd:S.omTag && /ران|run/.test(S.omTag) ? S.omTag.split(" · ").slice(1).join(" · ") : stamp, src:S.om ? "Open-Meteo (CC BY 4.0)" : (S.src || t("سونداژ واردشده", "imported sounding"))};
    }
    window.mtExport(sv, name + "_" + stamp, png, o);
  }
  function bind(){
    root.querySelectorAll("[data-tab]").forEach(b => b.onclick = () => { S.tab = b.dataset.tab; root.querySelector("#labPaste").hidden = S.tab !== "paste"; root.querySelector("#labOm").hidden = S.tab !== "om"; root.querySelector("#labWy").hidden = S.tab !== "wy"; if(S.tab === "wy") wyLoad(); root.querySelectorAll("[data-tab]").forEach(x => x.classList.toggle("on", x.dataset.tab === S.tab)); });
    { const g = root.querySelector("#labWyGo"); if(g) g.onclick = wyRun; }
    root.querySelector("[data-tab=" + S.tab + "]").click();
    root.querySelector("#labRun").onclick = runText;
    root.querySelector("#labSample").onclick = () => { root.querySelector("#labTxt").value = M.SAMPLE; root.querySelector("#labWu").value = "kt"; runText(); };
    root.querySelector("#labFile").onchange = ev => { const f = ev.target.files[0]; if(!f) return; if(f.size > 2e6){ msg(t("فایل بزرگ است (بیش از ۲ مگابایت).", "File too large (> 2 MB)."), true); return; } const rd = new FileReader(); rd.onload = () => { root.querySelector("#labTxt").value = String(rd.result); runText(); }; rd.readAsText(f); ev.target.value = ""; };
    root.querySelector("#xsGo").onclick = xsRun; root.querySelector("#labPlChg").onclick = () => plCollapse(false); root.querySelector("#labOmGo").onclick = () => { { const la = parseFloat(root.querySelector("#labLat").value), lo = parseFloat(root.querySelector("#labLon").value); if(!(S.place && Math.abs((S.place.lat == null ? 1e9 : S.place.lat) - la) < 1e-6 && Math.abs((S.place.lon == null ? 1e9 : S.place.lon) - lo) < 1e-6)) S.place = null; } omFetch(); mgFetch(); };   /* r193: شهر انتخاب‌شده تا وقتی مختصات عوض نشده در تیتر می‌ماند */ placeBind(); { const ms = root.querySelector("#labOmM"); if(ms){ const v = sget("lab.om.m", "ecmwf_ifs025"); ms.value = OM_MODELS.some(m => m[0] === v) ? v : "ecmwf_ifs025"; ms.onchange = () => { S.place = S.place; omFetch(); }; } } root.querySelector("#labOmT").onchange = omRun;
    root.querySelectorAll("[data-an]").forEach(b => b.onclick = () => anShow(b.dataset.an));
    root.querySelectorAll("[data-skm]").forEach(b => b.onclick = () => { S.skMode = b.dataset.skm; if(S.res) render(); });
    root.querySelector("#skRot").oninput = ev => { S.skRot = +ev.target.value; if(S.res && S.skMode === "3d") { const sk = root.querySelector("#labSk"); sk.innerHTML = M.skewt2.svg3d(S.res, {en:E(), parcel:S.parcel, title:S.parcel + " parcel", rot:S.skRot}); } };
    root.querySelectorAll("[data-par]").forEach(b => b.onclick = () => { S.parcel = b.dataset.par; if(S.raw) { const keep = S.src; if(S.om && S.src.indexOf("Open-Meteo") === 0) omRun(); else analyze(S.raw, keep); } });
    root.querySelectorAll("[data-mgp]").forEach(b => b.onclick = () => { S.mgP = b.dataset.mgp; mgRender(); });
    root.querySelectorAll("[data-mgr]").forEach(b => b.onclick = () => { S.mgRange = +b.dataset.mgr; sset("mg.range", S.mgRange); mgRender(); });
    root.querySelectorAll("[data-mgc]").forEach(b => b.onclick = () => { S.mgClim = !S.mgClim; sset("mg.clim", S.mgClim ? 1 : 0); mgRender(); });
    root.querySelectorAll("[data-mgf]").forEach(b => b.onclick = () => { S.mgFit[b.dataset.mgf] = !S.mgFit[b.dataset.mgf]; mgRender(); });
    root.querySelectorAll("[data-mgdl]").forEach(b => b.onclick = () => { const sv = root.querySelector("#mgChart svg"); if(sv) frameDl(sv, "meteogram-" + S.mgP, b.dataset.mgdl === "png", "mg"); });
    root.querySelector("#mgLeg").onclick = ev => { const b = ev.target.closest("[data-mgm]"); if(!b) return; const k = b.dataset.mgm;
      if(k === "*"){ S.mgHide.clear(); } else if(S.mgHide.has(k)) S.mgHide.delete(k); else S.mgHide.add(k); mgRender(); };
    root.querySelectorAll("[data-dl]").forEach(b => b.onclick = () => { const sv = root.querySelector("#labSk svg"); if(sv) frameDl(sv, "skewt-" + S.parcel, b.dataset.dl === "png", "sk"); });
  }
  window.labInit = function(host){
    if(!host) return; if(root === host && host.firstChild) return;
    root = host; const keepTxt = ""; host.innerHTML = shell(); bind(); render();
    if(!host._lg){ host._lg = true; document.addEventListener("langchange", () => { if(!host.hidden && root === host){ const txt = host.querySelector("#labTxt").value, tab = S.tab; const la = host.querySelector("#labLat").value, lo = host.querySelector("#labLon").value; host.innerHTML = shell(); S.tab = tab; bind(); host.querySelector("#labTxt").value = txt; host.querySelector("#labLat").value = la; host.querySelector("#labLon").value = lo; render(); mgRender(); } }); }
  };
})();
