/* ===== آزمایشگاه محاسبات هواشناسی — ثابت‌ها (فاز ۱) =====
   مرجع: MetPy (BSD-3، Unidata) metpy.constants — مقادیر عیناً با MetPy ۱٫۷+ هم‌خوان‌اند تا آزمون رگرسیون ممکن باشد.
   قرارداد واحدها (همه‌جا در MET): فشار hPa، دمای ورودی/خروجی عمومی °C، دمای داخلی K (پسوند K)، ارتفاع m، باد m/s، نسبت اختلاط kg/kg.
   مقدار مفقود = null/NaN؛ هیچ تابعی مقدار مفقود را صفر نمی‌کند. خروجی شاخص‌ها: {v:عدد|null, why:دلیل}. */
(function(root){
  "use strict";
  const MET = root.MET = root.MET || {};
  MET.C = Object.freeze({
    Rd: 287.04749097718457, Rv: 461.52311572606084,        // J/(kg·K) ثابت گاز هوای خشک / بخار آب
    Cp_d: 1004.6662184201462, Cp_v: 1860.078011865639, Cp_l: 4219.400000000001, Cp_i: 2090.0,   // J/(kg·K)
    Lv: 2500840.0, Lf: 333700.0, Ls: 2834540.0,            // J/kg گرمای نهان تبخیر/ذوب/تصعید در T0
    epsilon: 0.6219569100577033,                           // Mw/Md
    kappa: 0.28571428571428564,                            // Rd/Cp_d
    T0: 273.16, zeroC: 273.15,                             // K (نقطهٔ سه‌گانه / صفر سلسیوس)
    P0: 1000.0, es0: 6.112,                                // hPa (فشار مرجع پتانسیل / فشار بخار اشباع در T0)
    g: 9.80665, rhoL: 999.97495                            // m/s² ، kg/m³
  });
  MET.VERSION = "met-1.0.0-phase1";
  MET.REF = "MetPy (BSD-3-Clause, Unidata); Romps 2017 (LCL); Bolton 1980 (Td, θe)";
  // نتیجهٔ ناموفق/ناکافی — همیشه با دلیل؛ هرگز صفر
  MET.nil = function(why){ return {v:null, why:why}; };
  MET.ok = function(v, extra){ const o = {v:v, why:null}; if(extra) Object.assign(o, extra); return o; };
  MET.isNum = function(x){ return typeof x === "number" && isFinite(x); };
})(typeof globalThis !== "undefined" ? globalThis : this);
