/* ===== فرادادهٔ شاخص‌ها: ورودی، واحد، فرمول، خروجی، دادهٔ ناکافی، محدودیت تفسیر =====
   مصرف‌کننده: کارت شاخص در صفحهٔ آزمایشگاه (فاز ۳). متن علمی جدا از رنگ‌بندی است؛ این فایل هیچ رنگی نمی‌داند. */
(function(){
  "use strict";
  const M = globalThis.MET;
  M.meta = {
    CAPE: {fa:"انرژی پتانسیل همرفتی در دسترس", en:"Convective Available Potential Energy", unit:"J/kg", range:"≥ 0",
      inputs:"پروفایل p (hPa)، T و Td (°C) از سطح تا ≥ ۱۰۰ hPa؛ نوع پارسل SB/ML(۱۰۰ hPa)/MU(۳۰۰ hPa)",
      formula:"CAPE = Rd ∫ (Tv,parcel − Tv,env) d ln p بین LFC و EL (دمای مجازی؛ ذوزنقه)", ref:"MetPy cape_cin; Moncrieff & Miller 1976",
      insufficient:"LCL قابل‌حل نیست، پروفایل < ۳ سطح معتبر، یا فشار تکراری ⇒ v=null (نه صفر). «بدون LFC» = CAPE صفر معتبر با note=no_lfc",
      limits:"بدون آمیختگی با محیط، بدون بار آبی/یخ؛ وابسته به انتخاب پارسل و شمارش LFC/EL چندگانه (پیش‌فرض MetPy: LFC پایین، EL بالا)"},
    CIN: {fa:"بازدارندگی همرفتی", en:"Convective Inhibition", unit:"J/kg", range:"≤ 0",
      inputs:"همان CAPE", formula:"CIN = Rd ∫ (Tv,parcel − Tv,env) d ln p از سطح پارسل تا LFC (منفی)", ref:"MetPy cape_cin",
      insufficient:"مانند CAPE", limits:"مقدار به نقطهٔ شروع پارسل بسیار حساس است"},
    LCL: {fa:"تراز چگالش بالابرده", en:"Lifted Condensation Level", unit:"hPa / K", range:"p ≤ p سطح",
      inputs:"p، T، Td پارسل (Td ≤ T)", formula:"حل بسته با تابع W لامبرت (شاخهٔ −۱)", ref:"Romps 2017, J. Atmos. Sci.; MetPy lcl",
      insufficient:"Td > T ⇒ null", limits:"فرض رطوبت نسبت به آب مایع"},
    LI: {fa:"شاخص بالابری", en:"Lifted Index", unit:"K", range:"منفی = ناپایدار",
      inputs:"T500 محیط و پارسل سطحی بالارفته تا ۵۰۰ hPa", formula:"LI = T500,env − T500,parcel", ref:"Galway 1956; MetPy lifted_index",
      insufficient:"۵۰۰ hPa خارج از پروفایل ⇒ null", limits:"بدون اصلاح دمای مجازی؛ پارسل سطحی ممکن است نمایندهٔ لایهٔ مرزی نباشد"},
    K: {fa:"شاخص K", en:"K-index", unit:"°C", range:"≥ ۳۰ پتانسیل بالا", inputs:"T850، T700، T500، Td850، Td700",
      formula:"K = (T850 − T500) + Td850 − (T700 − Td700)", ref:"George 1960; MetPy k_index",
      insufficient:"هر سطح خارج از پروفایل (مثلاً ۸۵۰ زیر زمین در مناطق مرتفع) ⇒ null با why=level_below_ground_850", limits:"برای همرفت جرم‌هوایی؛ نه سامانه‌های شدید"},
    TT: {fa:"توتال‌توتال", en:"Total Totals", unit:"°C", range:"≥ ۴۴ احتمال تندری", inputs:"T850، Td850، T500",
      formula:"TT = VT + CT = (T850 − T500) + (Td850 − T500)", ref:"Miller 1972; MetPy total_totals_index",
      insufficient:"۸۵۰ یا ۵۰۰ خارج از پروفایل ⇒ null", limits:"وابسته به ۸۵۰ hPa؛ نامناسب برای ارتفاع‌های بالا"},
    SHOWALTER: {fa:"شاخص شوالتر", en:"Showalter Index", unit:"K", range:"منفی = ناپایدار", inputs:"پارسل از ۸۵۰ hPa تا ۵۰۰",
      formula:"SI = T500,env − T500,parcel(850→500)", ref:"Showalter 1953; MetPy showalter_index", insufficient:"مانند K", limits:"فقط لایهٔ ۸۵۰–۵۰۰"},
    PWAT: {fa:"آب قابل بارش", en:"Precipitable Water", unit:"mm", range:"≥ 0", inputs:"p، Td (لایه)",
      formula:"PW = −(1/(g ρw)) ∫ r dp، r = ε e(Td)/(p − e)", ref:"MetPy precipitable_water",
      insufficient:"لایهٔ درخواستی خارج از پروفایل ⇒ null", limits:"لایهٔ ناقص (بدون سطوح بالا) کمتر از واقعیت است"}
  };
})();
