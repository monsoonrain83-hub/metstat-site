/* ===== فرادادهٔ شاخص‌ها: ورودی، واحد، فرمول، خروجی، دادهٔ ناکافی، محدودیت تفسیر =====
   مصرف‌کننده: کارت شاخص در صفحهٔ آزمایشگاه (فاز ۳). متن علمی جدا از رنگ‌بندی است؛ این فایل هیچ رنگی نمی‌داند. */
(function(){
  "use strict";
  const M = globalThis.MET;
  M.meta = {
    CAPE: {fa:"انرژی پتانسیل همرفتی در دسترس", en:"Convective Available Potential Energy", unit:"J/kg", range:"≥ 0",
      inputs:"پروفایل p (hPa)، T و Td (°C) از سطح تا ≥ ۱۰۰ hPa؛ نوع پارسل SB/ML(۱۰۰ hPa)/MU(۳۰۰ hPa)",
      formula:"CAPE = Rd ∫ (Tv,parcel − Tv,env) d ln p بین LFC و EL (دمای مجازی؛ ذوزنقه)", ref:"MetPy cape_cin; Moncrieff & Miller 1976",
      insufficient:"LCL قابل‌حل نیست، پروفایل < ۳ سطح معتبر، یا فشار تکراری ⇒ v=null (نه صفر). «بدون LFC» = CAPE صفر معتبر با note=no_lfc",
      limits:"بدون آمیختگی با محیط، بدون بار آبی/یخ؛ وابسته به انتخاب پارسل و شمارش LFC/EL چندگانه (پیش‌فرض MetPy: LFC پایین، EL بالا)"},
    CIN: {fa:"بازدارندگی همرفتی", en:"Convective Inhibition", unit:"J/kg", range:"≤ 0",
      inputs:"همان CAPE", formula:"CIN = Rd ∫ (Tv,parcel − Tv,env) d ln p از سطح پارسل تا LFC (منفی)", ref:"MetPy cape_cin",
      insufficient:"مانند CAPE", limits:"مقدار به نقطهٔ شروع پارسل بسیار حساس است"},
    LCL: {fa:"تراز چگالش بالابرده", en:"Lifted Condensation Level", unit:"hPa / K", range:"p ≤ p سطح",
      inputs:"p، T، Td پارسل (Td ≤ T)", formula:"حل بسته با تابع W لامبرت (شاخهٔ −۱)", ref:"Romps 2017, J. Atmos. Sci.; MetPy lcl",
      insufficient:"Td > T ⇒ null", limits:"فرض رطوبت نسبت به آب مایع"},
    LI: {fa:"شاخص بالابری", en:"Lifted Index", unit:"K", range:"منفی = ناپایدار",
      inputs:"T500 محیط و پارسل سطحی بالارفته تا ۵۰۰ hPa", formula:"LI = T500,env − T500,parcel", ref:"Galway 1956; MetPy lifted_index",
      insufficient:"۵۰۰ hPa خارج از پروفایل ⇒ null", limits:"بدون اصلاح دمای مجازی؛ پارسل سطحی ممکن است نمایندهٔ لایهٔ مرزی نباشد"},
    K: {fa:"شاخص K", en:"K-index", unit:"°C", range:"≥ ۳۰ پتانسیل بالا", inputs:"T850، T700، T500، Td850، Td700",
      formula:"K = (T850 − T500) + Td850 − (T700 − Td700)", ref:"George 1960; MetPy k_index",
      insufficient:"هر سطح خارج از پروفایل (مثلاً ۸۵۰ زیر زمین در مناطق مرتفع) ⇒ null با why=level_below_ground_850", limits:"برای همرفت جرم‌هوایی؛ نه سامانه‌های شدید"},
    TT: {fa:"توتال‌توتال", en:"Total Totals", unit:"°C", range:"≥ ۴۴ احتمال تندری", inputs:"T850، Td850، T500",
      formula:"TT = VT + CT = (T850 − T500) + (Td850 − T500)", ref:"Miller 1972; MetPy total_totals_index",
      insufficient:"۸۵۰ یا ۵۰۰ خارج از پروفایل ⇒ null", limits:"وابسته به ۸۵۰ hPa؛ نامناسب برای ارتفاع‌های بالا"},
    SHOWALTER: {fa:"شاخص شوالتر", en:"Showalter Index", unit:"K", range:"منفی = ناپایدار", inputs:"پارسل از ۸۵۰ hPa تا ۵۰۰",
      formula:"SI = T500,env − T500,parcel(850→500)", ref:"Showalter 1953; MetPy showalter_index", insufficient:"مانند K", limits:"فقط لایهٔ ۸۵۰–۵۰۰"},
    SHEAR: {fa:"برش باد لایه‌ای", en:"Bulk wind shear", unit:"m/s", range:"≥ 0", inputs:"u،v (m/s) و z (m)؛ لایه بر حسب متر AGL (۰–۱، ۰–۳، ۰–۶ km)",
      formula:"S = |V(بالا) − V(پایین)| با درون‌یابی لگاریتمی در فشار", ref:"MetPy bulk_shear",
      insufficient:"لایه از بالای پروفایل بیرون زند یا < ۳ ردیف با u,v,z معتبر ⇒ null", limits:"۰–۶ km: ≥ ۱۸ m/s برای ابرسلول مناسب‌تر است (Rasmussen & Blanchard 1998، راهنمای تجربی نه حد قطعی)"},
    BUNKERS: {fa:"حرکت توفان بانکرز (راست‌گرد/چپ‌گرد)", en:"Bunkers storm motion", unit:"m/s", range:"بردار (u,v)",
      inputs:"u،v،z تا ≥ ۶ km AGL", formula:"میانگین ۰–۶ km (وزن فشار) ± ۷٫۵ m/s عمود بر برش (میانگین ۵٫۵–۶ km منهای ۰–۰٫۵ km)",
      ref:"Bunkers et al. 2000; MetPy bunkers_storm_motion", insufficient:"پروفایل کوتاه‌تر از ۶ km ⇒ null", limits:"نیمکرهٔ شمالی؛ برای سامانه‌های غیرابرسلولی نمایندهٔ حرکت واقعی نیست"},
    SRH: {fa:"هلیسیتی نسبی توفان", en:"Storm-relative helicity", unit:"m²/s²", range:"مثبت = چرخش ساعتگرد در برش",
      inputs:"u،v،z و حرکت توفان (پیش‌فرض: Bunkers راست‌گرد)", formula:"SRH = Σ [(u_{i+1}−c_x)(v_i−c_y) − (u_i−c_x)(v_{i+1}−c_y)] روی لایه", ref:"Davies-Jones et al. 1990; MetPy storm_relative_helicity",
      insufficient:"لایه فراتر از بالای پروفایل ⇒ null", limits:"حساس به وضوح قائم و حرکت توفان؛ مثبت و منفی جدا گزارش می‌شوند"},
    CRITICAL: {fa:"زاویهٔ بحرانی", en:"Critical angle", unit:"درجه", range:"۰–۱۸۰", inputs:"برش ۰–۵۰۰ m و بردار باد سطحی تا حرکت توفان", formula:"زاویهٔ بین دو بردار",
      ref:"Esterheld & Giuliano 2008; MetPy critical_angle", insufficient:"برش صفر ⇒ null", limits:"مقادیر ~۹۰° برای ابرسلول چرخان مساعد گزارش شده؛ آستانهٔ قطعی نیست"},
    PWAT: {fa:"آب قابل بارش", en:"Precipitable Water", unit:"mm", range:"≥ 0", inputs:"p، Td (لایه)",
      formula:"PW = −(1/(g ρw)) ∫ r dp، r = ε e(Td)/(p − e)", ref:"MetPy precipitable_water",
      insufficient:"لایهٔ درخواستی خارج از پروفایل ⇒ null", limits:"لایهٔ ناقص (بدون سطوح بالا) کمتر از واقعیت است"}
  };
})();
