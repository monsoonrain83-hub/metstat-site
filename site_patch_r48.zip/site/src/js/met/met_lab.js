/* ===== آزمایشگاه محاسبات: ورود دادهٔ سونداژ (متن/CSV/Open-Meteo) و تحلیل کامل پروفایل (فاز ۳) =====
   بدون DOM: در Node هم آزموده می‌شود. قرارداد داده: خام {p(hPa),T(°C),Td(°C),z(m),u,v(m/s)} → MET.profile.clean → تحلیل.
   قاعدهٔ داده: ردیف ناقص حذف و گزارش می‌شود، هرگز با صفر پر نمی‌شود؛ شاخصی که ورودی‌اش کافی نیست null با علت برمی‌گرداند.
   Open-Meteo (CC BY 4.0، open-meteo.com): فقط خوانده می‌شود؛ ترازهای زیر سطح زمین (p > فشار سطحی) حذف می‌شوند، نه برون‌یابی. */
(function(){
  "use strict";
  const M = globalThis.MET, C = M.C, T = M.thermo, PF = M.profile, W = M.wind, IO = {}, L = {};
  const fin = x => typeof x === "number" && isFinite(x);
  const num = s => { if(s == null) return NaN; s = String(s).trim().replace(/٫/g, ".").replace(/,/g, "."); if(s === "" || /^(nan|null|na|n\/a|-+)$/i.test(s)) return NaN; const v = Number(s); return isFinite(v) ? v : NaN; };
  /* ---------- پارس سونداژ ---------- */
  const ALIAS = {p:["pres", "pressure", "p", "press", "p_hpa", "pressure_hpa"], z:["hght", "height", "z", "hgt", "alt", "altitude", "h", "geopotential_height", "z_m"],
    T:["temp", "temperature", "t", "tdry", "t_c", "temp_c", "temperature_c"], Td:["dwpt", "dewpoint", "td", "dew", "dewp", "td_c", "dwpt_c", "dewpoint_c"],
    dir:["drct", "wdir", "dir", "winddir", "wind_direction", "direction"], spd_kt:["sknt", "wspd_kt", "kt", "knot", "knots"], spd:["sped", "wspd", "wind_speed", "speed", "ws", "spd", "windspeed"],
    u:["u", "uwind", "u_wind", "ugrd"], v:["v", "vwind", "v_wind", "vgrd"], rh:["relh", "rh", "humidity"]};
  function colMap(names){ const map = {}; names.forEach((n, i) => { const k = String(n).trim().toLowerCase().replace(/\(.*?\)/g, "").replace(/\s+/g, "_").replace(/_+$/, "");
    for(const key in ALIAS) if(ALIAS[key].indexOf(k) >= 0 && map[key] == null) map[key] = i; }); return map; }
  // windUnit برای ستون سرعت عمومی: "ms" | "kt" | "kmh"
  IO.parse = function(text, opts){
    opts = opts || {}; const issues = [];
    if(typeof text !== "string" || !text.trim()) return {ok:false, why:"empty_input"};
    const lines = text.replace(/\r/g, "").split("\n");
    // سرایند: خطی که هم pres و هم یکی از temp/hght دارد
    let h = -1; for(let i = 0; i < lines.length && i < 60; i++){ const s = lines[i].toLowerCase(); if(/\bpres\b|\bpressure\b|(^|[,;\s])p([,;\s]|$)/.test(s) && /\btemp\b|\bt\b|temperature|hght|height|\bz\b/.test(s) && !/^\s*[-\d.]/.test(s)){ h = i; break; } }
    if(h < 0) return {ok:false, why:"header_not_found"};
    const head = lines[h]; let rows = [], names, mode;
    if(/[,;\t]/.test(head)){ const sep = head.indexOf(";") >= 0 ? ";" : (head.indexOf("\t") >= 0 ? "\t" : ","); mode = "csv"; names = head.split(sep);
      for(let i = h + 1; i < lines.length; i++){ const ln = lines[i]; if(!ln.trim() || /^\s*[-=]+\s*$/.test(ln)) continue; if(/[A-Za-z]{3,}/.test(ln) && !/^\s*[-\d.]/.test(ln)) continue; rows.push(ln.split(sep)); } }
    else {
      const names0 = head.trim().split(/\s+/); names = names0;
      // Wyoming: ستون‌های ثابت ۷ نویسه‌ای (پس از خط خط‌چین)
      const hasUnits = /hpa/i.test(lines[h + 1] || ""), dash = /^-{10,}/.test((lines[h + 1] || "").trim()) || /^-{10,}/.test((lines[h + 2] || "").trim());
      const wy = /^\s*PRES\s+HGHT/.test(head) && (hasUnits || dash); mode = wy ? "wyoming" : "table";
      let start = h + 1; while(start < lines.length && (/^\s*[-=]+\s*$/.test(lines[start]) || /hpa|\bm\b.*\bc\b/i.test(lines[start]) && !/^\s*\d/.test(lines[start]))) start++;
      for(let i = start; i < lines.length; i++){ const ln = lines[i]; if(!ln.trim()) { if(wy && rows.length) break; continue; } if(/^\s*[A-Za-z<]/.test(ln)) { if(wy) break; continue; } if(/^\s*[-=]+\s*$/.test(ln)) continue;
        if(wy){ const row = []; for(let c = 0; c < names.length; c++) row.push(ln.substr(c * 7, 7)); rows.push(row); } else rows.push(ln.trim().split(/\s+/)); } }
    const m = colMap(names); if(m.p == null) return {ok:false, why:"no_pressure_column"}; if(m.T == null && m.z == null) return {ok:false, why:"no_temperature_column"};
    if(m.T == null) return {ok:false, why:"no_temperature_column"}; if(m.Td == null && m.rh == null) return {ok:false, why:"no_dewpoint_column"};
    const wu = opts.windUnit || "ms", kmh = wu === "kmh" ? 1 / 3.6 : 1, f = wu === "kt" ? W.KT : kmh;
    const raw = {p:[], T:[], Td:[], z:[], u:[], v:[]}; let nWind = 0;
    for(const r of rows){ const p = num(r[m.p]); if(!fin(p)) continue; const t = num(r[m.T]); let td = m.Td != null ? num(r[m.Td]) : NaN;
      if(!fin(td) && m.rh != null && fin(t)){ const rh = num(r[m.rh]); if(fin(rh) && rh > 0 && rh <= 100) td = T.dewpointFromRH(t + C.zeroC, rh / 100) - C.zeroC; }
      let u = NaN, v = NaN;
      if(m.u != null && m.v != null){ u = num(r[m.u]) * (wu === "kt" ? W.KT : f); v = num(r[m.v]) * (wu === "kt" ? W.KT : f); }
      else if(m.dir != null){ const d = num(r[m.dir]); let s = NaN; if(m.spd_kt != null) s = num(r[m.spd_kt]) * W.KT; else if(m.spd != null) s = num(r[m.spd]) * f;
        if(fin(d) && fin(s) && d >= 0 && d <= 360 && s >= 0){ const c = W.components(s, d); u = c.u; v = c.v; } }
      if(fin(u) && fin(v)) nWind++;
      raw.p.push(p); raw.T.push(t); raw.Td.push(td); raw.z.push(m.z != null ? num(r[m.z]) : NaN); raw.u.push(u); raw.v.push(v); }
    if(!raw.p.length) return {ok:false, why:"no_data_rows"};
    if(m.z == null) issues.push("no_height_column"); if(!nWind) issues.push("no_wind_data");
    return {ok:true, raw:raw, mode:mode, columns:Object.keys(m), rows:raw.p.length, issues:issues};
  };
  /* ---------- Open-Meteo ---------- */
  IO.OM_LEVELS = [1000, 975, 950, 925, 900, 850, 800, 700, 600, 500, 400, 300, 250, 200, 150, 100, 70, 50, 30];
  IO.omUrl = function(lat, lon, o){ o = o || {}; const lv = IO.OM_LEVELS, h = ["temperature_2m", "dew_point_2m", "surface_pressure", "wind_speed_10m", "wind_direction_10m"];
    for(const l of lv){ h.push("temperature_" + l + "hPa", "relative_humidity_" + l + "hPa", "geopotential_height_" + l + "hPa", "wind_speed_" + l + "hPa", "wind_direction_" + l + "hPa"); }
    return "https://api.open-meteo.com/v1/forecast?latitude=" + lat + "&longitude=" + lon + "&hourly=" + h.join(",") + "&wind_speed_unit=ms&timezone=GMT&forecast_days=" + (o.days || 3) + (o.model ? "&models=" + o.model : ""); };
  // خروجی JSON → {times:[...], at(i):{raw,issues}} ؛ ساعت i را به سونداژ خام تبدیل می‌کند
  IO.omToRaw = function(j, i){
    if(!j || !j.hourly || !j.hourly.time) return {ok:false, why:"bad_response"};
    const H = j.hourly, g = (k) => H[k] ? H[k][i] : null, raw = {p:[], T:[], Td:[], z:[], u:[], v:[]}, issues = [];
    const ps = g("surface_pressure"), t2 = g("temperature_2m"), d2 = g("dew_point_2m"), s10 = g("wind_speed_10m"), w10 = g("wind_direction_10m"), elev = j.elevation;
    if(!fin(ps) || !fin(t2) || !fin(d2)) return {ok:false, why:"surface_data_missing"};
    const wc = (s, d) => (fin(s) && fin(d)) ? W.components(s, d) : {u:NaN, v:NaN};
    const c10 = wc(s10, w10);
    raw.p.push(ps); raw.T.push(t2); raw.Td.push(d2); raw.z.push(fin(elev) ? elev : NaN); raw.u.push(c10.u); raw.v.push(c10.v);   // z سطح = ارتفاع مدل (elevation)؛ باد ۱۰ متری
    if(!fin(elev)) issues.push("no_elevation");
    let below = 0;
    for(const l of IO.OM_LEVELS){
      if(l >= ps - 1e-6){ below++; continue; }                                  // ترازهای زیر/روی سطح زمین
      const t = g("temperature_" + l + "hPa"), rh = g("relative_humidity_" + l + "hPa"), z = g("geopotential_height_" + l + "hPa"), s = g("wind_speed_" + l + "hPa"), d = g("wind_direction_" + l + "hPa");
      if(!fin(t) || !fin(rh) || rh <= 0) continue;
      const td = T.dewpointFromRH(t + C.zeroC, Math.min(1, rh / 100)) - C.zeroC, c = wc(s, d);
      raw.p.push(l); raw.T.push(t); raw.Td.push(td); raw.z.push(fin(z) ? z : NaN); raw.u.push(c.u); raw.v.push(c.v);
    }
    // ترازی که ارتفاعش زیر ارتفاع سطح باشد نامعتبر است
    if(fin(elev)) for(let k = 1; k < raw.p.length; k++) if(fin(raw.z[k]) && raw.z[k] <= elev){ raw.z[k] = NaN; issues.push("level_height_below_surface@" + raw.p[k]); }
    return {ok:true, raw:raw, belowGround:below, issues:issues, time:H.time[i], lat:j.latitude, lon:j.longitude, elevation:elev};
  };
  IO.omTimes = j => (j && j.hourly && j.hourly.time) ? j.hourly.time.slice() : [];

  /* ---------- تحلیل ---------- */
  function parcelSetup(prof, type){
    if(type === "ML"){ const mp = M.parcel.mixedParcel(prof, 100); if(!mp) return null; const p0 = prof.p[0], sel = prof.p.map((q, i) => i).filter(i => prof.p[i] < p0 - 100);
      return {p:[mp.p].concat(sel.map(i => prof.p[i])), Tk:[mp.Tk].concat(sel.map(i => prof.Tk[i])), Tdk:[mp.Tdk].concat(sel.map(i => prof.Tdk[i]))}; }
    if(type === "MU"){ const lay = PF.layer(prof, ["Tk", "Tdk"], null, 300, false); if(!lay || !lay.p.length) return null; let bi = 0, best = -Infinity;
      for(let i = 0; i < lay.p.length; i++){ const te = T.thetaE(lay.p[i], lay.Tk[i], lay.Tdk[i]); if(te > best){ best = te; bi = i; } }
      const s = prof.p.indexOf(lay.p[bi]); return {p:prof.p.slice(s), Tk:prof.Tk.slice(s), Tdk:prof.Tdk.slice(s)}; }
    return {p:prof.p, Tk:prof.Tk, Tdk:prof.Tdk};
  }
  const CAPEFN = {SB:"sbCapeCin", ML:"mlCapeCin", MU:"muCapeCin"};
  L.analyze = function(raw, opts){
    opts = opts || {}; const type = CAPEFN[opts.parcel] ? opts.parcel : "SB";
    const cl = PF.clean(raw); if(!cl.ok) return {ok:false, why:cl.why, issues:cl.issues, dropped:cl.dropped};
    const prof = cl.prof, I = M.indices, out = {ok:true, prof:prof, parcelType:type, dropped:cl.dropped, issues:cl.issues.slice(), items:{}, parcels:{}};
    out.surface = {p:prof.p[0], T:prof.Tk[0] - C.zeroC, Td:prof.Tdk[0] - C.zeroC, z:prof.z[0]};
    out.top = prof.p[prof.p.length - 1];
    for(const t of ["SB", "ML", "MU"]){ try{ out.parcels[t] = M.parcel[CAPEFN[t]](prof); }catch(e){ out.parcels[t] = M.nil("exception:" + e.message); } }
    const P = out.parcels[type], it = out.items;
    it.CAPE = P && P.v != null ? M.ok(P.v, {note:P.note}) : M.nil(P ? P.why : "cape_failed");
    it.CIN = P && P.v != null ? M.ok(P.cin) : M.nil(P ? P.why : "cape_failed");
    it.LCL = P && P.lcl ? M.ok(P.lcl.p, {Tk:P.lcl.Tk, z:L.heightAtP(prof, P.lcl.p)}) : M.nil(P && P.why || "lcl_failed");
    const lf = P && P.lfc ? P.lfc.p : null, el = P && P.el ? P.el.p : null;
    out.lfc = lf; out.el = el;
    it.LI = I.liftedIndex(prof); it.K = I.kIndex(prof); it.TT = I.totalTotals(prof); it.SHOWALTER = I.showalter(prof); it.PWAT = I.pwat(prof);
    it.VT = I.verticalTotals(prof); it.CT = I.crossTotals(prof);
    const sh = (b, d) => W.bulkShear(prof, b, d);
    it.SHEAR = {s01:sh(0, 1000), s03:sh(0, 3000), s06:sh(0, 6000), v:null, why:null};
    const bk = W.bunkers(prof); it.BUNKERS = bk;
    if(bk.right){ const st = bk.right; it.SRH = {s01:W.srh(prof, 1000, st), s03:W.srh(prof, 3000, st), v:null}; it.CRITICAL = W.criticalAngle(prof, st); }
    else { it.SRH = {s01:M.nil(bk.why), s03:M.nil(bk.why), v:null}; it.CRITICAL = M.nil(bk.why); }
    it.SHEAR.v = it.SHEAR.s06.v; it.SHEAR.why = it.SHEAR.s06.why; it.SRH.v = it.SRH.s03.v;
    out.hodo = W.hodograph(prof, 10000);
    out.hasWind = !!W.windProfile(prof);
    return out;
  };
  L.heightAtP = function(prof, p){ if(!prof.z || !prof.z.length) return null; const idx = []; for(let i = 0; i < prof.p.length; i++) if(fin(prof.z[i])) idx.push(i); if(idx.length < 2) return null;
    const pp = idx.map(i => Math.log(prof.p[i])), zz = idx.map(i => prof.z[i]); const x = Math.log(p);
    if(x > pp[0] + 1e-9 || x < pp[pp.length - 1] - 1e-9) return null; for(let i = 0; i < pp.length - 1; i++) if(x <= pp[i] && x >= pp[i + 1]){ const f = (x - pp[i]) / (pp[i + 1] - pp[i]); return zz[i] + f * (zz[i + 1] - zz[i]); } return null; };
  // منحنی پارسل برای رسم Skew-T (K)
  L.parcelCurve = function(prof, type){ const s = parcelSetup(prof, type); if(!s) return null; const w = M.parcel.parcelProfileWithLcl(s); if(!w) return null; return {p:w.p, Tk:w.Tp, pLcl:w.pLcl, tLcl:w.tLcl}; };
  // متن علت داده‌ی ناکافی
  L.whyText = function(why, en){
    if(!why) return ""; let m;
    if((m = /^level_below_ground_(\d+)/.exec(why))) return en ? "Level " + m[1] + " hPa is below the ground surface" : "تراز " + m[1] + " hPa زیر سطح زمین است";
    if((m = /^level_above_profile_top_(\d+)/.exec(why))) return en ? "Level " + m[1] + " hPa is above the profile top" : "تراز " + m[1] + " hPa بالاتر از بالای پروفایل است";
    const D = {lcl_failed:["LCL قابل‌محاسبه نیست (Td > T یا رطوبت نامعتبر)", "LCL cannot be solved (Td > T or invalid humidity)"], cape_failed:["محاسبهٔ CAPE ممکن نشد", "CAPE could not be computed"],
      layer_outside_profile:["لایهٔ لازم خارج از پروفایل است", "Required layer lies outside the profile"], layer_exceeds_profile_top:["لایه از بالای پروفایل (ارتفاع) بیرون می‌زند", "Layer exceeds the profile top (height)"],
      insufficient_wind_levels:["باد یا ارتفاع کافی نیست (کمتر از ۳ سطح با u،v،z)", "Not enough wind/height levels (< 3 with u, v, z)"], zero_shear:["برش صفر است", "Shear is zero"], zero_vector:["بردار صفر است", "Zero vector"],
      no_lfc:["پارسل به LFC نمی‌رسد (CAPE صفر معتبر)", "Parcel never reaches an LFC (valid zero CAPE)"], nonfinite_mixing_ratio:["نسبت اختلاط نامعتبر", "Invalid mixing ratio"]};
    return D[why] ? D[why][en ? 1 : 0] : why;
  };
  L.ioWhyText = function(why, en){ const D = {empty_input:["ورودی خالی است", "Input is empty"], header_not_found:["سطر عنوان ستون‌ها (مثلاً PRES HGHT TEMP DWPT DRCT SKNT) پیدا نشد", "Column header row (e.g. PRES HGHT TEMP DWPT DRCT SKNT) not found"],
      no_pressure_column:["ستون فشار (PRES) نیست", "No pressure (PRES) column"], no_temperature_column:["ستون دما (TEMP) نیست", "No temperature (TEMP) column"], no_dewpoint_column:["ستون نقطهٔ شبنم (DWPT) یا رطوبت نسبی نیست", "No dew-point (DWPT) or RH column"],
      no_data_rows:["ردیف داده‌ای پیدا نشد", "No data rows found"], too_few_valid_levels:["کمتر از ۳ سطح معتبر", "Fewer than 3 valid levels"], duplicate_pressure:["فشار تکراری در پروفایل", "Duplicate pressure in profile"], empty_profile:["پروفایل خالی", "Empty profile"],
      bad_response:["پاسخ Open-Meteo نامعتبر است", "Invalid Open-Meteo response"], surface_data_missing:["دادهٔ سطحی (فشار/دما/شبنم) برای این ساعت موجود نیست", "Surface data (pressure/T/Td) missing for this hour"]};
    return D[why] ? D[why][en ? 1 : 0] : why; };
  M.io = IO; M.lab = L; M.VERSION = "met-1.2.0-phase3";
})();
