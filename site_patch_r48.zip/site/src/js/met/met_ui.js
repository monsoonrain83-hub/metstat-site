/* ===== رابط «آزمایشگاه محاسبات» (فاز ۳) — زبانهٔ پنجم صفحهٔ «تحلیل و هشدار» =====
   ورودی: چسباندن/بارگذاری سونداژ (Wyoming یا CSV) یا Open-Meteo؛ خروجی: Skew-T، هودوگراف، کارت هر شاخص.
   محاسبه در MET.lab است؛ این فایل فقط نمایش می‌دهد. رنگ‌بندی برچسب‌ها صرفاً نمایشی و جدا از محاسبه است. */
(function(){
  "use strict";
  const M = globalThis.MET, S = {res:null, parcel:"SB", src:"", om:null, omSel:0, tab:"paste", busy:false};
  const E = () => typeof LANG !== "undefined" && LANG === "en";
  const t = (fa, en) => E() ? en : fa;
  const fin = x => typeof x === "number" && isFinite(x);
  const esc = s => String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  const fx = (x, d) => fin(x) ? x.toFixed(d == null ? 1 : d) : "—";
  let root = null;
  /* ---- برچسب رنگی نمایشی (آستانه‌ها راهنمای تجربی‌اند، نه حد قطعی) ---- */
  const BAND = {
    CAPE:v => v < 300 ? [0, "ضعیف", "Weak"] : v < 1000 ? [1, "متوسط", "Moderate"] : v < 2500 ? [2, "قوی", "Strong"] : [3, "بسیار قوی", "Extreme"],
    LI:v => v > 0 ? [0, "پایدار", "Stable"] : v > -3 ? [1, "ناپایداری ضعیف", "Marginal"] : v > -6 ? [2, "ناپایدار", "Unstable"] : [3, "بسیار ناپایدار", "Very unstable"],
    K:v => v < 20 ? [0, "کم", "Low"] : v < 30 ? [1, "متوسط", "Moderate"] : v < 35 ? [2, "زیاد", "High"] : [3, "بسیار زیاد", "Very high"],
    TT:v => v < 44 ? [0, "کم", "Low"] : v < 50 ? [1, "تندری محتمل", "Thunderstorms likely"] : v < 55 ? [2, "تندری شدید محتمل", "Severe possible"] : [3, "بسیار زیاد", "Very high"],
    SHEAR:v => v < 10 ? [0, "ضعیف", "Weak"] : v < 18 ? [1, "متوسط", "Moderate"] : v < 25 ? [2, "قوی", "Strong"] : [3, "بسیار قوی", "Very strong"],
    SRH:v => v < 100 ? [0, "کم", "Low"] : v < 250 ? [1, "متوسط", "Moderate"] : v < 400 ? [2, "زیاد", "High"] : [3, "بسیار زیاد", "Very high"]
  };
  const bandTag = (k, v) => { if(!fin(v) || !BAND[k]) return ""; const b = BAND[k](v); return '<span class="labBand b' + b[0] + '" title="' + esc(t("رنگ‌بندی نمایشی؛ آستانه‌ها راهنمای تجربی‌اند", "Display only; thresholds are empirical guides")) + '">' + esc(b[E() ? 2 : 1]) + "</span>"; };
  const val = (v, u, d) => '<span class="labV" dir="ltr">' + fx(v, d) + '</span> <span class="labU">' + esc(u) + "</span>";
  const why = w => w ? '<div class="labWhy">' + esc(M.lab.whyText(w, E())) + "</div>" : "";
  /* ---- کارت ---- */
  function card(key, body, o){
    o = o || {}; const m = M.meta[o.meta || key] || {}, name = E() ? m.en : m.fa, bad = o.bad;
    const det = m.formula ? '<details class="labDet"><summary>' + esc(t("ورودی، فرمول و محدودیت‌ها", "Inputs, formula and limits")) + "</summary><dl>" +
      "<dt>" + esc(t("ورودی", "Inputs")) + "</dt><dd>" + esc(m.inputs || "") + "</dd><dt>" + esc(t("فرمول / الگوریتم", "Formula / algorithm")) + '</dt><dd dir="ltr" class="labF">' + esc(m.formula) + "</dd>" +
      "<dt>" + esc(t("واحد و بازه", "Unit and range")) + "</dt><dd>" + esc((m.unit || "") + (m.range ? " — " + m.range : "")) + "</dd>" +
      "<dt>" + esc(t("داده ناکافی", "Insufficient data")) + "</dt><dd>" + esc(m.insufficient || "") + "</dd><dt>" + esc(t("محدودیت تفسیر", "Limits")) + "</dt><dd>" + esc(m.limits || "") + "</dd>" +
      "<dt>" + esc(t("مرجع", "Reference")) + '</dt><dd dir="ltr">' + esc(m.ref || "") + "</dd></dl></details>" : "";
    return '<article class="labCard' + (bad ? " bad" : "") + '"><h4>' + esc(name || key) + (o.tag || "") + "</h4>" + body + det + "</article>";
  }
  const simple = (k, it, unit, d, band, extra) => it && it.v != null ? card(k, '<div class="labMain">' + val(it.v, unit, d) + (band ? bandTag(band, it.v) : "") + "</div>" + (extra || "")) :
    card(k, '<div class="labMain labNA">' + esc(t("داده ناکافی", "Insufficient data")) + "</div>" + why(it && it.why), {bad:true});
  function cardsHtml(r){
    const I = r.items, P = r.parcels[r.parcelType], z0 = r.surface.z, agl = p => { const z = M.lab.heightAtP(r.prof, p); return fin(z) && fin(z0) ? z - z0 : null; };
    let h = '<h3 class="labH">' + esc(t("شاخص‌های ترمودینامیکی", "Thermodynamic indices")) + "</h3><div class='labGrid'>";
    const note = I.CAPE.note === "no_lfc" ? '<div class="labWhy">' + esc(M.lab.whyText("no_lfc", E())) + "</div>" : "";
    h += simple("CAPE", I.CAPE, "J/kg", 0, "CAPE", '<div class="labSub">' + esc(t("پارسل", "Parcel")) + ": " + r.parcelType + "</div>" + note);
    h += simple("CIN", I.CIN, "J/kg", 0);
    h += I.LCL.v != null ? card("LCL", '<div class="labMain">' + val(I.LCL.v, "hPa", 0) + '</div><div class="labSub">' + (agl(I.LCL.v) != null ? fx(agl(I.LCL.v), 0) + " m AGL · " : "") + fx(I.LCL.Tk - 273.15, 1) + " °C</div>") : simple("LCL", I.LCL, "hPa", 0);
    if(I.CAPE.v != null){
      h += r.lfc != null ? card("LFC", '<div class="labMain">' + val(r.lfc, "hPa", 0) + "</div>" + (agl(r.lfc) != null ? '<div class="labSub">' + fx(agl(r.lfc), 0) + " m AGL</div>" : "")) : card("LFC", '<div class="labMain labNA">—</div>' + why("no_lfc"));
      h += r.el != null ? card("EL", '<div class="labMain">' + val(r.el, "hPa", 0) + "</div>" + (agl(r.el) != null ? '<div class="labSub">' + fx(agl(r.el), 0) + " m AGL</div>" : "")) : card("EL", '<div class="labMain labNA">—</div>' + why(r.lfc == null ? "no_lfc" : ""));
    } else { h += simple("LFC", I.CAPE, "hPa", 0); h += simple("EL", I.CAPE, "hPa", 0); }
    h += simple("LI", I.LI, "°C", 1, "LI") + simple("SHOWALTER", I.SHOWALTER, "°C", 1) + simple("K", I.K, "°C", 1, "K") + simple("TT", I.TT, "°C", 1, "TT") + simple("VT", I.VT, "°C", 1) + simple("CT", I.CT, "°C", 1) + simple("PWAT", I.PWAT, "mm", 1);
    h += "</div>";
    h += '<h3 class="labH">' + esc(t("باد و برش", "Wind and shear")) + "</h3>";
    if(!r.hasWind) h += '<div class="labNote">' + esc(t("دادهٔ باد یا ارتفاع کافی نیست (کمتر از ۳ سطح با u،v و z)؛ شاخص‌های باد محاسبه نمی‌شوند. چیزی با صفر جایگزین نشده است.", "Not enough wind/height data (< 3 levels with u, v, z); wind indices are not computed. Nothing was replaced with zero.")) + "</div>";
    h += "<div class='labGrid'>";
    const sh = I.SHEAR, row = (lab, it, u, d, k) => '<div class="labRow"><span>' + lab + '</span><span>' + (it.v != null ? val(it.v, u, d) + (k ? bandTag(k, it.v) : "") : '<span class="labNA">—</span>') + "</span></div>";
    h += card("SHEAR", row("0–1 km", sh.s01, "m/s", 1) + row("0–3 km", sh.s03, "m/s", 1) + row("0–6 km", sh.s06, "m/s", 1, "SHEAR") + (sh.s06.v == null ? why(sh.s06.why) : ""), {bad:sh.s06.v == null && sh.s03.v == null});
    const bk = I.BUNKERS, vec = q => q ? fx(W().speed(q.u, q.v), 1) + " m/s @ " + fx(W().direction(q.u, q.v), 0) + "°" : "—";
    h += bk.right ? card("BUNKERS", '<div class="labRow"><span>RM</span><span dir="ltr">' + vec(bk.right) + '</span></div><div class="labRow"><span>LM</span><span dir="ltr">' + vec(bk.left) + '</span></div><div class="labRow"><span>' + esc(t("میانگین ۰–۶ km", "Mean 0–6 km")) + '</span><span dir="ltr">' + vec(bk.mean) + "</span></div>") : card("BUNKERS", '<div class="labMain labNA">' + esc(t("داده ناکافی", "Insufficient data")) + "</div>" + why(bk.why), {bad:true});
    const sr = I.SRH, srr = (lab, it) => '<div class="labRow"><span>' + lab + "</span><span>" + (it.v != null ? val(it.v, "m²/s²", 0) + '<span class="labSub"> (+' + fx(it.pos, 0) + " / " + fx(it.neg, 0) + ")</span>" : '<span class="labNA">—</span>') + "</span></div>";
    h += card("SRH", srr("0–1 km", sr.s01) + srr("0–3 km", sr.s03) + (sr.s03.v != null ? bandTag("SRH", sr.s03.v) : "") + '<div class="labSub">' + esc(t("نسبت به حرکت راست‌گرد Bunkers", "Relative to Bunkers right-mover")) + "</div>" + (sr.s03.v == null ? why(sr.s03.why) : ""), {bad:sr.s03.v == null && sr.s01.v == null});
    h += simple("CRITICAL", I.CRITICAL, "°", 0);
    return h + "</div>";
  }
  const W = () => M.wind;
  /* ---- رندر نتیجه ---- */
  function render(){
    const out = root.querySelector("#labOut"); if(!S.res){ out.hidden = true; return; } const r = S.res; out.hidden = false;
    const n = r.prof.p.length, iss = r.issues.length ? ' <span class="labSub">· ' + esc(t("هشدار کیفیت", "Quality notes")) + ": " + esc(r.issues.slice(0, 6).join("، ")) + (r.issues.length > 6 ? " …" : "") + "</span>" : "";
    root.querySelector("#labSum").innerHTML = "<b>" + esc(S.src) + "</b> — " + esc(t("سطوح معتبر", "valid levels")) + ": <b>" + n + "</b> (" + fx(r.surface.p, 0) + "→" + fx(r.top, 0) + " hPa) · " + esc(t("ردیف حذف‌شده", "dropped rows")) + ": " + r.dropped + iss;
    root.querySelectorAll("[data-par]").forEach(b => b.classList.toggle("on", b.dataset.par === S.parcel));
    const sk = root.querySelector("#labSk"); sk.innerHTML = M.skewt.svg(r, {en:E(), parcel:S.parcel, title:S.parcel + " parcel"}); M.skewt.attach(sk, r, root.querySelector("#labInfo"));
    const hd = M.skewt.hodograph(r, {en:E()}); root.querySelector("#labHodo").innerHTML = hd || '<div class="labNote">' + esc(t("هودوگراف: دادهٔ باد کافی نیست.", "Hodograph: not enough wind data.")) + "</div>";
    root.querySelector("#labCards").innerHTML = cardsHtml(r);
  }
  function analyze(raw, src, keepFirst){
    const res = M.lab.analyze(raw, {parcel:S.parcel});
    if(!res.ok){ S.res = null; render(); msg(t("تحلیل ممکن نشد: ", "Cannot analyse: ") + M.lab.ioWhyText(res.why, E()) + (res.issues && res.issues.length ? " (" + res.issues.slice(0, 3).join("، ") + ")" : ""), true); return false; }
    S.res = res; S.src = src; S.raw = raw; msg(""); render(); return true;
  }
  function msg(s, bad){ const e = root.querySelector("#labMsg"); e.textContent = s; e.className = "labMsg" + (bad ? " bad" : ""); e.hidden = !s; }
  /* ---- Open-Meteo ---- */
  async function omFetch(){
    const lat = parseFloat(root.querySelector("#labLat").value), lon = parseFloat(root.querySelector("#labLon").value);
    if(!(lat >= -90 && lat <= 90) || !(lon >= -180 && lon <= 180)){ msg(t("مختصات نامعتبر است.", "Invalid coordinates."), true); return; }
    const btn = root.querySelector("#labOmGo"); btn.disabled = true; msg(t("در حال دریافت از Open-Meteo…", "Fetching from Open-Meteo…"));
    const ac = new AbortController(), to = setTimeout(() => ac.abort(), 20000);
    try{
      const rs = await fetch(M.io.omUrl(lat, lon), {signal:ac.signal}); if(!rs.ok) throw new Error("HTTP " + rs.status);
      const j = await rs.json(); if(j.error) throw new Error(j.reason || "api error");
      S.om = j; const times = M.io.omTimes(j), sel = root.querySelector("#labOmT"); const now = new Date().toISOString().slice(0, 13);
      sel.innerHTML = times.map((x, i) => '<option value="' + i + '">' + esc(x.replace("T", " ") + " UTC") + "</option>").join(""); let k = times.findIndex(x => x.slice(0, 13) >= now); if(k < 0) k = 0; sel.value = String(k);
      msg(""); root.querySelector("#labOmRow").hidden = false; omRun();
    }catch(e){ S.om = null; msg(t("دریافت ناموفق: ", "Fetch failed: ") + (e.name === "AbortError" ? t("زمان انتظار تمام شد", "timeout") : e.message) + t(" — اتصال یا دسترسی مرورگر به api.open-meteo.com را بررسی کنید؛ می‌توانید سونداژ را دستی بچسبانید.", " — check connection / access to api.open-meteo.com; you can paste a sounding instead."), true); }
    finally{ clearTimeout(to); btn.disabled = false; }
  }
  function omRun(){
    if(!S.om) return; const i = parseInt(root.querySelector("#labOmT").value, 10), c = M.io.omToRaw(S.om, i);
    if(!c.ok){ S.res = null; render(); msg(M.lab.ioWhyText(c.why, E()), true); return; }
    analyze(c.raw, "Open-Meteo " + fx(c.lat, 2) + "°N " + fx(c.lon, 2) + "°E · " + c.time.replace("T", " ") + " UTC" + (fin(c.elevation) ? " · " + fx(c.elevation, 0) + " m" : ""));
    if(S.res && c.belowGround) S.res.issues.push(c.belowGround + " " + t("تراز زیر سطح زمین حذف شد", "levels below ground removed")), render();
  }
  /* ---- ورودی متن/فایل ---- */
  function runText(){
    const txt = root.querySelector("#labTxt").value, wu = root.querySelector("#labWu").value, r = M.io.parse(txt, {windUnit:wu});
    if(!r.ok){ S.res = null; render(); msg(t("ورودی خوانده نشد: ", "Input not read: ") + M.lab.ioWhyText(r.why, E()), true); return; }
    const ok = analyze(r.raw, t("ورودی دستی", "Manual input") + " (" + r.mode + ", " + r.rows + " " + t("ردیف", "rows") + ")");
    if(ok && r.issues.length){ S.res.issues = S.res.issues.concat(r.issues); render(); }
  }
  const PRESETS = [["استهبان", "Estahban", 29.13, 54.04], ["شیراز", "Shiraz", 29.59, 52.58], ["تهران", "Tehran", 35.69, 51.39], ["مشهد", "Mashhad", 36.30, 59.60], ["تبریز", "Tabriz", 38.08, 46.29], ["اهواز", "Ahvaz", 31.32, 48.67]];
  function shell(){
    const pr = PRESETS.map((p, i) => '<button type="button" class="labChip" data-pre="' + i + '">' + esc(E() ? p[1] : p[0]) + "</button>").join("");
    return '<div class="lab" dir="' + (E() ? "ltr" : "rtl") + '">' +
      '<section class="labIn"><h3>' + esc(t("آزمایشگاه محاسبات جوّ بالا", "Upper-air computation lab")) + '</h3><p class="labNote">' + esc(t("سونداژ یا پروفایل مدل را وارد کنید؛ شاخص‌ها با هستهٔ ترمودینامیک MET (سازگار با MetPy و آزموده‌شده) در مرورگر محاسبه می‌شوند. دادهٔ ناقص هرگز با صفر پر نمی‌شود.", "Enter a sounding or model profile; indices are computed in your browser with the MET thermodynamic core (MetPy-compatible, regression-tested). Missing data is never filled with zero.")) + "</p>" +
      '<div class="labSeg" role="tablist"><button type="button" data-tab="paste">' + esc(t("چسباندن / فایل", "Paste / file")) + '</button><button type="button" data-tab="om">Open-Meteo</button></div>' +
      '<div id="labPaste"><textarea id="labTxt" rows="9" dir="ltr" spellcheck="false" placeholder="PRES HGHT TEMP DWPT DRCT SKNT&#10;1000.0  36  22.2  21.0 180 7&#10;…"></textarea>' +
      '<div class="labBtns"><label class="labFile">' + esc(t("بارگذاری فایل", "Load file")) + '<input type="file" id="labFile" accept=".txt,.csv,.tsv,text/plain,text/csv" hidden></label>' +
      '<button type="button" id="labSample">' + esc(t("نمونه", "Sample")) + '</button><label>' + esc(t("یکای سرعت باد (ستون عمومی)", "Wind speed unit (generic column)")) + ' <select id="labWu"><option value="ms">m/s</option><option value="kt">kt</option><option value="kmh">km/h</option></select></label>' +
      '<button type="button" id="labRun" class="labGo">' + esc(t("تحلیل", "Analyse")) + '</button></div>' +
      '<p class="labSub">' + esc(t("قالب‌ها: متن Wyoming (ستون‌های PRES HGHT TEMP DWPT … DRCT SKNT) یا CSV با سرایند: pressure, height, temperature, dewpoint, wdir, wspd (یا u, v). دما و شبنم °C، فشار hPa، ارتفاع m.", "Formats: Wyoming text (PRES HGHT TEMP DWPT … DRCT SKNT) or CSV with header: pressure, height, temperature, dewpoint, wdir, wspd (or u, v). Temperature/dew point °C, pressure hPa, height m.")) + "</p></div>" +
      '<div id="labOm" hidden><div class="labBtns">' + pr + '</div><div class="labBtns"><label>' + esc(t("عرض", "Lat")) + ' <input id="labLat" type="number" step="0.01" value="29.13" dir="ltr"></label><label>' + esc(t("طول", "Lon")) + ' <input id="labLon" type="number" step="0.01" value="54.04" dir="ltr"></label><button type="button" id="labOmGo" class="labGo">' + esc(t("دریافت پروفایل", "Fetch profile")) + "</button></div>" +
      '<div class="labBtns" id="labOmRow" hidden><label>' + esc(t("زمان معتبر", "Valid time")) + ' <select id="labOmT"></select></label></div>' +
      '<p class="labSub">' + esc(t("دادهٔ مدل از ", "Model data from ")) + '<a href="https://open-meteo.com/" target="_blank" rel="noopener">Open-Meteo.com</a> (CC BY 4.0). ' + esc(t("خروجی مدل است نه رصد؛ ترازهای زیر سطح زمین حذف می‌شوند و باد سطح = ۱۰ متری.", "Model output, not observations; levels below ground are dropped; the surface wind is the 10 m wind.")) + "</p></div>" +
      '<div id="labMsg" class="labMsg" hidden></div></section>' +
      '<section id="labOut" hidden><div id="labSum" class="labSum"></div><div class="labTop"><div class="labPanel"><div class="labSeg2">' +
      ["SB", "ML", "MU"].map(k => '<button type="button" data-par="' + k + '">' + k + "</button>").join("") + '<span class="labSub">' + esc(t("نوع پارسل: سطحی / مخلوط ۱۰۰ hPa / ناپایدارترین ۳۰۰ hPa", "Parcel: surface / mixed 100 hPa / most unstable 300 hPa")) + '</span></div><div id="labSk"></div><div id="labInfo" class="labInfo">' + esc(t("برای خواندن مقادیر، روی نمودار بزنید یا نشانگر را حرکت دهید.", "Tap or hover on the chart to read values.")) + '</div>' +
      '<div class="labBtns"><button type="button" data-dl="svg">SVG</button><button type="button" data-dl="png">PNG</button><span class="labSub">' + esc(t("خطوط: دما قرمز، شبنم سبز، پارسل خط‌چین؛ سایهٔ قرمز = CAPE و آبی = CIN (روی دمای واقعی رسم می‌شود؛ مقدار عددی بر دمای مجازی است).", "Red = temperature, green = dew point, dashed = parcel; red shading = CAPE, blue = CIN (drawn on actual temperature; the numbers use virtual temperature).")) + "</span></div></div>" +
      '<div class="labPanel labHodoP"><h4>' + esc(t("هودوگراف", "Hodograph")) + '</h4><div id="labHodo"></div><div class="labSub">' + esc(t("رنگ: ۰–۳ km قرمز، ۳–۶ سبز، ۶–۹ نارنجی، بالاتر بنفش · RM/LM حرکت توفان راست/چپ‌گرد Bunkers", "Colour: 0–3 km red, 3–6 green, 6–9 orange, above purple · RM/LM = Bunkers right/left mover")) + "</div></div></div>" +
      '<div id="labCards"></div></section></div>';
  }
  function bind(){
    root.querySelectorAll("[data-tab]").forEach(b => b.onclick = () => { S.tab = b.dataset.tab; root.querySelector("#labPaste").hidden = S.tab !== "paste"; root.querySelector("#labOm").hidden = S.tab !== "om"; root.querySelectorAll("[data-tab]").forEach(x => x.classList.toggle("on", x.dataset.tab === S.tab)); });
    root.querySelector("[data-tab=" + S.tab + "]").click();
    root.querySelector("#labRun").onclick = runText;
    root.querySelector("#labSample").onclick = () => { root.querySelector("#labTxt").value = M.SAMPLE; root.querySelector("#labWu").value = "kt"; runText(); };
    root.querySelector("#labFile").onchange = ev => { const f = ev.target.files[0]; if(!f) return; if(f.size > 2e6){ msg(t("فایل بزرگ است (بیش از ۲ مگابایت).", "File too large (> 2 MB)."), true); return; } const rd = new FileReader(); rd.onload = () => { root.querySelector("#labTxt").value = String(rd.result); runText(); }; rd.readAsText(f); ev.target.value = ""; };
    root.querySelectorAll("[data-pre]").forEach(b => b.onclick = () => { const p = PRESETS[+b.dataset.pre]; root.querySelector("#labLat").value = p[2]; root.querySelector("#labLon").value = p[3]; omFetch(); });
    root.querySelector("#labOmGo").onclick = omFetch; root.querySelector("#labOmT").onchange = omRun;
    root.querySelectorAll("[data-par]").forEach(b => b.onclick = () => { S.parcel = b.dataset.par; if(S.raw) { const keep = S.src; if(S.om && S.src.indexOf("Open-Meteo") === 0) omRun(); else analyze(S.raw, keep); } });
    root.querySelectorAll("[data-dl]").forEach(b => b.onclick = () => { const sv = root.querySelector("#labSk svg"); if(sv) M.skewt.download(sv, "skewt-" + S.parcel, b.dataset.dl === "png"); });
  }
  window.labInit = function(host){
    if(!host) return; if(root === host && host.firstChild) return;
    root = host; const keepTxt = ""; host.innerHTML = shell(); bind(); render();
    if(!host._lg){ host._lg = true; document.addEventListener("langchange", () => { if(!host.hidden && root === host){ const txt = host.querySelector("#labTxt").value, tab = S.tab; host.innerHTML = shell(); S.tab = tab; bind(); host.querySelector("#labTxt").value = txt; render(); } }); }
  };
})();
