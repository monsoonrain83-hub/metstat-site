/* ===== صفحهٔ «تحلیل و هشدار جوی» (مرحلهٔ ۲-ج) =====
   چهار بخش در یک صفحه و با نوار زبانه:
   ۱) ترکیب خودکار (همرفت و هشدار از نقشه‌های آنلاین)   ۲) تحلیل چندمدلی و ابزارهای نقشه
   ۳) هشدار جوی (از نقشه‌های خود کاربر)                  ۴) همرفت (از نقشه‌های خود کاربر)
   دو صفحهٔ قدیمی هشدار (wnApp) و همرفت (cvApp) همان‌جا درون این صفحه قرار می‌گیرند و منطقشان دست‌نخورده است؛
   آدرس‌های /alertmaps و /convection و #/alertmaps و #/convection هم همین صفحه را با زبانهٔ مربوط باز می‌کنند. */
const AN={tab:store.get("an.tab","auto"), msg:""};
(function(){
  const app=$("anApp"), auto=$("anAuto"), cvA=$("cvApp"), wnA=$("wnApp"), labA=$("labApp"); if(!app||!auto||!cvA||!wnA) return;
  app.append(cvA,wnA);                                   // دو صفحهٔ قدیمی داخل صفحهٔ جدید
  const TABS=[["auto","ترکیب خودکار","Auto composite"],["multi","تحلیل چندمدلی","Multi-model analysis"],["wn","هشدار جوی","Weather warnings"],["cv","همرفت","Convection"],["lab","آزمایشگاه محاسبات","Computation lab"]];
  if(!["auto","multi"].includes(AN.tab)) AN.tab="auto";
  const bar=$("anTabs");
  TABS.forEach(([k,fa,en])=>{ const b=document.createElement("button"); b.type="button"; b.className="anTab"; b.dataset.k=k; b.setAttribute("role","tab"); b.dataset.fa=fa; b.dataset.en=en; b.textContent=fa;
    b.onclick=()=>{ if(k==="wn") openWN(); else if(k==="cv") openCV(); else if(k==="lab") openLab(); else openAN(k); window.scrollTo(0,0); }; bar.append(b); });
  const curTab=()=>{ const m=store.get("mode",""); return AN.lab?"lab":(m==="wn"||m==="cv"?m:AN.tab); };
  function paint(){
    const en=typeof LANG!=="undefined"&&LANG==="en", t=curTab();
    bar.querySelectorAll(".anTab").forEach(b=>{ const on=b.dataset.k===t; b.classList.toggle("on",on); b.setAttribute("aria-selected",on?"true":"false"); const v=en?b.dataset.en:b.dataset.fa; if(b.textContent!==v) b.textContent=v; });
  }
  function syncEmpty(){
    const e=$("anEmpty"); if(!e) return; const has=!!(ON.man&&ON.man.items&&ON.man.items.length), oc=$("onComp");
    $("anOutAuto").hidden=AN.tab!=="auto"; if($("anSecAuto")) $("anSecAuto").hidden=AN.tab!=="auto"; if($("anSecMulti")) $("anSecMulti").hidden=AN.tab!=="multi";
    let T,D;
    if(!has){ T="تحلیل و هشدار جوی"; D=AN.msg||"فهرست نقشه‌های روی هاست در دسترس نیست."; }
    else if(AN.tab==="auto"){ T="نقشه‌های ترکیبی خودکار"; D="محصول (همرفت یا هشدار)، مدل و زمان معتبر را از ستون کناری انتخاب کنید؛ نقشه با هر تغییر منو بی‌درنگ ساخته و همین‌جا نشان داده می‌شود."; }
    else { T="تحلیل چندمدلی و ابزارهای نقشه"; D="عملیات را انتخاب و اجرا کنید: میانگین، بیشینه، کمینه، احتمال، جمع و تفریق نقشه‌ها در صفحهٔ تحلیل weather.us باز می‌شود؛ همرفت و هشدار هم در زبانه‌های همین صفحه‌اند."; }
    $("anEmptyT").textContent=T; $("anEmptyD").textContent=D;
    e.hidden = AN.tab==="auto" && has && oc && !oc.hidden;
  }
  function setTab(t){ if(t!=="auto"&&t!=="multi") t="auto"; AN.tab=t; store.set("an.tab",t); paint(); syncEmpty(); }
  new MutationObserver(()=>{ paint(); syncEmpty(); }).observe($("onComp"),{attributes:true,attributeFilter:["hidden"]});
  for(const e of [cvA,wnA,app]) new MutationObserver(()=>setTimeout(paint,20)).observe(e,{attributes:true,attributeFilter:["hidden"]});
  document.addEventListener("langchange",paint);

  /* ---- ساخت منوهای ستون کناری (از فهرست نقشه‌های هاست) ---- */
  window.anBuildUI=function(msg){
    const a=$("anAside"); if(!a) return; AN.msg=msg||""; const M=ON.man;
    const regs=M&&M.regions?Object.entries(M.regions).filter(([k])=>k!=="me"):[["iran",{fa:"ایران"}]];
    a.innerHTML=`<div id="anSecRange"><section class="card"><h3>بازهٔ زمانی</h3>
      <label title="فقط نقشه‌های هاست که زمان اعتبارشان از این زمان به بعد است">زمان شروع<select id="anT0"></select></label>
      <label title="فقط نقشه‌های هاست که زمان اعتبارشان تا این زمان است">زمان پایان<select id="anT1"></select></label>
      <button class="btn sm" type="button" id="anTClr">پاک کردن بازه</button>
      <p class="hint" id="anTHint" style="margin:6px 0 0"></p></section></div>
      <div id="anSecManual"><section class="card"><h3>نقشه‌های دستی</h3>
      <label class="drop" id="anMDrop"><input type="file" id="anMFiles" accept="image/png,image/*" multiple><b>افزودن نقشه به‌صورت دستی</b><span>کنار نقشه‌های خودکار هاست ترکیب می‌شود؛ نوع پدیده/شاخص و زمان از خود نقشه یا نام فایل تشخیص داده می‌شود</span></label>
      <div class="models" id="anMList"></div>
      <button class="btn sm" type="button" id="anMClr" hidden>🗑 حذف نقشه‌های دستی</button>
      <p class="hint" id="anMHint" style="margin:6px 0 0"></p></section></div>
      <div id="anSecMulti"><section class="card"><h3>تحلیل چندمدلی و ابزارهای نقشه</h3>
      <label>منطقهٔ نقشه‌های تحلیلی <select id="onReg">${regs.map(([k,v])=>`<option value="${k}">${v.fa}</option>`).join("")}</select></label>
      <label>عملیات <select id="onOp"></select></label>
      <div id="onOpBox"></div>
      <button class="btn main" type="button" id="onRun">اجرا و ارسال به صفحهٔ تحلیل</button>
      <p class="hint">میانگین، بیشینه، کمینه، احتمال، جمع و تفریق نقشه‌ها: نقشه‌های انتخاب‌شده مستقیم به صفحهٔ تحلیل می‌روند و همهٔ گزینه‌های آن صفحه (مرزبندی، نوار رنگ، خروجی، گزارش متنی، راهنما و…) در دسترس است. پتانسیل همرفت و نقشهٔ هشدار هم با همین منو به زبانهٔ «همرفت» و «هشدار جوی» همین صفحه می‌روند.</p></section></div>
      <div id="anSecAuto">${nvCompHTML()}</div>
      <section class="card"><button class="btn sm" type="button" id="anReload">↻ به‌روزرسانی فهرست نقشه‌ها</button></section>`;
    if(M&&M.regions){ const r=store.get("on.reg",""); if(M.regions[r]&&r!=="me") $("onReg").value=r; }
    $("onReg").onchange=()=>{ store.set("on.reg",$("onReg").value); onFillOps(); ncFillM(false); };
    $("anReload").onclick=async()=>{ onStatus("خواندن فهرست نقشه‌ها…",0.2); const m=await onLoadManifest(); onStatus("",1); onBuildUI(m); };
    $("onOp").onchange=()=>{ store.set("on.op",$("onOp").value); onOpBox(); };
    $("onRun").onclick=()=>onRunOp().catch(e=>{ console.error(e); onStatus("⚠ "+e.message,0); });
    onFillOps(); try{ ncInit(); }catch(e){ console.warn(e); }
    for(const id of ["anT0","anT1"]) $(id).onchange=()=>{ const x=$("anT0").value, y=$("anT1").value; anRangeSet(x===""?null:+x, y===""?null:+y, "an"); anRangeApply(); };
    $("anTClr").onclick=()=>{ anRangeSet(null,null,"an"); anRangeApply(); };
    $("anMFiles").onchange=()=>{ anManualAdd($("anMFiles").files); $("anMFiles").value=""; };
    { const el=$("anMDrop"); el.addEventListener("dragover",e=>{ e.preventDefault(); el.classList.add("over"); }); el.addEventListener("dragleave",()=>el.classList.remove("over"));
      el.addEventListener("drop",e=>{ e.preventDefault(); el.classList.remove("over"); anManualAdd(e.dataTransfer.files); }); }
    $("anMClr").onclick=()=>{ ANM.list.length=0; anManualDraw(); anManualChanged(); };
    anManualDraw();
    anRangeRefresh();
    syncEmpty();
  };
  window.anRefresh=function(){ if(app.hidden||!$("onOp")) return; try{ onFillOps(); ncFillM(false); }catch(e){} anRangeRefresh(); syncEmpty(); };

  /* ---- باز کردن صفحه ---- */
  const ALL=["landing","app","dsApp","cvApp","ltApp","wnApp","cqcApp","caApp","onApp","ciApp","saApp"];
  window.openAN=async function(tab){
    tab=tab||AN.tab||"auto"; if(tab==="wn") return openWN(); if(tab==="cv") return openCV();
    if(!$("onApp").hidden){ try{ nvLeave(); }catch(e){} }
    for(const id of ALL) if($(id)) $(id).hidden=true;
    AN.lab=false; if(labA) labA.hidden=true; app.hidden=false; auto.hidden=false; setTab(tab);
    $("srcName").textContent=PAGE_NAME.an; $("srcBtn").hidden=true; store.set("mode","an"); window.scrollTo(0,0); paint();
    if(!AN.loaded){ AN.loaded=true; onStatus("خواندن فهرست نقشه‌های روی هاست…",0.2); const msg=await onLoadManifest(); onStatus("",1); anBuildUI(msg); }
    else if(!$("onOp")) anBuildUI(AN.msg);
  };
  /* آزمایشگاه محاسبات (زبانهٔ پنجم): صفحهٔ مستقل درون همین قاب؛ منطق در met/met_ui.js */
  window.openLab=function(){
    if(!labA) return; if(!$("onApp").hidden){ try{ nvLeave(); }catch(e){} }
    for(const id of ALL) if($(id)) $(id).hidden=true;
    app.hidden=false; auto.hidden=true; AN.lab=true; labA.hidden=false; try{ labInit(labA); }catch(e){ labA.textContent="lab init failed: "+e.message; }
    $("srcName").textContent=PAGE_NAME.an; $("srcBtn").hidden=true; store.set("mode","an"); window.scrollTo(0,0); paint();
  };
  /* همرفت و هشدار: همان صفحه‌های قدیمی، اما درون صفحهٔ جدید و با نوار زبانه */
  for(const fn of ["openCV","openWN"]){ const f=window[fn]; if(typeof f!=="function") continue;
    window[fn]=function(...a){ AN.lab=false; if(labA) labA.hidden=true; auto.hidden=true; app.hidden=false; for(const id of ["onApp","ciApp","saApp"]) if($(id)) $(id).hidden=true;
      const r=f.apply(this,a); paint(); try{ anEnsureMan(); anRangeRefresh(); }catch(e){} return r; }; }
  /* هر صفحهٔ دیگری که باز شود، صفحهٔ جدید پنهان می‌شود (نتیجهٔ ترکیب خودکار پاک می‌شود) */
  for(const fn of ["switchMode","showLanding","openCQC","openDS","openLT","openCA","openON","openCI","openSA"]){ const f=window[fn]; if(typeof f!=="function") continue;
    window[fn]=function(...a){ AN.lab=false; if(labA) labA.hidden=true; if(!app.hidden){ if(!auto.hidden){ try{ nvCompClear(); }catch(e){} } app.hidden=true; auto.hidden=true; } return f.apply(this,a); }; }
  /* راهنما */
  if(typeof HELP!=="undefined"&&!HELP.an){
    const S=[["این صفحه چیست؟","چهار ابزار تحلیل در یک صفحه جمع شده‌اند: ترکیب خودکار، تحلیل چندمدلی، هشدار جوی و همرفت. بین آن‌ها با نوار زبانهٔ بالای صفحه جابه‌جا شوید."],
      ["ترکیب خودکار","از نقشه‌های آنلاین مدل‌ها، همرفت (احتمال و شدت توفان تندری) یا هشدار رنگی می‌سازد: محصول، مدل و زمان معتبر را انتخاب کنید؛ با هر تغییر، نقشه بی‌درنگ ساخته می‌شود."],
      ["تحلیل چندمدلی","میانگین، بیشینه، کمینه و احتمال بارش و دما از چند مدل، جمع و تفریق نقشه‌ها؛ نتیجه در صفحهٔ تحلیل weather.us باز می‌شود."],
      ["هشدار جوی و همرفت","همان ابزارهای قبلی‌اند: نقشه‌های خودتان را بیندازید یا از منوی «تحلیل چندمدلی» نقشه‌های آنلاین را به آن‌ها بفرستید."]];
    HELP.an={fa:{t:"راهنما: تحلیل و هشدار جوی",s:S},en:{t:"Help: Analysis and weather warnings",s:[["What is this page?","Auto composite, multi-model analysis, weather warnings and convection are combined in one page; switch with the tabs at the top."],["Auto composite","Builds convection or colour-coded warning maps from the online model maps: choose product, model and valid time; the map is built as soon as a menu changes."],["Multi-model analysis","Mean, max, min and probability of precipitation and temperature from several models, plus sum and difference of maps; the result opens in the weather.us analysis page."],["Warnings and convection","The previous tools: drop your own maps, or send online maps to them from the multi-model menu."]]}};
  }
  const hm=window.helpMode; if(typeof hm==="function") window.helpMode=function(){ return (!app.hidden&&!auto.hidden&&HELP.an)?"an":hm(); };
  paint();
})();

/* ===== بازهٔ زمانی مشترک چهار زبانهٔ «تحلیل و هشدار» =====
   یک وضعیت برای هر چهار زبانه (ANR، به میلی‌ثانیهٔ UTC). گزینه‌های هر زبانه = زمان نقشه‌های واردشده در آن زبانه + زمان‌های نقشه‌های هاست
   (برای همین بدون بارگذاری نقشه هم فعال است). ترکیب خودکار و تحلیل چندمدلی نقشه‌های هاست داخل بازه را می‌گیرند؛
   هشدار جوی و همرفت نقشه‌های واردشده (دستی یا از هاست) داخل بازه را ترکیب می‌کنند. */
const ANR={t0:null,t1:null};
const ANR_ACC=/^(p24|pacc|snow24|snowacc)$/;
const anRange=()=>({t0:ANR.t0, t1:ANR.t1});
const anActive=()=>ANR.t0!==null||ANR.t1!==null;
const anInR=v=>{ if(!anActive()) return true; const t=+onDate(v); return (ANR.t0===null||t>=ANR.t0)&&(ANR.t1===null||t<=ANR.t1); };
const anCurTab=()=>{ const m=store.get("mode",""); return m==="wn"||m==="cv"?m:(AN.tab||"auto"); };
async function anEnsureMan(){ if(ON.man&&ON.man.items) return; try{ AN.msg=await onLoadManifest(); }catch(e){} anRangeRefresh(); }
function anHostTimes(tab){
  const items=(ON.man&&ON.man.items)||[]; let ps=null, model=null, noacc=false, reg="iran";
  if(tab==="cv"){ ps=ON_OPS.find(o=>o.id==="conv").ps; noacc=true; }
  else if(tab==="wn"){ ps=ON_OPS.find(o=>o.id==="warn").ps; noacc=true; }
  else if(tab==="auto"){ const op=$("ncP")&&ncOp(); if(op){ ps=op.ps; noacc=true; model=($("ncM")&&$("ncM").value)||null; } }
  else { const op=$("onOp")&&ON_OPS.find(o=>o.id===$("onOp").value); reg=$("onReg")?$("onReg").value:"iran"; if(op){ if(op.ps){ ps=op.ps; noacc=true; } else if(op.p) ps=[op.p]; } }
  const set=new Set();
  for(const i of items){ if(i.r!==reg) continue; if(ps&&!ps.includes(i.p)) continue; if(noacc&&ANR_ACC.test(i.p)) continue; if(model&&i.m!==model) continue; const t=+onDate(i.v); if(isFinite(t)) set.add(t); }
  return [...set].sort((a,b)=>a-b);
}
function anMapTimes(maps){ const ts=[], offs=new Map();
  for(const m of maps||[]){ if(m.bad||m.role==="cmp") continue; const t=m.times&&m.times.end?+m.times.end:null; if(t!==null&&!offs.has(t)){ ts.push(t); offs.set(t,m.times.offset||0); } }
  return {ts, offs}; }
function anFillSel(el, first, ts, offs, cur){
  el.replaceChildren(); const o0=document.createElement("option"); o0.value=""; o0.textContent=first; el.append(o0);
  const all=[...new Set([...ts, ...(cur!==null?[cur]:[])])].sort((a,b)=>a-b);
  for(const t of all){ const off=offs&&offs.has(t)?offs.get(t):210, d=wnDayPart(t,off,false), o=document.createElement("option"); o.value=String(t); o.textContent=(d?d+" ":"")+persianDT(t,off)+tzSuffix(off); el.append(o); }
  el.value=cur===null?"":String(cur);
}
function anRangeRefresh(o){ o=o||{};
  for(const [i0,i1,ih,tab] of [["wnT0","wnT1","wnTHint","wn"],["cvT0","cvT1","cvTHint","cv"],["anT0","anT1","anTHint","an"]]){
    const a=$(i0), b=$(i1); if(!a||!b) continue;
    const own = tab==="wn" ? (o.wnTs?{ts:o.wnTs,offs:o.wnOffs}:anMapTimes(wn.maps)) : tab==="cv" ? anMapTimes(cv.maps) : {ts:[],offs:new Map()};
    const host=anHostTimes(tab==="an"?(AN.tab==="multi"?"multi":"auto"):tab), ts=[...new Set([...own.ts, ...host])];
    anFillSel(a,"از اولین زمان نقشه‌ها",ts,own.offs,ANR.t0); anFillSel(b,"تا آخرین زمان نقشه‌ها",ts,own.offs,ANR.t1);
    a.disabled=b.disabled=ts.length<1;
    const h=$(ih); if(!h) continue;
    const lo=ANR.t0!==null?ANR.t0:-Infinity, hi=ANR.t1!==null?ANR.t1:Infinity, inH=host.filter(t=>t>=lo&&t<=hi).length, inO=own.ts.filter(t=>t>=lo&&t<=hi).length;
    h.textContent = !ts.length ? "زمانی پیدا نشد: فهرست نقشه‌های هاست در دسترس نیست و نقشه‌ای هم وارد نشده است."
      : tab==="an" ? (anActive()?`${FA(inH)} از ${FA(host.length)} زمان نقشه‌های هاست در بازه است؛ نقشه‌ها از همین زمان‌ها گرفته می‌شوند. بازه به زبانه‌های هشدار جوی و همرفت هم اعمال می‌شود.`:`${FA(host.length)} زمان در نقشه‌های هاست هست. بدون بازه، همان زمان معتبر انتخاب‌شده در منو استفاده می‌شود.`)
      : `${FA(own.ts.length)} زمان در نقشه‌های واردشده و ${FA(host.length)} زمان در نقشه‌های هاست؛ ${anActive()?`بازه: ${FA(inO)} زمان از نقشه‌های واردشده در ترکیب می‌آید.`:"بدون بازه همهٔ نقشه‌های واردشده ترکیب می‌شوند."}`;
  }
}
function anRangeSet(t0,t1,from){
  ANR.t0=t0===null||t0===undefined||t0===""||!isFinite(+t0)?null:+t0; ANR.t1=t1===null||t1===undefined||t1===""||!isFinite(+t1)?null:+t1;
  if(ANR.t0!==null&&ANR.t1!==null&&ANR.t0>ANR.t1){ const x=ANR.t0; ANR.t0=ANR.t1; ANR.t1=x; }
  try{ wn.t0=ANR.t0; wn.t1=ANR.t1; }catch(e){}
  anRangeRefresh();
}
// پس از تغییر بازه در زبانهٔ ترکیب خودکار یا تحلیل چندمدلی: ساخت دوبارهٔ نقشه / فهرست‌های زمان
function anRangeApply(){
  try{ if(AN.tab==="auto"&&$("ncP")) ncFillInfo(true); else if(AN.tab==="multi"&&$("onOp")) onOpBox(); }catch(e){ console.warn(e); }
}

/* ===== نقشه‌های دستی در زبانه‌های «ترکیب خودکار» و «تحلیل چندمدلی» =====
   کاربر می‌تواند نقشهٔ خودش را کنار نقشه‌های خودکار هاست اضافه کند؛ هر دو یک‌جا به موتور همرفت/هشدار یا صفحهٔ weather.us می‌روند.
   نقش هر نقشه: «شاخص/ورودی» (پیش‌فرض) یا «بارش مقایسه» (فقط برای همرفت). نوع و زمان را خود موتور از نقشه تشخیص می‌دهد
   و بازهٔ زمانی مشترک هم روی آن‌ها اعمال می‌شود. */
const ANM={list:[]};      // [{file, role:"idx"|"cmp"}]
const anManualFiles=role=>ANM.list.filter(x=>role?x.role===role:true).map(x=>x.file);
function anManualAdd(files){ for(const f of files){ if(!/^image\//.test(f.type||"image/png")) continue; if(ANM.list.some(x=>x.file.name===f.name&&x.file.size===f.size)) continue; ANM.list.push({file:f, role:"idx"}); } anManualDraw(); anManualChanged(); }
function anManualDraw(){ const box=$("anMList"); if(!box) return; box.innerHTML="";
  ANM.list.forEach((x,k)=>{ const row=document.createElement("div"); row.className="cvrow"; const l1=document.createElement("div"); l1.className="l1";
    const nm=document.createElement("b"); nm.textContent=x.file.name; nm.title=x.file.name;
    const sel=document.createElement("select"); sel.setAttribute("aria-label","نقش نقشه"); sel.innerHTML='<option value="idx">شاخص / ورودی</option><option value="cmp">بارش مقایسه (فقط همرفت)</option>'; sel.value=x.role; sel.onchange=()=>{ x.role=sel.value; anManualChanged(); };
    const del=document.createElement("button"); del.className="del"; del.type="button"; del.textContent="×"; del.setAttribute("aria-label","حذف "+x.file.name); del.onclick=()=>{ ANM.list.splice(k,1); anManualDraw(); anManualChanged(); };
    l1.append(nm,sel,del); row.append(l1); box.append(row); });
  const c=$("anMClr"); if(c) c.hidden=!ANM.list.length;
  const h=$("anMHint"); if(h) h.textContent=ANM.list.length?`${FA(ANM.list.length)} نقشهٔ دستی کنار نقشه‌های خودکار هاست ترکیب می‌شود.`:"اختیاری. بدون نقشهٔ دستی فقط نقشه‌های خودکار هاست استفاده می‌شوند.";
}
function anManualChanged(){ anManualDraw_hint(); try{ if(AN.tab==="auto"&&$("ncP")) ncFillInfo(true); }catch(e){ console.warn(e); } }
function anManualDraw_hint(){ const h=$("anMHint"); if(h) h.textContent=ANM.list.length?`${FA(ANM.list.length)} نقشهٔ دستی کنار نقشه‌های خودکار هاست ترکیب می‌شود.`:"اختیاری. بدون نقشهٔ دستی فقط نقشه‌های خودکار هاست استفاده می‌شوند."; const c=$("anMClr"); if(c) c.hidden=!ANM.list.length; }

