/* ===== شاخص‌های ناپایداری (فاز ۱) =====
   مرجع: MetPy thermo/indices. هر تابع {v, why} برمی‌گرداند؛ مقدار مفقود هرگز صفر نمی‌شود.
   سطوح ۸۵۰/۷۰۰/۵۰۰ hPa باید در بازهٔ پروفایل باشند (درون‌یابی خطی در p، مثل MetPy)؛ در ایران مرتفع سطح ۸۵۰ ممکن است زیر زمین باشد ⇒ why="level_below_ground_850". */
(function(){
  "use strict";
  const M = globalThis.MET, C = M.C, T = M.thermo, PF = M.profile, I = {};
  function at(prof, lev, key){ return PF.interpLin(lev, prof.p, prof[key]); }
  function need(prof, levels){ for(const l of levels){ if(!(l <= prof.p[0] + 1e-9)) return "level_below_ground_" + l; if(!(l >= prof.p[prof.p.length - 1] - 1e-9)) return "level_above_profile_top_" + l; } return null; }
  I.kIndex = function(prof){ const w = need(prof, [850, 700, 500]); if(w) return M.nil(w);
    const t850 = at(prof, 850, "Tk"), t700 = at(prof, 700, "Tk"), t500 = at(prof, 500, "Tk"), d850 = at(prof, 850, "Tdk"), d700 = at(prof, 700, "Tdk");
    return M.ok((t850 - t500) + (d850 - C.zeroC) - (t700 - d700)); };      // Td850 مطلق (°C)؛ سایر جمله‌ها اختلاف
  I.verticalTotals = function(prof){ const w = need(prof, [850, 500]); if(w) return M.nil(w); return M.ok(at(prof, 850, "Tk") - at(prof, 500, "Tk")); };
  I.crossTotals = function(prof){ const w = need(prof, [850, 500]); if(w) return M.nil(w); return M.ok(at(prof, 850, "Tdk") - at(prof, 500, "Tk")); };
  I.totalTotals = function(prof){ const w = need(prof, [850, 500]); if(w) return M.nil(w); return M.ok((at(prof, 850, "Tk") - at(prof, 500, "Tk")) + (at(prof, 850, "Tdk") - at(prof, 500, "Tk"))); };
  // شاخص بالابری LI = T500(محیط) − T500(پارسل سطحی)؛ بدون اصلاح دمای مجازی (مثل MetPy). منفی = ناپایدار
  I.liftedIndex = function(prof){ const w = need(prof, [500]); if(w) return M.nil(w);
    const tp = M.parcel.parcelProfile(prof.p, prof.Tk[0], prof.Tdk[0]); if(!tp) return M.nil("lcl_failed");
    return M.ok(PF.interpLin(500, prof.p, prof.Tk) - PF.interpLin(500, prof.p, tp)); };
  // شوالتر: پارسل از ۸۵۰ hPa تا ۵۰۰ (T500 − Tparcel)
  I.showalter = function(prof){ const w = need(prof, [850, 500]); if(w) return M.nil(w);
    const t850 = at(prof, 850, "Tk"), d850 = at(prof, 850, "Tdk"), t500 = at(prof, 500, "Tk");
    const tp = M.parcel.parcelProfile([850, 500], t850, d850); if(!tp) return M.nil("lcl_failed");
    return M.ok(t500 - tp[tp.length - 1]); };
  // آب قابل بارش (mm): −(1/(g ρw)) ∫ r dp ، r از Td اشباع؛ لایهٔ پیش‌فرض: کل پروفایل. لایهٔ ناقص ⇒ null
  I.pwat = function(prof, bottom, top){
    const pmax = prof.p[0], pmin = prof.p[prof.p.length - 1];
    bottom = bottom == null ? pmax : bottom; top = top == null ? pmin : top;
    if(bottom > pmax + 1e-9 || top < pmin - 1e-9 || top >= bottom) return M.nil("layer_outside_profile");
    const lay = PF.layer({p:prof.p, Tdk:prof.Tdk}, ["Tdk"], bottom, bottom - top, true); if(!lay) return M.nil("layer_outside_profile");
    const w = lay.p.map((q, i) => T.mixingRatio(T.es(lay.Tdk[i]), q));
    if(w.some(x => !isFinite(x))) return M.nil("nonfinite_mixing_ratio");
    return M.ok(-PF.trapz(w, lay.p) * 100 / (C.g * C.rhoL) * 1000, {unit:"mm"}); };  // hPa→Pa ×100 ؛ m→mm ×1000
  M.indices = I;
})();
