/* ===== پارسل، LCL/LFC/EL، CAPE/CIN =====
   مرجع: MetPy metpy.calc.thermo (parcel_profile, lfc, el, cape_cin, mixed_parcel, most_unstable_parcel) — منطق عیناً بازنویسی شده
   (شامل رفتار شناخته‌شدهٔ MetPy: LCL/LFC روی دمای مجازی سنجیده می‌شوند)؛ اختلاف عددی مجاز با MetPy: CAPE/CIN ≤ ۱٪ یا ۵ J/kg.
   قرارداد: CAPE ≥ 0، CIN ≤ 0 (J/kg)؛ انتگرال Rd∫(Tv_parcel−Tv_env) d ln p بر پایهٔ ذوزنقه؛ دمای مجازی برای محیط از Td محیط.
   محدودیت: پارسل بدون اختلاط (entrainment)، آدیاباتیک برگشت‌پذیر مرطوب؛ بدون فاز یخ؛ پروفایل باید تا ≥ ۱۰۰ hPa نباشد ولی هرچه بالاتر، EL دقیق‌تر. */
(function(){
  "use strict";
  const M = globalThis.MET, C = M.C, T = M.thermo, PF = M.profile, Q = {};
  const isclose = (a, b) => Math.abs(a - b) <= 1e-8 + 1e-5 * Math.abs(b);
  const lessOrClose = (a, b) => a < b || isclose(a, b), greaterOrClose = (a, b) => a > b || isclose(a, b);
  const sgn = x => x > 0 ? 1 : x < 0 ? -1 : 0;
  // جدا کردن ردیف‌های NaN هم‌زمان (مثل _remove_nans)
  function rmNaN(){ const arrs = Array.from(arguments), n = arrs[0].length, keep = [];
    for(let i = 0; i < n; i++) if(arrs.every(a => !Number.isNaN(a[i]))) keep.push(i);
    return arrs.map(a => keep.map(i => a[i])); }
  // نقاط تقاطع دو منحنی (MetPy find_intersections). x بر حسب p (log_x=true)
  function intersections(x, a, b, direction, logx){
    const xs = logx ? x.map(Math.log) : x.slice(), n = xs.length, X = [], Y = [], S = [];
    const d = a.map((v, i) => v - b[i]);
    for(let i = 0; i < n - 1; i++){
      if(sgn(d[i + 1]) - sgn(d[i]) === 0) continue;
      const dy0 = d[i], dy1 = d[i + 1], x0 = xs[i], x1 = xs[i + 1];
      const ix = (dy1 * x0 - dy0 * x1) / (dy1 - dy0), iy = ((ix - x0) / (x1 - x0)) * (a[i + 1] - a[i]) + a[i];
      X.push(logx ? Math.exp(ix) : ix); Y.push(iy); S.push(sgn(d[i + 1]));
    }
    const dup = X.map((v, i) => i === X.length - 1 ? true : X[i + 1] !== v);
    const ox = [], oy = [];
    for(let i = 0; i < X.length; i++){
      if(!dup[i]) continue;
      if(direction === "increasing" && !(S[i] > 0)) continue;
      if(direction === "decreasing" && !(S[i] < 0)) continue;
      ox.push(X[i]); oy.push(Y[i]);
    }
    return [ox, oy];
  }
  // پروفایل پارسل از ردیف اول: خروجی {pLower,pLcl,pUpper,tLower,tLcl,tUpper}. p نزولی، T0/Td0 (K) دمای پارسل در p[0]
  function parcelHelper(p, T0, Td0){
    const L = T.lcl(p[0], T0, Td0); if(!L) return null;
    const pl = L.p, lower = p.filter(q => q >= pl); lower.push(pl);
    const tl = lower.map(q => T.dryLapse(q, T0, p[0]));
    if(greaterOrClose(Math.min.apply(null, p), pl)) return {pLower:lower.slice(0, -1), pLcl:pl, pUpper:[], tLower:tl.slice(0, -1), tLcl:L.Tk, tUpper:[]};
    const up = p.filter(q => q < pl);
    const tu = T.moistLapse(up, tl[tl.length - 1], pl);
    return {pLower:lower.slice(0, -1), pLcl:pl, pUpper:up, tLower:tl.slice(0, -1), tLcl:L.Tk, tUpper:tu};
  }
  function insertLcl(p, y, pl){ const v = PF.interpLin(pl, p, y); let loc = 0; while(loc < p.length && p[loc] >= pl) loc++; const o = y.slice(); o.splice(loc, 0, v); return o; }
  // پروفایل پارسل با LCL: ورودی پروفایل پاک‌شده یا {p,Tk,Tdk} با پارسل از ردیف اول
  Q.parcelProfileWithLcl = function(prof){
    const h = parcelHelper(prof.p, prof.Tk[0], prof.Tdk[0]); if(!h) return null;
    const p = h.pLower.concat([h.pLcl], h.pUpper), tp = h.tLower.concat([h.tLcl], h.tUpper);
    return {p:p, Tk:insertLcl(prof.p, prof.Tk, h.pLcl), Tdk:insertLcl(prof.p, prof.Tdk, h.pLcl), Tp:tp, pLcl:h.pLcl, tLcl:h.tLcl};
  };
  Q.parcelProfile = function(p, T0, Td0){ const h = parcelHelper(p, T0, Td0); return h ? h.tLower.concat(h.tUpper) : null; };
  function capeCinCore(p, Tk, Tdk, Tp, whichLfc, whichEl){
    [p, Tk, Tdk, Tp] = rmNaN(p, Tk, Tdk, Tp);
    const L0 = T.lcl(p[0], Tk[0], Tdk[0]); if(!L0) return null;
    const w0 = T.satMixingRatio(p[0], Tdk[0]);
    const w = p.map((q, i) => q > L0.p ? w0 : T.satMixingRatio(q, Tp[i]));
    const Tenv = p.map((q, i) => T.virtualTFromDewpoint(q, Tk[i], Tdk[i]));
    const Tpar = Tp.map((t, i) => T.virtualT(t, w[i]));
    const lf = lfcCore(p, Tenv, Tdk, Tpar, whichLfc);
    if(lf === null) return {cape:0, cin:0, lfc:null, el:null, lcl:{p:L0.p, Tk:L0.Tk}, why:"no_lfc"};
    const lfcP = lf.p;
    const e = elCore(p, Tenv, Tdk, Tpar, whichEl);
    const elP = e === null ? p[p.length - 1] : e.p;
    let y = Tpar.map((t, i) => t - Tenv[i]), x = p.slice();
    const cr = intersections(x.slice(1), y.slice(1), y.slice(1).map(() => 0), "all", true);
    x = x.concat(cr[0]); y = y.concat(cr[1]);
    const ord = x.map((v, i) => i).sort((a, b) => x[a] - x[b]); x = ord.map(i => x[i]); y = ord.map(i => y[i]);
    const keep = x.map((v, i) => i === x.length - 1 ? true : (x[i + 1] - v) > 1e-6); x = x.filter((v, i) => keep[i]); y = y.filter((v, i) => keep[i]);
    let xs = [], ys = [];
    for(let i = 0; i < x.length; i++) if(lessOrClose(x[i], lfcP) && greaterOrClose(x[i], elP)){ xs.push(Math.log(x[i])); ys.push(y[i]); }
    const cape = C.Rd * PF.trapz(ys, xs);
    xs = []; ys = [];
    for(let i = 0; i < x.length; i++) if(greaterOrClose(x[i], lfcP)){ xs.push(Math.log(x[i])); ys.push(y[i]); }
    let cin = C.Rd * PF.trapz(ys, xs); if(cin > 0) cin = 0;
    return {cape:cape, cin:cin, lfc:lf, el:e, lcl:{p:L0.p, Tk:L0.Tk}, why:null};
  }
  function lfcCore(p, T_, Td, Tp, which){
    [p, T_, Td, Tp] = rmNaN(p, T_, Td, Tp);
    const Ld = Td[0];
    const inc = isclose(Tp[0], T_[0]) ? intersections(p.slice(1), Tp.slice(1), T_.slice(1), "increasing", true) : intersections(p, Tp, T_, "increasing", true);
    const L = T.lcl(p[0], Tp[0], Ld);
    let x = inc[0], y = inc[1];
    if(!L) return null;
    if(x.length === 0){
      let all = true; for(let i = 0; i < p.length; i++) if(p[i] < L.p && !lessOrClose(Tp[i], T_[i])) { all = false; break; }
      return all ? null : {p:L.p, Tk:L.Tk};
    }
    const idx = x.map(v => v < L.p);
    if(!idx.some(Boolean)){
      const el = intersections(p.slice(1), Tp.slice(1), T_.slice(1), "decreasing", true)[0];
      if(el.length && Math.min.apply(null, el) > L.p) return null;
      return {p:L.p, Tk:L.Tk};
    }
    return multiple(x, y, idx, which, p, T_, Td, Tp, "LFC");
  }
  function elCore(p, T_, Td, Tp, which){
    [p, T_, Td, Tp] = rmNaN(p, T_, Td, Tp);
    if(Tp[Tp.length - 1] > T_[T_.length - 1]) return null;
    const r = intersections(p.slice(1), Tp.slice(1), T_.slice(1), "decreasing", true), x = r[0], y = r[1];
    const L = T.lcl(p[0], T_[0], Td[0]); if(!L) return null;
    if(x.length > 0 && x[x.length - 1] < L.p){ const idx = x.map(v => v < L.p); return multiple(x, y, idx, which, p, T_, Td, Tp, "EL"); }
    return null;
  }
  function multiple(xs, ys, idx, which, p, T_, Td, Tp, kind){
    const pl = xs.filter((v, i) => idx[i]), tl = ys.filter((v, i) => idx[i]);
    which = which || "top";
    if(which === "bottom") return {p:pl[0], Tk:tl[0]};
    if(which === "top") return {p:pl[pl.length - 1], Tk:tl[tl.length - 1]};
    if(which === "wide"){
      let lfcL, elL;
      if(kind === "LFC"){ lfcL = pl; elL = intersections(p.slice(1), Tp.slice(1), T_.slice(1), "decreasing", true)[0]; }
      else { elL = pl; lfcL = intersections(p, Tp, T_, "increasing", true)[0]; }
      const n = Math.min(lfcL.length, elL.length); let best = -Infinity, bi = 0;
      for(let i = 0; i < n; i++){ const d = lfcL[i] - elL[i]; if(d > best){ best = d; bi = i; } }
      return {p:pl[bi], Tk:tl[bi]};
    }
    if(which === "most_cape"){
      const combos = [["top","top"],["top","bottom"],["bottom","top"],["bottom","bottom"]]; let best = -Infinity, pick = combos[0];
      for(const c of combos){ const r = capeCinCore(p, T_, Td, Tp, c[0], c[1]); /* همان ترتیب MetPy: lfc سپس el */ if(r && r.cape > best){ best = r.cape; pick = c; } }
      const side = kind === "LFC" ? pick[0] : pick[1];
      return side === "top" ? {p:pl[pl.length - 1], Tk:tl[tl.length - 1]} : {p:pl[0], Tk:tl[0]};
    }
    return null;
  }
  Q.capeCinFromProfile = capeCinCore;
  // LFC و EL بر دمای واقعی (نه مجازی) — همان فراخوانی عمومی MetPy lfc()/el() با پارسل سطحی؛ LFC/EL داخل CAPE بر پایهٔ Tv هستند
  Q.lfcEl = function(prof, which){ const w = Q.parcelProfileWithLcl(prof); if(!w) return M.nil("lcl_failed");
    const l = lfcCore(w.p, w.Tk, w.Tdk, w.Tp, (which && which.lfc) || "top"), e = elCore(w.p, w.Tk, w.Tdk, w.Tp, (which && which.el) || "top");
    return M.ok(l ? l.p : null, {lfc:l, el:e, why: l ? null : "no_lfc"}); };
  // پارسل سطحی (SB)
  Q.sbCapeCin = function(prof, opts){ opts = opts || {};
    const w = Q.parcelProfileWithLcl(prof); if(!w) return M.nil("lcl_failed");
    const r = capeCinCore(w.p, w.Tk, w.Tdk, w.Tp, opts.whichLfc || "bottom", opts.whichEl || "top");
    return r ? Object.assign(M.ok(r.cape), {cin:r.cin, lfc:r.lfc, el:r.el, lcl:r.lcl, note:r.why, parcel:"SB"}) : M.nil("cape_failed"); };
  // پارسل مخلوط لایهٔ پایین ۱۰۰ hPa (ML): θ و r میانگین انتگرال‌گیری‌شده در فشار
  Q.mixedParcel = function(prof, depth){ depth = depth || 100;
    const th = prof.p.map((q, i) => T.theta(q, prof.Tk[i])), r = prof.p.map((q, i) => T.satMixingRatio(q, prof.Tdk[i]));
    const lay = PF.layer({p:prof.p, th:th, r:r}, ["th", "r"], null, depth, true); if(!lay) return null;
    const dp = Math.abs(lay.p[0] - lay.p[lay.p.length - 1]);
    const mth = PF.trapz(lay.th, lay.p) / -dp, mr = PF.trapz(lay.r, lay.p) / -dp;
    const p0 = prof.p[0], tk = mth * T.exner(p0), e = T.vaporPressure(p0, mr);
    return {p:p0, Tk:tk, Tdk:T.dewpointFromE(e)}; };
  Q.mlCapeCin = function(prof, opts){ opts = opts || {}; const depth = opts.depth || 100;
    const mp = Q.mixedParcel(prof, depth); if(!mp) return M.nil("layer_outside_profile");
    const p0 = prof.p[0], sel = prof.p.map((q, i) => i).filter(i => prof.p[i] < p0 - depth);
    const pp = [mp.p].concat(sel.map(i => prof.p[i])), tt = [mp.Tk].concat(sel.map(i => prof.Tk[i])), dd = [mp.Tdk].concat(sel.map(i => prof.Tdk[i]));
    const w = Q.parcelProfileWithLcl({p:pp, Tk:tt, Tdk:dd}); if(!w) return M.nil("lcl_failed");
    const r = capeCinCore(w.p, w.Tk, w.Tdk, w.Tp, opts.whichLfc || "bottom", opts.whichEl || "top");
    return r ? Object.assign(M.ok(r.cape), {cin:r.cin, lfc:r.lfc, el:r.el, lcl:r.lcl, note:r.why, parcel:"ML"}) : M.nil("cape_failed"); };
  // پارسل ناپایدارترین (MU): بیشینهٔ θe در ۳۰۰ hPa پایینی
  Q.muCapeCin = function(prof, opts){ opts = opts || {}; const depth = opts.depth || 300;
    const lay = PF.layer(prof, ["Tk", "Tdk"], null, depth, false); if(!lay || !lay.p.length) return M.nil("layer_outside_profile");
    let bi = 0, best = -Infinity;
    for(let i = 0; i < lay.p.length; i++){ const te = T.thetaE(lay.p[i], lay.Tk[i], lay.Tdk[i]); if(te > best){ best = te; bi = i; } }
    const start = prof.p.indexOf(lay.p[bi]);
    const sub = {p:prof.p.slice(start), Tk:prof.Tk.slice(start), Tdk:prof.Tdk.slice(start)};
    const w = Q.parcelProfileWithLcl(sub); if(!w) return M.nil("lcl_failed");
    const r = capeCinCore(w.p, w.Tk, w.Tdk, w.Tp, opts.whichLfc || "bottom", opts.whichEl || "top");
    return r ? Object.assign(M.ok(r.cape), {cin:r.cin, lfc:r.lfc, el:r.el, lcl:r.lcl, note:r.why, parcel:"MU", startP:lay.p[bi]}) : M.nil("cape_failed"); };
  M.parcel = Q;
})();
