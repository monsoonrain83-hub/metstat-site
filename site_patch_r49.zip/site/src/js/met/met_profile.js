/* ===== پروفایل قائم: اعتبارسنجی، درون‌یابی، لایه =====
   قرارداد: p (hPa) نزولی از سطح زمین؛ T و Td برحسب °C در ورودی خام و K در پروفایل پاک‌شده (Tk, Tdk)؛ z (m) اختیاری.
   قاعدهٔ داده: ردیف‌های ناقص (NaN) حذف و در dropped گزارش می‌شوند — هرگز با صفر پر نمی‌شوند.
   Td > T به‌اندازهٔ بیش از ۱ °C ⇒ ردیف رد می‌شود؛ ≤۱ °C ⇒ Td=T (اشباع) و در issues ثبت می‌شود. فشار تکراری ⇒ خطا. */
(function(){
  "use strict";
  const M = globalThis.MET, C = M.C, P = {};
  const fin = x => typeof x === "number" && isFinite(x);
  P.clean = function(raw){
    const issues = [], n = raw && raw.p ? raw.p.length : 0, rows = [];
    if(!n) return {ok:false, why:"empty_profile", issues:["no_pressure_levels"]};
    let dropped = 0;
    for(let i = 0; i < n; i++){
      const p = raw.p[i], t = raw.T[i], td = raw.Td[i];
      if(!fin(p) || !fin(t) || !fin(td) || p <= 0){ dropped++; continue; }
      if(t < -100 || t > 70){ dropped++; issues.push("temperature_out_of_range@" + p); continue; }
      let tdd = td;
      if(td > t){ if(td - t > 1){ dropped++; issues.push("dewpoint_exceeds_temperature@" + p); continue; } tdd = t; issues.push("dewpoint_clipped_to_T@" + p); }
      rows.push({p:p, Tk:t + C.zeroC, Tdk:tdd + C.zeroC, z: raw.z && fin(raw.z[i]) ? raw.z[i] : null,
                 u: raw.u && fin(raw.u[i]) ? raw.u[i] : null, v: raw.v && fin(raw.v[i]) ? raw.v[i] : null});
    }
    rows.sort((a, b) => b.p - a.p);
    for(let i = 1; i < rows.length; i++) if(rows[i].p === rows[i - 1].p) return {ok:false, why:"duplicate_pressure", issues:issues.concat(["duplicate@" + rows[i].p])};
    if(rows.length < 3) return {ok:false, why:"too_few_valid_levels", issues:issues, dropped:dropped};
    return {ok:true, prof:{p:rows.map(r => r.p), Tk:rows.map(r => r.Tk), Tdk:rows.map(r => r.Tdk), z:rows.map(r => r.z), u:rows.map(r => r.u), v:rows.map(r => r.v)}, dropped:dropped, issues:issues};
  };
  // درون‌یابی خطی نسبت به p (مثل MetPy interpolate_1d): p نزولی؛ خارج بازه ⇒ NaN
  P.interpLin = function(x, p, y){
    if(!(x <= p[0] && x >= p[p.length - 1])) return NaN;
    for(let i = 0; i < p.length - 1; i++){
      if(x <= p[i] && x >= p[i + 1]){ if(p[i] === p[i + 1]) return y[i]; const f = (x - p[i]) / (p[i + 1] - p[i]); return y[i] + f * (y[i + 1] - y[i]); }
    }
    return NaN;
  };
  // درون‌یابی نسبت به ln p (مثل MetPy log_interpolate_1d)
  P.interpLog = function(x, p, y){
    if(!(x <= p[0] && x >= p[p.length - 1])) return NaN;
    const lx = Math.log(x);
    for(let i = 0; i < p.length - 1; i++){
      if(x <= p[i] && x >= p[i + 1]){ const a = Math.log(p[i]), b = Math.log(p[i + 1]); if(a === b) return y[i]; return y[i] + (lx - a) / (b - a) * (y[i + 1] - y[i]); }
    }
    return NaN;
  };
  // لایهٔ فشاری [bottom, bottom−depth]؛ interpolate=true مرزها را اضافه می‌کند (درون‌یابی لگاریتمی). خروجی نزولی.
  P.layer = function(prof, vars, bottom, depth, interpolate){
    const p = prof.p, pmax = p[0], pmin = p[p.length - 1];
    if(bottom == null) bottom = pmax;
    const top = bottom - depth, eps = 1e-6;
    if(bottom > pmax + eps || top < pmin - eps) return null;
    const idx = []; for(let i = 0; i < p.length; i++) if(p[i] <= bottom + eps && p[i] >= top - eps) idx.push(i);
    let ps = idx.map(i => p[i]);
    if(interpolate !== false){
      if(!ps.some(q => Math.abs(q - top) < eps)) ps.push(top);
      if(!ps.some(q => Math.abs(q - bottom) < eps)) ps.push(bottom);
      ps.sort((a, b) => b - a);
      const out = {p:ps}; for(const k of vars) out[k] = ps.map(q => P.interpLog(q, p, prof[k])); return out;
    }
    const out = {p:ps}; for(const k of vars) out[k] = idx.map(i => prof[k][i]); return out;
  };
  P.trapz = function(y, x){ let s = 0; for(let i = 0; i < x.length - 1; i++) s += (x[i + 1] - x[i]) * (y[i] + y[i + 1]) / 2; return s; };
  M.profile = P;
})();
