/* ===== پارامترهای ترکیبی توفان شدید (فاز ۴): لایهٔ مؤثر، SCP، STP ثابت و مؤثر، SHIP =====
   فرمول‌ها: Thompson et al. 2003/2004/2012 (SCP, STP)، Johnson & Sugden 2014 / SPC (SHIP)؛ تطبیق عددی با MetPy (supercell_composite, significant_tornado).
   پیاده‌سازی مستقل (کد کپی نشده). هر جزء جداگانه برمی‌گردد تا قابل بازرسی باشد. ورودی ناکافی ⇒ null با علت؛ «بدون لایهٔ مؤثر» = صفر معتبر با note.
   ساده‌سازی اعلام‌شده: حرکت توفان = Bunkers ۰–۶ km (نه نسخهٔ لایهٔ مؤثر)؛ ارتفاع LCL از ارتفاع محیط در فشار LCL درون‌یابی می‌شود. */
(function(){
  "use strict";
  const M = globalThis.MET, C = M.C, PF = M.profile, T = M.thermo, W = M.wind, V = {};
  const fin = x => typeof x === "number" && isFinite(x);
  const clip = (x, a, b) => Math.min(Math.max(x, a), b);
  /* ---- فرمول‌های خالص (قابل آزمون با MetPy) ---- */
  V.scpFormula = function(mucape, esrh, ebwd, mucin){
    const sh = ebwd > 20 ? 20 : (ebwd < 10 ? 0 : ebwd), t = {cape: mucape / 1000, srh: esrh / 50, shear: sh / 20};
    const base = t.cape * t.srh * t.shear;
    let cinT = 1; if(fin(mucin) && mucin < -40) cinT = -40 / mucin;          // جملهٔ CIN نسخهٔ SPC
    return {v: base, withCin: base * cinT, terms: t, cinTerm: cinT};
  };
  V.stpFixedFormula = function(sbcape, lclAgl, srh01, bwd6){
    const lt = lclAgl < 1000 ? 1 : (lclAgl > 2000 ? 0 : (2000 - lclAgl) / 1000), b = bwd6 > 30 ? 30 : (bwd6 < 12.5 ? 0 : bwd6), t = {cape: sbcape / 1500, lcl: lt, srh: srh01 / 150, shear: b / 20};
    return {v: t.cape * t.lcl * t.srh * t.shear, terms: t};
  };
  V.stpEffFormula = function(mlcape, esrh, ebwd, mllclAgl, mlcin){
    const b = ebwd < 12.5 ? 0 : (ebwd > 30 ? 1.5 : ebwd / 20), lt = mllclAgl < 1000 ? 1 : (mllclAgl > 2000 ? 0 : (2000 - mllclAgl) / 1000), ct = mlcin > -50 ? 1 : (mlcin < -200 ? 0 : (mlcin + 200) / 150), t = {cape: mlcape / 1500, srh: esrh / 150, shear: b, lcl: lt, cin: ct};
    return {v: Math.max(t.cape * t.srh * t.shear * t.lcl * t.cin, 0), terms: t};
  };
  V.shipFormula = function(mucape, mumr, lr75, t500c, shr06, frzH){
    const sh = clip(shr06, 7, 27), mr = clip(mumr, 11, 13.6), t5 = t500c > -5.5 ? -5.5 : t500c; let s = -(mucape * mr * lr75 * t5 * sh) / 42000000;
    const adj = {cape: mucape < 1300 ? mucape / 1300 : 1, lr: lr75 < 5.8 ? lr75 / 5.8 : 1, frz: (fin(frzH) && frzH < 2400) ? frzH / 2400 : 1};
    return {v: s * adj.cape * adj.lr * adj.frz, terms: {shear: sh, mr: mr, t500: t5}, adj: adj};
  };
  /* ---- لایهٔ مؤثر ورودی: CAPE ≥ 100 و CIN > −250 از پارسل هر تراز (مثل SHARPpy/SPC) ---- */
  V.effectiveLayer = function(prof, mu, opts){
    opts = opts || {}; const ec = opts.cape == null ? 100 : opts.cape, ei = opts.cin == null ? -250 : opts.cin;
    if(!mu || mu.v == null) return M.nil("mu_parcel_failed");
    if(!(mu.v >= ec && mu.cin > ei)) return M.ok(null, {none: true, why: "no_effective_inflow"});
    const ok = i => { const r = M.parcel.sbCapeCin({p: prof.p.slice(i), Tk: prof.Tk.slice(i), Tdk: prof.Tdk.slice(i)}); return r && r.v != null && r.v >= ec && r.cin > ei; };
    let ib = -1; for(let i = 0; i < prof.p.length - 1; i++) if(ok(i)){ ib = i; break; }
    if(ib < 0) return M.ok(null, {none: true, why: "no_effective_inflow"});
    let it = ib; for(let i = ib + 1; i < prof.p.length - 1; i++){ if(ok(i)) it = i; else break; }
    const zs = prof.z && fin(prof.z[0]) ? prof.z[0] : null, hz = i => (zs != null && fin(prof.z[i])) ? prof.z[i] - zs : null;
    return M.ok(prof.p[ib], {none: false, baseP: prof.p[ib], topP: prof.p[it], baseAgl: hz(ib), topAgl: hz(it), baseIdx: ib, topIdx: it});
  };
  const interpAt = (prof, p, key) => PF.interpLin(p, prof.p, prof[key]);
  const nilw = (w) => M.nil(w);
  V.compute = function(res){
    const prof = res.prof, P = res.parcels, I = res.items, out = {}, z0 = prof.z && fin(prof.z[0]) ? prof.z[0] : null, hAgl = p => { const z = M.lab.heightAtP(prof, p); return fin(z) && z0 != null ? z - z0 : null; };
    const sb = P.SB, ml = P.ML, mu = P.MU, bk = I.BUNKERS, hasWind = res.hasWind;
    const lclAgl = q => q && q.lcl ? hAgl(q.lcl.p) : null;
    /* لایهٔ مؤثر و کمیت‌های وابسته */
    const eil = V.effectiveLayer(prof, mu); out.EIL = eil;
    let elNote = null, elAgl = mu && mu.el ? hAgl(mu.el.p) : null;
    if(mu && mu.v != null && mu.v > 0 && !mu.el){ elAgl = hAgl(prof.p[prof.p.length - 1]); elNote = "el_at_profile_top"; }   // پارسل تا بالای پروفایل شناور می‌ماند: ارتفاع بالای پروفایل = کران پایین EL
    out.muEl = elAgl;
    let esrh = nilw("insufficient_wind_levels"), ebwd = nilw("insufficient_wind_levels");
    if(!eil || eil.v === null && eil.none){ esrh = M.ok(0, {note: "no_effective_inflow"}); ebwd = M.ok(0, {note: "no_effective_inflow"}); }
    else if(eil.v != null && hasWind && bk && bk.right){
      if(eil.baseAgl == null || eil.topAgl == null) { esrh = nilw("no_height_data"); ebwd = nilw("no_height_data"); }
      else {
        const depth = Math.max(eil.topAgl - eil.baseAgl, 1);
        esrh = W.srh(prof, depth, bk.right, eil.baseAgl);
        if(elAgl == null) ebwd = nilw(mu && mu.el === null ? "no_el" : "no_height_data");
        else { const d = 0.5 * elAgl - eil.baseAgl; ebwd = d > 0 ? W.bulkShear(prof, eil.baseAgl, d) : nilw("el_below_effective_base"); if(ebwd.v != null && elNote) ebwd.note = elNote; }
      }
    } else if(eil.v != null && !hasWind){ esrh = nilw("insufficient_wind_levels"); ebwd = nilw("insufficient_wind_levels"); }
    out.ESRH = esrh; out.EBWD = ebwd;
    /* SCP */
    if(mu && mu.v != null && esrh.v != null && ebwd.v != null){ const f = V.scpFormula(mu.v, esrh.v, ebwd.v, mu.cin); out.SCP = M.ok(f.v, {withCin: f.withCin, terms: f.terms, cinTerm: f.cinTerm, note: (esrh.note || ebwd.note || null)}); }
    else out.SCP = nilw(mu && mu.v != null ? (esrh.why || ebwd.why) : "mu_parcel_failed");
    /* STP ثابت (SBCAPE، LCL سطحی، SRH 0–1 km، برش 0–6 km) */
    const s01 = I.SRH.s01, sh6 = I.SHEAR.s06, sbl = lclAgl(sb);
    if(sb && sb.v != null && sbl != null && s01.v != null && sh6.v != null){ const f = V.stpFixedFormula(sb.v, sbl, s01.v, sh6.v); out.STPF = M.ok(f.v, {terms: f.terms, lclAgl: sbl}); }
    else out.STPF = nilw(!(sb && sb.v != null) ? "cape_failed" : (sbl == null ? "no_height_data" : (s01.v == null ? s01.why : sh6.why)));
    /* STP مؤثر (MLCAPE، MLLCL، ESRH، EBWD، MLCIN) */
    const mll = lclAgl(ml);
    if(ml && ml.v != null && mll != null && esrh.v != null && ebwd.v != null){ const f = V.stpEffFormula(ml.v, esrh.v, ebwd.v, mll, ml.cin); out.STPE = M.ok(f.v, {terms: f.terms, lclAgl: mll, note: (esrh.note || ebwd.note || null)}); }
    else out.STPE = nilw(!(ml && ml.v != null) ? "cape_failed" : (mll == null ? "no_height_data" : (esrh.why || ebwd.why)));
    /* SHIP */
    const lv = [700, 500]; let lr = nilw("level_out_of_profile"), t5 = null, frz = nilw("no_height_data");
    if(lv.every(l => l <= prof.p[0] + 1e-9 && l >= prof.p[prof.p.length - 1] - 1e-9)){
      const z7 = M.lab.heightAtP(prof, 700), z5 = M.lab.heightAtP(prof, 500), T7 = interpAt(prof, 700, "Tk"), T5 = interpAt(prof, 500, "Tk"); t5 = T5 - C.zeroC;
      lr = (fin(z7) && fin(z5) && z5 > z7) ? M.ok((T7 - T5) / ((z5 - z7) / 1000), {unit: "K/km"}) : nilw("no_height_data");
    } else lr = nilw(prof.p[0] < 700 ? "level_below_ground_700" : "level_above_profile_top_500");
    out.LR75 = lr;
    // تراز انجماد (AGL): اولین عبور دما از ۰ °C از سطح به بالا (درون‌یابی در ln p)
    if(prof.Tk[0] <= C.zeroC) frz = M.ok(0, {note: "surface_below_freezing"});
    else { let found = null; for(let i = 0; i < prof.p.length - 1; i++) if(prof.Tk[i + 1] <= C.zeroC){ const f = (prof.Tk[i] - C.zeroC) / (prof.Tk[i] - prof.Tk[i + 1]), pz = Math.exp(Math.log(prof.p[i]) + f * (Math.log(prof.p[i + 1]) - Math.log(prof.p[i]))); const h = hAgl(pz); found = h; break; }
      frz = found != null ? M.ok(found) : (prof.p[prof.p.length - 1] <= 500 && z0 != null && !prof.Tk.some(x => x <= C.zeroC) ? M.ok(Infinity, {note: "no_freezing_in_profile"}) : nilw("no_height_data")); }
    out.FZL = frz;
    let mumr = null; if(mu && mu.v != null && fin(mu.startP)){ const td = interpAt(prof, mu.startP, "Tdk"); mumr = T.satMixingRatio(mu.startP, td) * 1000; }
    if(mu && mu.v != null && mumr != null && lr.v != null && t5 != null && sh6.v != null && frz.v != null){ const f = V.shipFormula(mu.v, mumr, lr.v, t5, sh6.v, frz.v); out.SHIP = M.ok(f.v, {terms: f.terms, adj: f.adj, mumr: mumr, t500: t5, frz: frz.v}); }
    else out.SHIP = nilw(!(mu && mu.v != null) ? "mu_parcel_failed" : (lr.v == null ? lr.why : (sh6.v == null ? sh6.why : (frz.v == null ? frz.why : "no_height_data"))));
    return out;
  };
  M.severe = V;
})();
