/* ===== Skew-T log-p و هودوگراف (SVG خالص، بدون کتابخانه) — فاز ۳ =====
   الهام ساختار: skewt-js (MIT) — کد کپی نشده؛ محورها و منحنی‌ها با هستهٔ MET محاسبه می‌شوند.
   رنگ‌ها فقط نمایشی‌اند و به محاسبه راه ندارند. خروجی SVG مستقل است (استایل درون‌خطی) تا ذخیره به‌صورت SVG/PNG وفادار بماند. */
(function(){
  "use strict";
  const M = globalThis.MET, C = M.C, T = M.thermo, PF = M.profile, W = M.wind, S = {};
  const fin = x => typeof x === "number" && isFinite(x);
  const f1 = x => (Math.round(x * 10) / 10).toString(), f0 = x => Math.round(x).toString();
  const esc = s => String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;");
  const G = {W:640, H:600, ML:46, MR:78, MT:14, MB:34, pb:1050, Tmin:-35, Trange:80, k:0.8};
  G.pw = G.W - G.ML - G.MR; G.ph = G.H - G.MT - G.MB;
  function geom(pTop){
    const g = Object.assign({}, G); g.pt = pTop || 100; g.sx = g.pw / g.Trange; const lr = Math.log(g.pb / g.pt);
    g.y = p => g.MT + g.ph * (Math.log(p / g.pt) / lr);                         // بالاتر = فشار کمتر
    g.yb = g.MT + g.ph;
    g.x = (tc, p) => g.ML + (tc - g.Tmin) * g.sx + (g.yb - g.y(p)) * g.k;      // tc ‎°C
    g.pFromY = y => g.pt * Math.exp(lr * (y - g.MT) / g.ph);
    return g;
  }
  const poly = (pts, st, fill) => '<polyline points="' + pts.map(q => f1(q[0]) + "," + f1(q[1])).join(" ") + '" fill="' + (fill || "none") + '" ' + st + "/>";
  function barb(x, y, u, v, len){
    const spd = Math.hypot(u, v) / W.KT, dir = W.direction(u, v);
    if(spd < 2.5) return '<circle cx="' + f1(x) + '" cy="' + f1(y) + '" r="3" fill="none" stroke="#222" stroke-width="1"/>';
    let s = Math.round(spd / 5) * 5, d = "", yy = 0; const step = 4.5, bl = 11;
    d += "M0,0 L0," + (-len);
    while(s >= 50){ d += " M0," + (-len + yy) + " L" + bl + "," + (-len + yy + 3) + " L0," + (-len + yy + 6) + " Z"; yy += 7; s -= 50; }
    if(yy) yy += 1;
    while(s >= 10){ d += " M0," + (-len + yy) + " l" + bl + ",-4"; yy += step; s -= 10; }
    if(s >= 5){ if(yy === 0) yy += step; d += " M0," + (-len + yy) + " l" + (bl / 2) + ",-2"; }
    return '<g transform="translate(' + f1(x) + "," + f1(y) + ") rotate(" + f1(dir) + ')"><path d="' + d + '" stroke="#222" stroke-width="1.1" fill="#222"/></g>';
  }
  /* res = MET.lab.analyze(...)؛ o = {en, parcel:"SB"|"ML"|"MU", showMoist, showMix} */
  S.svg = function(res, o){
    o = o || {}; const en = !!o.en, prof = res.prof, g = geom(100);
    const clip = '<clipPath id="skc"><rect x="' + g.ML + '" y="' + g.MT + '" width="' + g.pw + '" height="' + g.ph + '"/></clipPath>';
    let b = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + g.W + " " + g.H + '" font-family="Vazirmatn,Tahoma,sans-serif" font-size="10" style="width:100%;height:auto;display:block;background:#fff" role="img" aria-label="Skew-T log-p"><defs>' + clip + "</defs>";
    b += '<rect width="' + g.W + '" height="' + g.H + '" fill="#fff"/><rect x="' + g.ML + '" y="' + g.MT + '" width="' + g.pw + '" height="' + g.ph + '" fill="#fbfcfd" stroke="#888"/>';
    b += '<g clip-path="url(#skc)">';
    // زیر سطح زمین
    const yg = g.y(prof.p[0]); if(yg < g.yb) b += '<rect x="' + g.ML + '" y="' + f1(yg) + '" width="' + g.pw + '" height="' + f1(g.yb - yg) + '" fill="#c9c2b6" opacity=".55"/>';
    // ایزوترم‌ها
    for(let t = -140; t <= 60; t += 10){ b += '<line x1="' + f1(g.x(t, g.pb)) + '" y1="' + f1(g.y(g.pb)) + '" x2="' + f1(g.x(t, g.pt)) + '" y2="' + f1(g.y(g.pt)) + '" stroke="' + (t === 0 ? "#6aa0d8" : "#d4dae0") + '" stroke-width="' + (t === 0 ? 1.1 : 0.7) + '"/>'; }
    // ایزوبارها
    for(let p = 1000; p >= 100; p -= 50){ const major = p % 100 === 0; b += '<line x1="' + g.ML + '" x2="' + (g.ML + g.pw) + '" y1="' + f1(g.y(p)) + '" y2="' + f1(g.y(p)) + '" stroke="' + (major ? "#b8c0c8" : "#e4e8ec") + '" stroke-width="' + (major ? 0.8 : 0.5) + '"/>'; }
    const pg = []; for(let p = g.pb; p >= g.pt - 1e-9; p -= 25) pg.push(p);
    // آدیاباتیک خشک
    for(let th = 250; th <= 520; th += 10){ const pts = pg.map(p => [g.x(T.dryLapse(p, th, 1000) - C.zeroC, p), g.y(p)]); b += poly(pts, 'stroke="#e6c9a8" stroke-width="0.7"'); }
    // آدیاباتیک اشباع
    if(o.showMoist !== false) for(let t0 = -10; t0 <= 36; t0 += 5){ const pp = []; for(let p = 1000; p >= g.pt - 1e-9; p -= 25) pp.push(p); const tk = T.moistLapse(pp, t0 + C.zeroC, 1000);
      if(tk) b += poly(pp.map((p, i) => [g.x(tk[i] - C.zeroC, p), g.y(p)]), 'stroke="#a8d4b8" stroke-width="0.7" stroke-dasharray="3 2"'); }
    // نسبت اختلاط
    if(o.showMix !== false) for(const w of [1, 2, 4, 8, 12, 16, 20]){ const pts = []; for(let p = g.pb; p >= 600; p -= 25) pts.push([g.x(T.dewpointFromE(T.vaporPressure(p, w / 1000)) - C.zeroC, p), g.y(p)]);
      b += poly(pts, 'stroke="#b9d9a3" stroke-width="0.7" stroke-dasharray="1 3"'); b += '<text x="' + f1(pts[pts.length - 1][0]) + '" y="' + f1(pts[pts.length - 1][1] - 2) + '" fill="#7fae62" font-size="8" text-anchor="middle">' + w + "</text>"; }
    // پارسل و سایه‌ی CAPE/CIN
    const pc = M.lab.parcelCurve(prof, o.parcel || res.parcelType);
    if(pc){
      const envT = p => PF.interpLog(p, prof.p, prof.Tk), P = pc.p, d = P.map((p, i) => pc.Tk[i] - envT(p));
      const lfc = res.lfc, seg = (i, j) => [g.x(pc.Tk[i] - C.zeroC, P[i]), g.y(P[i])];
      if(fin(lfc)) for(let i = 0; i < P.length - 1; i++){
        let a = {p:P[i], tp:pc.Tk[i], te:envT(P[i]), d:d[i]}, c = {p:P[i + 1], tp:pc.Tk[i + 1], te:envT(P[i + 1]), d:d[i + 1]};
        if(!fin(a.d) || !fin(c.d)) continue;
        const parts = []; if(a.d * c.d < 0){ const f = a.d / (a.d - c.d), pm = Math.exp(Math.log(a.p) + f * (Math.log(c.p) - Math.log(a.p))), tm = envT(pm); parts.push([a, {p:pm, tp:tm, te:tm, d:0}]); parts.push([{p:pm, tp:tm, te:tm, d:0}, c]); } else parts.push([a, c]);
        for(const [s0, s1] of parts){ const m = (s0.d + s1.d) / 2, pm = Math.sqrt(s0.p * s1.p); if(m === 0) continue; const pos = m > 0; if(pos && pm > lfc + 1e-6) continue; if(!pos && pm < lfc - 1e-6) continue;
          const q = [[g.x(s0.tp - C.zeroC, s0.p), g.y(s0.p)], [g.x(s1.tp - C.zeroC, s1.p), g.y(s1.p)], [g.x(s1.te - C.zeroC, s1.p), g.y(s1.p)], [g.x(s0.te - C.zeroC, s0.p), g.y(s0.p)]];
          b += '<polygon points="' + q.map(z => f1(z[0]) + "," + f1(z[1])).join(" ") + '" fill="' + (pos ? "#e8503a" : "#3a78e8") + '" opacity=".28"/>'; }
      }
    }
    // منحنی‌های محیط
    const lineOf = key => poly(prof.p.map((p, i) => [g.x(prof[key][i] - C.zeroC, p), g.y(p)]), 'stroke="' + (key === "Tk" ? "#d22" : "#1a8a3a") + '" stroke-width="2.2" stroke-linejoin="round"');
    b += lineOf("Tdk") + lineOf("Tk");
    if(pc) b += poly(pc.p.map((p, i) => [g.x(pc.Tk[i] - C.zeroC, p), g.y(p)]), 'stroke="#111" stroke-width="1.6" stroke-dasharray="5 3"');
    b += "</g>";
    // ترازهای LCL/LFC/EL
    const mark = (p, lab, col) => { if(!fin(p) || p < g.pt || p > g.pb) return ""; const y = g.y(p); return '<line x1="' + (g.ML + g.pw - 36) + '" x2="' + (g.ML + g.pw) + '" y1="' + f1(y) + '" y2="' + f1(y) + '" stroke="' + col + '" stroke-width="1.4"/><text x="' + (g.ML + g.pw - 38) + '" y="' + f1(y - 2) + '" text-anchor="end" fill="' + col + '" font-size="9.5" font-weight="700">' + lab + " " + f0(p) + "</text>"; };
    b += mark(res.items.LCL.v, "LCL", "#0a7") + mark(res.lfc, "LFC", "#a50") + mark(res.el, "EL", "#70a");
    // برچسب محورها
    for(let p = 1000; p >= 100; p -= 100) b += '<text x="' + (g.ML - 4) + '" y="' + f1(g.y(p) + 3) + '" text-anchor="end" fill="#444">' + p + "</text>";
    b += '<text x="10" y="' + f1(g.MT + g.ph / 2) + '" fill="#444" transform="rotate(-90 10 ' + f1(g.MT + g.ph / 2) + ')" text-anchor="middle">hPa</text>';
    for(let t = -30; t <= 40; t += 10) b += '<text x="' + f1(g.x(t, g.pb)) + '" y="' + (g.yb + 12) + '" text-anchor="middle" fill="#444">' + t + "</text>";
    b += '<text x="' + f1(g.ML + g.pw / 2) + '" y="' + (g.H - 6) + '" text-anchor="middle" fill="#444">' + (en ? "Temperature at 1050 hPa (°C)" : "°C (دما در تراز ۱۰۵۰ hPa)") + "</text>";
    // بارب باد
    const wi = []; for(let i = 0; i < prof.p.length; i++) if(fin(prof.u[i]) && fin(prof.v[i])) wi.push(i);
    if(wi.length){ const bx = g.W - g.MR / 2 + 6; b += '<line x1="' + f1(bx) + '" x2="' + f1(bx) + '" y1="' + g.MT + '" y2="' + g.yb + '" stroke="#ddd"/>'; let last = -99;
      for(const i of wi){ const y = g.y(prof.p[i]); if(y < g.MT || y > g.yb || Math.abs(y - last) < 15) continue; last = y; b += barb(bx, y, prof.u[i], prof.v[i], 22); } }
    // تیتر پارسل
    b += '<text x="' + (g.ML + 6) + '" y="' + (g.MT + 12) + '" fill="#111" font-weight="700">' + esc(o.title || "") + "</text>";
    b += '<g id="skCur" style="display:none"><line id="skCl" x1="' + g.ML + '" x2="' + (g.ML + g.pw) + '" y1="0" y2="0" stroke="#e0a000" stroke-width="1.2"/><circle id="skCT" r="3.5" fill="#d22" stroke="#fff"/><circle id="skCD" r="3.5" fill="#1a8a3a" stroke="#fff"/></g>';
    b += '<rect id="skHit" x="' + g.ML + '" y="' + g.MT + '" width="' + g.pw + '" height="' + g.ph + '" fill="transparent" style="touch-action:pan-y;cursor:crosshair"/>';
    return b + "</svg>";
  };
  // اتصال رویداد نشانگر؛ info(div) متن را می‌گیرد
  S.attach = function(host, res, infoEl, o){
    o = o || {}; const svg = host.querySelector("svg"); if(!svg) return; const g = geom(100), prof = res.prof;
    const hit = svg.querySelector("#skHit"), cur = svg.querySelector("#skCur"), cl = svg.querySelector("#skCl"), cT = svg.querySelector("#skCT"), cD = svg.querySelector("#skCD");
    const wi = []; for(let i = 0; i < prof.p.length; i++) if(fin(prof.u[i]) && fin(prof.v[i])) wi.push(i);
    function at(ev){
      const r = svg.getBoundingClientRect(), sc = g.W / r.width, y = (ev.clientY - r.top) * sc; const p = Math.max(Math.min(g.pFromY(y), prof.p[0]), prof.p[prof.p.length - 1]);
      const t = PF.interpLog(p, prof.p, prof.Tk), td = PF.interpLog(p, prof.p, prof.Tdk); if(!fin(t) || !fin(td)) return;
      const yy = g.y(p); cur.style.display = ""; cl.setAttribute("y1", yy); cl.setAttribute("y2", yy);
      cT.setAttribute("cx", g.x(t - C.zeroC, p)); cT.setAttribute("cy", yy); cD.setAttribute("cx", g.x(td - C.zeroC, p)); cD.setAttribute("cy", yy);
      const z = M.lab.heightAtP(prof, p), rh = T.rhFromDewpoint(t, td) * 100; let w = "";
      if(wi.length > 1){ const pp = wi.map(i => prof.p[i]), u = PF.interpLog(p, pp, wi.map(i => prof.u[i])), v = PF.interpLog(p, pp, wi.map(i => prof.v[i])); if(fin(u) && fin(v)) w = " · " + f0(W.direction(u, v)) + "°/" + f1(Math.hypot(u, v)) + " m/s"; }
      if(infoEl) infoEl.textContent = f0(p) + " hPa" + (fin(z) ? " · " + f0(z) + " m" : "") + " · T " + f1(t - C.zeroC) + " °C · Td " + f1(td - C.zeroC) + " °C · RH " + f0(rh) + "%" + w;
    }
    hit.addEventListener("pointermove", at); hit.addEventListener("pointerdown", at);
  };
  /* ---------- هودوگراف ---------- */
  S.hodograph = function(res, o){
    o = o || {}; const en = !!o.en, H = res.hodo; if(!H || H.v == null) return null;
    const pts = H.points; let mx = 0; pts.forEach(p => { mx = Math.max(mx, Math.hypot(p.u, p.v)); });
    const items = res.items, bk = items.BUNKERS; ["right", "left", "mean"].forEach(k => { if(bk && bk[k]) mx = Math.max(mx, Math.hypot(bk[k].u, bk[k].v)); });
    const R = Math.max(30, Math.ceil((mx + 2) / 10) * 10), S0 = 300, c = S0 / 2, k = (c - 14) / R, X = u => c + u * k, Y = v => c - v * k;
    let b = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + S0 + " " + S0 + '" font-family="Vazirmatn,Tahoma,sans-serif" font-size="9" style="width:100%;height:auto;display:block;background:#fff" role="img" aria-label="hodograph"><rect width="' + S0 + '" height="' + S0 + '" fill="#fff"/>';
    for(let r = 10; r <= R; r += 10) b += '<circle cx="' + c + '" cy="' + c + '" r="' + f1(r * k) + '" fill="none" stroke="#d4dae0"/><text x="' + f1(c + 2) + '" y="' + f1(c - r * k - 1) + '" fill="#889">' + r + "</text>";
    b += '<line x1="6" x2="' + (S0 - 6) + '" y1="' + c + '" y2="' + c + '" stroke="#aab"/><line y1="6" y2="' + (S0 - 6) + '" x1="' + c + '" x2="' + c + '" stroke="#aab"/>';
    const col = z => z < 3000 ? "#d22" : z < 6000 ? "#1a8a3a" : z < 9000 ? "#c80" : "#70a";
    for(let i = 0; i < pts.length - 1; i++) b += '<line x1="' + f1(X(pts[i].u)) + '" y1="' + f1(Y(pts[i].v)) + '" x2="' + f1(X(pts[i + 1].u)) + '" y2="' + f1(Y(pts[i + 1].v)) + '" stroke="' + col((pts[i].z + pts[i + 1].z) / 2) + '" stroke-width="2.2"/>';
    H.marks.forEach(m => { if(fin(m.u) && fin(m.v)) b += '<circle cx="' + f1(X(m.u)) + '" cy="' + f1(Y(m.v)) + '" r="7" fill="#fff" stroke="' + col(m.km * 1000 - 1) + '"/><text x="' + f1(X(m.u)) + '" y="' + f1(Y(m.v) + 3) + '" text-anchor="middle" font-weight="700" fill="#222">' + m.km + "</text>"; });
    if(bk && bk.right){ const pt = (q, lab, shape) => '<g><' + (shape === "t" ? 'polygon points="' + f1(X(q.u)) + "," + f1(Y(q.v) - 6) + " " + f1(X(q.u) - 5.5) + "," + f1(Y(q.v) + 4) + " " + f1(X(q.u) + 5.5) + "," + f1(Y(q.v) + 4) + '"' : 'rect x="' + f1(X(q.u) - 4.5) + '" y="' + f1(Y(q.v) - 4.5) + '" width="9" height="9"') + ' fill="#111" opacity=".85"/><text x="' + f1(X(q.u) + 8) + '" y="' + f1(Y(q.v) + 3) + '" font-weight="700">' + lab + "</text></g>";
      b += pt(bk.right, "RM", "t") + pt(bk.left, "LM", "t") + '<circle cx="' + f1(X(bk.mean.u)) + '" cy="' + f1(Y(bk.mean.v)) + '" r="3.5" fill="none" stroke="#111" stroke-width="1.5"/><text x="' + f1(X(bk.mean.u) + 6) + '" y="' + f1(Y(bk.mean.v) - 4) + '">' + (en ? "mean" : "میانگین") + "</text>"; }
    b += '<text x="' + (S0 - 6) + '" y="' + (S0 - 6) + '" text-anchor="end" fill="#667">m/s</text>';
    return b + "</svg>";
  };
  // ذخیره: SVG یا PNG
  S.download = function(svgEl, name, png){
    const xml = new XMLSerializer().serializeToString(svgEl), blob = new Blob([xml], {type:"image/svg+xml;charset=utf-8"});
    const save = (bl, fn) => { const a = document.createElement("a"); a.href = URL.createObjectURL(bl); a.download = fn; document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 500); };
    if(!png) return save(blob, name + ".svg");
    const vb = svgEl.viewBox.baseVal, sc = 2, img = new Image(); img.onload = () => { const cv = document.createElement("canvas"); cv.width = vb.width * sc; cv.height = vb.height * sc; const cx = cv.getContext("2d"); cx.fillStyle = "#fff"; cx.fillRect(0, 0, cv.width, cv.height); cx.drawImage(img, 0, 0, cv.width, cv.height); cv.toBlob(b2 => save(b2, name + ".png")); };
    img.src = "data:image/svg+xml;charset=utf-8," + encodeURIComponent(xml);
  };
  M.skewt = S;
})();
