/* ===== ترمودینامیک پایه (توابع خالص، بدون DOM) =====
   مرجع: MetPy metpy.calc.thermo — فرمول‌ها عیناً: فشار بخار اشباع (Ambaum 2020 / Romps 2017)، Td (Bolton 1980)،
   LCL (Romps 2017، شاخهٔ −۱ تابع W لامبرت)، θe (Bolton 1980 تقریب)، دمای مجازی، آدیاباتیک خشک/مرطوب.
   ورودی‌ها: فشار hPa، دما K (پسوند K). فرضیات: هوا گاز ایدهآل؛ بخار اشباع نسبت به آب (liquid) مگر مشخص شود. */
(function(){
  "use strict";
  const M = globalThis.MET, C = M.C;
  const LN = Math.log, EXP = Math.exp;
  const T = {};
  T.cToK = c => c + C.zeroC;  T.kToC = k => k - C.zeroC;
  T.latentVap = Tk => C.Lv - (C.Cp_l - C.Cp_v) * (Tk - C.T0);
  T.latentSub = Tk => C.Ls - (C.Cp_i - C.Cp_v) * (Tk - C.T0);
  T.esLiquid = function(Tk){ const L = T.latentVap(Tk), hp = (C.Cp_l - C.Cp_v) / C.Rv, ex = ((C.Lv / C.T0 - L / Tk) / C.Rv);
    return C.es0 * Math.pow(C.T0 / Tk, hp) * EXP(ex); };
  T.esSolid = function(Tk){ const L = T.latentSub(Tk), hp = (C.Cp_i - C.Cp_v) / C.Rv, ex = ((C.Ls / C.T0 - L / Tk) / C.Rv);
    return C.es0 * Math.pow(C.T0 / Tk, hp) * EXP(ex); };
  T.es = function(Tk, phase){ phase = phase || "liquid";
    if(phase === "liquid") return T.esLiquid(Tk);
    if(phase === "solid") return T.esSolid(Tk);
    return Tk > C.T0 ? T.esLiquid(Tk) : T.esSolid(Tk); };
  T.mixingRatio = (e, p) => C.epsilon * e / (p - e);
  T.satMixingRatio = function(p, Tk, phase){ const e = T.es(Tk, phase); return e >= p ? NaN : T.mixingRatio(e, p); };
  T.vaporPressure = (p, w) => p * w / (C.epsilon + w);
  T.dewpointFromE = function(e){ const v = LN(e / C.es0); return C.zeroC + 243.5 * v / (17.67 - v); };      // K
  T.dewpointFromRH = (Tk, rh) => T.dewpointFromE(rh * T.es(Tk, "liquid"));                                  // rh 0..1
  T.rhFromDewpoint = (Tk, Tdk, phase) => T.es(Tdk, phase || "liquid") / T.es(Tk, phase || "liquid");
  T.specHumFromMixing = w => w / (1 + w);
  T.specHumFromDewpoint = (p, Tdk, phase) => T.specHumFromMixing(T.satMixingRatio(p, Tdk, phase));
  T.moistGasConst = q => C.Rd + q * (C.Rv - C.Rd);
  T.moistCp = q => C.Cp_d + q * (C.Cp_v - C.Cp_d);
  T.exner = p => Math.pow(p / C.P0, C.kappa);
  T.theta = (p, Tk) => Tk / T.exner(p);
  T.dryLapse = (p, Tk0, p0) => Tk0 * Math.pow(p / p0, C.kappa);
  T.virtualT = (Tk, w) => Tk * ((w + C.epsilon) / (C.epsilon * (1 + w)));
  T.virtualTFromDewpoint = (p, Tk, Tdk) => T.virtualT(Tk, T.satMixingRatio(p, Tdk));
  // θe (Bolton 1980، همان تقریب MetPy): ورودی Tk, Tdk برحسب K
  T.thetaE = function(p, Tk, Tdk){ const r = T.satMixingRatio(p, Tdk), e = T.es(Tdk);
    const tL = 56 + 1 / (1 / (Tdk - 56) + LN(Tk / Tdk) / 800);
    const thL = T.theta(p - e, Tk) * Math.pow(Tk / tL, 0.28 * r);
    return thL * EXP(r * (1 + 0.448 * r) * (3036 / tL - 1.78)); };
  // شاخهٔ −۱ تابع W لامبرت، x ∈ [−1/e, 0): تکرار هالی
  T.lambertWm1 = function(x){
    if(!(x < 0) || x < -1 / Math.E - 1e-15) return NaN;
    if(x <= -1 / Math.E) return -1;
    let w;
    if(x < -0.25){ const p = -Math.sqrt(2 * (Math.E * x + 1)); w = -1 + p - p * p / 3 + 11 / 72 * p * p * p; }
    else { const l1 = LN(-x), l2 = LN(-l1); w = l1 - l2 + l2 / l1; }
    for(let i = 0; i < 60; i++){
      const ew = EXP(w), f = w * ew - x, wp1 = w + 1;
      const d = ew * wp1 - (w + 2) * f / (2 * wp1);
      const nw = w - f / d;
      if(Math.abs(nw - w) <= 1e-15 * Math.max(1, Math.abs(nw))){ w = nw; break; }
      w = nw;
    }
    return w;
  };
  // LCL (Romps 2017، معادلات 22a–22f). ورودی: p hPa، Tk، Tdk (K). خروجی {p,Tk} یا null
  T.lcl = function(p, Tk, Tdk){
    if(!(Tdk <= Tk + 1e-9)) return null;
    const q = T.specHumFromDewpoint(p, Tdk);
    if(!isFinite(q)) return null;
    const ratio = T.moistCp(q) / T.moistGasConst(q), dC = C.Cp_l - C.Cp_v;
    const a = ratio + dC / C.Rv, b = -(C.Lv + dC * C.T0) / (C.Rv * Tk), c = b / a;
    const rh = T.rhFromDewpoint(Tk, Tdk, "liquid");
    const w = T.lambertWm1(Math.pow(rh, 1 / a) * c * EXP(c));
    const tl = c / w * Tk, pl = p * Math.pow(tl / Tk, ratio);
    return isFinite(tl) && isFinite(pl) ? {p: pl, Tk: tl} : null;
  };
  // شیب آدیاباتیک مرطوب dT/dp (K/hPa)، آهنگ MetPy
  function dTdp(p, t){
    const rs = T.satMixingRatio(p, t);
    const num = C.Rd * t + C.Lv * rs, den = C.Cp_d + C.Lv * C.Lv * rs * C.epsilon / (C.Rd * t * t);
    return num / den / p;
  }
  // پروفایل آدیاباتیک مرطوب: pArr کاهشی (از p0 به بالا)؛ RK4 با گام ≤ ۲ hPa (خطا ≪ ۰٫۰۰۱ K)
  T.moistLapse = function(pArr, Tk0, p0){
    const out = new Array(pArr.length); let p = p0, t = Tk0;
    for(let i = 0; i < pArr.length; i++){
      const pt = pArr[i], n = Math.max(1, Math.ceil(Math.abs(pt - p) / 2)), h = (pt - p) / n;
      for(let k = 0; k < n; k++){
        const k1 = dTdp(p, t), k2 = dTdp(p + h / 2, t + h / 2 * k1), k3 = dTdp(p + h / 2, t + h / 2 * k2), k4 = dTdp(p + h, t + h * k3);
        t += h / 6 * (k1 + 2 * k2 + 2 * k3 + k4); p += h;
      }
      p = pt; out[i] = t;
    }
    return out;
  };
  M.thermo = T;
})();
