/* ===== باد: برش، میانگین، حرکت توفان Bunkers، SRH، زاویهٔ بحرانی، دادهٔ هودوگراف (فاز ۲) =====
   مرجع: MetPy indices.bulk_shear / bunkers_storm_motion / critical_angle، kinematics.storm_relative_helicity؛ Bunkers et al. 2000 (Wea. Forecasting)؛ Davies-Jones et al. 1990 (SRH).
   قرارداد: باد m/s؛ جهت «از» (meteorological) درجه؛ ارتفاع z متر از سطح دریا (ژئوپتانسیل)، ارتفاع‌های لایه AGL نسبت به پایین‌ترین ردیف معتبر.
   نیمکرهٔ شمالی: توفان راست‌گرد Bunkers = میانگین باد ۰–۶ km + ۷٫۵ m/s عمود (راست) بر برش ۵٫۵–۶ km منهای ۰–۰٫۵ km.
   داده‌ی ناکافی: ردیف بدون u,v,z نادیده؛ اگر لایه از بالای پروفایل بیرون زند ⇒ null (why=layer_exceeds_profile_top). */
(function(){
  "use strict";
  const M = globalThis.MET, PF = M.profile, W = {};
  const fin = x => typeof x === "number" && isFinite(x);
  const isclose = (a, b) => Math.abs(a - b) <= 1e-8 + 1e-5 * Math.abs(b);
  W.KT = 0.514444444444;     // m/s در هر گره (دقیق: 1852/3600)
  W.components = function(speed, dirDeg){ const r = dirDeg * Math.PI / 180; return {u: -speed * Math.sin(r), v: -speed * Math.cos(r)}; };
  W.direction = function(u, v){ if(u === 0 && v === 0) return 0; let d = 90 - Math.atan2(-v, -u) * 180 / Math.PI; d = ((d % 360) + 360) % 360; return d <= 0 ? d + 360 : d; };
  W.speed = (u, v) => Math.hypot(u, v);
  // پروفیل باد: ردیف‌هایی که p,z,u,v همه معتبرند؛ p نزولی. خروجی {p,z,u,v,zAgl}
  W.windProfile = function(prof){
    const idx = []; for(let i = 0; i < prof.p.length; i++) if(fin(prof.p[i]) && fin(prof.z && prof.z[i]) && fin(prof.u && prof.u[i]) && fin(prof.v && prof.v[i])) idx.push(i);
    if(idx.length < 3) return null;
    const o = {p: idx.map(i => prof.p[i]), z: idx.map(i => prof.z[i]), u: idx.map(i => prof.u[i]), v: idx.map(i => prof.v[i])};
    for(let i = 1; i < o.z.length; i++) if(!(o.z[i] > o.z[i - 1])) return null;     // ارتفاع باید اکیداً صعودی باشد
    o.zAgl = o.z.map(z => z - o.z[0]); return o;
  };
  const interpZ = (x, z, y) => { if(x < z[0] - 1e-9 || x > z[z.length - 1] + 1e-9) return NaN; for(let i = 0; i < z.length - 1; i++) if(x >= z[i] && x <= z[i + 1]){ const f = (x - z[i]) / (z[i + 1] - z[i]); return y[i] + f * (y[i + 1] - y[i]); } return NaN; };
  const pAtZ = (zq, w) => interpZ(zq, w.z, w.p);                           // np.interp(height → pressure)
  // لایه با کران ارتفاعی (مثل MetPy get_layer با height): بازهٔ فشاری معادل، مرزها با درون‌یابی لگاریتمی
  function layerP(w, bottomAgl, depth){
    const zb = w.z[0] + bottomAgl, zt = zb + depth;
    if(zt > w.z[w.z.length - 1] + 1e-9) return null;
    const pb = bottomAgl === 0 ? w.p[0] : pAtZ(zb, w), pt = pAtZ(zt, w);
    if(!fin(pb) || !fin(pt)) return null;
    let ps = w.p.filter(q => q <= pb + 1e-9 && q >= pt - 1e-9);
    if(!ps.some(q => isclose(pt, q))) ps.push(pt);
    if(!ps.some(q => isclose(pb, q))) ps.push(pb);
    ps.sort((a, b) => b - a);
    return {p: ps, u: ps.map(q => PF.interpLog(q, w.p, w.u)), v: ps.map(q => PF.interpLog(q, w.p, w.v))};
  }
  const meanW = function(w, bottomAgl, depth){ const L = layerP(w, bottomAgl, depth); if(!L) return null;
    const dp = L.p[L.p.length - 1] - L.p[0]; return {u: PF.trapz(L.u, L.p) / dp, v: PF.trapz(L.v, L.p) / dp}; };
  // برش بردار بین بالا و پایین لایه (لایه با پایه/ضخامت بر حسب متر AGL)
  W.bulkShear = function(prof, bottom, depth){
    const w = W.windProfile(prof); if(!w) return M.nil("insufficient_wind_levels");
    const L = layerP(w, bottom || 0, depth); if(!L) return M.nil("layer_exceeds_profile_top");
    const du = L.u[L.u.length - 1] - L.u[0], dv = L.v[L.v.length - 1] - L.v[0];
    return M.ok(Math.hypot(du, dv), {du: du, dv: dv, unit: "m/s"}); };
  W.bunkers = function(prof){
    const w = W.windProfile(prof); if(!w) return M.nil("insufficient_wind_levels");
    const mean = meanW(w, 0, 6000), w05 = meanW(w, 0, 500), w55 = meanW(w, 5500, 500);
    if(!mean || !w05 || !w55) return M.nil("layer_exceeds_profile_top");
    const sh = {u: w55.u - w05.u, v: w55.v - w05.v}, mag = Math.hypot(sh.u, sh.v);
    if(!(mag > 0)) return M.nil("zero_shear");
    const dev = {u: sh.v * (7.5 / mag), v: -sh.u * (7.5 / mag)};
    return M.ok(null, {right: {u: mean.u + dev.u, v: mean.v + dev.v}, left: {u: mean.u - dev.u, v: mean.v - dev.v}, mean: mean, unit: "m/s"}); };
  // SRH: لایهٔ [bottom, bottom+depth] متر AGL؛ حرکت توفان (m/s) پیش‌فرض صفر؛ خروجی مثبت، منفی، کل (m²/s²)
  W.srh = function(prof, depth, storm, bottom){
    const w = W.windProfile(prof); if(!w) return M.nil("insufficient_wind_levels");
    bottom = bottom || 0; const top = bottom + depth;
    if(top > w.zAgl[w.zAgl.length - 1] + 1e-9) return M.nil("layer_exceeds_profile_top");
    const zs = w.zAgl.filter(z => z >= bottom - 1e-9 && z <= top + 1e-9);
    if(!zs.some(z => z === top)) zs.push(top);
    if(!zs.some(z => z === bottom)) zs.push(bottom);
    zs.sort((a, b) => a - b);
    const su = storm ? storm.u : 0, sv = storm ? storm.v : 0;
    const u = zs.map(z => interpZ(z, w.zAgl, w.u) - su), v = zs.map(z => interpZ(z, w.zAgl, w.v) - sv);
    let pos = 0, neg = 0;
    for(let i = 0; i < zs.length - 1; i++){ const t = u[i + 1] * v[i] - u[i] * v[i + 1]; if(t > 0) pos += t; else if(t < 0) neg += t; }
    return M.ok(pos + neg, {pos: pos, neg: neg, unit: "m2/s2"}); };
  // زاویهٔ بحرانی (°): میان بردار برش ۰–۵۰۰ m و بردار «باد سطح → حرکت توفان» (Esterheld & Giuliano 2008)
  W.criticalAngle = function(prof, storm){
    const w = W.windProfile(prof); if(!w) return M.nil("insufficient_wind_levels");
    const L = layerP(w, 0, 500); if(!L) return M.nil("layer_exceeds_profile_top");
    const shr = {u: L.u[L.u.length - 1] - L.u[0], v: L.v[L.v.length - 1] - L.v[0]}, sm = {u: storm.u - w.u[0], v: storm.v - w.v[0]};
    const n = Math.hypot(shr.u, shr.v) * Math.hypot(sm.u, sm.v); if(!(n > 0)) return M.nil("zero_vector");
    return M.ok(Math.acos(Math.max(-1, Math.min(1, (shr.u * sm.u + shr.v * sm.v) / n))) * 180 / Math.PI, {unit: "deg"}); };
  // دادهٔ هودوگراف: نقاط (u,v) هر پروفیل تا maxH متر AGL + نشانگر هر کیلومتر
  W.hodograph = function(prof, maxH){
    const w = W.windProfile(prof); if(!w) return M.nil("insufficient_wind_levels"); maxH = maxH || 10000;
    if(maxH > w.zAgl[w.zAgl.length - 1]) maxH = w.zAgl[w.zAgl.length - 1];
    const pts = []; for(let i = 0; i < w.zAgl.length; i++) if(w.zAgl[i] <= maxH) pts.push({z: w.zAgl[i], u: w.u[i], v: w.v[i]});
    const marks = []; for(let km = 1; km * 1000 <= maxH; km++) marks.push({km: km, u: interpZ(km * 1000, w.zAgl, w.u), v: interpZ(km * 1000, w.zAgl, w.v)});
    return M.ok(pts.length, {points: pts, marks: marks}); };
  M.wind = W;
})();
