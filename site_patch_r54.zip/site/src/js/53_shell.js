/* ===== پوستهٔ سایت (r52): منوی همبرگری، صفحهٔ اصلی دوبخشی، صفحهٔ «ترکیب نقشه‌های آفلاین»، مختصات زیر نشانگر =====
   هیچ صفحه‌ای جابه‌جا یا بازنویسی نمی‌شود؛ همان تابع‌های بازکردن قبلی (openON، openSA، کلیک دکمه‌های لندینگ و …) صدا زده می‌شوند.
   نوار دکمه‌های افقی قبلی (#topnav) فقط پنهان می‌شود و منطق همگام‌سازی‌اش (عنوان تب، آدرس صفحه) سر جایش می‌ماند. */
(function(){
  const EN=()=>typeof LANG!=="undefined"&&LANG==="en";
  const land=document.getElementById("landing");
  const keyOf=b=>b.dataset.tt?"tt":b.dataset.wm?"wm":b.dataset.mode;
  const landBtn=k=>land?[...land.querySelectorAll(".choice")].find(b=>keyOf(b)===k):null;
  const GO={
    on:()=>openON(), sa:()=>openSA(), an:()=>openAN(), lab:()=>(typeof openLab==="function"?openLab():openAN()),
    ds:()=>openDS(), ca:()=>openCA(), ci:()=>openCI()
  };
  function go(k){ try{ const f=GO[k]; if(f) f(); else { const b=landBtn(k); if(b) b.click(); } }catch(e){ console.warn("shell go",k,e); } window.scrollTo(0,0); setTimeout(sync,80); }
  /* کلید صفحهٔ فعلی (همان منطق نوار قبلی + زبانهٔ آزمایشگاه) */
  function cur(){ let m=""; try{ m=store.get("mode",""); }catch(e){}
    if(m==="cv"||m==="wn") return "an";
    if(m==="an"){ try{ if(AN.lab) return "lab"; }catch(e){} }
    return m; }
  const OFF=["wu","wb","wm","cu","lt"], MAIN=["on","sa"];

  /* ---------- منوی همبرگری ---------- */
  const NAVI=[
    {g:["صفحهٔ اصلی","Home"], items:[["on","مدل‌های هواشناسی","Weather models"],["ci","شاخص‌های اقلیمی","Climate indices"],["sa","تصاویر ماهواره و رعدوبرق","Satellite & lightning"]]},
    {g:["تحلیل","Analysis"], items:[["an","تحلیل و هشدار","Analysis & warnings"],["lab","آزمایشگاه محاسبات","Computation lab"]]},
    {g:["ترکیب نقشه‌های آفلاین","Offline map composer"], items:[["wu","weather.us","weather.us"],["wb","WeatherBELL","WeatherBELL"],["wm","weathermodels","weathermodels"],["cu","tropicaltidbits و هر سایت","tropicaltidbits & any site"],["lt","تراکم رعدوبرق","Lightning density"]]},
    {g:["ابزارها و اقلیم","Tools & climate"], items:[["ds","اصلاح با ارتفاع","Elevation correction"],["ca","اطلس اقلیمی","Climate atlas"]]}
  ];
  const ICON_K={}, iconOf=k=>{ if(k==="lab") return '<svg class="ch-ic" viewBox="0 0 24 24" aria-hidden="true"><path d="M9 3h6M10 3v6L4.5 19a1.5 1.5 0 0 0 1.3 2h12.4a1.5 1.5 0 0 0 1.3-2L14 9V3"/><path d="M7 15h10"/></svg>'; const s=document.querySelector(`#topnav .tn-btn[data-k="${ICON_K[k]||k}"] svg`); return s?s.outerHTML:'<svg class="ch-ic" viewBox="0 0 24 24"><circle cx="12" cy="12" r="4"/></svg>'; };
  const topIn=document.querySelector(".top .top-in");
  const hb=document.createElement("button"); hb.type="button"; hb.id="hambBtn"; hb.className="hamb"; hb.setAttribute("data-noi18n",""); hb.setAttribute("aria-haspopup","true"); hb.setAttribute("aria-expanded","false");
  hb.innerHTML='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16M4 12h16M4 17h16"/></svg><span class="hambCur"></span>';
  if(topIn) topIn.prepend(hb);
  const dr=document.createElement("div"); dr.id="drawer"; dr.className="drawer"; dr.hidden=true; dr.setAttribute("data-noi18n","");
  dr.innerHTML='<div class="drBack"></div><nav class="drPan" aria-label="menu"><div class="drHead"><b class="drT"></b><button type="button" class="drX" aria-label="close">×</button></div><div class="drBody"></div></nav>';
  document.body.append(dr);
  function drFill(){ const en=EN(), k=cur();
    dr.querySelector(".drT").textContent=en?"Site pages":"صفحه‌های سایت";
    dr.querySelector(".drBody").innerHTML=NAVI.map(G=>`<div class="drG"><div class="drGh">${en?G.g[1]:G.g[0]}</div>${G.items.map(([id,fa,e])=>`<button type="button" class="drI${id===k?" on":""}" data-go="${id}">${iconOf(id)}<span>${en?e:fa}</span></button>`).join("")}</div>`).join(""); }
  function drOpen(){ drFill(); dr.hidden=false; hb.setAttribute("aria-expanded","true"); requestAnimationFrame(()=>dr.classList.add("open")); const a=dr.querySelector(".drI.on")||dr.querySelector(".drI"); if(a) try{ a.focus({preventScroll:true}); }catch(e){} }
  function drClose(){ dr.classList.remove("open"); hb.setAttribute("aria-expanded","false"); setTimeout(()=>{ if(!dr.classList.contains("open")) dr.hidden=true; },220); }
  hb.onclick=()=>dr.hidden?drOpen():drClose();
  dr.addEventListener("click",e=>{ const b=e.target.closest("[data-go]"); if(b){ drClose(); go(b.dataset.go); return; } if(e.target.closest(".drX")||e.target.classList.contains("drBack")) drClose(); });
  document.addEventListener("keydown",e=>{ if(e.key==="Escape"&&!dr.hidden) drClose(); });

  /* ---------- نوارهای بالای صفحه ---------- */
  const anchor=document.getElementById("pgAddr")||document.getElementById("topnav")||document.querySelector(".top");
  const hubM=document.createElement("div"); hubM.id="hubMain"; hubM.className="hub hubMain"; hubM.hidden=true; hubM.setAttribute("data-noi18n","");
  hubM.innerHTML='<button type="button" class="hubBig" data-go="on"><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3.2 3 14.8 0 18M12 3c-3 3.2-3 14.8 0 18"/></svg><span></span></button><button type="button" class="hubBig" data-go="sa"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M13 2L4 14h7l-1 8 9-12h-7z"/></svg><span></span></button>';
  const hubO=document.createElement("div"); hubO.id="hubOff"; hubO.className="hub hubOff"; hubO.hidden=true; hubO.setAttribute("data-noi18n","");
  hubO.innerHTML='<div class="hubOh"><b></b><small></small></div><div class="hubOr"><div class="hubOg" data-g="s"></div><div class="hubOg hubOlt" data-g="l"></div></div>';
  anchor.parentNode.insertBefore(hubO, anchor.nextSibling); anchor.parentNode.insertBefore(hubM, anchor.nextSibling);
  const OFFL={wu:["weather.us","weather.us"],wb:["WeatherBELL","WeatherBELL"],wm:["weathermodels","weathermodels"],cu:["tropicaltidbits و هر سایت","tropicaltidbits & any site"]};
  function hubTxt(){ const en=EN();
    const s=hubM.querySelectorAll(".hubBig span"); s[0].textContent=en?"Weather models":"مدل‌های هواشناسی"; s[1].textContent=en?"Satellite & lightning images":"تصاویر ماهواره و رعدوبرق";
    hubO.querySelector(".hubOh b").textContent=en?"Offline map composer":"ترکیب نقشه‌های آفلاین";
    hubO.querySelector(".hubOh small").textContent=en?"Combine screenshots from popular model sites":"ترکیب تصویر نقشه‌های سایت‌های پرکاربرد مدل";
    hubO.querySelector('[data-g="s"]').innerHTML=Object.entries(OFFL).filter(([k])=>k==="cu"||landBtn(k)).map(([k,t])=>`<button type="button" class="hubC" data-go="${k}">${en?t[1]:t[0]}</button>`).join("");
    hubO.querySelector('[data-g="l"]').innerHTML=`<span class="hubOs">${en?"Separate tool":"ابزار جدا"}</span><button type="button" class="hubC hubLt" data-go="lt">${iconOf("lt")}${en?"Lightning density map":"ساخت نقشهٔ تراکم رعدوبرق"}</button>`;
    sync(); }
  for(const h of [hubM,hubO]) h.addEventListener("click",e=>{ const b=e.target.closest("[data-go]"); if(!b) return; if(b.classList.contains("on")) return; go(b.dataset.go); });

  function sync(){
    const k=cur(), vis=land?land.hidden:true;
    hubM.hidden=!(vis&&MAIN.includes(k)); hubO.hidden=!(vis&&OFF.includes(k));
    hubM.querySelectorAll("[data-go]").forEach(b=>b.classList.toggle("on",b.dataset.go===k));
    hubO.querySelectorAll("[data-go]").forEach(b=>b.classList.toggle("on",b.dataset.go===k));
    let lab=""; for(const G of NAVI) for(const it of G.items) if(it[0]===k) lab=EN()?it[2]:it[1];
    const c=hb.querySelector(".hambCur"); if(c.textContent!==lab) c.textContent=lab;
    hb.title=EN()?"Menu":"منو";
    if(!dr.hidden) dr.querySelectorAll(".drI").forEach(b=>b.classList.toggle("on",b.dataset.go===k));
  }
  window.shellSync=sync;
  const mo=new MutationObserver(()=>setTimeout(sync,40));
  for(const id of ["landing","app","dsApp","cvApp","ltApp","wnApp","cqcApp","caApp","onApp","ciApp","saApp","anApp","labApp"]){ const e=document.getElementById(id); if(e) mo.observe(e,{attributes:true,attributeFilter:["hidden"]}); }
  addEventListener("popstate",()=>setTimeout(sync,80)); addEventListener("hashchange",()=>setTimeout(sync,80));
  document.addEventListener("langchange",()=>{ hubTxt(); if(!dr.hidden) drFill(); });
  setInterval(sync,1200); hubTxt();
})();

/* ===== «اصلاح با ارتفاع» با نقشهٔ آنلاین: کادر از نمایشگر به بالای صفحهٔ اصلاح با ارتفاع منتقل شد =====
   همان کادر و همان تابع nvXRender (41_nwp_viewer.js)؛ فقط محل قرارگیری عوض شده. اگر صفحهٔ اصلاح مستقیم باز شود
   و فهرست نقشه‌های هاست هنوز خوانده نشده باشد، اینجا خوانده می‌شود. بخش دستی (PNG/JPG) زیر آن مثل قبل می‌ماند. */
(function(){
  const asd=document.querySelector("#dsApp > aside"); if(!asd) return;
  let box=document.getElementById("nvXfer");
  const sec=document.createElement("section"); sec.className="panel dsOnl"; sec.id="dsOnl";
  sec.innerHTML='<h2>نقشهٔ آنلاین مدل‌ها</h2><p class="hint dsOnlH" id="dsOnlH">در حال خواندن فهرست نقشه‌های روی هاست…</p>';
  if(box){ box.remove(); } else { box=document.createElement("div"); box.className="nvXfer"; box.id="nvXfer"; }
  sec.append(box); asd.prepend(sec);
  try{ for(const [f,e] of [["نقشهٔ آنلاین مدل‌ها","Online model maps"],["ورود دستی نقشه (PNG یا JPG)","Manual map input (PNG or JPG)"],["در حال خواندن فهرست نقشه‌های روی هاست…","Reading the list of maps on the host…"],
    ["فعلاً نقشهٔ بارش یا دمای ایران روی هاست نیست.","No Iran precipitation or temperature maps on the host yet."],["بخش آنلاین در دسترس نیست.","The online section is not available."],["فهرست نقشه‌ها خوانده نشد.","The map list could not be read."]]) I18N_EX.set(i18nNorm(f),e); }catch(e){}
  const man=asd.querySelector("#dsDrop"); if(man){ const s=man.closest("section"); if(s&&!s.id) s.id="dsManPanel"; try{ VPAGES.ds.keepAside=(VPAGES.ds.keepAside||[]).concat(["dsOnl","dsManPanel"]); }catch(e){} if(s&&!s.querySelector(".dsManTag")){ const t=document.createElement("div"); t.className="dsManTag"; t.textContent="ورود دستی نقشه (PNG یا JPG)"; s.prepend(t); } }
  let busy=false;
  async function ensure(){ const h=document.getElementById("dsOnlH");
    if(typeof ON==="undefined"||typeof onLoadManifest!=="function"){ if(h) h.textContent="بخش آنلاین در دسترس نیست."; return; }
    if(!ON.man&&!busy){ busy=true; try{ const msg=await onLoadManifest(); if(!ON.man&&h){ h.textContent=msg||"فهرست نقشه‌ها خوانده نشد."; return; } }finally{ busy=false; } }
    try{ nvXRender(); }catch(e){ console.warn("dsOnl",e); }
    if(h){ const has=box.innerHTML.trim(); h.hidden=!!has; if(!has&&ON.man) h.textContent="فعلاً نقشهٔ بارش یا دمای ایران روی هاست نیست."; } }
  const o=window.openDS; if(typeof o==="function"){ window.openDS=function(){ const r=o.apply(this,arguments); setTimeout(ensure,0); return r; }; }
  if(document.getElementById("dsApp")&&!document.getElementById("dsApp").hidden) setTimeout(ensure,0);
})();

/* ===== مختصات زیر نشانگر ماوس روی نقشهٔ صفحهٔ اصلی (مثل Google Earth و ArcGIS) =====
   درجهٔ اعشاری + درجه/دقیقه/ثانیه؛ در حالت تمام‌صفحه نمایشگر خودش (fsCoord) را دارد و این پنهان می‌شود. */
(function(){
  const dms=(v,p,n)=>{ const a=Math.abs(v), d=Math.floor(a), mf=(a-d)*60, m=Math.floor(mf), s=Math.round((mf-m)*60); let D=d,M=m,S=s; if(S===60){ S=0; M++; } if(M===60){ M=0; D++; }
    return `${D}°${String(M).padStart(2,"0")}′${String(S).padStart(2,"0")}″${v>=0?p:n}`; };
  let el=null, last=0;
  function hide(){ if(el) el.hidden=true; }
  document.addEventListener("pointermove",e=>{
    if(e.pointerType&&e.pointerType!=="mouse"&&e.pointerType!=="pen") return;
    const st=document.getElementById("nvStage");
    if(!st||!st.contains(e.target)||typeof NV==="undefined"||!NV.view||(typeof NVF!=="undefined"&&NVF.on)){ hide(); return; }
    const now=performance.now(); if(now-last<30) return; last=now;
    const r=st.getBoundingClientRect(), x=e.clientX-r.left, y=e.clientY-r.top, v=NV.view, lon=v.x0+x/v.k, lat=v.y0-y/v.k;
    if(!el||el.parentNode!==st){ el=document.createElement("div"); el.id="nvCoord"; el.className="nvCoord"; el.setAttribute("aria-hidden","true"); el.setAttribute("data-noi18n",""); st.append(el); }
    if(!(lat>-90&&lat<90&&isFinite(lon))){ hide(); return; }
    el.hidden=false; el.innerHTML=`<b>${dms(lat,"N","S")}  ${dms(lon,"E","W")}</b><span>${lat.toFixed(4)}, ${lon.toFixed(4)}</span>`;
  },{passive:true});
  document.addEventListener("pointerleave",hide,true);
  document.addEventListener("mouseout",e=>{ const st=document.getElementById("nvStage"); if(st&&!st.contains(e.relatedTarget)) hide(); },true);
})();
