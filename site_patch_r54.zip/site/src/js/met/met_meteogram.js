/* ===== متئوگرام چندمدلی (r53) — آزمایشگاه محاسبات =====
   داده: Open-Meteo (CC BY 4.0)، برای هر مدل یک درخواست جدا (اگر یک مدل برای این نقطه داده نداشت بقیه از دست نمی‌روند).
   همهٔ زمان‌ها به وقت ایران (timezone=Asia/Tehran). مقدار مفقود null می‌ماند و رسم نمی‌شود؛ هیچ مقداری ساخته یا صفر نمی‌شود.
   میانه فقط جایی رسم می‌شود که دست‌کم ۲ مدل مقدار دارند. نمودارها SVG خودمان است (نه کپی سایتی)؛ حالت برجسته با سایه و
   ستون‌های سه‌بعدی فقط جنبهٔ نمایشی دارد و روی مقدارها اثری ندارد. */
(function(M){
  "use strict";
  const MODELS = [
    ["ecmwf_ifs025", "ECMWF IFS", "#b91c1c"], ["ecmwf_aifs025_single", "ECMWF AIFS", "#f97316"], ["gfs_seamless", "GFS", "#2563eb"],
    ["icon_seamless", "ICON", "#059669"], ["gem_seamless", "GEM", "#7c3aed"], ["meteofrance_seamless", "ARPEGE", "#db2777"],
    ["ukmo_seamless", "UKMO", "#0891b2"], ["jma_seamless", "JMA", "#ca8a04"], ["cma_grapes_global", "CMA", "#65a30d"],
    ["bom_access_global", "ACCESS-G", "#64748b"], ["kma_seamless", "KMA", "#0d9488"]
  ];
  const HV = ["temperature_2m", "relative_humidity_2m", "wind_speed_10m", "wind_direction_10m", "wind_gusts_10m", "precipitation"];
  const KEY = {temperature_2m:"t", relative_humidity_2m:"rh", wind_speed_10m:"ws", wind_direction_10m:"wd", wind_gusts_10m:"wg", precipitation:"pr"};
  const fin = x => typeof x === "number" && isFinite(x);
  function url(lat, lon, id){
    return "https://api.open-meteo.com/v1/forecast?latitude=" + lat.toFixed(4) + "&longitude=" + lon.toFixed(4) + "&hourly=" + HV.join(",") +
      "&daily=precipitation_sum&models=" + id + "&forecast_days=16&timezone=Asia%2FTehran&wind_speed_unit=kmh&timeformat=iso8601";
  }
  async function fetchOne(lat, lon, id, signal){
    try{
      const r = await fetch(url(lat, lon, id), {signal}); let j = null; try{ j = await r.json(); }catch(e){}
      if(!r.ok || !j || j.error) return {id, ok:false, why:(j && j.reason) || ("HTTP " + r.status)};
      const H = j.hourly || {}, D = j.daily || {}, g = (o, k) => o[k + "_" + id] || o[k] || null;
      if(!Array.isArray(H.time)) return {id, ok:false, why:"no hourly"};
      const s = {}; for(const v of HV){ const a = g(H, v); s[KEY[v]] = Array.isArray(a) ? a.map(x => fin(x) ? x : null) : null; }
      const dp = g(D, "precipitation_sum");
      const any = s.t && s.t.some(fin);
      return {id, ok:!!any, why:any ? "" : "no data", time:H.time, s, dtime:Array.isArray(D.time) ? D.time : [], dpr:Array.isArray(dp) ? dp.map(x => fin(x) ? x : null) : null, elev:j.elevation};
    }catch(e){ return {id, ok:false, why:e.name === "AbortError" ? "timeout" : e.message}; }
  }
  /* دریافت همه و هم‌ترازکردن روی یک محور زمانی مشترک (اجتماع زمان‌ها) */
  async function fetchAll(lat, lon){
    const ac = new AbortController(), to = setTimeout(() => ac.abort(), 30000);
    try{
      const R = await Promise.all(MODELS.map(m => fetchOne(lat, lon, m[0], ac.signal)));
      const ok = R.filter(r => r.ok);
      const T = [...new Set([].concat(...ok.map(r => r.time)))].sort(), Ti = new Map(T.map((x, i) => [x, i]));
      const DT = [...new Set([].concat(...ok.map(r => r.dtime)))].sort(), Di = new Map(DT.map((x, i) => [x, i]));
      const mods = ok.map(r => { const m = MODELS.find(q => q[0] === r.id), o = {id:r.id, name:m[1], color:m[2], s:{}, dpr:new Array(DT.length).fill(null)};
        for(const k of Object.values(KEY)){ const a = new Array(T.length).fill(null), src = r.s[k]; if(src) r.time.forEach((x, i) => { a[Ti.get(x)] = src[i]; }); o.s[k] = a; }
        if(r.dpr) r.dtime.forEach((x, i) => { o.dpr[Di.get(x)] = r.dpr[i]; });
        /* بارش تجمعی: جمع ساعتی تا جایی که مدل داده دارد؛ بعد از آخرین مقدار null */
        let acc = 0, last = -1; o.s.pr.forEach((v, i) => { if(fin(v)) last = i; }); o.s.pc = o.s.pr.map((v, i) => { if(i > last) return null; if(fin(v)) acc += v; return +acc.toFixed(2); });
        return o; });
      const elev = (ok.find(r => fin(r.elev)) || {}).elev;
      return {lat, lon, elev, T, DT, mods, fail:R.filter(r => !r.ok).map(r => ({id:r.id, name:(MODELS.find(q => q[0] === r.id) || [])[1], why:r.why}))};
    } finally { clearTimeout(to); }
  }
  const median = a => { const v = a.filter(fin).sort((x, y) => x - y), n = v.length; if(n < 2) return null; return n % 2 ? v[(n - 1) / 2] : (v[n / 2 - 1] + v[n / 2]) / 2; };
  function niceTicks(lo, hi, n){
    if(!(hi > lo)){ hi = lo + 1; }
    const raw = (hi - lo) / n, p = Math.pow(10, Math.floor(Math.log10(raw))), f = raw / p, st = (f < 1.5 ? 1 : f < 3 ? 2 : f < 7 ? 5 : 10) * p;
    const a = Math.floor(lo / st) * st, b = Math.ceil(hi / st) * st, out = []; for(let v = a; v <= b + st * 1e-6; v += st) out.push(+v.toFixed(6)); return out;
  }
  function shade(hex, f){ const n = parseInt(hex.slice(1), 16); let r = n >> 16, g = (n >> 8) & 255, b = n & 255;
    const m = c => Math.round(f >= 0 ? c + (255 - c) * f : c * (1 + f)); return "rgb(" + m(r) + "," + m(g) + "," + m(b) + ")"; }
  /* ---------- زمان محلی (رشته‌های Open-Meteo به وقت ایران‌اند؛ بدون تبدیل منطقهٔ زمانی مرورگر) ---------- */
  const pt = s => { const y = +s.slice(0, 4), mo = +s.slice(5, 7), d = +s.slice(8, 10), h = +(s.slice(11, 13) || 0); return new Date(Date.UTC(y, mo - 1, d, h)); };
  const FMT = {
    fa:{wd:new Intl.DateTimeFormat("fa-IR", {weekday:"short", timeZone:"UTC"}), dm:new Intl.DateTimeFormat("fa-IR-u-ca-persian", {day:"numeric", month:"short", timeZone:"UTC"}), full:new Intl.DateTimeFormat("fa-IR-u-ca-persian", {weekday:"long", day:"numeric", month:"long", hour:"2-digit", minute:"2-digit", timeZone:"UTC", hour12:false}), day:new Intl.DateTimeFormat("fa-IR-u-ca-persian", {weekday:"long", day:"numeric", month:"long", timeZone:"UTC"})},
    en:{wd:new Intl.DateTimeFormat("en-GB", {weekday:"short", timeZone:"UTC"}), dm:new Intl.DateTimeFormat("en-GB", {day:"numeric", month:"short", timeZone:"UTC"}), full:new Intl.DateTimeFormat("en-GB", {weekday:"short", day:"numeric", month:"short", hour:"2-digit", minute:"2-digit", timeZone:"UTC", hour12:false}), day:new Intl.DateTimeFormat("en-GB", {weekday:"long", day:"numeric", month:"long", timeZone:"UTC"})}
  };
  function nowLocal(){ const p = new Intl.DateTimeFormat("en-CA", {timeZone:"Asia/Tehran", year:"numeric", month:"2-digit", day:"2-digit", hour:"2-digit", hour12:false}).formatToParts(new Date()), g = k => (p.find(x => x.type === k) || {}).value;
    return g("year") + "-" + g("month") + "-" + g("day") + "T" + String(+g("hour") % 24).padStart(2, "0") + ":00"; }
  const PARAMS = {
    t:{fa:"دما", en:"Temperature", u:"°C", k:"t", d:1},
    w:{fa:"باد", en:"Wind", u:"km/h", k:"ws", d:0},
    rh:{fa:"رطوبت نسبی", en:"Relative humidity", u:"%", k:"rh", d:0, lo:0, hi:100},
    pd:{fa:"بارش روزانه", en:"Daily precipitation", u:"mm", bar:true, d:1, lo:0},
    pc:{fa:"بارش تجمعی", en:"Accumulated precipitation", u:"mm", k:"pc", d:1, lo:0}
  };
  const esc = s => String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  let UID = 0;
  /* ---------- رسم ---------- */
  function render(host, D, pk, st){
    const en = st.en, L = en ? "en" : "fa", F = FMT[L], P = PARAMS[pk], vis = D.mods.filter(m => !st.hidden.has(m.id)), showMed = !st.hidden.has("median");
    const uid = "mg" + (++UID), box = host.getBoundingClientRect(), phone = (box.width || 900) < 640;
    const nT = D.T.length, nD = D.DT.length, perDay = phone ? 66 : 58;
    const W = Math.max(Math.round(box.width || 900), (P.bar ? nD : nT / 24) * perDay + 60), H = phone ? 320 : 380;
    const ml = 46, mr = 14, mt = 40, mb = 30, pw = W - ml - mr, ph = H - mt - mb;
    /* داده‌های این پارامتر */
    let series, xs, med, xi;
    if(P.bar){ series = vis.map(m => m.dpr); const gw = pw / Math.max(1, nD); xi = i => ml + gw * (i + 0.5); xs = gw;
      med = D.DT.map((_, i) => median(D.mods.map(m => m.dpr[i]))); }
    else { series = vis.map(m => m.s[P.k]); xi = i => ml + (nT > 1 ? pw * i / (nT - 1) : 0);
      med = D.T.map((_, i) => median(D.mods.map(m => m.s[P.k][i]))); }
    let lo = Infinity, hi = -Infinity; for(const a of series.concat(showMed ? [med] : [])) for(const v of a) if(fin(v)){ if(v < lo) lo = v; if(v > hi) hi = v; }
    const empty = !(hi >= lo); if(empty){ lo = 0; hi = 1; }
    if(P.lo != null) lo = Math.min(P.lo, lo); if(pk === "rh") hi = Math.min(100, hi);
    if(P.bar || pk === "pc") hi = Math.max(hi, 1);
    const pad = (hi - lo) * 0.08; let ticks = niceTicks(P.lo === 0 ? lo : lo - pad, hi + pad, phone ? 5 : 7); if(pk === "rh") ticks = ticks.filter(v => v >= 0 && v <= 100);
    const y0 = ticks[0], y1 = ticks[ticks.length - 1], yv = v => mt + ph - (v - y0) / (y1 - y0 || 1) * ph;
    const o = [];
    o.push('<svg xmlns="http://www.w3.org/2000/svg" class="mgSvg" width="' + W + '" height="' + H + '" viewBox="0 0 ' + W + " " + H + '" font-family="Vazirmatn,Tahoma,sans-serif" direction="ltr">');
    o.push('<defs><linearGradient id="' + uid + 'bg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#f8fbff"/><stop offset="1" stop-color="#eaf1fb"/></linearGradient>' +
      '<filter id="' + uid + 'sh" x="-5%" y="-20%" width="110%" height="140%"><feDropShadow dx="0" dy="1.6" stdDeviation="1.3" flood-color="#0f172a" flood-opacity=".28"/></filter>' +
      '<filter id="' + uid + 'in"><feOffset dy="2"/><feGaussianBlur stdDeviation="3" result="b"/><feComposite in="SourceGraphic" in2="b" operator="over"/></filter>' +
      '<linearGradient id="' + uid + 'sp" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#6366f1" stop-opacity=".22"/><stop offset="1" stop-color="#6366f1" stop-opacity=".06"/></linearGradient>');
    vis.forEach((m, i) => o.push('<linearGradient id="' + uid + "g" + i + '" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="' + shade(m.color, 0.35) + '"/><stop offset=".55" stop-color="' + m.color + '"/><stop offset="1" stop-color="' + shade(m.color, -0.15) + '"/></linearGradient>'));
    o.push("</defs>");
    o.push('<rect x="0" y="0" width="' + W + '" height="' + H + '" rx="14" fill="#fff"/>');
    o.push('<rect x="' + ml + '" y="' + mt + '" width="' + pw + '" height="' + ph + '" rx="8" fill="url(#' + uid + 'bg)" stroke="#dbe4f0"/>');
    /* شب‌ها (۱۸ تا ۰۶) کم‌رنگ و جداکنندهٔ روزها با برچسب روز هفته و تاریخ */
    if(!P.bar){
      let s0 = -1; for(let i = 0; i <= nT; i++){ const h = i < nT ? +D.T[i].slice(11, 13) : -1, night = h >= 18 || (h >= 0 && h < 6);
        if(night && s0 < 0) s0 = i; if((!night || i === nT) && s0 >= 0){ const xa = xi(s0), xb = xi(Math.min(i, nT - 1)); o.push('<rect x="' + xa.toFixed(1) + '" y="' + mt + '" width="' + Math.max(0, xb - xa).toFixed(1) + '" height="' + ph + '" fill="#1e3a8a" opacity=".045"/>'); s0 = -1; } }
      D.T.forEach((s, i) => { if(s.slice(11, 13) !== "00") return; const x = xi(i); o.push('<line x1="' + x.toFixed(1) + '" x2="' + x.toFixed(1) + '" y1="' + mt + '" y2="' + (mt + ph) + '" stroke="#94a3b8" stroke-width=".8" opacity=".55"/>');
        if(i + 12 < nT || i === 0){ const d = pt(s), xc = xi(Math.min(i + 12, nT - 1)); o.push('<text x="' + xc.toFixed(1) + '" y="16" text-anchor="middle" font-size="11.5" font-weight="700" fill="#334155">' + esc(F.wd.format(d)) + '</text><text x="' + xc.toFixed(1) + '" y="30" text-anchor="middle" font-size="10.5" fill="#64748b">' + esc(F.dm.format(d)) + "</text>"); } });
    } else {
      D.DT.forEach((s, i) => { const d = pt(s), x = xi(i); if(i) o.push('<line x1="' + (x - xs / 2).toFixed(1) + '" x2="' + (x - xs / 2).toFixed(1) + '" y1="' + mt + '" y2="' + (mt + ph) + '" stroke="#cbd5e1" stroke-width=".8"/>');
        o.push('<text x="' + x.toFixed(1) + '" y="16" text-anchor="middle" font-size="11.5" font-weight="700" fill="#334155">' + esc(F.wd.format(d)) + '</text><text x="' + x.toFixed(1) + '" y="30" text-anchor="middle" font-size="10.5" fill="#64748b">' + esc(F.dm.format(d)) + "</text>"); });
    }
    /* محور عمودی */
    for(const v of ticks){ const y = yv(v); o.push('<line x1="' + ml + '" x2="' + (ml + pw) + '" y1="' + y.toFixed(1) + '" y2="' + y.toFixed(1) + '" stroke="#cbd5e1" stroke-width="' + (v === 0 && pk === "t" ? 1.4 : .7) + '"' + (v === 0 && pk === "t" ? ' stroke-dasharray="4 3"' : "") + "/>");
      o.push('<text x="' + (ml - 6) + '" y="' + (y + 4).toFixed(1) + '" text-anchor="end" font-size="11" fill="#475569">' + (+v.toFixed(2)) + "</text>"); }
    o.push('<text x="8" y="' + (mt - 6) + '" font-size="11" font-weight="700" fill="#475569">' + esc(P.u) + "</text>");
    /* «اکنون» */
    if(!P.bar){ const nw = nowLocal(), k = D.T.indexOf(nw); if(k >= 0){ const x = xi(k); o.push('<line x1="' + x.toFixed(1) + '" x2="' + x.toFixed(1) + '" y1="' + mt + '" y2="' + (mt + ph) + '" stroke="#dc2626" stroke-width="1.2" stroke-dasharray="3 3"/><text x="' + (x + 3).toFixed(1) + '" y="' + (mt + 12) + '" font-size="10" fill="#dc2626">' + (en ? "now" : "اکنون") + "</text>"); } }
    if(empty) o.push('<text x="' + (ml + pw / 2) + '" y="' + (mt + ph / 2) + '" text-anchor="middle" font-size="14" fill="#64748b">' + (en ? "No data for the selected models" : "برای مدل‌های انتخابی داده‌ای نیست") + "</text>");
    else if(P.bar){
      /* ستون‌های سه‌بعدی: هر روز یک گروه، هر مدل یک ستون */
      const n = Math.max(1, vis.length), bw = Math.max(1.5, xs * 0.82 / n), dep = Math.min(5, Math.max(1.2, bw * 0.45)), base = yv(Math.max(0, y0));
      D.DT.forEach((_, i) => { const gx = xi(i) - bw * n / 2;
        vis.forEach((m, j) => { const v = m.dpr[i]; if(!fin(v)) return; const x = gx + j * bw, y = yv(v), h = base - y; if(h < 0.5){ o.push('<rect x="' + x.toFixed(1) + '" y="' + (base - 1).toFixed(1) + '" width="' + (bw - .4).toFixed(1) + '" height="1" fill="' + m.color + '" opacity=".5"/>'); return; }
          const w = bw - Math.min(.6, bw * .15);
          o.push('<g><rect x="' + x.toFixed(1) + '" y="' + y.toFixed(1) + '" width="' + w.toFixed(1) + '" height="' + h.toFixed(1) + '" fill="url(#' + uid + "g" + j + ')"/>' +
            '<polygon points="' + [x, y, x + dep, y - dep, x + w + dep, y - dep, x + w, y].map(q => q.toFixed(1)).join(" ") + '" fill="' + shade(m.color, 0.5) + '"/>' +
            '<polygon points="' + [x + w, y, x + w + dep, y - dep, x + w + dep, base - dep, x + w, base].map(q => q.toFixed(1)).join(" ") + '" fill="' + shade(m.color, -0.35) + '"/></g>'); });
        const mv = med[i]; if(showMed && fin(mv)){ const y = yv(mv), xa = gx - 2, xb = gx + bw * n + dep + 2; o.push('<line x1="' + xa.toFixed(1) + '" x2="' + xb.toFixed(1) + '" y1="' + y.toFixed(1) + '" y2="' + y.toFixed(1) + '" stroke="#fff" stroke-width="5" stroke-linecap="round"/><line x1="' + xa.toFixed(1) + '" x2="' + xb.toFixed(1) + '" y1="' + y.toFixed(1) + '" y2="' + y.toFixed(1) + '" stroke="#0f172a" stroke-width="2.6" stroke-linecap="round" filter="url(#' + uid + 'sh)"/>');
          if(mv >= 0.1) o.push('<text x="' + xi(i).toFixed(1) + '" y="' + (y - dep - 5).toFixed(1) + '" text-anchor="middle" font-size="10.5" font-weight="700" fill="#0f172a" paint-order="stroke" stroke="#fff" stroke-width="3">' + mv.toFixed(1) + "</text>"); } });
    } else {
      /* محدودهٔ پراکندگی مدل‌ها (کمینه تا بیشینه) */
      const env = []; for(let i = 0; i < nT; i++){ const v = series.map(a => a[i]).filter(fin); env.push(v.length >= 2 ? [Math.min(...v), Math.max(...v)] : null); }
      let seg = []; const flush = () => { if(seg.length > 1){ const up = seg.map(i => xi(i).toFixed(1) + "," + yv(env[i][1]).toFixed(1)), dn = seg.slice().reverse().map(i => xi(i).toFixed(1) + "," + yv(env[i][0]).toFixed(1)); o.push('<polygon points="' + up.concat(dn).join(" ") + '" fill="url(#' + uid + 'sp)"/>'); } seg = []; };
      env.forEach((e, i) => { if(e) seg.push(i); else flush(); }); flush();
      const path = a => { let d = "", pen = false; a.forEach((v, i) => { if(fin(v)){ d += (pen ? "L" : "M") + xi(i).toFixed(1) + " " + yv(v).toFixed(1); pen = true; } else pen = false; }); return d; };
      o.push('<g filter="url(#' + uid + 'sh)" fill="none" stroke-linejoin="round" stroke-linecap="round">');
      vis.forEach((m, j) => { const d = path(series[j]); if(d) o.push('<path d="' + d + '" stroke="' + m.color + '" stroke-width="' + (phone ? 1.5 : 1.7) + '" opacity=".9"/>'); });
      o.push("</g>");
      if(showMed){ const d = path(med); if(d) o.push('<path d="' + d + '" fill="none" stroke="#fff" stroke-width="6.5" stroke-linejoin="round" stroke-linecap="round" opacity=".9"/><path d="' + d + '" fill="none" stroke="#0f172a" stroke-width="3.2" stroke-linejoin="round" stroke-linecap="round" filter="url(#' + uid + 'sh)"/>'); }
      /* باد: پیکان جهت میانهٔ مدل‌ها (میانگین برداری) هر ۶ ساعت، بالای کادر */
      if(pk === "w"){ for(let i = 0; i < nT; i += (phone ? 12 : 6)){ let u = 0, v = 0, c = 0; for(const m of D.mods){ const s = m.s.ws[i], dd = m.s.wd[i]; if(fin(s) && fin(dd)){ const r = dd * Math.PI / 180; u += -s * Math.sin(r); v += -s * Math.cos(r); c++; } }
          if(c < 2) continue; const dir = (Math.atan2(-u, -v) * 180 / Math.PI + 360) % 360, x = xi(i), y = mt + 14;
          o.push('<g transform="translate(' + x.toFixed(1) + "," + y + ") rotate(" + (dir + 180).toFixed(0) + ')"><path d="M0 -7 L4 3 L0 1 L-4 3 Z" fill="#0f172a" opacity=".75"/></g>'); } }
    }
    o.push('<line class="mgX" x1="0" x2="0" y1="' + mt + '" y2="' + (mt + ph) + '" stroke="#0f172a" stroke-width="1" opacity="0"/>');
    o.push('<text x="' + (W - 8) + '" y="' + (H - 8) + '" text-anchor="end" font-size="10" fill="#94a3b8">Open-Meteo.com · CC BY 4.0 · MetStat</text>');
    o.push("</svg>");
    host.innerHTML = '<div class="mgScroll">' + o.join("") + '<div class="mgTip" hidden></div></div>';
    const sc = host.querySelector(".mgScroll"), sv = sc.querySelector("svg"), tip = sc.querySelector(".mgTip"), xl = sv.querySelector(".mgX");
    /* خواندن مقدار: حرکت نشانگر یا لمس */
    function at(ev){
      const r = sv.getBoundingClientRect(), x = (ev.clientX - r.left) * W / r.width; if(x < ml - 4 || x > ml + pw + 4){ tip.hidden = true; xl.setAttribute("opacity", 0); return; }
      let i, lab;
      if(P.bar){ i = Math.max(0, Math.min(nD - 1, Math.floor((x - ml) / xs))); lab = F.day.format(pt(D.DT[i])); }
      else { i = Math.max(0, Math.min(nT - 1, Math.round((x - ml) / pw * (nT - 1)))); lab = F.full.format(pt(D.T[i])); }
      const X = xi(i); xl.setAttribute("x1", X); xl.setAttribute("x2", X); xl.setAttribute("opacity", .45);
      const rows = vis.map((m, j) => [m, series[j][i]]).filter(q => fin(q[1])).sort((a, b) => b[1] - a[1]);
      const fmt = v => v.toFixed(P.d);
      let h = '<b>' + esc(lab) + "</b>";
      if(showMed && fin(med[i])) h += '<div class="mgTr mgTm"><i style="background:#0f172a"></i><span>' + (en ? "Median" : "میانه") + "</span><b>" + fmt(med[i]) + " " + P.u + "</b></div>";
      h += rows.map(([m, v]) => { let ex = ""; if(pk === "w"){ const g = m.s.wg[i], d = m.s.wd[i]; ex = [fin(g) ? "<bdi>" + (en ? "G " : "تندباد ") + g.toFixed(0) + "</bdi>" : "", fin(d) ? '<bdi dir="ltr">' + d.toFixed(0) + "°</bdi>" : ""].filter(Boolean).join(" · "); }
        return '<div class="mgTr"><i style="background:' + m.color + '"></i><span>' + esc(m.name) + "</span><b>" + fmt(v) + " " + P.u + "</b><small>" + ex + "</small></div>"; }).join("") || '<div class="mgTr">' + (en ? "no value" : "بدون مقدار") + "</div>";
      tip.innerHTML = h; tip.hidden = false;
      const px = X * r.width / W + (r.left - sc.getBoundingClientRect().left) + sc.scrollLeft, tw = tip.offsetWidth, sw = sc.scrollLeft + sc.clientWidth;
      tip.style.left = Math.max(sc.scrollLeft + 4, Math.min(sw - tw - 4, px + 14 + tw > sw ? px - tw - 14 : px + 14)) + "px"; tip.style.top = (mt + 6) + "px";
    }
    sv.addEventListener("pointermove", at); sv.addEventListener("pointerdown", at);
    sv.addEventListener("pointerleave", e => { if(e.pointerType === "mouse"){ tip.hidden = true; xl.setAttribute("opacity", 0); } });
    /* روی گوشی کادر به «اکنون» اسکرول شود */
    if(sc.scrollWidth > sc.clientWidth && !P.bar){ const k = D.T.indexOf(nowLocal()); if(k > 0) sc.scrollLeft = Math.max(0, xi(k) - 40); }
    return sv;
  }
  M.mg = {MODELS, PARAMS, fetchAll, render, median, url};
})(globalThis.MET = globalThis.MET || {});
