/* ===== شاخص‌های اقلیمی درون صفحهٔ اصلی (r54) =====
   زبانهٔ «شاخص‌های اقلیمی» کنار «نقشه‌های ثانویه» در بخش پارامترِ نمایشگر. با زدن یک شاخص، کادر نقشه محو و کادر شاخص
   (نمودار تعاملی، فاز فعلی، پیش‌بینی، گزارش و اطلاعات علمی) نشان داده می‌شود؛ با انتخاب دوبارهٔ یک پارامتر نقشه‌ای، کادر نقشه برمی‌گردد.
   داده: online/data/idx/index.json + <id>.json (سری عددی کوچک، از indices.py r54) و PNGهای قبلی به‌عنوان جایگزین.
   فهرست هر مدل: پیش‌بینی‌های روزانهٔ همان مدل (mdl؛ مثلاً GEFS برای GFS) + شاخص‌های مشاهداتی ماهانه (برای همهٔ مدل‌ها).
   هیچ سری عددی ساخته یا درون‌یابی نمی‌شود؛ مقدار مفقود null می‌ماند و رسم نمی‌شود. */
const CIV={idx:null, at:0, sel:null, per:{}, ser:new Map(), tok:0, rep:false, info:false};
const civEN=()=>typeof LANG!=="undefined"&&LANG==="en";
const civT=(fa,en)=>civEN()?en:fa;
const civEsc=s=>String(s==null?"":s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
const civFin=x=>typeof x==="number"&&isFinite(x);
const civN=(v,d)=>civFin(v)?"\u2066"+(typeof FA==="function"?FA(v.toFixed(d==null?2:d)):v.toFixed(d==null?2:d))+"\u2069":"—";
async function civLoad(force){
  if(CIV.idx&&!force&&Date.now()-CIV.at<600000) return CIV.idx;
  try{ const r=await fetch(ON.base+"data/idx/index.json?"+Date.now(),{cache:"no-store"}); if(!r.ok) throw 0; CIV.idx=await r.json(); try{ if(typeof CI!=="undefined"&&!CI.idx) CI.idx=CIV.idx; }catch(e){} }
  catch(e){ CIV.idx=CIV.idx||{items:{}, err:1}; }
  CIV.at=Date.now(); return CIV.idx; }
function civMdl(id,e){ if(e&&e.mdl) return e.mdl; const m=/_(gefs|gfs|ecmwf|ec|aifs)$/.exec(id); return m?({gefs:"gfs",ec:"ecmwf"}[m[1]]||m[1]):""; }
function civFits(mdl,m){ m=String(m||"").toLowerCase(); if(!mdl) return true;
  if(mdl==="gfs") return /gfs|gefs/.test(m); if(mdl==="ecmwf") return /ecmwf|ifs|aifs|ec46|^ens/.test(m); return m.indexOf(mdl)===0; }
function civEnt(id){ const e=CIV.idx&&CIV.idx.items&&CIV.idx.items[id]; return e?Object.assign({id},e):null; }
function civGroups(m){
  const it=(CIV.idx&&CIV.idx.items)||{}, ids=Object.keys(it), own=[], obs=new Map();
  for(const id of ids){ const md=civMdl(id,it[id]); if(md){ if(civFits(md,m)) own.push(id); continue; } const g=it[id].grp||civT("شاخص‌ها","Indices"); if(!obs.has(g)) obs.set(g,[]); obs.get(g).push(id); }
  const out=[]; if(own.length) out.push(["own",civT("پیش‌بینی روزانهٔ همین مدل","Daily forecast from this model"),own]);
  for(const [g,L] of obs) out.push(["o:"+g,civT("مشاهداتی — ","Observed — ")+g,L]); return out; }
function civName(id){ const e=civEnt(id); if(!e) return id; if(civEN()) return (e.en||id).replace(/ · (GEFS ensemble forecast|ECMWF ENS \(MetStat-computed\))$/,"").trim()+(e.kind==="plume"?(e.mdl==="ecmwf"||/ecmwf/i.test(e.src||"")?" (ECMWF · MetStat-computed)":" (GEFS)"):""); return e.kind!=="plume"&&e.fa?e.fa:ciMeta(e).fa; }
/* محتوای زبانهٔ پارامتر (از nvWx در 41_nwp_viewer.js صدا زده می‌شود) */
function niParHTML(){
  if(!CIV.idx){ civLoad().then(()=>{ if(NVW.ptab==="ci") nvWx(); }); return `<div class="hint">${civT("در حال دریافت فهرست شاخص‌ها…","Loading the list of indices…")}</div>`; }
  const G=civGroups(NV.s.m); if(!G.length) return `<div class="hint">${civT("هنوز شاخصی روی هاست نیست (workflow شاخص‌ها را اجرا کنید).","No indices on the host yet (run the indices workflow).")}</div>`;
  const head=`<div class="hint">${civT("با زدن هر شاخص، کادر نقشه کنار می‌رود و نمودار شاخص می‌آید؛ با انتخاب یک پارامتر نقشه‌ای، نقشه برمی‌گردد.","Pick an index to swap the map for its chart; pick any map parameter to bring the map back.")}</div>`;
  return head+G.map(([k,t,L])=>{ const st=NVW.cg.ci, open=st===undefined?(k==="own"||L.includes(CIV.sel)||(!G.some(g=>g[0]==="own")&&k===G[0][0])):st===k;
    return `<button type="button" class="wxCat wxCatB${open?" on":""}" data-cg="ci|${civEsc(k)}" aria-expanded="${open}"><span>${civEsc(t)}</span><svg class="wxCh" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg></button>`+
      (open?`<div class="wxRow">${L.map(id=>wxChip(civEsc(civName(id)),CIV.sel===id,`data-ci="${id}"`)).join("")}</div>`:""); }).join(""); }

/* ---------- باز/بستن کادر شاخص ---------- */
function civCard(){ return document.querySelector("#onViewer .nvCard")||document.querySelector(".nvCard"); }
function civPanel(){ let p=$("civPanel"); const c=civCard(); if(!c) return null;
  if(!p){ p=document.createElement("article"); p.id="civPanel"; p.className="card wide civCard"; p.hidden=true; p.setAttribute("data-noi18n",""); c.after(p);
    p.addEventListener("click",civClick); }
  else if(p.previousElementSibling!==c) c.after(p);
  return p; }
function civFade(el,show){ if(!el) return; clearTimeout(el._fd);
  if(show){ el.hidden=false; el.classList.add("civFadeOut"); requestAnimationFrame(()=>requestAnimationFrame(()=>el.classList.remove("civFadeOut"))); }
  else { el.classList.add("civFadeOut"); el._fd=setTimeout(()=>{ el.hidden=true; el.classList.remove("civFadeOut"); },230); } }
async function civOpen(id){
  await civLoad(); const e=civEnt(id); if(!e) return; CIV.sel=id; CIV.rep=false; CIV.info=false;
  const p=civPanel(), c=civCard(); if(!p) return;
  try{ if(NV.anim){ $("nvPlay").click(); } }catch(_){}
  civFade(c,false); setTimeout(()=>{ civFade(p,true); },c&&!c.hidden?220:0);
  civRender(); if(NVW.ptab==="ci") nvWx();
  try{ const r=p.getBoundingClientRect(); if(r.top<0||r.top>innerHeight*.6) setTimeout(()=>p.scrollIntoView({behavior:"smooth",block:"start"}),260); }catch(_){}
}
function civClose(){ if(!CIV.sel&&($("civPanel")||{}).hidden!==false) return; CIV.sel=null; const p=$("civPanel"), c=civCard();
  civFade(p,false); setTimeout(()=>{ civFade(c,true); setTimeout(()=>{ try{ NV.view=NV.view||null; nvResize(); nvDraw(); nvLegend(); }catch(_){ } },40); },p&&!p.hidden?220:0);
  if(NVW.ptab==="ci") try{ nvWx(); }catch(_){} }
window.civClose=civClose; window.civOpen=civOpen;
/* رویدادها: زدن شاخص در زبانه، یا بازگشت با هر پارامتر نقشه‌ای */
document.addEventListener("click",e=>{ const box=$("nvWx"); if(!box||!box.contains(e.target)) return; const b=e.target.closest("button"); if(!b) return;
  if(b.dataset.ci){ e.stopPropagation(); civOpen(b.dataset.ci); return; }
  if(b.dataset.p&&CIV.sel) civClose();
  if(b.dataset.m&&CIV.sel){ setTimeout(()=>{ const e2=civEnt(CIV.sel); if(e2&&!civFits(civMdl(CIV.sel,e2),NV.s.m)) civClose(); },60); } },true);
document.addEventListener("change",e=>{ if(CIV.sel&&e.target&&(e.target.id==="nvP"||e.target.id==="nvCat")) civClose(); },true);

/* ---------- سری عددی ---------- */
async function civSer(e){ if(!e.ser) return null; const k=e.id+"|"+((CIV.idx&&CIV.idx.updated)||""); if(CIV.ser.has(k)) return CIV.ser.get(k);
  const pr=fetch(ON.base+"data/idx/"+e.id+".json?"+((CIV.idx&&CIV.idx.updated)||Date.now()),{cache:"no-store"}).then(r=>r.ok?r.json():null).catch(()=>null);
  CIV.ser.set(k,pr); return pr; }
const civD=s=>{ const y=+s.slice(0,4), m=+s.slice(5,7), d=+(s.slice(8,10)||15); return new Date(Date.UTC(y,m-1,d)); };
const CIV_F={fa:{d:new Intl.DateTimeFormat("fa-IR-u-ca-persian",{day:"numeric",month:"short",timeZone:"UTC"}), dl:{format:d=>new Intl.DateTimeFormat("fa-IR",{weekday:"long",timeZone:"UTC"}).format(d)+" "+new Intl.DateTimeFormat("fa-IR-u-ca-persian",{day:"numeric",month:"long",year:"numeric",timeZone:"UTC"}).format(d)}, m:new Intl.DateTimeFormat("fa-IR-u-ca-persian",{month:"long",year:"numeric",timeZone:"UTC"}), y:new Intl.DateTimeFormat("fa-IR-u-ca-persian",{year:"numeric",timeZone:"UTC"})},
  en:{d:new Intl.DateTimeFormat("en-GB",{day:"numeric",month:"short",timeZone:"UTC"}), dl:new Intl.DateTimeFormat("en-GB",{weekday:"short",day:"numeric",month:"long",year:"numeric",timeZone:"UTC"}), m:new Intl.DateTimeFormat("en-GB",{month:"long",year:"numeric",timeZone:"UTC"}), y:new Intl.DateTimeFormat("en-GB",{year:"numeric",timeZone:"UTC"})}};
const CIV_GM=new Intl.DateTimeFormat("en-GB",{month:"short",year:"numeric",timeZone:"UTC"});
function civPhaseOf(e,v){ return ciPhase({id:e.id,en:e.en,fa:e.fa,kind:e.kind,val:v}); }
function civTicks(lo,hi,n){ if(!(hi>lo)) hi=lo+1; const raw=(hi-lo)/n, p=Math.pow(10,Math.floor(Math.log10(raw))), f=raw/p, st=(f<1.5?1:f<3?2:f<7?5:10)*p, out=[]; for(let v=Math.floor(lo/st)*st; v<=hi+st*1e-6; v+=st) out.push(+v.toFixed(6)); return out; }

/* ---------- رسم نمودار (SVG؛ حالت برجسته با سایه و ستون‌های سه‌بعدی، فقط نمایشی) ---------- */
function civChart(host,e,S,per){
  const en=civEN(), F=CIV_F[en?"en":"fa"], M=ciMeta(e), thr=(M.th&&M.th[0])||0.5;
  const W0=Math.max(320,Math.round(host.getBoundingClientRect().width||900)), phone=W0<640, W=W0, H=phone?300:380, ml=40, mr=12, mt=26, mb=34, pw=W-ml-mr, ph=H-mt-mb;
  const o=[], uid="cv"+(++CIV.tok);
  let X=[], kind=S.kind, obs=[], fc=null, nObs=0, xs;
  if(kind==="plume"){ const days=+(String(per).replace(/\D/g,""))||60, ot=S.obs.t.slice(-days), ov=S.obs.v.slice(-days); nObs=ot.length;
    obs=ot.map((t,i)=>({t,v:ov[i]}));
    if(S.fc){ const i0=civD(S.fc.init); fc={t:S.fc.lead.map(l=>{ const d=new Date(i0.getTime()+l*864e5); return d.toISOString().slice(0,10); }), mean:S.fc.mean, mem:S.fc.mem}; }
    const all=[...new Set(obs.map(q=>q.t).concat(fc?fc.t:[]))].sort(); X=all; }
  else { const yrs={all:999,y30:30,y10:10,y3:3}[per]||30, n=Math.min(S.t.length,yrs*12); X=S.t.slice(-n); obs=X.map((t,i)=>({t,v:S.v[S.v.length-n+i]})); nObs=n; }
  const Xi=new Map(X.map((t,i)=>[t,i])), N=X.length; xs=pw/Math.max(1,N);
  const xi=i=>ml+xs*(i+.5);
  let lo=Infinity, hi=-Infinity; const acc=v=>{ if(civFin(v)){ if(v<lo) lo=v; if(v>hi) hi=v; } };
  obs.forEach(q=>acc(q.v)); if(fc){ fc.mem.forEach(r=>r.forEach(acc)); fc.mean.forEach(acc); }
  if(!(hi>=lo)){ lo=-1; hi=1; } const sym=Math.max(Math.abs(lo),Math.abs(hi),thr*1.4); if(kind!=="line"){ lo=-sym; hi=sym; }
  const tk=civTicks(lo-(hi-lo)*.04,hi+(hi-lo)*.04,phone?5:7), y0=tk[0], y1=tk[tk.length-1], yv=v=>mt+ph-(v-y0)/(y1-y0||1)*ph, zero=yv(Math.max(y0,Math.min(y1,0)));
  o.push(`<svg xmlns="http://www.w3.org/2000/svg" class="civSvg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" font-family="Vazirmatn,Tahoma,sans-serif" direction="ltr">`);
  o.push(`<defs><linearGradient id="${uid}bg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#f8fbff"/><stop offset="1" stop-color="#eaf1fb"/></linearGradient>
    <linearGradient id="${uid}p" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#fca5a5"/><stop offset=".55" stop-color="#dc2626"/><stop offset="1" stop-color="#991b1b"/></linearGradient>
    <linearGradient id="${uid}n" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#93c5fd"/><stop offset=".55" stop-color="#2563eb"/><stop offset="1" stop-color="#1e3a8a"/></linearGradient>
    <linearGradient id="${uid}ap" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#dc2626" stop-opacity=".38"/><stop offset="1" stop-color="#dc2626" stop-opacity=".04"/></linearGradient>
    <linearGradient id="${uid}an" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#2563eb" stop-opacity=".38"/><stop offset="1" stop-color="#2563eb" stop-opacity=".04"/></linearGradient>
    <linearGradient id="${uid}sp" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#7c3aed" stop-opacity=".26"/><stop offset="1" stop-color="#7c3aed" stop-opacity=".08"/></linearGradient>
    <filter id="${uid}sh" x="-5%" y="-20%" width="110%" height="140%"><feDropShadow dx="0" dy="1.6" stdDeviation="1.3" flood-color="#0f172a" flood-opacity=".3"/></filter>
    <clipPath id="${uid}cl"><rect x="${ml}" y="${mt}" width="${pw}" height="${ph}"/></clipPath></defs>`);
  o.push(`<rect x="0" y="0" width="${W}" height="${H}" rx="14" fill="#fff"/><rect x="${ml}" y="${mt}" width="${pw}" height="${ph}" rx="8" fill="url(#${uid}bg)" stroke="#dbe4f0"/>`);
  /* نوار آستانه‌ها */
  if(kind!=="line") for(const s of [1,-1]){ const ya=yv(s*thr); o.push(`<line x1="${ml}" x2="${ml+pw}" y1="${ya.toFixed(1)}" y2="${ya.toFixed(1)}" stroke="${s>0?"#dc2626":"#2563eb"}" stroke-width="1" stroke-dasharray="5 4" opacity=".55"/>`); }
  for(const v of tk){ const y=yv(v); o.push(`<line x1="${ml}" x2="${ml+pw}" y1="${y.toFixed(1)}" y2="${y.toFixed(1)}" stroke="#cbd5e1" stroke-width="${v===0?1.3:.6}"/><text x="${ml-6}" y="${(y+4).toFixed(1)}" text-anchor="end" font-size="11" fill="#475569">${+v.toFixed(2)}</text>`); }
  /* برچسب‌های زمان */
  if(kind==="plume"){ const step=Math.max(1,Math.ceil(N/(phone?6:12))); X.forEach((t,i)=>{ if(i%step) return; const x=xi(i); o.push(`<line x1="${x.toFixed(1)}" x2="${x.toFixed(1)}" y1="${mt+ph}" y2="${mt+ph+4}" stroke="#94a3b8"/><text x="${x.toFixed(1)}" y="${H-14}" text-anchor="middle" font-size="10.5" fill="#475569">${civEsc(F.d.format(civD(t)))}</text>`); }); }
  else { let ly=""; X.forEach((t,i)=>{ const y=t.slice(0,4), m=+t.slice(5,7); const span=N/12, every=span>24?5:span>10?2:1; if(m===1&&(+y)%every===0&&y!==ly){ ly=y; const x=ml+xs*i; o.push(`<line x1="${x.toFixed(1)}" x2="${x.toFixed(1)}" y1="${mt}" y2="${mt+ph}" stroke="#94a3b8" stroke-width=".6" opacity=".5"/><text x="${(x+2).toFixed(1)}" y="${H-14}" font-size="10.5" fill="#475569">${y}</text>`); } }); }
  o.push(`<g clip-path="url(#${uid}cl)">`);
  if(kind==="plume"){
    /* تحلیل: ستون‌های سه‌بعدی روزانه (قرمز مثبت، آبی منفی) */
    const bw=Math.max(1.2,xs*.72), dep=Math.min(4,Math.max(.8,bw*.4));
    obs.forEach(q=>{ if(!civFin(q.v)) return; const i=Xi.get(q.t), x=xi(i)-bw/2, y=yv(q.v), pos=q.v>=0, top=Math.min(y,zero), h=Math.abs(zero-y); if(h<.4) return; const c=pos?"#dc2626":"#2563eb";
      o.push(`<rect x="${x.toFixed(1)}" y="${top.toFixed(1)}" width="${bw.toFixed(1)}" height="${h.toFixed(1)}" fill="url(#${uid}${pos?"p":"n"})"/>`+(pos?`<polygon points="${[x,y,x+dep,y-dep,x+bw+dep,y-dep,x+bw,y].map(n=>n.toFixed(1)).join(" ")}" fill="${pos?"#fecaca":"#bfdbfe"}"/>`:"")+`<polygon points="${[x+bw,top,x+bw+dep,top-dep,x+bw+dep,top+h-dep,x+bw,top+h].map(n=>n.toFixed(1)).join(" ")}" fill="${pos?"#7f1d1d":"#1e3a8a"}" opacity=".85"/>`); });
    if(fc){ const fx=fc.t.map(t=>Xi.get(t));
      /* بازهٔ ۱۰ تا ۹۰ درصد اعضا */
      const q=(a,p)=>{ const s=a.filter(civFin).sort((x,y)=>x-y); if(s.length<3) return null; const k=(s.length-1)*p, f=Math.floor(k); return s[f]+(s[Math.min(f+1,s.length-1)]-s[f])*(k-f); };
      const P10=fc.t.map((_,j)=>q(fc.mem.map(r=>r[j]),.1)), P90=fc.t.map((_,j)=>q(fc.mem.map(r=>r[j]),.9)); fc.p10=P10; fc.p90=P90;
      const up=[], dn=[]; fc.t.forEach((_,j)=>{ if(civFin(P10[j])&&civFin(P90[j])){ up.push(xi(fx[j]).toFixed(1)+","+yv(P90[j]).toFixed(1)); dn.unshift(xi(fx[j]).toFixed(1)+","+yv(P10[j]).toFixed(1)); } });
      const x0=xi(fx[0]); o.push(`<rect x="${(x0-xs/2).toFixed(1)}" y="${mt}" width="${(ml+pw-(x0-xs/2)).toFixed(1)}" height="${ph}" fill="#7c3aed" opacity=".035"/>`);
      if(up.length>1) o.push(`<polygon points="${up.concat(dn).join(" ")}" fill="url(#${uid}sp)"/>`);
      const path=a=>{ let d="",pen=false; a.forEach((v,j)=>{ if(civFin(v)){ d+=(pen?"L":"M")+xi(fx[j]).toFixed(1)+" "+yv(v).toFixed(1); pen=true; } else pen=false; }); return d; };
      o.push(`<g fill="none" stroke-linejoin="round" stroke-linecap="round">`+fc.mem.map(r=>{ const d=path(r); return d?`<path d="${d}" stroke="#6366f1" stroke-width=".9" opacity=".32"/>`:""; }).join("")+`</g>`);
      const md=path(fc.mean); if(md) o.push(`<path d="${md}" fill="none" stroke="#fff" stroke-width="6.5" stroke-linejoin="round" stroke-linecap="round"/><path d="${md}" fill="none" stroke="#0f172a" stroke-width="3" stroke-linejoin="round" stroke-linecap="round" filter="url(#${uid}sh)"/>`);
      o.push(`<line x1="${(x0-xs/2).toFixed(1)}" x2="${(x0-xs/2).toFixed(1)}" y1="${mt}" y2="${mt+ph}" stroke="#7c3aed" stroke-width="1.3" stroke-dasharray="4 3"/><text x="${(x0-xs/2+4).toFixed(1)}" y="${mt+13}" font-size="10.5" font-weight="700" fill="#6d28d9">${civT("پیش‌بینی","forecast")} →</text>`); }
  } else if(kind==="line"){
    let d="",pen=false; obs.forEach((q,i)=>{ if(civFin(q.v)){ d+=(pen?"L":"M")+xi(i).toFixed(1)+" "+yv(q.v).toFixed(1); pen=true; } else pen=false; });
    o.push(`<path d="${d}L${xi(N-1).toFixed(1)} ${zero.toFixed(1)}L${xi(0).toFixed(1)} ${zero.toFixed(1)}Z" fill="url(#${uid}ap)" opacity=".7"/><path d="${d}" fill="none" stroke="#fff" stroke-width="5"/><path d="${d}" fill="none" stroke="#7c3aed" stroke-width="2.2" filter="url(#${uid}sh)"/>`);
  } else {
    const bw=Math.max(.8,xs*.78), dep=Math.min(4,Math.max(0,bw*.38));
    obs.forEach((q,i)=>{ if(!civFin(q.v)) return; const x=xi(i)-bw/2, y=yv(q.v), pos=q.v>=0, top=Math.min(y,zero), h=Math.abs(zero-y); if(h<.3) return;
      o.push(`<rect x="${x.toFixed(1)}" y="${top.toFixed(1)}" width="${bw.toFixed(1)}" height="${h.toFixed(1)}" fill="url(#${uid}${pos?"p":"n"})"/>`+(dep>=1?(pos?`<polygon points="${[x,y,x+dep,y-dep,x+bw+dep,y-dep,x+bw,y].map(n=>n.toFixed(1)).join(" ")}" fill="#fecaca"/>`:"")+`<polygon points="${[x+bw,top,x+bw+dep,top-dep,x+bw+dep,top+h-dep,x+bw,top+h].map(n=>n.toFixed(1)).join(" ")}" fill="${pos?"#7f1d1d":"#1e3a8a"}" opacity=".85"/>`:"")); });
    /* میانگین متحرک ۱۲ ماهه */
    if(N>=24){ let d="",pen=false; obs.forEach((q,i)=>{ if(i<11){ pen=false; return; } const w=obs.slice(i-11,i+1).map(z=>z.v).filter(civFin); if(w.length<9){ pen=false; return; } const m=w.reduce((a,b)=>a+b,0)/w.length; d+=(pen?"L":"M")+xi(i).toFixed(1)+" "+yv(m).toFixed(1); pen=true; });
      if(d) o.push(`<path d="${d}" fill="none" stroke="#fff" stroke-width="5" stroke-linejoin="round"/><path d="${d}" fill="none" stroke="#0f172a" stroke-width="2.2" stroke-linejoin="round" filter="url(#${uid}sh)"/>`); }
  }
  o.push(`</g><line class="civX" x1="0" x2="0" y1="${mt}" y2="${mt+ph}" stroke="#0f172a" stroke-width="1" opacity="0"/>`);
  o.push(`<text x="${W-8}" y="${H-3}" text-anchor="end" font-size="9.5" fill="#94a3b8">MetStat · ${civEsc(e.src||"NOAA")}</text></svg>`);
  host.innerHTML=`<div class="civScroll">${o.join("")}<div class="mgTip civTip" hidden></div></div>`;
  const sc=host.querySelector(".civScroll"), sv=sc.querySelector("svg"), tip=sc.querySelector(".civTip"), xl=sv.querySelector(".civX");
  const at=ev=>{ const r=sv.getBoundingClientRect(), x=(ev.clientX-r.left)*W/r.width; if(x<ml||x>ml+pw){ tip.hidden=true; xl.setAttribute("opacity",0); return; }
    const i=Math.max(0,Math.min(N-1,Math.floor((x-ml)/xs))), t=X[i], X1=xi(i); xl.setAttribute("x1",X1); xl.setAttribute("x2",X1); xl.setAttribute("opacity",.4);
    let h=`<b>${civEsc(kind==="plume"?F.dl.format(civD(t)):F.m.format(civD(t))+(en?"":" · "+CIV_GM.format(civD(t))))}</b>`;
    const ob=obs.find(q=>q.t===t); if(ob&&civFin(ob.v)){ const ph_=civPhaseOf(e,ob.v); h+=`<div class="mgTr mgTm"><i style="background:${ob.v>=0?"#dc2626":"#2563eb"}"></i><span>${civT(kind==="plume"?"تحلیل":"مقدار",kind==="plume"?"Analysis":"Value")}</span><b>${civN(ob.v)}</b></div>`+(ph_?`<div class="civTp">${civEsc(civEN()?civPhaseEN(ph_,e,ob.v):ph_.txt)}</div>`:""); }
    if(fc){ const j=fc.t.indexOf(t); if(j>=0){ const col=fc.mem.map(r=>r[j]).filter(civFin), pp=col.length?Math.round(100*col.filter(v=>v>0.5).length/col.length):null, pn=col.length?Math.round(100*col.filter(v=>v<-0.5).length/col.length):null;
      h+=`<div class="mgTr"><i style="background:#0f172a"></i><span>${civT("میانگین اعضا","Ensemble mean")}</span><b>${civN(fc.mean[j])}</b></div>`;
      if(civFin(fc.p10[j])) h+=`<div class="mgTr"><i style="background:#a78bfa"></i><span>${civT("بازهٔ ۱۰–۹۰٪","10–90% range")}</span><b>${civN(fc.p10[j])} … ${civN(fc.p90[j])}</b></div>`;
      if(pp!=null) h+=`<div class="civTp">${civT(`احتمال فاز مثبت ${FA(pp)}٪ · منفی ${FA(pn)}٪ (${FA(col.length)} عضو)`,`P(positive) ${pp}% · P(negative) ${pn}% (${col.length} members)`)}</div>`; } }
    tip.innerHTML=h; tip.hidden=false; const px=X1*r.width/W+(r.left-sc.getBoundingClientRect().left)+sc.scrollLeft, tw=tip.offsetWidth, sw=sc.scrollLeft+sc.clientWidth;
    tip.style.left=Math.max(sc.scrollLeft+4,Math.min(sw-tw-4,px+14+tw>sw?px-tw-14:px+14))+"px"; tip.style.top=(mt+6)+"px"; };
  sv.addEventListener("pointermove",at); sv.addEventListener("pointerdown",at); sv.addEventListener("pointerleave",ev=>{ if(ev.pointerType==="mouse"){ tip.hidden=true; xl.setAttribute("opacity",0); } });
  return sv; }
function civPhaseEN(p,e,v){ const M=ciMeta(e); const nm=["neutral","weak","moderate","strong"]; return p.lv?`${v>0?"positive":"negative"} — ${nm[p.lv]}`:"neutral"; }

/* ---------- محتوای کادر ---------- */
async function civRender(){
  const p=$("civPanel"), e=CIV.sel&&civEnt(CIV.sel); if(!p||!e) return; const en=civEN(), M=ciMeta(e), ph_=ciPhase(e);
  const pers=Object.entries(e.per||{}); let per=CIV.per[e.id]; if(!pers.some(q=>q[0]===per)) per=(pers.find(q=>q[0]==="d60"||q[0]==="y30")||pers[0]||[""])[0]; CIV.per[e.id]=per;
  const perLab=k=>{ if(!en) return (e.per||{})[k]||k; return {all:"Whole record",y30:"Last 30 years",y10:"Last 10 years",y3:"Last 3 years",d30:"30 days + forecast",d60:"60 days + forecast",d120:"120 days + forecast"}[k]||k; };
  const fcRows=Array.isArray(e.fc)?e.fc:[];
  const ttl=civName(e.id), sub=[e.src, e.note, en?"":""].filter(Boolean).join(" · ");
  p.innerHTML=`<header class="civHd"><div><h3>${civEsc(ttl)}</h3><div class="sub">${civEsc(sub)}</div></div><button type="button" class="btn sm civBack" data-cv="back">${civT("بازگشت به نقشه","Back to the map")} ↩</button></header>
   <div class="civStats">
    <div class="civSt civBig" style="${ph_?`background:${ph_.bg};color:${ph_.fg}`:""}"><small>${civT("آخرین مقدار","Latest value")}</small><b>${ph_?civN(ph_.v):"—"}</b><span>${civEsc(ph_?(en?civPhaseEN(ph_,e,ph_.v):ph_.txt):civT("مقدار منتشر نشده","not published"))}</span></div>
    <div class="civSt"><small>${civT("آغاز فاز فعلی","Current phase since")}</small><b>${civEsc(e.since||"—")}</b></div>
    <div class="civSt"><small>${civT(e.kind==="plume"?"۳۰ روز پیش":"ماه قبل",e.kind==="plume"?"30 days ago":"Previous month")}</small><b>${civFin(e.prev)?civN(e.prev):"—"}</b></div>
    <div class="civSt"><small>${civT("آخرین داده","Latest data")}</small><b>${civEsc(e.last||"—")}</b><span>${civT("به‌روزرسانی: ","updated: ")}${civEsc(ciUpd(e))}</span></div></div>
   <div class="mgTabs civPer">${pers.map(([k])=>`<button type="button" data-cper="${k}" class="${k===per?"on":""}">${civEsc(perLab(k))}</button>`).join("")}</div>
   <div id="civChart" class="civChart"><div class="hint">${civT("در حال بارگذاری نمودار…","Loading the chart…")}</div></div>
   <div class="civLeg">${e.kind==="plume"?`<span><i class="civSw" style="background:linear-gradient(90deg,#dc2626 50%,#2563eb 50%)"></i>${civT("تحلیل روزانه (مثبت/منفی)","Daily analysis (+/−)")}</span><span><i class="civSw" style="background:#0f172a;height:4px"></i>${civT("میانگین اعضا","Ensemble mean")}</span><span><i class="civSw" style="background:#c4b5fd"></i>${civT("بازهٔ ۱۰ تا ۹۰٪ اعضا","10–90% of members")}</span><span><i class="civSw" style="background:#6366f1;height:2px;opacity:.5"></i>${civT("هر عضو","each member")}</span>`:`<span><i class="civSw" style="background:linear-gradient(90deg,#dc2626 50%,#2563eb 50%)"></i>${civT("مقدار ماهانه","Monthly value")}</span>${e.kind==="line"?"":`<span><i class="civSw" style="background:#0f172a;height:4px"></i>${civT("میانگین متحرک ۱۲ ماهه","12-month running mean")}</span>`}`}<span><i class="civSw civDash"></i>${civT("آستانهٔ فاز","phase threshold")} ±${civN((M.th||[.5])[0],1)}</span></div>
   ${fcRows.length?`<div class="civFc"><h4>${civT("پیش‌بینی روزانه","Daily forecast")}</h4><div class="civTW"><table><tr><th>${civT("زمان","Lead")}</th><th>${civT("میانگین","Mean")}</th><th>${civT("بازهٔ ۱۰–۹۰٪","10–90%")}</th><th>${civT("فاز مثبت","P(+)")}</th><th>${civT("فاز منفی","P(−)")}</th></tr>${fcRows.map(f=>{ const q=civPhaseOf(e,f.v); return `<tr><td>${civEsc(en?String(f.l).replace(/[۰-۹]/g,d=>"۰۱۲۳۴۵۶۷۸۹".indexOf(d)).replace(" روز بعد"," d"):f.l)}</td><td style="${q?`background:${q.bg};color:${q.fg}`:""}">${civN(f.v)}</td><td>${civFin(f.lo)?civN(f.lo)+" … "+civN(f.hi):"—"}</td><td>${civFin(f.pp)?FA(f.pp)+"٪":"—"}</td><td>${civFin(f.pn)?FA(f.pn)+"٪":"—"}</td></tr>`; }).join("")}</table></div></div>`:""}
   <div class="labBtns civBtns"><button type="button" class="labGo" data-cv="rep">${civT("گزارش و تحلیل","Report & analysis")}</button><button type="button" data-cv="png">${civT("دانلود PNG","Download PNG")}</button><button type="button" data-cv="orig">${civT("نمودار PNG اصلی","Original PNG chart")}</button><button type="button" data-cv="info">ℹ ${civT("اطلاعات علمی","Scientific info")}</button></div>
   <div class="civRep" id="civRep" ${CIV.rep?"":"hidden"}></div>
   <div class="civInfo" id="civInfo" ${CIV.info?"":"hidden"}><p>${civEsc(M.desc||civT("توضیحی ثبت نشده است.","No description."))}</p>${e.en?`<p><b>${civT("نام انگلیسی","English name")}:</b> ${civEsc(e.en)}</p>`:""}<p><b>${civT("منبع داده","Data source")}:</b> ${civEsc(e.src||"—")}</p>${M.ref?`<p><b>${civT("مرجع","Reference")}:</b> ${civEsc(M.ref)}</p>`:""}</div>`;
  if(CIV.rep) $("civRep").innerHTML=civReport(e);
  const host=$("civChart"), my=++CIV.tok, S=await civSer(e); if(CIV.sel!==e.id||!$("civChart")) return;
  if(S&&(S.kind==="plume"?S.obs&&S.obs.t&&S.obs.t.length:S.t&&S.t.length)){ try{ civChart(host,e,S,per); return; }catch(err){ console.warn("civChart",err); } }
  host.innerHTML=`<div class="hint">${civT("سری عددی این شاخص هنوز روی هاست نیست (نسخهٔ جدید indices.py)؛ نمودار تصویری:","The numeric series is not on the host yet (new indices.py); image chart:")}</div><img class="civImg" alt="" src="${ON.base}data/idx/${e.id}_${per}.png?${(CIV.idx&&CIV.idx.updated)||""}">`;
}
function civReport(e){
  const en=civEN(), M=ciMeta(e), p=ciPhase(e), L=[];
  L.push(`<h4>${civEsc(civT("تحلیل ","Analysis: ")+civName(e.id))}</h4>`);
  if(!p) L.push(`<p>${civT("مقدار عددی آخرین دوره برای این شاخص منتشر نشده است.","No latest value has been published for this index.")}</p>`);
  else { L.push(`<p>${civT(`مقدار فعلی شاخص ${civN(p.v)} و در فاز «${p.txt}» است.`,`The current value is ${p.v.toFixed(2)}, phase: ${civPhaseEN(p,e,p.v)}.`)}${e.since?civT(` این فاز از ${e.since} ادامه دارد.`,` In this phase since ${e.since}.`):""}</p>`);
    if(civFin(e.prev)){ const d=p.v-e.prev; L.push(`<p>${civT(`نسبت به ${e.kind==="plume"?"۳۰ روز پیش":"ماه قبل"} (${civN(e.prev)}) ${Math.abs(d)<.05?"تقریباً بدون تغییر است":d>0?"افزایش یافته است":"کاهش یافته است"}.`,`Compared with ${e.kind==="plume"?"30 days ago":"the previous month"} (${e.prev.toFixed(2)}) it has ${Math.abs(d)<.05?"barely changed":d>0?"increased":"decreased"}.`)}</p>`); }
    const fc=Array.isArray(e.fc)?e.fc:[]; if(fc.length){ const last=fc[fc.length-1], q=civPhaseOf(e,last.v);
      L.push(`<p>${civT(`بر پایهٔ میانگین اعضای پیش‌بینی، مقدار شاخص در ${last.l} به ${civN(last.v)} (${q?q.txt:"—"}) می‌رسد.`,`The ensemble mean reaches ${last.v.toFixed(2)} at the last lead (${q?civPhaseEN(q,e,last.v):"—"}).`)}${civFin(last.pp)?civT(` احتمال فاز مثبت ${FA(last.pp)}٪ و فاز منفی ${FA(last.pn)}٪ است.`,` P(positive) ${last.pp}%, P(negative) ${last.pn}%.`):""}</p>`); } }
  if(M.desc&&!en) L.push(`<p class="hint">${civEsc(M.desc)}</p>`);
  L.push(`<div class="labBtns"><button type="button" data-cv="cp">${civT("کپی متن","Copy text")}</button></div>`);
  return L.join(""); }
async function civClick(ev){
  const b=ev.target.closest("button"); if(!b) return; const e=civEnt(CIV.sel); if(!e) return;
  if(b.dataset.cper){ CIV.per[e.id]=b.dataset.cper; return civRender(); }
  const a=b.dataset.cv; if(!a) return;
  if(a==="back"){ civClose(); try{ NVW.ptab="used"; nvWx(); }catch(_){} return; }
  if(a==="rep"){ CIV.rep=!CIV.rep; const r=$("civRep"); r.hidden=!CIV.rep; if(CIV.rep) r.innerHTML=civReport(e); return; }
  if(a==="info"){ CIV.info=!CIV.info; $("civInfo").hidden=!CIV.info; return; }
  if(a==="cp"){ const t=$("civRep").innerText.replace(/\n?(کپی متن|Copy text)\s*$/,""); try{ await navigator.clipboard.writeText(t); b.textContent=civT("کپی شد ✓","Copied ✓"); }catch(_){ } return; }
  if(a==="orig"){ const per=CIV.per[e.id]; window.open(`${ON.base}data/idx/${e.id}_${per}.png?${(CIV.idx&&CIV.idx.updated)||""}`,"_blank","noopener"); return; }
  if(a==="png"){ const sv=$("civChart").querySelector("svg"); if(sv&&globalThis.MET&&MET.skewt) MET.skewt.download(sv,e.id+"_"+CIV.per[e.id],true); else if(!sv) civClick({target:{closest:()=>({dataset:{cv:"orig"}})}}); return; }
}
/* بازکردن مستقیم: «شاخص‌های اقلیمی» در منو یا آدرس قدیمی #/climate-indices → صفحهٔ اصلی + همین زبانه */
async function civGoTab(){ try{ try{ setRoute("on",true); }catch(_){ } NVW.ptab="ci"; NVW.open.par=true; await civLoad(); nvWx(); const s=document.querySelector('#nvWx [data-ptab="ci"]'); if(s) s.scrollIntoView({block:"center"}); }catch(e){ console.warn("civGoTab",e); } }
(function(){
  const o=window.openCI;
  window.openCI=async function(){ try{ await openON(); }catch(e){ console.warn(e); } setTimeout(civGoTab,350); };
  const L=window.nvLeave; if(typeof L==="function") window.nvLeave=function(){ try{ if(CIV.sel){ CIV.sel=null; const p=$("civPanel"); if(p) p.hidden=true; const c=civCard(); if(c) c.hidden=false; } }catch(_){ } return L.apply(this,arguments); };
  let rz=0; addEventListener("resize",()=>{ clearTimeout(rz); rz=setTimeout(()=>{ const p=$("civPanel"); if(p&&!p.hidden&&CIV.sel) civRender(); },220); });
  document.addEventListener("langchange",()=>{ const p=$("civPanel"); if(p&&!p.hidden&&CIV.sel) civRender(); });
  setInterval(async()=>{ if(document.hidden) return; const p=$("civPanel"); if(!p||p.hidden||!CIV.sel) return; const u=CIV.idx&&CIV.idx.updated; await civLoad(true); if(CIV.idx&&CIV.idx.updated!==u) civRender(); },600000);
})();
