/* ===== رابط «آزمایشگاه محاسبات» (فاز ۳) — زبانهٔ پنجم صفحهٔ «تحلیل و هشدار» =====
   ورودی: چسباندن/بارگذاری سونداژ (Wyoming یا CSV) یا Open-Meteo؛ خروجی: Skew-T، هودوگراف، کارت هر شاخص.
   محاسبه در MET.lab است؛ این فایل فقط نمایش می‌دهد. رنگ‌بندی برچسب‌ها صرفاً نمایشی و جدا از محاسبه است. */
(function(){
  "use strict";
  const M = globalThis.MET, S = {res:null, parcel:"SB", src:"", om:null, omSel:0, tab:"om", busy:false, mg:null, mgP:"t", mgRange:+(typeof store!=="undefined"&&store.get?store.get("mg.range",15):15)||15, mgFit:{trend:false, per:false, ma:false}, skMode:"2d", skRot:38, an:null, mgHide:new Set(), mgBusy:0, place:null};
  const E = () => typeof LANG !== "undefined" && LANG === "en";
  const t = (fa, en) => E() ? en : fa;
  const fin = x => typeof x === "number" && isFinite(x);
  const esc = s => String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  const fx = (x, d) => fin(x) ? x.toFixed(d == null ? 1 : d) : "—";
  let root = null;
  /* ---- برچسب رنگی نمایشی (آستانه‌ها راهنمای تجربی‌اند، نه حد قطعی) ---- */
  const BAND = {
    CAPE:v => v < 300 ? [0, "ضعیف", "Weak"] : v < 1000 ? [1, "متوسط", "Moderate"] : v < 2500 ? [2, "قوی", "Strong"] : [3, "بسیار قوی", "Extreme"],
    LI:v => v > 0 ? [0, "پایدار", "Stable"] : v > -3 ? [1, "ناپایداری ضعیف", "Marginal"] : v > -6 ? [2, "ناپایدار", "Unstable"] : [3, "بسیار ناپایدار", "Very unstable"],
    K:v => v < 20 ? [0, "کم", "Low"] : v < 30 ? [1, "متوسط", "Moderate"] : v < 35 ? [2, "زیاد", "High"] : [3, "بسیار زیاد", "Very high"],
    TT:v => v < 44 ? [0, "کم", "Low"] : v < 50 ? [1, "تندری محتمل", "Thunderstorms likely"] : v < 55 ? [2, "تندری شدید محتمل", "Severe possible"] : [3, "بسیار زیاد", "Very high"],
    SHEAR:v => v < 10 ? [0, "ضعیف", "Weak"] : v < 18 ? [1, "متوسط", "Moderate"] : v < 25 ? [2, "قوی", "Strong"] : [3, "بسیار قوی", "Very strong"],
    SCP:v => v < 1 ? [0, "زیر آستانه", "Below threshold"] : v < 4 ? [1, "مساعد", "Favourable"] : v < 10 ? [2, "قوی", "Strong"] : [3, "بسیار قوی", "Very strong"],
    STP:v => v < 1 ? [0, "زیر آستانه", "Below threshold"] : v < 3 ? [1, "مساعد", "Favourable"] : v < 6 ? [2, "قوی", "Strong"] : [3, "بسیار قوی", "Very strong"],
    SHIP:v => v < 1 ? [0, "زیر آستانه", "Below threshold"] : v < 2 ? [1, "مساعد", "Favourable"] : v < 4 ? [2, "قوی", "Strong"] : [3, "بسیار قوی", "Very strong"],
    SRH:v => v < 100 ? [0, "کم", "Low"] : v < 250 ? [1, "متوسط", "Moderate"] : v < 400 ? [2, "زیاد", "High"] : [3, "بسیار زیاد", "Very high"]
  };
  const bandTag = (k, v) => { if(!fin(v) || !BAND[k]) return ""; const b = BAND[k](v); return '<span class="labBand b' + b[0] + '" title="' + esc(t("رنگ‌بندی نمایشی؛ آستانه‌ها راهنمای تجربی‌اند", "Display only; thresholds are empirical guides")) + '">' + esc(b[E() ? 2 : 1]) + "</span>"; };
  const val = (v, u, d) => '<span dir="ltr" style="unicode-bidi:isolate"><span class="labV">' + fx(v, d) + '</span> <span class="labU">' + esc(u) + "</span></span>";
  const why = w => w ? '<div class="labWhy">' + esc(M.lab.whyText(w, E())) + "</div>" : "";
  /* ---- کارت ---- */
  function card(key, body, o){
    o = o || {}; const m = M.meta[o.meta || key] || {}, name = E() ? m.en : m.fa, bad = o.bad;
    const det = m.formula ? '<details class="labDet"><summary>' + esc(t("ورودی، فرمول و محدودیت‌ها", "Inputs, formula and limits")) + "</summary><dl>" +
      "<dt>" + esc(t("ورودی", "Inputs")) + "</dt><dd>" + esc(m.inputs || "") + "</dd><dt>" + esc(t("فرمول / الگوریتم", "Formula / algorithm")) + '</dt><dd dir="ltr" class="labF">' + esc(m.formula) + "</dd>" +
      "<dt>" + esc(t("واحد و بازه", "Unit and range")) + "</dt><dd>" + esc((m.unit || "") + (m.range ? " — " + m.range : "")) + "</dd>" +
      "<dt>" + esc(t("داده ناکافی", "Insufficient data")) + "</dt><dd>" + esc(m.insufficient || "") + "</dd><dt>" + esc(t("محدودیت تفسیر", "Limits")) + "</dt><dd>" + esc(m.limits || "") + "</dd>" +
      "<dt>" + esc(t("مرجع", "Reference")) + '</dt><dd dir="ltr">' + esc(m.ref || "") + "</dd></dl></details>" : "";
    return '<article class="labCard' + (bad ? " bad" : "") + '"><h4>' + esc(name || key) + (o.tag || "") + "</h4>" + body + det + "</article>";
  }
  const simple = (k, it, unit, d, band, extra) => it && it.v != null ? card(k, '<div class="labMain">' + val(it.v, unit, d) + (band ? bandTag(band, it.v) : "") + "</div>" + (extra || "")) :
    card(k, '<div class="labMain labNA">' + esc(t("داده ناکافی", "Insufficient data")) + "</div>" + why(it && it.why), {bad:true});
  function cardsHtml(r){
    const I = r.items, P = r.parcels[r.parcelType], z0 = r.surface.z, agl = p => { const z = M.lab.heightAtP(r.prof, p); return fin(z) && fin(z0) ? z - z0 : null; };
    let h = '<h3 class="labH">' + esc(t("شاخص‌های ترمودینامیکی", "Thermodynamic indices")) + "</h3><div class='labGrid'>";
    const note = I.CAPE.note === "no_lfc" ? '<div class="labWhy">' + esc(M.lab.whyText("no_lfc", E())) + "</div>" : "";
    h += simple("CAPE", I.CAPE, "J/kg", 0, "CAPE", '<div class="labSub">' + esc(t("پارسل", "Parcel")) + ": " + r.parcelType + "</div>" + note);
    h += simple("CIN", I.CIN, "J/kg", 0);
    h += I.LCL.v != null ? card("LCL", '<div class="labMain">' + val(I.LCL.v, "hPa", 0) + '</div><div class="labSub">' + (agl(I.LCL.v) != null ? fx(agl(I.LCL.v), 0) + " m AGL · " : "") + fx(I.LCL.Tk - 273.15, 1) + " °C</div>") : simple("LCL", I.LCL, "hPa", 0);
    if(I.CAPE.v != null){
      h += r.lfc != null ? card("LFC", '<div class="labMain">' + val(r.lfc, "hPa", 0) + "</div>" + (agl(r.lfc) != null ? '<div class="labSub">' + fx(agl(r.lfc), 0) + " m AGL</div>" : "")) : card("LFC", '<div class="labMain labNA">—</div>' + why("no_lfc"));
      h += r.el != null ? card("EL", '<div class="labMain">' + val(r.el, "hPa", 0) + "</div>" + (agl(r.el) != null ? '<div class="labSub">' + fx(agl(r.el), 0) + " m AGL</div>" : "")) : card("EL", '<div class="labMain labNA">—</div>' + why(r.lfc == null ? "no_lfc" : ""));
    } else { h += simple("LFC", I.CAPE, "hPa", 0); h += simple("EL", I.CAPE, "hPa", 0); }
    h += simple("LI", I.LI, "°C", 1, "LI") + simple("SHOWALTER", I.SHOWALTER, "°C", 1) + simple("K", I.K, "°C", 1, "K") + simple("TT", I.TT, "°C", 1, "TT") + simple("VT", I.VT, "°C", 1) + simple("CT", I.CT, "°C", 1) + simple("PWAT", I.PWAT, "mm", 1);
    h += "</div>";
    h += '<h3 class="labH">' + esc(t("باد و برش", "Wind and shear")) + "</h3>";
    if(!r.hasWind) h += '<div class="labNote">' + esc(t("دادهٔ باد یا ارتفاع کافی نیست (کمتر از ۳ سطح با u،v و z)؛ شاخص‌های باد محاسبه نمی‌شوند. چیزی با صفر جایگزین نشده است.", "Not enough wind/height data (< 3 levels with u, v, z); wind indices are not computed. Nothing was replaced with zero.")) + "</div>";
    h += "<div class='labGrid'>";
    const sh = I.SHEAR, row = (lab, it, u, d, k) => '<div class="labRow"><span>' + lab + '</span><span>' + (it.v != null ? val(it.v, u, d) + (k ? bandTag(k, it.v) : "") : '<span class="labNA">—</span>') + "</span></div>";
    h += card("SHEAR", row("0–1 km", sh.s01, "m/s", 1) + row("0–3 km", sh.s03, "m/s", 1) + row("0–6 km", sh.s06, "m/s", 1, "SHEAR") + (sh.s06.v == null ? why(sh.s06.why) : ""), {bad:sh.s06.v == null && sh.s03.v == null});
    const bk = I.BUNKERS, vec = q => q ? fx(W().speed(q.u, q.v), 1) + " m/s @ " + fx(W().direction(q.u, q.v), 0) + "°" : "—";
    h += bk.right ? card("BUNKERS", '<div class="labRow"><span>RM</span><span dir="ltr">' + vec(bk.right) + '</span></div><div class="labRow"><span>LM</span><span dir="ltr">' + vec(bk.left) + '</span></div><div class="labRow"><span>' + esc(t("میانگین ۰–۶ km", "Mean 0–6 km")) + '</span><span dir="ltr">' + vec(bk.mean) + "</span></div>") : card("BUNKERS", '<div class="labMain labNA">' + esc(t("داده ناکافی", "Insufficient data")) + "</div>" + why(bk.why), {bad:true});
    const sr = I.SRH, srr = (lab, it) => '<div class="labRow"><span>' + lab + "</span><span>" + (it.v != null ? val(it.v, "m²/s²", 0) + '<span class="labSub"> (+' + fx(it.pos, 0) + " / " + fx(it.neg, 0) + ")</span>" : '<span class="labNA">—</span>') + "</span></div>";
    h += card("SRH", srr("0–1 km", sr.s01) + srr("0–3 km", sr.s03) + (sr.s03.v != null ? bandTag("SRH", sr.s03.v) : "") + '<div class="labSub">' + esc(t("نسبت به حرکت راست‌گرد Bunkers", "Relative to Bunkers right-mover")) + "</div>" + (sr.s03.v == null ? why(sr.s03.why) : ""), {bad:sr.s03.v == null && sr.s01.v == null});
    h += simple("CRITICAL", I.CRITICAL, "°", 0);
    h += "</div>" + severeHtml(r);
    return h;
  }
  /* ---- پارامترهای توفان شدید (فاز ۴) ---- */
  function terms(o){ if(!o || !o.terms) return ""; const nm = {cape:"CAPE", srh:"SRH", shear:t("برش", "shear"), lcl:"LCL", cin:"CIN", mr:"MUmr", t500:"T500"};
    return '<div class="labSub" dir="ltr">' + Object.keys(o.terms).map(k => (nm[k] || k) + "=" + fx(o.terms[k], 2)).join(" · ") + "</div>"; }
  function severeHtml(r){
    const sv = r.severe; if(!sv || sv.error) return ""; let h = '<h3 class="labH">' + esc(t("پارامترهای ترکیبی توفان شدید", "Composite severe-storm parameters")) + '</h3><div class="labNote">' + esc(t("هر جزء فرمول جداگانه نشان داده می‌شود. حرکت توفان = Bunkers ۰–۶ km (ساده‌سازی). مقدار ۰ «بدون لایهٔ مؤثر» یک نتیجهٔ معتبر است، نه داده‌ی گمشده.", "Each formula term is shown. Storm motion = Bunkers 0–6 km (simplification). A 0 from “no effective inflow” is a valid result, not missing data.")) + "</div><div class='labGrid'>";
    const nt = it => it && it.note ? '<div class="labWhy">' + esc(M.lab.whyText(it.note, E())) + "</div>" : "";
    const sc = (k, it, band, extra, unit) => it && it.v != null ? card(k, '<div class="labMain">' + val(it.v, unit || "", unit ? 1 : 2) + (band ? bandTag(band, it.v) : "") + "</div>" + terms(it) + (extra || "") + nt(it)) : card(k, '<div class="labMain labNA">' + esc(t("داده ناکافی", "Insufficient data")) + "</div>" + why(it && it.why), {bad:true});
    const eil = sv.EIL;
    h += eil && eil.none ? card("EIL", '<div class="labMain labNA">—</div>' + why("no_effective_inflow")) : (eil && eil.v != null ? card("EIL", '<div class="labMain">' + val(eil.baseP, "hPa", 0) + " → " + val(eil.topP, "hPa", 0) + "</div>" + (eil.baseAgl != null ? '<div class="labSub">' + fx(eil.baseAgl, 0) + " → " + fx(eil.topAgl, 0) + " m AGL</div>" : "")) : card("EIL", '<div class="labMain labNA">' + esc(t("داده ناکافی", "Insufficient data")) + "</div>" + why(eil && eil.why), {bad:true}));
    h += sc("ESRH", sv.ESRH, null, "", "m²/s²");
    h += sc("EBWD", sv.EBWD, null, "", "m/s");
    h += sc("SCP", sv.SCP, "SCP", sv.SCP && sv.SCP.v != null ? '<div class="labSub">' + esc(t("با جملهٔ CIN (SPC)", "with CIN term (SPC)")) + ": " + fx(sv.SCP.withCin, 2) + "</div>" : "");
    h += sc("STPF", sv.STPF, "STP") + sc("STPE", sv.STPE, "STP") + sc("SHIP", sv.SHIP, "SHIP", sv.SHIP && sv.SHIP.v != null ? '<div class="labSub">' + esc(t("ضرایب تعدیل", "adjustments")) + ": CAPE ×" + fx(sv.SHIP.adj.cape, 2) + " · LR ×" + fx(sv.SHIP.adj.lr, 2) + " · FZL ×" + fx(sv.SHIP.adj.frz, 2) + "</div>" : "");
    h += simple("LR75", sv.LR75, "K/km", 1) + simple("FZL", sv.FZL, "m AGL", 0, null, sv.FZL && sv.FZL.note ? '<div class="labSub">' + esc(M.lab.whyText(sv.FZL.note, E())) + "</div>" : "");
    return h + "</div>";
  }
  const W = () => M.wind;
  /* ---- تحلیل علمی (آفلاین، قاعده‌محور + لجستیک کنترل‌شده) ---- */
  function anShow(kind){
    const box = root.querySelector("#labAn"); if(!S.res){ msg(t("ابتدا پروفایل را دریافت یا وارد کنید.", "Fetch or enter a profile first."), true); return; }
    let a; try{ a = kind === "lab" ? M.analysis.lab(S.res, {en:E(), mg:S.mg, mgDays:S.mgRange > 5 ? 5 : S.mgRange}) : M.analysis.skewt(S.res, {en:E()}); }catch(e){ console.warn(e); msg(t("تحلیل ناموفق بود.", "Analysis failed."), true); return; }
    S.an = {kind}; box.hidden = false;
    box.innerHTML = '<div class="anTop"><span></span><span><button type="button" id="anCopy">' + esc(t("کپی متن", "Copy text")) + '</button><button type="button" id="anX">✕</button></span></div>' + M.analysis.html(a, E());
    box.querySelector("#anX").onclick = () => { S.an = null; box.hidden = true; };
    box.querySelector("#anCopy").onclick = () => { const tx = M.analysis.text(a); try{ navigator.clipboard.writeText(tx); msg(t("متن تحلیل کپی شد.", "Analysis text copied.")); }catch(e){ msg(tx); } };
    box.scrollIntoView({behavior:"smooth", block:"start"});
  }
  /* ---- رندر نتیجه ---- */
  function render(){
    const out = root.querySelector("#labOut"); if(!S.res){ out.hidden = true; return; } const r = S.res; out.hidden = false;
    const n = r.prof.p.length, iss = r.issues.length ? ' <span class="labSub">· ' + esc(t("هشدار کیفیت", "Quality notes")) + ": " + esc(r.issues.slice(0, 6).join("، ")) + (r.issues.length > 6 ? " …" : "") + "</span>" : "";
    root.querySelector("#labSum").innerHTML = "<b>" + esc(S.src) + "</b> — " + esc(t("سطوح معتبر", "valid levels")) + ": <b>" + n + "</b> (" + fx(r.surface.p, 0) + "→" + fx(r.top, 0) + " hPa) · " + esc(t("ردیف حذف‌شده", "dropped rows")) + ": " + r.dropped + iss;
    root.querySelectorAll("[data-par]").forEach(b => b.classList.toggle("on", b.dataset.par === S.parcel));
    const sk = root.querySelector("#labSk"), ttl = S.parcel + " parcel";
    root.querySelectorAll("[data-skm]").forEach(b => b.classList.toggle("on", b.dataset.skm === S.skMode)); root.querySelector("#skRotL").hidden = S.skMode !== "3d";
    try{
      if(S.skMode === "3d" && M.skewt2){ sk.innerHTML = M.skewt2.svg3d(r, {en:E(), parcel:S.parcel, title:ttl, rot:S.skRot}); }
      else if(S.skMode === "2d" && M.skewt2){ sk.innerHTML = M.skewt2.svg(r, {en:E(), parcel:S.parcel, title:ttl}); M.skewt2.attach(sk, r, root.querySelector("#labInfo")); }
      else { sk.innerHTML = M.skewt.svg(r, {en:E(), parcel:S.parcel, title:ttl}); M.skewt.attach(sk, r, root.querySelector("#labInfo")); }
    }catch(e){ console.warn("skewt", e); sk.innerHTML = M.skewt.svg(r, {en:E(), parcel:S.parcel, title:ttl}); M.skewt.attach(sk, r, root.querySelector("#labInfo")); }
    if(S.an) anShow(S.an.kind);
    const hd = M.skewt.hodograph(r, {en:E()}); root.querySelector("#labHodo").innerHTML = hd || '<div class="labNote">' + esc(t("هودوگراف: دادهٔ باد کافی نیست.", "Hodograph: not enough wind data.")) + "</div>";
    root.querySelector("#labCards").innerHTML = cardsHtml(r);
  }
  function analyze(raw, src, keepFirst){
    const res = M.lab.analyze(raw, {parcel:S.parcel});
    if(!res.ok){ S.res = null; render(); msg(t("تحلیل ممکن نشد: ", "Cannot analyse: ") + M.lab.ioWhyText(res.why, E()) + (res.issues && res.issues.length ? " (" + res.issues.slice(0, 3).join("، ") + ")" : ""), true); return false; }
    S.res = res; S.src = src; S.raw = raw; msg(""); render(); return true;
  }
  function msg(s, bad){ const e = root.querySelector("#labMsg"); e.textContent = s; e.className = "labMsg" + (bad ? " bad" : ""); e.hidden = !s; }
  /* ---- Open-Meteo ---- */
  async function omFetch(){
    const lat = parseFloat(root.querySelector("#labLat").value), lon = parseFloat(root.querySelector("#labLon").value);
    if(!(lat >= -90 && lat <= 90) || !(lon >= -180 && lon <= 180)){ msg(t("مختصات نامعتبر است.", "Invalid coordinates."), true); return; }
    const btn = root.querySelector("#labOmGo"); btn.disabled = true; msg(t("در حال دریافت از Open-Meteo…", "Fetching from Open-Meteo…"));
    const ac = new AbortController(), to = setTimeout(() => ac.abort(), 60000);
    try{
      const q = await M.mg.cget(M.io.omUrl(lat, lon), ac.signal); if(!q.ok) throw new Error("HTTP " + q.status);
      const j = q.j; if(!j || j.error) throw new Error((j && j.reason) || "api error");
      S.om = j; const times = M.io.omTimes(j), sel = root.querySelector("#labOmT"); const now = new Date().toISOString().slice(0, 13);
      sel.innerHTML = times.map((x, i) => '<option value="' + i + '">' + esc(x.replace("T", " ") + " UTC") + "</option>").join(""); let k = times.findIndex(x => x.slice(0, 13) >= now); if(k < 0) k = 0; sel.value = String(k);
      msg(""); root.querySelector("#labOmRow").hidden = false; omRun();
    }catch(e){ S.om = null; msg(t("دریافت ناموفق: ", "Fetch failed: ") + (e.name === "AbortError" ? t("زمان انتظار تمام شد", "timeout") : /429/.test(e.message) ? t("HTTP 429 = سقف درخواست رایگان Open-Meteo پر شده؛ چند دقیقه (یا اگر ادامه داشت، چند ساعت) بعد دوباره امتحان کنید", "HTTP 429 = Open-Meteo free request limit reached; try again in a few minutes (or hours if it persists)") : e.message) + t(" — اتصال یا دسترسی مرورگر به api.open-meteo.com را بررسی کنید؛ می‌توانید سونداژ را دستی بچسبانید.", " — check connection / access to api.open-meteo.com; you can paste a sounding instead."), true); }
    finally{ clearTimeout(to); btn.disabled = false; }
  }
  function omRun(){
    if(!S.om) return; const i = parseInt(root.querySelector("#labOmT").value, 10), c = M.io.omToRaw(S.om, i);
    if(!c.ok){ S.res = null; render(); msg(M.lab.ioWhyText(c.why, E()), true); return; }
    analyze(c.raw, "Open-Meteo " + fx(c.lat, 2) + "°N " + fx(c.lon, 2) + "°E · " + c.time.replace("T", " ") + " UTC" + (fin(c.elevation) ? " · " + fx(c.elevation, 0) + " m" : ""));
    if(S.res && c.belowGround) S.res.issues.push(c.belowGround + " " + t("تراز زیر سطح زمین حذف شد", "levels below ground removed")), render();
  }
  /* ---- ورودی متن/فایل ---- */
  function runText(){
    const txt = root.querySelector("#labTxt").value, wu = root.querySelector("#labWu").value, r = M.io.parse(txt, {windUnit:wu});
    if(!r.ok){ S.res = null; render(); msg(t("ورودی خوانده نشد: ", "Input not read: ") + M.lab.ioWhyText(r.why, E()), true); return; }
    const ok = analyze(r.raw, t("ورودی دستی", "Manual input") + " (" + r.mode + ", " + r.rows + " " + t("ردیف", "rows") + ")");
    if(ok && r.issues.length){ S.res.issues = S.res.issues.concat(r.issues); render(); }
  }
  /* ---- استان/مرکز شهرستان ---- */
  const coll = new Intl.Collator("fa");
  function provs(){ return (M.places || []).slice().sort((a, b) => coll.compare(a[0], b[0])); }
  function seatsOf(pv){ const p = (M.places || []).find(x => x[0] === pv); if(!p) return []; return p[2].slice().sort((a, b) => (b[3] === 1) - (a[3] === 1) || coll.compare(a[0], b[0])); }
  const sget = (k, d) => { try{ return store.get(k, d); }catch(e){ return d; } }, sset = (k, v) => { try{ store.set(k, v); }catch(e){} };
  function placeBind(){
    const ps = root.querySelector("#labProv"), ss = root.querySelector("#labSeat"); if(!ps || !ss) return;
    const P = provs(); let pv = sget("lab.prov", "فارس"); if(!P.some(p => p[0] === pv)) pv = (P[0] || [""])[0];
    ps.innerHTML = '<option value="">' + esc(t("— نقطهٔ دلخواه —", "— custom point —")) + "</option>" + P.map(p => '<option value="' + esc(p[0]) + '">' + esc(E() ? p[1] : p[0]) + "</option>").join("");
    const fillSeats = (sel) => { const L = seatsOf(ps.value); ss.innerHTML = L.length ? L.map(c => '<option value="' + esc(c[0]) + '">' + esc(c[0] + (c[3] === 1 ? t(" (مرکز استان)", " (capital)") : "")) + "</option>").join("") : '<option value="">—</option>'; ss.disabled = !L.length; if(sel && L.some(c => c[0] === sel)) ss.value = sel; };
    ps.value = sget("lab.provOn", 1) ? pv : ""; fillSeats(sget("lab.seat", "استهبان"));
    const pick = () => { const c = seatsOf(ps.value).find(x => x[0] === ss.value); if(!c) return; sset("lab.prov", ps.value); sset("lab.seat", c[0]); sset("lab.provOn", 1);
      root.querySelector("#labLat").value = c[1]; root.querySelector("#labLon").value = c[2]; S.place = {name:c[0], prov:ps.value, en:(provs().find(p => p[0] === ps.value) || [])[1]}; omFetch(); mgFetch(); };
    ps.onchange = () => { if(!ps.value){ sset("lab.provOn", 0); fillSeats(""); return; } fillSeats(""); pick(); };
    ss.onchange = pick;
    root.querySelectorAll("#labLat,#labLon").forEach(i => i.addEventListener("input", () => { if(ps.value){ ps.value = ""; fillSeats(""); sset("lab.provOn", 0); } S.place = null; }));
  }
  /* ---- متئوگرام چندمدلی ---- */
  async function mgFetch(){
    if(!M.mg) return; const lat = parseFloat(root.querySelector("#labLat").value), lon = parseFloat(root.querySelector("#labLon").value);
    if(!(lat >= -90 && lat <= 90) || !(lon >= -180 && lon <= 180)) return;
    const my = ++S.mgBusy, sec = root.querySelector("#labMg"); sec.hidden = false; S.mgPend = {lat, lon};
    root.querySelector("#mgSt").textContent = t("در حال دریافت متئوگرام همهٔ مدل‌ها از Open-Meteo…", "Fetching the meteogram of all models from Open-Meteo…"); mgHead();
    try{ const D = await M.mg.fetchAll(lat, lon); if(my !== S.mgBusy) return; D.place = S.place; S.mg = D; mgRender(); }
    catch(e){ if(my !== S.mgBusy) return; root.querySelector("#mgSt").textContent = t("دریافت متئوگرام ناموفق: ", "Meteogram fetch failed: ") + e.message; }
  }
  function mgHead(){
    const D = S.mg, pl = (D && D.place) || S.place, p = D || S.mgPend || {}, h = root.querySelector("#mgTitle"), sb = root.querySelector("#mgSub"); if(!h) return;
    h.textContent = t("متئوگرام چندمدلی", "Multi-model meteogram") + (pl ? " — " + pl.name + " (" + (E() ? pl.en || pl.prov : pl.prov) + ")" : "");
    sb.innerHTML = (fin(p.lat) ? '<bdi dir="ltr">' + fx(p.lat, 2) + "°N " + fx(p.lon, 2) + "°E</bdi>" : "") + (D && fin(D.elev) ? " · " + esc(t("ارتفاع مدل ", "model elevation ")) + '<bdi dir="ltr">' + fx(D.elev, 0) + " m</bdi>" : "") + " · " + esc(t(FA(S.mgRange) + " روز از امروز، ساعتی، به وقت ایران", "from today, " + S.mgRange + " days, hourly, Iran time"));
  }
  function mgRender(){
    const sec = root && root.querySelector("#labMg"); if(!sec || !S.mg){ if(sec && !S.mgPend) sec.hidden = true; return; }
    sec.hidden = false; mgHead(); const D = S.mg;
    root.querySelectorAll("[data-mgp]").forEach(b => b.classList.toggle("on", b.dataset.mgp === S.mgP));
    root.querySelector("#mgLeg").innerHTML = '<button type="button" class="mgChip mgMed' + (S.mgHide.has("median") ? " off" : "") + '" data-mgm="median"><i style="background:#0f172a"></i>' + esc(t("میانه", "Median")) + "</button>" +
      D.mods.map(m => '<button type="button" class="mgChip' + (S.mgHide.has(m.id) ? " off" : "") + '" data-mgm="' + m.id + '"><i style="background:' + m.color + '"></i>' + esc(m.name) + "</button>").join("") +
      (S.mgHide.size ? '<button type="button" class="mgChip mgAll" data-mgm="*">' + esc(t("نمایش همه", "Show all")) + "</button>" : "");
    const st = root.querySelector("#mgSt");
    st.textContent = t("مدل‌های دریافت‌شده: ", "Models received: ") + D.mods.length + t(" از ", " of ") + M.mg.MODELS.length + (D.fail.length ? " · " + t("بدون داده برای این نقطه: ", "no data for this point: ") + D.fail.map(f => f.name + " (" + f.why + ")").join("، ") : "");
    if(!D.mods.length){ root.querySelector("#mgChart").innerHTML = '<div class="labMsg bad">' + esc(t("هیچ مدلی داده نداد؛ اتصال به api.open-meteo.com را بررسی کنید.", "No model returned data; check access to api.open-meteo.com.")) + "</div>"; return; }
    root.querySelectorAll("[data-mgr]").forEach(b => b.classList.toggle("on", +b.dataset.mgr === S.mgRange));
    const fitOk = S.mgP === "t" || S.mgP === "rh"; root.querySelector("#mgFits").hidden = !fitOk;
    root.querySelectorAll("[data-mgf]").forEach(b => b.classList.toggle("on", !!S.mgFit[b.dataset.mgf]));
    const stt = {en:E(), hidden:S.mgHide, range:S.mgRange, fit:S.mgFit};
    M.mg.render(root.querySelector("#mgChart"), D, S.mgP, stt);
    const fi = root.querySelector("#mgFitInfo"), F = stt.fitInfo; fi.hidden = !(fitOk && F);
    if(!fi.hidden){ const u = S.mgP === "t" ? "°C" : "%", sg = (F.slope >= 0 ? "+" : "−") + Math.abs(F.slope).toFixed(2);
      fi.innerHTML = '<bdi dir="ltr">' + esc(t("روند کلی (خط قرمز): ", "Overall trend (red line): ")) + sg + " " + u + "/" + esc(t("روز", "day")) + (F.r2lin != null ? " · R²=" + F.r2lin.toFixed(2) : "") + "</bdi>" +
        (F.amp != null ? ' · <bdi dir="ltr">' + esc(t("برازش دوره‌ای (سبز): دامنهٔ چرخهٔ شبانه‌روزی ", "Periodic fit (green): diurnal amplitude ")) + F.amp.toFixed(1) + " " + u + (F.r2per != null ? " · R²=" + F.r2per.toFixed(2) : "") + "</bdi>" : ""); }
  }
  let mgRz = 0; window.addEventListener("resize", () => { clearTimeout(mgRz); mgRz = setTimeout(() => { if(root && !root.hidden && S.mg) mgRender(); }, 200); });
  const PRESETS = [["استهبان", "Estahban", 29.13, 54.04], ["شیراز", "Shiraz", 29.59, 52.58], ["تهران", "Tehran", 35.69, 51.39], ["مشهد", "Mashhad", 36.30, 59.60], ["تبریز", "Tabriz", 38.08, 46.29], ["اهواز", "Ahvaz", 31.32, 48.67]];
  function shell(){
    const pr = PRESETS.map((p, i) => '<button type="button" class="labChip" data-pre="' + i + '">' + esc(E() ? p[1] : p[0]) + "</button>").join("");
    return '<div class="lab" dir="' + (E() ? "ltr" : "rtl") + '">' +
      '<section class="labIn"><h3>' + esc(t("آزمایشگاه محاسبات جوّ بالا", "Upper-air computation lab")) + '</h3><p class="labNote">' + esc(t("سونداژ یا پروفایل مدل را وارد کنید؛ شاخص‌ها با هستهٔ ترمودینامیک MET (سازگار با MetPy و آزموده‌شده) در مرورگر محاسبه می‌شوند. دادهٔ ناقص هرگز با صفر پر نمی‌شود.", "Enter a sounding or model profile; indices are computed in your browser with the MET thermodynamic core (MetPy-compatible, regression-tested). Missing data is never filled with zero.")) + "</p>" +
      '<div class="labSeg" role="tablist"><button type="button" data-tab="paste">' + esc(t("چسباندن / فایل", "Paste / file")) + '</button><button type="button" data-tab="om">Open-Meteo</button></div>' +
      '<div id="labPaste"><textarea id="labTxt" rows="9" dir="ltr" spellcheck="false" placeholder="PRES HGHT TEMP DWPT DRCT SKNT&#10;1000.0  36  22.2  21.0 180 7&#10;…"></textarea>' +
      '<div class="labBtns"><label class="labFile">' + esc(t("بارگذاری فایل", "Load file")) + '<input type="file" id="labFile" accept=".txt,.csv,.tsv,text/plain,text/csv" hidden></label>' +
      '<button type="button" id="labSample">' + esc(t("نمونه", "Sample")) + '</button><label>' + esc(t("یکای سرعت باد (ستون عمومی)", "Wind speed unit (generic column)")) + ' <select id="labWu"><option value="ms">m/s</option><option value="kt">kt</option><option value="kmh">km/h</option></select></label>' +
      '<button type="button" id="labRun" class="labGo">' + esc(t("تحلیل", "Analyse")) + '</button></div>' +
      '<p class="labSub">' + esc(t("قالب‌ها: متن Wyoming (ستون‌های PRES HGHT TEMP DWPT … DRCT SKNT) یا CSV با سرایند: pressure, height, temperature, dewpoint, wdir, wspd (یا u, v). دما و شبنم °C، فشار hPa، ارتفاع m.", "Formats: Wyoming text (PRES HGHT TEMP DWPT … DRCT SKNT) or CSV with header: pressure, height, temperature, dewpoint, wdir, wspd (or u, v). Temperature/dew point °C, pressure hPa, height m.")) + "</p></div>" +
      '<div id="labOm" hidden><div class="labBtns labPlace"><label>' + esc(t("استان", "Province")) + ' <select id="labProv"></select></label><label>' + esc(t("مرکز شهرستان", "County seat")) + ' <select id="labSeat"></select></label></div><p class="labSub">' + esc(t("با انتخاب شهر، پروفایل جوّ بالا و متئوگرام چندمدلی همان نقطه دریافت می‌شود؛ برای هر نقطهٔ دلخواه دیگر طول و عرض را بنویسید.", "Choosing a city fetches the upper-air profile and the multi-model meteogram for that point; for any other point type the latitude and longitude.")) + '</p><div class="labBtns"><label>' + esc(t("عرض", "Lat")) + ' <input id="labLat" type="number" step="0.01" value="29.13" dir="ltr"></label><label>' + esc(t("طول", "Lon")) + ' <input id="labLon" type="number" step="0.01" value="54.04" dir="ltr"></label><button type="button" id="labOmGo" class="labGo">' + esc(t("دریافت پروفایل", "Fetch profile")) + '</button><button type="button" data-an="skewt" class="labAnB">' + esc(t("تحلیل علمی اسکیوتی", "Scientific Skew-T analysis")) + '</button><button type="button" data-an="lab" class="labAnB">' + esc(t("تحلیل علمی آزمایشگاه محاسبات", "Scientific lab analysis")) + "</button></div>" +
      '<div class="labBtns" id="labOmRow" hidden><label>' + esc(t("زمان معتبر", "Valid time")) + ' <select id="labOmT"></select></label></div>' +
      '<p class="labSub">' + esc(t("دادهٔ مدل از ", "Model data from ")) + '<a href="https://open-meteo.com/" target="_blank" rel="noopener">Open-Meteo.com</a> (CC BY 4.0). ' + esc(t("خروجی مدل است نه رصد؛ ترازهای زیر سطح زمین حذف می‌شوند و باد سطح = ۱۰ متری.", "Model output, not observations; levels below ground are dropped; the surface wind is the 10 m wind.")) + "</p></div>" +
      '<div id="labMsg" class="labMsg" hidden></div></section>' +
      '<section id="labMg" class="labMgS" hidden><div class="mgHead"><h3 id="mgTitle"></h3><div id="mgSub" class="labSub"></div></div>' +
      '<div class="mgTabs" role="tablist">' + Object.entries(M.mg.PARAMS).map(([k, p]) => '<button type="button" data-mgp="' + k + '">' + esc(E() ? p.en : p.fa) + "</button>").join("") + "</div>" +
      '<div class="mgOpts"><div class="mgRng" role="group" aria-label="range">' + [3, 5, 10, 15].map(n => '<button type="button" data-mgr="' + n + '">' + esc(E() ? n + " days" : n.toLocaleString("fa-IR") + " روزه") + "</button>").join("") + "</div>" +
      '<div id="mgFits" class="mgRng" hidden><button type="button" data-mgf="trend">' + esc(t("روند کلی", "Overall trend")) + '</button><button type="button" data-mgf="per">' + esc(t("برازش دوره‌ای", "Periodic fit")) + '</button><button type="button" data-mgf="ma">' + esc(t("روند ۲۴ ساعته", "24 h trend")) + "</button></div></div>" +
      '<div id="mgFitInfo" class="labSub" hidden></div><div id="mgLeg" class="mgLeg"></div><div id="mgChart" class="mgChart"></div><div id="mgSt" class="labSub"></div>' +
      '<div class="labBtns"><button type="button" data-mgdl="png">PNG</button><button type="button" data-mgdl="svg">SVG</button><span class="labSub">' + esc(t("خط سیاه ضخیم = میانهٔ مدل‌ها (دست‌کم ۲ مدل)؛ نوار بنفش = پراکندگی (کمینه تا بیشینهٔ مدل‌ها)؛ نوار تیره = شب؛ زمان‌ها به وقت ایران. روی هر مدل در راهنما بزنید تا پنهان/نمایان شود.", "Thick black = model median (at least 2 models); violet band = spread (model min–max); shaded = night; times are Iran local time. Tap a model in the legend to hide/show it.")) + '</span></div></section>' +
      '<section id="labOut" hidden><div id="labSum" class="labSum"></div><div class="labBtns"><button type="button" data-an="skewt" class="labAnB">' + esc(t("تحلیل علمی اسکیوتی", "Scientific Skew-T analysis")) + '</button><button type="button" data-an="lab" class="labAnB">' + esc(t("تحلیل علمی آزمایشگاه محاسبات", "Scientific lab analysis")) + '</button></div><div id="labAn" class="anBox" hidden></div><div class="labTop"><div class="labPanel"><div class="labSeg2">' +
      ["SB", "ML", "MU"].map(k => '<button type="button" data-par="' + k + '">' + k + "</button>").join("") + '<span class="labSub">' + esc(t("نوع پارسل: سطحی / مخلوط ۱۰۰ hPa / ناپایدارترین ۳۰۰ hPa", "Parcel: surface / mixed 100 hPa / most unstable 300 hPa")) + '</span></div><div class="labSeg2 skModes"><button type="button" data-skm="2d">' + esc(t("مدرن ۲بعدی", "Modern 2D")) + '</button><button type="button" data-skm="3d">' + esc(t("سه‌بعدی", "3D")) + '</button><button type="button" data-skm="old">' + esc(t("کلاسیک", "Classic")) + '</button><label id="skRotL" class="labSub" hidden>' + esc(t("زاویه", "Angle")) + ' <input id="skRot" type="range" min="10" max="75" value="38"></label></div><div id="labSk"></div><div id="labInfo" class="labInfo">' + esc(t("برای خواندن مقادیر، روی نمودار بزنید یا نشانگر را حرکت دهید.", "Tap or hover on the chart to read values.")) + '</div>' +
      '<div class="labBtns"><button type="button" data-dl="svg">SVG</button><button type="button" data-dl="png">PNG</button><span class="labSub">' + esc(t("خطوط: دما قرمز، شبنم سبز، پارسل خط‌چین؛ سایهٔ قرمز = CAPE و آبی = CIN (روی دمای واقعی رسم می‌شود؛ مقدار عددی بر دمای مجازی است).", "Red = temperature, green = dew point, dashed = parcel; red shading = CAPE, blue = CIN (drawn on actual temperature; the numbers use virtual temperature).")) + "</span></div></div>" +
      '<div class="labPanel labHodoP"><h4>' + esc(t("هودوگراف", "Hodograph")) + '</h4><div id="labHodo"></div><div class="labSub">' + esc(t("رنگ: ۰–۳ km قرمز، ۳–۶ سبز، ۶–۹ نارنجی، بالاتر بنفش · RM/LM حرکت توفان راست/چپ‌گرد Bunkers", "Colour: 0–3 km red, 3–6 green, 6–9 orange, above purple · RM/LM = Bunkers right/left mover")) + "</div></div></div>" +
      '<div id="labCards"></div></section></div>';
  }
  function bind(){
    root.querySelectorAll("[data-tab]").forEach(b => b.onclick = () => { S.tab = b.dataset.tab; root.querySelector("#labPaste").hidden = S.tab !== "paste"; root.querySelector("#labOm").hidden = S.tab !== "om"; root.querySelectorAll("[data-tab]").forEach(x => x.classList.toggle("on", x.dataset.tab === S.tab)); });
    root.querySelector("[data-tab=" + S.tab + "]").click();
    root.querySelector("#labRun").onclick = runText;
    root.querySelector("#labSample").onclick = () => { root.querySelector("#labTxt").value = M.SAMPLE; root.querySelector("#labWu").value = "kt"; runText(); };
    root.querySelector("#labFile").onchange = ev => { const f = ev.target.files[0]; if(!f) return; if(f.size > 2e6){ msg(t("فایل بزرگ است (بیش از ۲ مگابایت).", "File too large (> 2 MB)."), true); return; } const rd = new FileReader(); rd.onload = () => { root.querySelector("#labTxt").value = String(rd.result); runText(); }; rd.readAsText(f); ev.target.value = ""; };
    root.querySelector("#labOmGo").onclick = () => { S.place = null; omFetch(); mgFetch(); }; placeBind(); root.querySelector("#labOmT").onchange = omRun;
    root.querySelectorAll("[data-an]").forEach(b => b.onclick = () => anShow(b.dataset.an));
    root.querySelectorAll("[data-skm]").forEach(b => b.onclick = () => { S.skMode = b.dataset.skm; if(S.res) render(); });
    root.querySelector("#skRot").oninput = ev => { S.skRot = +ev.target.value; if(S.res && S.skMode === "3d") { const sk = root.querySelector("#labSk"); sk.innerHTML = M.skewt2.svg3d(S.res, {en:E(), parcel:S.parcel, title:S.parcel + " parcel", rot:S.skRot}); } };
    root.querySelectorAll("[data-par]").forEach(b => b.onclick = () => { S.parcel = b.dataset.par; if(S.raw) { const keep = S.src; if(S.om && S.src.indexOf("Open-Meteo") === 0) omRun(); else analyze(S.raw, keep); } });
    root.querySelectorAll("[data-mgp]").forEach(b => b.onclick = () => { S.mgP = b.dataset.mgp; mgRender(); });
    root.querySelectorAll("[data-mgr]").forEach(b => b.onclick = () => { S.mgRange = +b.dataset.mgr; sset("mg.range", S.mgRange); mgRender(); });
    root.querySelectorAll("[data-mgf]").forEach(b => b.onclick = () => { S.mgFit[b.dataset.mgf] = !S.mgFit[b.dataset.mgf]; mgRender(); });
    root.querySelectorAll("[data-mgdl]").forEach(b => b.onclick = () => { const sv = root.querySelector("#mgChart svg"); if(sv) M.skewt.download(sv, "meteogram-" + S.mgP, b.dataset.mgdl === "png"); });
    root.querySelector("#mgLeg").onclick = ev => { const b = ev.target.closest("[data-mgm]"); if(!b) return; const k = b.dataset.mgm;
      if(k === "*"){ S.mgHide.clear(); } else if(S.mgHide.has(k)) S.mgHide.delete(k); else S.mgHide.add(k); mgRender(); };
    root.querySelectorAll("[data-dl]").forEach(b => b.onclick = () => { const sv = root.querySelector("#labSk svg"); if(sv) M.skewt.download(sv, "skewt-" + S.parcel, b.dataset.dl === "png"); });
  }
  window.labInit = function(host){
    if(!host) return; if(root === host && host.firstChild) return;
    root = host; const keepTxt = ""; host.innerHTML = shell(); bind(); render();
    if(!host._lg){ host._lg = true; document.addEventListener("langchange", () => { if(!host.hidden && root === host){ const txt = host.querySelector("#labTxt").value, tab = S.tab; const la = host.querySelector("#labLat").value, lo = host.querySelector("#labLon").value; host.innerHTML = shell(); S.tab = tab; bind(); host.querySelector("#labTxt").value = txt; host.querySelector("#labLat").value = la; host.querySelector("#labLon").value = lo; render(); mgRender(); } }); }
  };
})();
