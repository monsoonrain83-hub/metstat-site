/* ===== پوستهٔ سایت (r52): منوی همبرگری، صفحهٔ اصلی دوبخشی، صفحهٔ «ترکیب نقشه‌های آفلاین»، مختصات زیر نشانگر =====
   هیچ صفحه‌ای جابه‌جا یا بازنویسی نمی‌شود؛ همان تابع‌های بازکردن قبلی (openON، openSA، کلیک دکمه‌های لندینگ و …) صدا زده می‌شوند.
   نوار دکمه‌های افقی قبلی (#topnav) فقط پنهان می‌شود و منطق همگام‌سازی‌اش (عنوان تب، آدرس صفحه) سر جایش می‌ماند. */
(function(){
  const EN=()=>typeof LANG!=="undefined"&&LANG==="en";
  const land=document.getElementById("landing");
  const keyOf=b=>b.dataset.tt?"tt":b.dataset.wm?"wm":b.dataset.mode;
  const landBtn=k=>land?[...land.querySelectorAll(".choice")].find(b=>keyOf(b)===k):null;
  const GO={
    on:()=>openON(), sa:()=>openSA(), an:()=>openAN(), lab:()=>(typeof openLab==="function"?openLab():openAN()),
    ds:()=>openDS(), ca:()=>openCA(), ci:()=>openCI()
  };
  function go(k){ try{ const f=GO[k]; if(f) f(); else { const b=landBtn(k); if(b) b.click(); } }catch(e){ console.warn("shell go",k,e); } window.scrollTo(0,0); setTimeout(sync,80); }
  /* کلید صفحهٔ فعلی (همان منطق نوار قبلی + زبانهٔ آزمایشگاه) */
  function cur(){ let m=""; try{ m=store.get("mode",""); }catch(e){}
    if(m==="cv"||m==="wn") return "an";
    if(m==="an"){ try{ if(AN.lab) return "lab"; }catch(e){} }
    return m; }
  const OFF=["wu","wb","wm","cu","lt"], MAIN=["on","ci","sa"];

  /* ---------- منوی همبرگری (r56): فقط نام صفحه‌ها؛ زیرمجموعهٔ هر صفحه با فلش — دسکتاپ: با رفتن موس روی صفحه، کنار منو؛ موبایل: با لمس نام صفحه، زیر همان ردیف ---------- */
  /* هر صفحه: [شناسه، فارسی، انگلیسی، زیرمجموعه‌ها]؛ هر زیرمجموعه: [کلید رفتن، فارسی، انگلیسی]. کلیدهای رفتن: صفحه (on، sa، …) یا «صفحه:گزینه» */
  const NAVI=[
    ["on","مدل‌های هواشناسی","Weather models",[]],
    ["ci","شاخص‌های اقلیمی","Climate indices",[["ci:ocean","شاخص‌های اقیانوسی","Oceanic indices"],["ci:atmos","شاخص‌های جوی","Atmospheric indices"],["ci:sst","نقشه‌های شماتیک SST","Schematic SST maps"]]],
    ["sa","تصاویر ماهواره و رعدوبرق","Satellite & lightning",[["sa:sat","تصاویر ماهواره","Satellite images"],["sa:lt","رادار رعدوبرق","Lightning radar"],["sa:rad","رادار بارش","Rain radar"],["sa:mb","متئوبلو","meteoblue"],["sa:insat","INSAT","INSAT"]]],
    ["an","تحلیل","Analysis",[["an","تحلیل و هشدار","Analysis & warnings"],["lab","آزمایشگاه محاسبات","Computation lab"]]],
    ["off","ترکیب نقشه‌های آفلاین","Offline map composer",[["wu","weather.us","weather.us"],["wb","WeatherBELL","WeatherBELL"],["wm","weathermodels","weathermodels"],["cu","tropicaltidbits و هر سایت","tropicaltidbits & any site"],["lt","تراکم رعدوبرق","Lightning density"]]],
    ["tools","ابزارها و اقلیم","Tools & climate",[["ds","اصلاح با ارتفاع","Elevation correction"],["ca","اطلس اقلیمی","Climate atlas"]]]
  ];
  const ICON_K={off:"wu",tools:"ca"}, iconOf=k=>{ if(k==="lab") return '<svg class="ch-ic" viewBox="0 0 24 24" aria-hidden="true"><path d="M9 3h6M10 3v6L4.5 19a1.5 1.5 0 0 0 1.3 2h12.4a1.5 1.5 0 0 0 1.3-2L14 9V3"/><path d="M7 15h10"/></svg>'; if(k==="ci") return '<svg class="ch-ic" viewBox="0 0 24 24" aria-hidden="true"><path d="M3 17l5-6 4 3 5-8 4 5"/><path d="M3 21h18"/></svg>'; const s=document.querySelector(`#topnav .tn-btn[data-k="${ICON_K[k]||k}"] svg`); return s?s.outerHTML:'<svg class="ch-ic" viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="8"/></svg>'; };
  const topIn=document.querySelector(".top .top-in"), topEl=document.querySelector(".top");
  const hb=document.createElement("button"); hb.type="button"; hb.id="hambBtn"; hb.className="hamb"; hb.setAttribute("data-noi18n",""); hb.setAttribute("aria-haspopup","true"); hb.setAttribute("aria-expanded","false");
  hb.innerHTML='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 6.5h16M4 12h16M4 17.5h16"/></svg><span class="hambCur"></span>';
  /* نوار جدای منو: دیگر با لوگو و عنوان قاطی نمی‌شود */
  const mbar=document.createElement("div"); mbar.className="menuBar"; mbar.id="menuBar"; mbar.setAttribute("data-noi18n",""); mbar.append(hb);
  if(topEl&&topIn) topEl.insertBefore(mbar,topIn); else if(topIn) topIn.prepend(hb);
  const dr=document.createElement("div"); dr.id="drawer"; dr.className="drawer"; dr.hidden=true; dr.setAttribute("data-noi18n","");
  dr.innerHTML='<div class="drBack"></div><nav class="drPan" aria-label="menu"><div class="drHead"><b class="drT"></b><button type="button" class="drX" aria-label="close">×</button></div><div class="drBody"></div></nav><div class="drFly" hidden></div>';
  document.body.append(dr);
  const HOVER=()=>window.matchMedia&&matchMedia("(hover:hover) and (pointer:fine)").matches&&innerWidth>700;   /* موبایل/صفحهٔ باریک: همیشه حالت لمسی (باز/بسته با کلیک) */
  const chev='<svg class="drCh" viewBox="0 0 24 24" aria-hidden="true"><path d="M15 6l-6 6 6 6"/></svg>';
  const subHTML=(P,en)=>P[3].map(([g,fa,e])=>`<button type="button" class="drS" data-go="${g}">${en?e:fa}</button>`).join("");
  function onPage(k,P){ return k===P[0]||P[3].some(s=>s[0].split(":")[0]===k); }
  function drFill(){ const en=EN(), k=cur();
    dr.querySelector(".drT").textContent=en?"Menu":"منو";
    dr.querySelector(".drBody").innerHTML=NAVI.map(P=>{ const has=P[3].length>0, tgt=P[0]==="off"||P[0]==="tools"?"":P[0], on=onPage(k,P);
      return `<div class="drItem${on?" on":""}" data-id="${P[0]}"><button type="button" class="drI${on?" on":""}" ${has?`data-sub="${P[0]}"`:""} ${tgt&&!has?`data-go="${tgt}"`:""} ${has&&tgt?`data-main="${tgt}"`:""}>${iconOf(P[0])}<span>${en?P[2]:P[1]}</span>${has?chev:""}</button>${has?`<div class="drSub">${subHTML(P,en)}</div>`:""}</div>`; }).join(""); }
  let flyT=0, flyFor="";
  function flyHide(){ const f=dr.querySelector(".drFly"); clearTimeout(flyT); f.hidden=true; flyFor=""; dr.querySelectorAll(".drItem.hov").forEach(x=>x.classList.remove("hov")); }
  function flyShow(item){ if(!HOVER()) return; const P=NAVI.find(x=>x[0]===item.dataset.id); if(!P||!P[3].length) return; clearTimeout(flyT);
    const f=dr.querySelector(".drFly"), pan=dr.querySelector(".drPan"), pr=pan.getBoundingClientRect(), ir=item.getBoundingClientRect(), rtl=getComputedStyle(pan).direction==="rtl";
    f.innerHTML=subHTML(P,EN()); f.hidden=false; flyFor=P[0]; dr.querySelectorAll(".drItem.hov").forEach(x=>x.classList.remove("hov")); item.classList.add("hov");
    f.style.top=Math.max(8,Math.min(ir.top,innerHeight-f.offsetHeight-8))+"px"; if(rtl){ f.style.right=(innerWidth-pr.left)+"px"; f.style.left="auto"; } else { f.style.left=pr.right+"px"; f.style.right="auto"; } }
  function drOpen(){ drFill(); dr.hidden=false; hb.setAttribute("aria-expanded","true"); requestAnimationFrame(()=>dr.classList.add("open")); const a=dr.querySelector(".drI.on")||dr.querySelector(".drI"); if(a) try{ a.focus({preventScroll:true}); }catch(e){} }
  function drClose(){ flyHide(); dr.classList.remove("open"); hb.setAttribute("aria-expanded","false"); setTimeout(()=>{ if(!dr.classList.contains("open")) dr.hidden=true; },220); }
  hb.onclick=()=>dr.hidden?drOpen():drClose();
  /* کلید رفتن: «صفحه» یا «صفحه:گزینه» (ماهواره: زبانه؛ شاخص‌ها: دسته) */
  function goSub(g){ const [pg,opt]=g.split(":"); if(pg==="sa"&&opt){ go("sa"); setTimeout(()=>{ const t=document.querySelector(`.saTab[data-t="${opt}"]`); if(t) t.click(); },350); return; }
    if(pg==="ci"&&opt){ try{ cxGo(opt); }catch(e){ go("ci"); } setTimeout(sync,120); return; } go(pg); }
  dr.addEventListener("click",e=>{
    const sb=e.target.closest(".drS"); if(sb){ drClose(); goSub(sb.dataset.go); return; }
    const b=e.target.closest(".drI");
    if(b){ const item=b.closest(".drItem");
      if(b.dataset.sub){ if(HOVER()){ if(b.dataset.main){ drClose(); go(b.dataset.main); } else flyShow(item); }       /* دسکتاپ: کلیک = رفتن به خود صفحه (اگر صفحهٔ اصلی دارد)، زیرمجموعه با موس */
        else { const was=item.classList.contains("open"); dr.querySelectorAll(".drItem.open").forEach(x=>x.classList.remove("open")); item.classList.toggle("open",!was); } return; }
      if(b.dataset.go){ drClose(); go(b.dataset.go); return; } }
    if(e.target.closest(".drX")||e.target.classList.contains("drBack")) drClose(); });
  dr.addEventListener("mouseover",e=>{ const it=e.target.closest(".drItem"); if(it&&it.querySelector(".drSub")&&HOVER()){ if(flyFor!==it.dataset.id) flyShow(it); else clearTimeout(flyT); } else if(!e.target.closest(".drFly")&&HOVER()){ clearTimeout(flyT); flyT=setTimeout(flyHide,160); } else if(e.target.closest(".drFly")) clearTimeout(flyT); });
  dr.querySelector(".drPan").addEventListener("mouseleave",()=>{ clearTimeout(flyT); flyT=setTimeout(flyHide,220); });
  dr.querySelector(".drFly").addEventListener("mouseenter",()=>clearTimeout(flyT));
  dr.querySelector(".drFly").addEventListener("mouseleave",()=>{ clearTimeout(flyT); flyT=setTimeout(flyHide,220); });
  document.addEventListener("keydown",e=>{ if(e.key==="Escape"&&!dr.hidden) drClose(); });

  /* ---------- نوارهای بالای صفحه ---------- */
  const anchor=document.getElementById("pgAddr")||document.getElementById("topnav")||document.querySelector(".top");
  const hubM=document.createElement("div"); hubM.id="hubMain"; hubM.className="hub hubMain"; hubM.hidden=true; hubM.setAttribute("data-noi18n","");
  hubM.innerHTML='<button type="button" class="hubBig" data-go="on"><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3.2 3 14.8 0 18M12 3c-3 3.2-3 14.8 0 18"/></svg><span></span></button><button type="button" class="hubBig" data-go="ci"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 17l5-6 4 3 5-8 4 5"/><path d="M3 21h18"/></svg><span></span></button><button type="button" class="hubBig" data-go="sa"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M13 2L4 14h7l-1 8 9-12h-7z"/></svg><span></span></button>';
  const hubO=document.createElement("div"); hubO.id="hubOff"; hubO.className="hub hubOff"; hubO.hidden=true; hubO.setAttribute("data-noi18n","");
  hubO.innerHTML='<div class="hubOh"><b></b><small></small></div><div class="hubOr"><div class="hubOg" data-g="s"></div><div class="hubOg hubOlt" data-g="l"></div></div>';
  anchor.parentNode.insertBefore(hubO, anchor.nextSibling); anchor.parentNode.insertBefore(hubM, anchor.nextSibling);
  const OFFL={wu:["weather.us","weather.us"],wb:["WeatherBELL","WeatherBELL"],wm:["weathermodels","weathermodels"],cu:["tropicaltidbits و هر سایت","tropicaltidbits & any site"]};
  function hubTxt(){ const en=EN();
    const s=hubM.querySelectorAll(".hubBig span"); s[0].textContent=en?"Weather models":"مدل‌های هواشناسی"; s[1].textContent=en?"Climate indices":"شاخص‌های اقلیمی"; s[2].textContent=en?"Satellite & lightning images":"تصاویر ماهواره و رعدوبرق";
    hubO.querySelector(".hubOh b").textContent=en?"Offline map composer":"ترکیب نقشه‌های آفلاین";
    hubO.querySelector(".hubOh small").textContent=en?"Combine screenshots from popular model sites":"ترکیب تصویر نقشه‌های سایت‌های پرکاربرد مدل";
    hubO.querySelector('[data-g="s"]').innerHTML=Object.entries(OFFL).filter(([k])=>k==="cu"||landBtn(k)).map(([k,t])=>`<button type="button" class="hubC" data-go="${k}">${en?t[1]:t[0]}</button>`).join("");
    hubO.querySelector('[data-g="l"]').innerHTML=`<span class="hubOs">${en?"Separate tool":"ابزار جدا"}</span><button type="button" class="hubC hubLt" data-go="lt">${iconOf("lt")}${en?"Lightning density map":"ساخت نقشهٔ تراکم رعدوبرق"}</button>`;
    sync(); }
  for(const h of [hubM,hubO]) h.addEventListener("click",e=>{ const b=e.target.closest("[data-go]"); if(!b) return; if(b.classList.contains("on")) return; go(b.dataset.go); });

  function sync(){
    const k=cur(), vis=land?land.hidden:true;
    hubM.hidden=!(vis&&MAIN.includes(k)); hubO.hidden=!(vis&&OFF.includes(k));
    hubM.querySelectorAll("[data-go]").forEach(b=>b.classList.toggle("on",b.dataset.go===k));
    hubO.querySelectorAll("[data-go]").forEach(b=>b.classList.toggle("on",b.dataset.go===k));
    const lab=EN()?"Menu":"منو"; const c=hb.querySelector(".hambCur"); if(c.textContent!==lab) c.textContent=lab;
    hb.title=lab; hb.setAttribute("aria-label",lab);
    if(!dr.hidden) dr.querySelectorAll(".drItem").forEach(it=>{ const P=NAVI.find(x=>x[0]===it.dataset.id), on=!!P&&onPage(k,P); it.classList.toggle("on",on); const b=it.querySelector(".drI"); if(b) b.classList.toggle("on",on); });
  }
  window.shellSync=sync;
  const mo=new MutationObserver(()=>setTimeout(sync,40));
  for(const id of ["landing","app","dsApp","cvApp","ltApp","wnApp","cqcApp","caApp","onApp","ciApp","saApp","anApp","labApp"]){ const e=document.getElementById(id); if(e) mo.observe(e,{attributes:true,attributeFilter:["hidden"]}); }
  addEventListener("popstate",()=>setTimeout(sync,80)); addEventListener("hashchange",()=>setTimeout(sync,80));
  document.addEventListener("langchange",()=>{ hubTxt(); if(!dr.hidden) drFill(); });
  setInterval(sync,1200); hubTxt();
})();

/* ===== «اصلاح با ارتفاع» با نقشهٔ آنلاین: کادر از نمایشگر به بالای صفحهٔ اصلاح با ارتفاع منتقل شد =====
   همان کادر و همان تابع nvXRender (41_nwp_viewer.js)؛ فقط محل قرارگیری عوض شده. اگر صفحهٔ اصلاح مستقیم باز شود
   و فهرست نقشه‌های هاست هنوز خوانده نشده باشد، اینجا خوانده می‌شود. بخش دستی (PNG/JPG) زیر آن مثل قبل می‌ماند. */
(function(){
  const asd=document.querySelector("#dsApp > aside"); if(!asd) return;
  let box=document.getElementById("nvXfer");
  const sec=document.createElement("section"); sec.className="panel dsOnl"; sec.id="dsOnl";
  sec.innerHTML='<h2>نقشهٔ آنلاین مدل‌ها</h2><p class="hint dsOnlH" id="dsOnlH">در حال خواندن فهرست نقشه‌های روی هاست…</p>';
  if(box){ box.remove(); } else { box=document.createElement("div"); box.className="nvXfer"; box.id="nvXfer"; }
  sec.append(box); asd.prepend(sec);
  try{ for(const [f,e] of [["نقشهٔ آنلاین مدل‌ها","Online model maps"],["ورود دستی نقشه (PNG یا JPG)","Manual map input (PNG or JPG)"],["در حال خواندن فهرست نقشه‌های روی هاست…","Reading the list of maps on the host…"],
    ["فعلاً نقشهٔ بارش یا دمای ایران روی هاست نیست.","No Iran precipitation or temperature maps on the host yet."],["بخش آنلاین در دسترس نیست.","The online section is not available."],["فهرست نقشه‌ها خوانده نشد.","The map list could not be read."]]) I18N_EX.set(i18nNorm(f),e); }catch(e){}
  const man=asd.querySelector("#dsDrop"); if(man){ const s=man.closest("section"); if(s&&!s.id) s.id="dsManPanel"; try{ VPAGES.ds.keepAside=(VPAGES.ds.keepAside||[]).concat(["dsOnl","dsManPanel"]); }catch(e){} if(s&&!s.querySelector(".dsManTag")){ const t=document.createElement("div"); t.className="dsManTag"; t.textContent="ورود دستی نقشه (PNG یا JPG)"; s.prepend(t); } }
  let busy=false;
  async function ensure(){ const h=document.getElementById("dsOnlH");
    if(typeof ON==="undefined"||typeof onLoadManifest!=="function"){ if(h) h.textContent="بخش آنلاین در دسترس نیست."; return; }
    if(!ON.man&&!busy){ busy=true; try{ const msg=await onLoadManifest(); if(!ON.man&&h){ h.textContent=msg||"فهرست نقشه‌ها خوانده نشد."; return; } }finally{ busy=false; } }
    try{ nvXRender(); }catch(e){ console.warn("dsOnl",e); }
    if(h){ const has=box.innerHTML.trim(); h.hidden=!!has; if(!has&&ON.man) h.textContent="فعلاً نقشهٔ بارش یا دمای ایران روی هاست نیست."; } }
  const o=window.openDS; if(typeof o==="function"){ window.openDS=function(){ const r=o.apply(this,arguments); setTimeout(ensure,0); return r; }; }
  if(document.getElementById("dsApp")&&!document.getElementById("dsApp").hidden) setTimeout(ensure,0);
})();

/* ===== مختصات زیر نشانگر ماوس روی نقشهٔ صفحهٔ اصلی (مثل Google Earth و ArcGIS) =====
   درجهٔ اعشاری + درجه/دقیقه/ثانیه؛ در حالت تمام‌صفحه نمایشگر خودش (fsCoord) را دارد و این پنهان می‌شود. */
(function(){
  const dms=(v,p,n)=>{ const a=Math.abs(v), d=Math.floor(a), mf=(a-d)*60, m=Math.floor(mf), s=Math.round((mf-m)*60); let D=d,M=m,S=s; if(S===60){ S=0; M++; } if(M===60){ M=0; D++; }
    return `${D}°${String(M).padStart(2,"0")}′${String(S).padStart(2,"0")}″${v>=0?p:n}`; };
  let el=null, last=0;
  function hide(){ if(el) el.hidden=true; }
  document.addEventListener("pointermove",e=>{
    if(e.pointerType&&e.pointerType!=="mouse"&&e.pointerType!=="pen") return;
    const st=document.getElementById("nvStage");
    if(!st||!st.contains(e.target)||typeof NV==="undefined"||!NV.view||(typeof NVF!=="undefined"&&NVF.on)){ hide(); return; }
    const now=performance.now(); if(now-last<30) return; last=now;
    const r=st.getBoundingClientRect(), x=e.clientX-r.left, y=e.clientY-r.top, v=NV.view, lon=v.x0+x/v.k, lat=v.y0-y/v.k;
    if(!el||el.parentNode!==st){ el=document.createElement("div"); el.id="nvCoord"; el.className="nvCoord"; el.setAttribute("aria-hidden","true"); el.setAttribute("data-noi18n",""); st.append(el); }
    if(!(lat>-90&&lat<90&&isFinite(lon))){ hide(); return; }
    el.hidden=false; el.innerHTML=`<b>${dms(lat,"N","S")}  ${dms(lon,"E","W")}</b><span>${lat.toFixed(4)}, ${lon.toFixed(4)}</span>`;
  },{passive:true});
  document.addEventListener("pointerleave",hide,true);
  document.addEventListener("mouseout",e=>{ const st=document.getElementById("nvStage"); if(st&&!st.contains(e.relatedTarget)) hide(); },true);
})();
