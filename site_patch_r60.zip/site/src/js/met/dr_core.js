/* ===== کارگاه خشکسالی و تغییر اقلیم — هستهٔ علمی (بدون DOM؛ در Node هم آزموده می‌شود) =====
   روش‌ها (بازنویسی مستقل از فرمول‌های منتشرشده؛ هیچ کدی از پروژه‌های AGPL/بی‌مجوز کپی نشده است):
   • SPI: McKee, Doesken & Kleist (1993)؛ برازش گاما به روش Thom (۱۹۵۸) با جرم صفر (Edwards & McKee 1997).
   • SPEI: Vicente-Serrano, Beguería & López-Moreno (2010)؛ لوگ‌لجستیک سه‌پارامتری با گشتاورهای وزنی احتمالی (Singh 1993).
   • ET0 هارگریوز–سامانی (۱۹۸۵) و تورنت‌وایت (۱۹۴۸)؛ تابش فرازمینی Ra از FAO-56 (Allen و همکاران ۱۹۹۸، معادلهٔ ۲۱).
   • رخداد خشکسالی: نظریهٔ ران‌ها (Yevjevich 1967؛ McKee 1993): آغاز با شاخص ≤ آستانهٔ آغاز، پایان با شاخص > آستانهٔ پایان.
   • SDF: بیشینهٔ سالانهٔ کمبود تجمعی برای مدت‌های مختلف + گامبل با گشتاورهای L (Hosking 1990).
   قراردادها: سری ماهانه با نمایه ۰ = ماه ۱ سال آغاز؛ مقدار مفقود NaN؛ هرگز با صفر پر نمی‌شود. ماه‌ها شمسی‌اند (همان پایگاه اطلس). */
(function(root){
  "use strict";
  const MET = root.MET = root.MET || {}, D = MET.dr = {};
  const fin = x => typeof x === "number" && isFinite(x);
  /* ---------- توابع ویژه ---------- */
  const G = [0.99999999999980993, 676.5203681218851, -1259.1392167224028, 771.32342877765313, -176.61502916214059, 12.507343278686905, -0.13857109526572012, 9.9843695780195716e-6, 1.5056327351493116e-7];
  function lgamma(z){ if(z < 0.5) return Math.log(Math.PI / Math.abs(Math.sin(Math.PI * z))) - lgamma(1 - z);
    z -= 1; let a = G[0]; const t = z + 7.5; for(let i = 1; i < 9; i++) a += G[i] / (z + i); return 0.5 * Math.log(2 * Math.PI) + (z + 0.5) * Math.log(t) - t + Math.log(a); }
  const gamma = z => (z < 0.5 ? Math.PI / (Math.sin(Math.PI * z) * gamma(1 - z)) : Math.exp(lgamma(z)));
  function gammaPQ(a, x){ // [P, Q] تابع گامای ناقص تنظیم‌شده (Numerical Recipes: سری / کسر مسلسل)
    if(!(x > 0)) return [0, 1]; if(!(a > 0)) return [NaN, NaN]; const lg = lgamma(a);
    if(x < a + 1){ let ap = a, sum = 1 / a, del = sum; for(let n = 0; n < 1000; n++){ ap += 1; del *= x / ap; sum += del; if(Math.abs(del) < Math.abs(sum) * 1e-16) break; } const P = sum * Math.exp(-x + a * Math.log(x) - lg); return [P, 1 - P]; }
    let b = x + 1 - a, c = 1e300, d = 1 / b, h = d; for(let i = 1; i < 1000; i++){ const an = -i * (i - a); b += 2; d = an * d + b; if(Math.abs(d) < 1e-300) d = 1e-300; c = b + an / c; if(Math.abs(c) < 1e-300) c = 1e-300; d = 1 / d; const del = d * c; h *= del; if(Math.abs(del - 1) < 1e-16) break; }
    const Q = Math.exp(-x + a * Math.log(x) - lg) * h; return [1 - Q, Q]; }
  const gammaP = (a, x) => gammaPQ(a, x)[0];
  function erfc(x){ const z = Math.abs(x), q = gammaPQ(0.5, z * z)[1]; return x >= 0 ? q : 2 - q; }   // erfc(x) = Q(½, x²)
  const normCdf = z => 0.5 * erfc(-z / Math.SQRT2);
  function normInv(p){ // Acklam + یک گام هالی ⇒ دقت ~1e-15
    if(!(p > 0 && p < 1)) return p === 0 ? -Infinity : p === 1 ? Infinity : NaN;
    const a = [-3.969683028665376e+01, 2.209460984245205e+02, -2.759285104469687e+02, 1.383577518672690e+02, -3.066479806614716e+01, 2.506628277459239e+00],
      b = [-5.447609879822406e+01, 1.615858368580409e+02, -1.556989798598866e+02, 6.680131188771972e+01, -1.328068155288572e+01],
      c = [-7.784894002430293e-03, -3.223964580411365e-01, -2.400758277161838e+00, -2.549732539343734e+00, 4.374664141464968e+00, 2.938163982698783e+00],
      d = [7.784695709041462e-03, 3.224671290700398e-01, 2.445134137142996e+00, 3.754408661907416e+00]; let x;
    if(p < 0.02425){ const q = Math.sqrt(-2 * Math.log(p)); x = (((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) / ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1); }
    else if(p > 1 - 0.02425){ const q = Math.sqrt(-2 * Math.log(1 - p)); x = -(((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) / ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1); }
    else { const q = p - 0.5, r = q * q; x = (((((a[0] * r + a[1]) * r + a[2]) * r + a[3]) * r + a[4]) * r + a[5]) * q / (((((b[0] * r + b[1]) * r + b[2]) * r + b[3]) * r + b[4]) * r + 1); }
    const e = normCdf(x) - p, u = e * Math.sqrt(2 * Math.PI) * Math.exp(x * x / 2); return x - u / (1 + x * u / 2); }
  D.sp = {lgamma, gamma, gammaP, gammaPQ, erfc, normCdf, normInv};
  const ZMAX = 3.09;   // برش احتمال به [0٫001, 0٫999] مانند پیاده‌سازی‌های مرجع SPI/SPEI
  const zOf = p => { if(!fin(p)) return NaN; const q = Math.min(0.999, Math.max(0.001, p)); return normInv(q); };

  /* ---------- برازش‌ها ---------- */
  D.fitGamma = function(x){ // x: مقادیر مثبت (جرم صفر جدا شمرده می‌شود)
    const pos = x.filter(v => v > 0), n = x.length; if(pos.length < 10) return null;
    const m = pos.reduce((s, v) => s + v, 0) / pos.length, lm = pos.reduce((s, v) => s + Math.log(v), 0) / pos.length, A = Math.log(m) - lm; if(!(A > 0)) return null;
    const alpha = (1 + Math.sqrt(1 + 4 * A / 3)) / (4 * A); return {alpha, beta: m / alpha, q: (n - pos.length) / n}; };
  D.cdfGamma = (f, v) => f.q + (1 - f.q) * (v > 0 ? gammaP(f.alpha, v / f.beta) : 0);
  D.fitLogLogistic = function(x){ // گشتاورهای وزنی احتمالی ناریب w_s = E[x(1−F)^s] (Landwehr و همکاران ۱۹۷۹؛ Singh 1993)
    const n = x.length; if(n < 15) return null; const s = x.slice().sort((a, b) => a - b); let w0 = 0, w1 = 0, w2 = 0;
    for(let i = 0; i < n; i++){ const j = i + 1; w0 += s[i]; w1 += s[i] * (n - j) / (n - 1); w2 += s[i] * (n - j) * (n - j - 1) / ((n - 1) * (n - 2)); }
    w0 /= n; w1 /= n; w2 /= n;
    const beta = (2 * w1 - w0) / (6 * w1 - w0 - 6 * w2), g1 = gamma(1 + 1 / beta), g2 = gamma(1 - 1 / beta);
    const alpha = (w0 - 2 * w1) * beta / (g1 * g2), gam = w0 - alpha * g1 * g2; if(!(alpha > 0) || !fin(beta) || !fin(gam) || beta <= 1) return null; return {alpha, beta, gamma: gam}; };
  D.cdfLogLogistic = (f, v) => { const t = (f.alpha) / (v - f.gamma); return (v - f.gamma) > 0 ? 1 / (1 + Math.pow(t, f.beta)) : 0.0000001; };

  /* ---------- تبخیر–تعرق مرجع ---------- */
  const MD = [31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29];                 // روزهای ماه شمسی (اسفند ۲۹؛ کبیسه نادیده)
  const MID = [95, 126, 157, 188, 219, 250, 281, 311, 341, 6, 36, 66];        // روز میلادی سال (DOY) میانهٔ هر ماه شمسی
  D.daysInMonth = (m, jy) => m === 12 ? (D.isLeapJ(jy) ? 30 : 29) : MD[m - 1];
  D.isLeapJ = jy => [1, 5, 9, 13, 17, 22, 26, 30].indexOf(((jy % 33) + 33) % 33) >= 0;
  D.midDoy = m => MID[m - 1];
  D.Ra = function(latDeg, doy){ // MJ m⁻² day⁻¹ (FAO-56، معادلهٔ ۲۱)
    const phi = latDeg * Math.PI / 180, dr = 1 + 0.033 * Math.cos(2 * Math.PI * doy / 365), dec = 0.409 * Math.sin(2 * Math.PI * doy / 365 - 1.39);
    const ws = Math.acos(Math.max(-1, Math.min(1, -Math.tan(phi) * Math.tan(dec))));
    return 24 * 60 / Math.PI * 0.0820 * dr * (ws * Math.sin(phi) * Math.sin(dec) + Math.cos(phi) * Math.cos(dec) * Math.sin(ws)); };
  D.hargreaves = function(tmax, tmin, latDeg, m, days){ // mm/ماه
    if(!fin(tmax) || !fin(tmin) || tmax < tmin) return NaN; const tm = (tmax + tmin) / 2, ra = D.Ra(latDeg, MID[m - 1]) * 0.408;
    return Math.max(0, 0.0023 * ra * (tm + 17.8) * Math.sqrt(tmax - tmin)) * days; };
  D.dayLength = function(latDeg, doy){ const phi = latDeg * Math.PI / 180, dec = 0.409 * Math.sin(2 * Math.PI * doy / 365 - 1.39); return 24 / Math.PI * Math.acos(Math.max(-1, Math.min(1, -Math.tan(phi) * Math.tan(dec)))); };
  D.thornthwaiteClim = function(tClim12, latDeg){ // tClim12: میانگین بلندمدت دمای ۱۲ ماه (°C) ⇒ تابع (T,m,days)
    let I = 0; for(const t of tClim12) if(fin(t) && t > 0) I += Math.pow(t / 5, 1.514); if(!(I > 0)) return null;
    const a = 6.75e-7 * I ** 3 - 7.71e-5 * I ** 2 + 1.792e-2 * I + 0.49239;
    return (T, m, days) => { if(!fin(T)) return NaN; if(T <= 0) return 0; const N = D.dayLength(latDeg, MID[m - 1]);
      const e = T < 26.5 ? 16 * Math.pow(10 * T / I, a) : -415.85 + 32.24 * T - 0.43 * T * T; return Math.max(0, e * (N / 12) * (days / 30)); }; };

  /* ---------- شاخص استاندارد (SPI/SPEI) ---------- */
  D.accumulate = function(x, k){ const o = new Float64Array(x.length).fill(NaN); for(let t = k - 1; t < x.length; t++){ let s = 0, ok = true; for(let j = 0; j < k; j++){ const v = x[t - j]; if(!fin(v)){ ok = false; break; } s += v; } if(ok) o[t] = s; } return o; };
  /* series: ماهانه؛ opts: {scale، method:"spi"|"spei"، ref:[سال‌نمایهٔ آغاز، پایان] (شامل)، minYears} ⇒ {z, fits, nref} */
  D.standardize = function(series, opts){
    const k = opts.scale || 1, meth = opts.method || "spi", n = series.length, acc = D.accumulate(series, k), z = new Float64Array(n).fill(NaN), fits = new Array(12).fill(null);
    const y0 = opts.ref ? opts.ref[0] : 0, y1 = opts.ref ? opts.ref[1] : Math.floor((n - 1) / 12), minY = opts.minYears || 20, nref = new Array(12).fill(0);
    for(let m = 0; m < 12; m++){
      const ref = []; for(let y = y0; y <= y1; y++){ const t = y * 12 + m; if(t >= 0 && t < n && fin(acc[t])) ref.push(acc[t]); } nref[m] = ref.length; if(ref.length < minY) continue;
      const f = meth === "spei" ? D.fitLogLogistic(ref) : D.fitGamma(ref); fits[m] = f; if(!f) continue;
      for(let t = m; t < n; t += 12){ const v = acc[t]; if(!fin(v)) continue; const p = meth === "spei" ? D.cdfLogLogistic(f, v) : D.cdfGamma(f, v); z[t] = zOf(p); } }
    return {z, fits, nref}; };
  D.SPI_CLASSES = [[2, "extremely_wet", "بسیار شدید تر", "Extremely wet"], [1.5, "very_wet", "خیلی تر", "Very wet"], [1, "moderately_wet", "نسبتاً تر", "Moderately wet"], [-1, "normal", "نزدیک نرمال", "Near normal"],
    [-1.5, "moderate_dry", "خشکی متوسط", "Moderately dry"], [-2, "severe_dry", "خشکی شدید", "Severely dry"], [-Infinity, "extreme_dry", "خشکی بسیار شدید", "Extremely dry"]];
  D.classOf = function(z){ if(!fin(z)) return null; if(z >= 2) return D.SPI_CLASSES[0]; if(z >= 1.5) return D.SPI_CLASSES[1]; if(z >= 1) return D.SPI_CLASSES[2]; if(z > -1) return D.SPI_CLASSES[3]; if(z > -1.5) return D.SPI_CLASSES[4]; if(z > -2) return D.SPI_CLASSES[5]; return D.SPI_CLASSES[6]; };

  /* ---------- رخدادهای خشکسالی (نظریهٔ ران‌ها) ---------- */
  D.events = function(z, o){ o = o || {}; const on = o.onset != null ? o.onset : -1, off = o.end != null ? o.end : 0, minDur = o.minDur || 1, ev = []; let cur = null;
    for(let t = 0; t < z.length; t++){ const v = z[t];
      if(!fin(v)){ if(cur){ cur.cut = true; ev.push(cur); cur = null; } continue; }
      if(!cur){ if(v <= on) cur = {start: t, end: t, sev: -v, peak: v, tPeak: t, n: 1, cut: false}; }
      else if(v > off){ ev.push(cur); cur = null; }
      else { cur.end = t; cur.n++; cur.sev += -v; if(v < cur.peak){ cur.peak = v; cur.tPeak = t; } } }
    if(cur){ cur.open = true; ev.push(cur); }
    return ev.filter(e => e.n >= minDur).map(e => Object.assign(e, {dur: e.end - e.start + 1, intensity: e.sev / e.n})); };

  /* ---------- شدت–مدت–بسامد (SDF) ---------- */
  D.gumbelFitL = function(x){ const n = x.length; if(n < 8) return null; const s = x.slice().sort((a, b) => a - b); let b0 = 0, b1 = 0; for(let i = 0; i < n; i++){ b0 += s[i]; b1 += s[i] * i / (n - 1); } b0 /= n; b1 /= n;
    const l1 = b0, l2 = 2 * b1 - b0, alpha = l2 / Math.LN2; if(!(alpha > 0)) return null; return {xi: l1 - 0.5772156649 * alpha, alpha}; };
  D.gumbelQ = (f, T) => f.xi - f.alpha * Math.log(-Math.log(1 - 1 / T));
  /* z: SPI یا SPEI یک‌ماهه (ماهانه)؛ مدت‌ها به ماه؛ برمی‌گرداند {durs, T, table[مدت][T] , n} و سری بیشینهٔ سالانه */
  D.sdf = function(z, durs, Ts){ durs = durs || [1, 3, 6, 12, 24]; Ts = Ts || [2, 5, 10, 25, 50]; const ny = Math.floor(z.length / 12), res = {durs, T: Ts, table: [], annual: [], n: []};
    for(const d of durs){ const ann = [];
      for(let y = 0; y < ny; y++){ let best = NaN; for(let t = y * 12; t < y * 12 + 12; t++){ if(t - d + 1 < 0) continue; let s = 0, ok = true; for(let j = 0; j < d; j++){ const v = z[t - j]; if(!fin(v)){ ok = false; break; } s += Math.max(0, -v); } if(ok && (!(best >= 0) || s > best)) best = s; } if(fin(best)) ann.push(best); }
      res.annual.push(ann); res.n.push(ann.length); const f = D.gumbelFitL(ann); res.table.push(f ? Ts.map(T => D.gumbelQ(f, T)) : Ts.map(() => null)); }
    return res; };

  /* ---------- ناحیه‌ای ---------- */
  D.areaFraction = function(zs, thr){ // zs: آرایهٔ سری‌های ایستگاهی هم‌طول؛ سهم ایستگاه‌های با z ≤ thr در هر ماه (فقط ایستگاه‌های دارای داده)
    const n = zs.length ? zs[0].length : 0, o = new Float64Array(n).fill(NaN), cnt = new Int32Array(n);
    for(let t = 0; t < n; t++){ let a = 0, b = 0; for(const z of zs){ const v = z[t]; if(fin(v)){ b++; if(v <= thr) a++; } } cnt[t] = b; if(b >= 5) o[t] = a / b; } return {frac: o, n: cnt}; };

  /* ---------- روند و تغییر (برای فاز تغییر اقلیم و آمار خشکسالی) ---------- */
  D.sen = function(xs, ys){ const sl = []; for(let i = 0; i < xs.length; i++) for(let j = i + 1; j < xs.length; j++) if(xs[j] !== xs[i] && fin(ys[i]) && fin(ys[j])) sl.push((ys[j] - ys[i]) / (xs[j] - xs[i]));
    if(sl.length < 3) return null; sl.sort((a, b) => a - b); const m = sl.length >> 1, slope = sl.length % 2 ? sl[m] : (sl[m - 1] + sl[m]) / 2, r = ys.filter(fin).map((y, i) => y - slope * xs[i]).sort((a, b) => a - b); return {slope, icpt: r[r.length >> 1]}; };
  D.mannKendall = function(y){ const v = y.filter(fin), n = v.length; if(n < 8) return null; let S = 0; for(let i = 0; i < n - 1; i++) for(let j = i + 1; j < n; j++) S += Math.sign(v[j] - v[i]);
    const tie = {}; v.forEach(a => tie[a] = (tie[a] || 0) + 1); let tt = 0; for(const k in tie){ const t = tie[k]; if(t > 1) tt += t * (t - 1) * (2 * t + 5); }
    const vr = (n * (n - 1) * (2 * n + 5) - tt) / 18, Z = S > 0 ? (S - 1) / Math.sqrt(vr) : S < 0 ? (S + 1) / Math.sqrt(vr) : 0; return {S, Z, p: 2 * (1 - normCdf(Math.abs(Z))), n}; };
})(typeof globalThis !== "undefined" ? globalThis : this);
