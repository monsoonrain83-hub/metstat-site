/* ===== صفحهٔ «شاخص‌های اقلیمی» (r56) =====
   دکمهٔ جدا کنار «مدل‌های هواشناسی» و «ماهواره و رعدوبرق». جریان: منبع/مدل (NOAA، GEFS، ECMWF) ← دسته (اقیانوسی، جوی، نقشهٔ شماتیک SST)
   ← زیردسته (اطلس، آرام، هند، شمالگان، جنوبگان | نیم‌کرهٔ شمالی، جنوبی، استوایی) ← شاخص ← نمودار (به‌جای کادر نقشه).
   نمودارها همان رسم‌کنندهٔ 54_nv_indices.js (civRender/civChart) هستند؛ این فایل فقط صفحه، دسته‌بندی و نمودار فاز MJO را اضافه می‌کند.
   داده: online/data/idx/index.json (+ <id>.json). هیچ عددی ساخته یا درون‌یابی نمی‌شود. */
const CX={src:"noaa",cat:"ocean",sub:"pacific",id:"",ok:false};
try{ Object.assign(CX,store.get("cx.sel",{})||{}); }catch(e){}
const cxEN=()=>typeof LANG!=="undefined"&&LANG==="en";
const cxT=(fa,en)=>cxEN()?en:fa;
const CX_SRC=[["noaa","NOAA","NOAA (مشاهداتی ماهانه)","NOAA (observed, monthly)"],["gefs","GEFS","GEFS (NOAA/NCEP)","GEFS (NOAA/NCEP)"],["ecmwf","ECMWF","ECMWF","ECMWF"]];
/* دسته‌بندی استاندارد: عبارت‌ها روی شناسهٔ پایهٔ شاخص (بدون پسوند _gefs/_ecmwf) تطبیق داده می‌شوند. AO و AAO هم زیر قطبی‌ها و هم زیر الگوهای جوی می‌آیند. */
const CX_CATS=[
 {k:"ocean",fa:"۱) شاخص‌های اقیانوسی",en:"1) Oceanic indices",subs:[
  {k:"pacific",fa:"اقیانوس آرام",en:"Pacific Ocean",re:/^(nino12|nino3|nino34|nino4|oni|meiv2|mei|pdo|ipo|soi)$/},
  {k:"atlantic",fa:"اقیانوس اطلس",en:"Atlantic Ocean",re:/^(amo|tna|tsa|amm|atlnino|atl3)$/},
  {k:"indian",fa:"اقیانوس هند",en:"Indian Ocean",re:/^(dmi|iod|iosd|iodw|iode)$/},
  {k:"arctic",fa:"شمالگان (قطب شمال)",en:"Arctic",re:/^(ao)$/},
  {k:"antarctic",fa:"جنوبگان (قطب جنوب)",en:"Antarctic",re:/^(aao|sam)$/}]},
 {k:"atmos",fa:"۲) شاخص‌های جوی",en:"2) Atmospheric indices",subs:[
  {k:"nh",fa:"الگوهای پیوند از دور نیم‌کرهٔ شمالی",en:"Northern Hemisphere teleconnections",re:/^(nao|ao|ea|eawr|ea_wr|wp|wpo|scand|pna|tnh|epnp|polar)$/},
  {k:"sh",fa:"نیم‌کرهٔ جنوبی",en:"Southern Hemisphere",re:/^(aao|sam|psa1|psa2)$/},
  {k:"trop",fa:"استوایی و پوشن‌سپهر (MJO، QBO، SOI)",en:"Tropics & stratosphere (MJO, QBO, SOI)",re:/^(soi|qbo|mjo)$/},
  {k:"other",fa:"سایر",en:"Other",re:null}]},
 {k:"sst",fa:"۳) نقشه‌های شماتیک SST",en:"3) Schematic SST maps",subs:[{k:"all",fa:"همهٔ نقشه‌ها",en:"All maps",re:null}]}
];
const cxBase=id=>String(id).replace(/_(gefs|ecmwf|ec|gfs|ens)$/i,"").toLowerCase();
const cxSrcOf=(id,e)=>{ const m=civMdl(id,e); return m==="gfs"?"gefs":m==="ecmwf"?"ecmwf":"noaa"; };
const cxIsMap=e=>e&&(e.kind==="map"||e.cat==="sst");
function cxMatch(id,e,catK,subK){
  if(catK==="sst") return cxIsMap(e);
  if(cxIsMap(e)) return false;
  const C=CX_CATS.find(c=>c.k===catK), S=C&&C.subs.find(s=>s.k===subK); if(!S) return false;
  const b=cxBase(id);
  if(S.re) return S.re.test(b);
  return !CX_CATS.some(c=>c.subs.some(s=>s.re&&s.re.test(b)));      /* «سایر»: هر چیزی که به هیچ زیردسته‌ای (در هیچ دسته‌ای) نخورده */
}
const cxItems=()=>(CIV.idx&&CIV.idx.items)||{};
const cxList=(src,cat,sub)=>Object.keys(cxItems()).filter(id=>{ const e=civEnt(id); return e&&cxSrcOf(id,e)===src&&cxMatch(id,e,cat,sub); });
function cxSave(){ try{ store.set("cx.sel",{src:CX.src,cat:CX.cat,sub:CX.sub,id:CX.id}); }catch(e){} }
/* اگر انتخاب فعلی تهی است، اولین ترکیب دارای شاخص را برمی‌دارد (ابتدا همان دسته/زیردسته، بعد بقیه) */
function cxFix(){
  const C=CX_CATS.find(c=>c.k===CX.cat)||CX_CATS[0]; CX.cat=C.k; if(!C.subs.some(s=>s.k===CX.sub)) CX.sub=C.subs[0].k;
  if(cxList(CX.src,CX.cat,CX.sub).length) return;
  for(const c of CX_CATS) for(const s of c.subs) if(cxList(CX.src,c.k,s.k).length){ CX.cat=c.k; CX.sub=s.k; return; }
}
const cxChip=(label,on,attr,dis,n)=>`<button type="button" class="cxChip${on?" on":""}"${dis?" disabled":""} ${attr}>${label}${n!=null?` <small>${typeof FA==="function"?FA(n):n}</small>`:""}</button>`;
function cxHTML(){
  return `<section class="card cxSel"><h3>${cxT("شاخص‌های اقلیمی","Climate indices")}</h3>
   <div class="cxLbl">${cxT("۱) منبع / مدل","1) Source / model")}</div><div class="cxRow" id="cxSrc"></div>
   <div class="cxLbl">${cxT("۲) دسته","2) Category")}</div><div class="cxRow" id="cxCat"></div>
   <div class="cxLbl">${cxT("۳) زیردسته","3) Subcategory")}</div><div class="cxRow" id="cxSub"></div>
   <div class="cxLbl">${cxT("۴) شاخص","4) Index")}</div><div class="cxRow" id="cxIdx"></div>
   <div class="hint" id="cxMsg"></div></section>
  <article id="civPanel" class="card wide civCard" hidden data-noi18n></article>
  <article id="cxMap" class="card wide civCard" hidden data-noi18n></article>`;
}
function cxDraw(){
  const m=$("ciMain"); if(!m||!m.dataset.cx) return; cxFix();
  $("cxSrc").innerHTML=CX_SRC.map(([k,,fa,en])=>cxChip(cxT(fa,en),CX.src===k,`data-cx-src="${k}"`,false,CX_CATS.reduce((n,c)=>n+c.subs.reduce((q,s)=>q+cxList(k,c.k,s.k).length,0),0)||0)).join("");
  $("cxCat").innerHTML=CX_CATS.map(c=>cxChip(cxT(c.fa,c.en),CX.cat===c.k,`data-cx-cat="${c.k}"`,false,c.subs.reduce((n,s)=>n+cxList(CX.src,c.k,s.k).length,0))).join("");
  const C=CX_CATS.find(c=>c.k===CX.cat);
  $("cxSub").innerHTML=C.subs.map(s=>{ const n=cxList(CX.src,C.k,s.k).length; if(s.k==="other"&&!n) return ""; return cxChip(cxT(s.fa,s.en),CX.sub===s.k,`data-cx-sub="${s.k}"`,!n,n); }).join("");
  const L=cxList(CX.src,CX.cat,CX.sub), msg=$("cxMsg");
  $("cxIdx").innerHTML=L.map(id=>cxChip(civEsc(civName(id)),CX.id===id,`data-cx-id="${id}"`)).join("");
  if(!Object.keys(cxItems()).length) msg.textContent=cxT("هنوز شاخصی روی هاست نیست (workflow شاخص‌ها را اجرا کنید).","No indices on the host yet (run the indices workflow).");
  else if(!L.length) msg.textContent=CX.cat==="sst"?cxT("هنوز نقشهٔ شماتیک SST اضافه نشده است. نقشه‌ها را در online/data/idx/ بگذارید و در index.json با kind:\"map\" و img ثبت کنید (راهنما در HANDOFF).","No schematic SST maps yet. Put images in online/data/idx/ and register them in index.json with kind:\"map\" and img."):cxT("برای این منبع در این زیردسته شاخصی نیست؛ منبع یا زیردستهٔ دیگری را بزنید.","Nothing for this source in this subcategory; try another source or subcategory.");
  else msg.textContent="";
  if(L.length&&!L.includes(CX.id)) CX.id=L[0];
  if(!L.length) CX.id="";
  [...$("cxIdx").children].forEach(b=>b.classList.toggle("on",b.dataset.cxId===CX.id));
  cxShow();
}
async function cxShow(){
  const p=$("civPanel"), mp=$("cxMap"); if(!p||!mp) return; const e=CX.id&&civEnt(CX.id);
  if(!e){ p.hidden=true; mp.hidden=true; CIV.sel=null; return; }
  if(cxIsMap(e)){ CIV.sel=null; p.hidden=true; mp.hidden=false;
    const u=e.img?(/^https?:|^\//.test(e.img)?e.img:ON.base+"data/idx/"+e.img):"";
    mp.innerHTML=`<header class="civHd"><div><h3>${civEsc(civName(e.id))}</h3><div class="sub">${civEsc([e.src,e.note].filter(Boolean).join(" · "))}</div></div></header>${u?`<img class="civImg" alt="" src="${civEsc(u)}?${(CIV.idx&&CIV.idx.updated)||""}">`:`<div class="hint">${cxT("تصویر این نقشه ثبت نشده است.","No image registered for this map.")}</div>`}`;
    return; }
  mp.hidden=true; CIV.hub=true; CIV.sel=e.id; CIV.rep=false; CIV.info=false; p.hidden=false; p.classList.remove("civFadeOut");
  await civRender();
}
async function cxLoad(force){ await civLoad(force); }
async function cxStart(){
  const m=$("ciMain"); if(!m) return;
  if(!m.dataset.cx){ m.innerHTML=cxHTML(); m.dataset.cx="1"; m.dataset.ok="1";
    const p=$("civPanel"); p.addEventListener("click",civClick);
    m.addEventListener("click",e=>{ const b=e.target.closest("button"); if(!b||b.disabled) return;
      if(b.dataset.cxSrc){ CX.src=b.dataset.cxSrc; CX.id=""; }
      else if(b.dataset.cxCat){ CX.cat=b.dataset.cxCat; CX.sub=""; CX.id=""; }
      else if(b.dataset.cxSub){ CX.sub=b.dataset.cxSub; CX.id=""; }
      else if(b.dataset.cxId){ CX.id=b.dataset.cxId; }
      else return; cxSave(); cxDraw(); }); }
  $("cxMsg").textContent=cxT("در حال دریافت فهرست شاخص‌ها…","Loading the list of indices…");
  await cxLoad(true); cxDraw(); cxSave();
}
/* از منوی همبرگری: باز کردن صفحه با دستهٔ مشخص (ocean | atmos | sst) */
window.cxGo=async function(cat){ if(cat&&CX_CATS.some(c=>c.k===cat)){ CX.cat=cat; CX.sub=""; CX.id=""; } try{ await openCI(); }catch(e){ console.warn(e); } };
window.openCI=async function(){
  for(const id of ["landing","app","dsApp","cvApp","ltApp","wnApp","cqcApp","caApp","onApp","saApp","anApp","labApp"]) if($(id)) $(id).hidden=true;
  $("ciApp").hidden=false; $("srcName").textContent="شاخص‌های اقلیمی"; $("srcBtn").hidden=false; store.set("mode","ci"); window.scrollTo(0,0);
  await cxStart(); };
/* با رفتن به هر صفحهٔ دیگر، این صفحه پنهان می‌شود (همان الگوی wrapperهای ماهواره) */
for(const fn of ["switchMode","showLanding","openCQC","openDS","openCV","openLT","openWN","openCA","openON","openSA","openAN"]){ const f=window[fn]; if(typeof f!=="function") continue; window[fn]=function(...a){ if($("ciApp")) $("ciApp").hidden=true; return f.apply(this,a); }; }
document.addEventListener("langchange",()=>{ const m=$("ciMain"); if(m&&m.dataset.cx&&!$("ciApp").hidden){ m.innerHTML=cxHTML(); $("civPanel").addEventListener("click",civClick); cxDraw(); } });

/* ---------- نمودار فاز MJO (فضای فاز RMM/OMI: محور افقی RMM1، عمودی RMM2؛ فاصله از مرکز = دامنه) ---------- */
const CX_MJO_PH=[["1","Western Hem. · Africa","نیمکرهٔ غربی · آفریقا"],["2","Indian Ocean","اقیانوس هند"],["3","Indian Ocean","اقیانوس هند"],["4","Maritime Continent","قارهٔ دریایی"],["5","Maritime Continent","قارهٔ دریایی"],["6","Western Pacific","غرب اقیانوس آرام"],["7","Western Pacific","غرب اقیانوس آرام"],["8","Western Hem. · Africa","نیمکرهٔ غربی · آفریقا"]];
function cxMjoPhase(a,b){ const ang=(Math.atan2(b,a)*180/Math.PI+360)%360; return ((Math.floor(((ang-180+360)%360)/45))%8)+1; }
function cxMjoChart(host,e,S,per){
  const en=civEN(), days=+(String(per).replace(/\D/g,""))||60, W0=Math.max(300,Math.round(host.getBoundingClientRect().width||600)), W=Math.min(W0,640), H=W, c=W/2, R=Math.max(2,0), LIM=4, sc=(W/2-26)/LIM, X=v=>c+v*sc, Y=v=>c-v*sc, uid="mj"+(++CIV.tok);
  const o=[`<svg xmlns="http://www.w3.org/2000/svg" class="civSvg cxMjo" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" font-family="Vazirmatn,Tahoma,sans-serif" direction="ltr">`,
   `<rect x="0" y="0" width="${W}" height="${H}" rx="14" fill="#fff"/><rect x="${X(-LIM)}" y="${Y(LIM)}" width="${X(LIM)-X(-LIM)}" height="${Y(-LIM)-Y(LIM)}" rx="8" fill="#f8fbff" stroke="#dbe4f0"/>`];
  for(let k=-LIM+1;k<LIM;k++){ if(k===0) continue; o.push(`<line x1="${X(k)}" x2="${X(k)}" y1="${Y(LIM)}" y2="${Y(-LIM)}" stroke="#e2e8f0" stroke-width=".7"/><line x1="${X(-LIM)}" x2="${X(LIM)}" y1="${Y(k)}" y2="${Y(k)}" stroke="#e2e8f0" stroke-width=".7"/><text x="${X(k)}" y="${Y(-LIM)+14}" font-size="10" text-anchor="middle" fill="#64748b">${k}</text><text x="${X(-LIM)+4}" y="${Y(k)+3}" font-size="10" fill="#64748b">${k}</text>`); }
  /* هشت قطاع فاز */
  for(let i=0;i<8;i++){ const a0=(180+45*i)*Math.PI/180, a1=a0+Math.PI/4, am=(a0+a1)/2; const x1=X(LIM*1.42*Math.cos(a0)), y1=Y(LIM*1.42*Math.sin(a0));
    o.push(`<line x1="${c}" y1="${c}" x2="${Math.max(X(-LIM),Math.min(X(LIM),x1))}" y2="${Math.max(Y(LIM),Math.min(Y(-LIM),y1))}" stroke="#cbd5e1" stroke-width="1"/>`);
    const lx=X(3.25*Math.cos(am)), ly=Y(3.25*Math.sin(am)); o.push(`<text x="${lx}" y="${ly}" text-anchor="middle" font-size="22" font-weight="800" fill="#94a3b8" opacity=".75">${CX_MJO_PH[i][0]}</text><text x="${X(3.35*Math.cos(am))}" y="${Y(3.35*Math.sin(am))+15}" text-anchor="middle" font-size="9.5" fill="#94a3b8">${civEsc(en?CX_MJO_PH[i][1]:CX_MJO_PH[i][2])}</text>`); }
  o.push(`<circle cx="${c}" cy="${c}" r="${sc}" fill="#e5e7eb" fill-opacity=".85" stroke="#94a3b8"/><text x="${c}" y="${c+4}" text-anchor="middle" font-size="10" fill="#475569">${civT("ضعیف","weak")}</text>`);
  const path=pts=>pts.map((q,i)=>(i?"L":"M")+X(q[0]).toFixed(1)+" "+Y(q[1]).toFixed(1)).join("");
  const ot=S.obs&&S.obs.t?S.obs.t.slice(-days):[], oa=S.obs&&S.obs.a?S.obs.a.slice(-days):[], ob=S.obs&&S.obs.b?S.obs.b.slice(-days):[];
  const op=ot.map((t,i)=>[oa[i],ob[i],t]).filter(q=>civFin(q[0])&&civFin(q[1]));
  const F=S.fc;
  if(F&&F.mem){ o.push(`<g fill="none" stroke-linejoin="round" stroke-linecap="round">`+F.mem.map(r=>{ const pts=[op.length?op[op.length-1]:null].concat(r).filter(q=>q&&civFin(q[0])&&civFin(q[1])); return pts.length>1?`<path d="${path(pts)}" stroke="#6366f1" stroke-width=".9" opacity=".3"/>`:""; }).join("")+`</g>`); }
  if(op.length>1) o.push(`<path d="${path(op)}" fill="none" stroke="#fff" stroke-width="5.5" stroke-linejoin="round"/><path d="${path(op)}" fill="none" stroke="#0f172a" stroke-width="2.4" stroke-linejoin="round"/>`);
  op.forEach((q,i)=>{ if((op.length-1-i)%5===0||i===op.length-1){ o.push(`<circle cx="${X(q[0])}" cy="${Y(q[1])}" r="${i===op.length-1?5.5:3}" fill="${i===op.length-1?"#dc2626":"#0f172a"}" stroke="#fff" stroke-width="1.4"/>`); if((op.length-1-i)%10===0) o.push(`<text x="${X(q[0])+6}" y="${Y(q[1])-6}" font-size="9.5" fill="#334155">${civEsc(String(q[2]).slice(5))}</text>`); } });
  if(F&&F.mean&&F.mean.length){ const pts=(op.length?[op[op.length-1]]:[]).concat(F.mean).filter(q=>civFin(q[0])&&civFin(q[1])); if(pts.length>1) o.push(`<path d="${path(pts)}" fill="none" stroke="#fff" stroke-width="6.5" stroke-linejoin="round"/><path d="${path(pts)}" fill="none" stroke="#7c3aed" stroke-width="3" stroke-linejoin="round" stroke-dasharray="1 0"/>`);
    F.mean.forEach((q,i)=>{ if(!civFin(q[0])||!civFin(q[1])) return; const l=F.lead&&F.lead[i]; if(l!=null&&(l%5===0)) o.push(`<circle cx="${X(q[0])}" cy="${Y(q[1])}" r="3.4" fill="#7c3aed" stroke="#fff" stroke-width="1.2"/><text x="${X(q[0])+6}" y="${Y(q[1])+12}" font-size="9.5" font-weight="700" fill="#6d28d9">+${l}</text>`); }); }
  o.push(`<text x="${W-8}" y="${H-5}" text-anchor="end" font-size="9.5" fill="#94a3b8">MetStat · ${civEsc(e.src||"NOAA")}</text><text x="${X(LIM)-4}" y="${Y(0)-5}" text-anchor="end" font-size="10.5" fill="#475569">RMM1 →</text><text x="${c+6}" y="${Y(LIM)+13}" font-size="10.5" fill="#475569">↑ RMM2</text></svg>`);
  host.innerHTML=`<div class="civScroll cxMjoW">${o.join("")}</div>`;
  const last=op.length?op[op.length-1]:null;
  if(last){ const amp=Math.hypot(last[0],last[1]), ph=cxMjoPhase(last[0],last[1]); host.insertAdjacentHTML("beforeend",`<div class="hint cxMjoT">${civT(`آخرین مقدار (${last[2]}): دامنه ${civN(amp)} · فاز ${typeof FA==="function"?FA(ph):ph} (${CX_MJO_PH[ph-1][2]}). دامنهٔ کمتر از ۱ = MJO ضعیف/غیرفعال.`,`Latest (${last[2]}): amplitude ${amp.toFixed(2)} · phase ${ph} (${CX_MJO_PH[ph-1][1]}). Amplitude < 1 = weak/inactive MJO.`)}</div>`); }
}
/* نمودار MJO را به civRender وصل می‌کند (بدون دست‌زدن به رسم‌کنندهٔ شاخص‌های دیگر) */
(function(){ const old=window.civChart; if(typeof old!=="function") return; window.civChart=function(host,e,S,per){ if(S&&S.kind==="mjo") return cxMjoChart(host,e,S,per); return old.apply(this,arguments); }; })();
