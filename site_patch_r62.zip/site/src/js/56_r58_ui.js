/* ===== r58: رفتار مشترک منوهای کشویی =====
   ۱) کلیک (یا لمس) بیرون از هر منوی کشویی، آن را می‌بندد؛ ۲) با باز شدن یکی، بقیه بسته می‌شوند. */
(function(){
  const SEL="details.ovd, details.mcDd, details.saLays";
  document.addEventListener("pointerdown",e=>{
    const t=e.target; if(!t||!t.closest) return;
    document.querySelectorAll(SEL).forEach(d=>{ if(d.open&&!d.contains(t)) d.open=false; });
  },true);
  /* باز شدن یک منو → بستن منوهای هم‌سطح دیگر (مثلاً در نوار بالای نقشه) */
  document.addEventListener("toggle",e=>{
    const d=e.target; if(!d||!d.matches||!d.open||!d.matches("details.ovd,details.saLays")) return;
    document.querySelectorAll("details.ovd[open],details.saLays[open]").forEach(o=>{ if(o!==d&&!o.contains(d)&&!d.contains(o)) o.open=false; });
  },true);
  document.addEventListener("keydown",e=>{ if(e.key==="Escape") document.querySelectorAll(SEL).forEach(d=>{ d.open=false; }); });
})();

/* ===== r58: Overlay چندلایه برای بررسی سینوپتیک =====
   هم‌پوشانی روی نقشهٔ فعلیِ «همان مدل، همان اجرا، همان ساعت اعتبار»:
   • خطوط/پر باد/خطوط جریان: لایهٔ شفاف {pid}L (فقط پارامترهایی که ln دارند: فشار سطح، ارتفاع ۸۵۰/۷۰۰/۵۰۰، باد ۱۰م، ۵۰۰/۳۰۰/۲۵۰/۲۰۰)
   • میدان رنگی: نقشهٔ هر پارامتر دیگر به‌صورت «multiply» با شفافیت قابل‌تنظیم (سفیدی تصویر اثری ندارد)
   نوار رنگ میدان هم‌پوشان زیر نوار اصلی می‌آید. ساعتی که برای لایه‌ای موجود نباشد، آن لایه نمایش داده نمی‌شود و در متن زیر نقشه نوشته می‌شود. */
const OVL={cfg:Object.assign({lines:[],field:"",a:0.5},(function(){ try{ return store.get("nv.ovl",{}); }catch(e){ return {}; } })()),miss:[]};
const OVL_PRE=[["ارتفاع ۵۰۰ + فشار سطح",["z500","sfc"]],["جت ۲۵۰ + ارتفاع ۵۰۰",["w250","z500"]],["۸۵۰ + ۵۰۰ + فشار سطح",["z850","z500","sfc"]]];
function nvOvlSave(){ try{ store.set("nv.ovl",OVL.cfg); }catch(e){} }
function nvOvlItem(pid,v){ try{ return nvMeItems(NV.s.m).find(i=>i.p===pid&&i.v===v)||null; }catch(e){ return null; } }
async function nvOvlLoad(cur){
  const c=OVL.cfg, cp=nvPid(), jobs=[]; OVL.miss=[]; if(!NV.s.m||!cur) return null;
  const par=id=>nvPar(id);
  for(const pid of (c.lines||[])){ if(pid===cp||pid===NV.s.p) continue; const it=nvOvlItem(pid,cur.v); if(!it){ OVL.miss.push(pid); continue; }
    const u=(ON.base+it.f).replace(/\/([a-zA-Z0-9]+)_(\d{10}\.webp)$/,"/$1L_$2")+nvRunQ(); jobs.push(nvImg(u).then(lay=>lay?{pid,mode:"lines",lay}:(OVL.miss.push(pid),null))); }
  if(c.field&&c.field!==cp&&c.field!==NV.s.p){ const it=nvOvlItem(c.field,cur.v); if(!it) OVL.miss.push(c.field);
    else jobs.push(nvImg(ON.base+it.f+nvRunQ()).then(img=>img?{pid:c.field,mode:"field",img,a:c.a,par:par(c.field)}:(OVL.miss.push(c.field),null))); }
  const out=(await Promise.all(jobs)).filter(Boolean); return out.length?out:null;
}
function nvOvlPaint(x,list,dx,dy,dw,dh){
  x.save(); x.imageSmoothingEnabled=false;
  for(const o of list){ if(o.mode!=="field"||!o.img) continue; x.globalCompositeOperation="multiply"; x.globalAlpha=Math.max(0.1,Math.min(1,o.a||0.5)); x.drawImage(o.img,0,0,NV_TW,NV_TH,dx,dy,dw,dh); }
  x.globalCompositeOperation="source-over"; x.globalAlpha=1; x.imageSmoothingEnabled=true; x.imageSmoothingQuality="high";
  for(const o of list){ if(o.mode==="lines"&&o.lay) x.drawImage(o.lay,0,0,NV_TW,NV_TH,dx,dy,dw,dh); }
  x.restore();
}
function nvOvlLegend(e){ const L=[]; for(const o of (e&&e.ovl)||[]){ if(o.mode!=="field"||!o.par) continue; try{ L.push({sc:nvScale(o.par.sc),unit:`${o.par.fa}${(o.par.mu||o.par.unit)?" ("+(o.par.mu||o.par.unit)+")":""} — هم‌پوشان`}); }catch(err){} } return L; }
function nvOvlNotes(e){ const t=[]; for(const o of (e&&e.ovl)||[]){ if(o.mode==="lines"){ const s=NV_LINES[o.pid]; if(s) t.push("هم‌پوشان — "+s); } else if(o.par) t.push(`هم‌پوشان رنگی: ${o.par.fa} (شفافیت ${FA(Math.round((1-(o.a||0.5))*100))}٪)`); }
  if(OVL.miss.length) t.push("برای این ساعت موجود نیست: "+OVL.miss.map(p=>(nvPar(p)||{}).fa||p).join("، ")); return t; }
function nvOvlAvail(){ const have=new Set((NV.s.m?nvMeItems(NV.s.m):[]).map(i=>i.p)), P=(ON.man&&ON.man.params)||[], cp=nvPid();
  return {lines:P.filter(p=>p.ln&&have.has(p.id)&&p.id!==cp&&p.id!==NV.s.p).sort((a,b)=>a.o-b.o), field:P.filter(p=>have.has(p.id)&&p.id!==cp&&p.id!==NV.s.p&&p.cat!=="sc").sort((a,b)=>a.o-b.o)}; }
function nvOvlHtml(k){
  const A=nvOvlAvail(), c=OVL.cfg, fs=k==="fs", chip=(l,on,attr)=>`<button type="button" class="${fs?"fsChip":"wxChip"}${on?" on":""}" ${attr}>${l}</button>`;
  const lines=A.lines.length?A.lines.map(p=>chip(p.fa.replace(/\s*\(.*$/,""),(c.lines||[]).includes(p.id),`data-ovl-l="${p.id}"`)).join(""):'<span class="hint">برای این مدل لایهٔ خطی نیست</span>';
  const pre=OVL_PRE.filter(([t,ids])=>ids.every(i=>A.lines.some(p=>p.id===i)||i===nvPid())).map(([t,ids])=>chip(t,false,`data-ovl-pre="${ids.join(",")}"`)).join("");
  const opts=A.field.map(p=>`<option value="${p.id}"${c.field===p.id?" selected":""}>${p.fa}</option>`).join("");
  const H=fs?"fsH":"hint";
  return `<div class="${H}">ترکیب‌های آماده (بررسی سینوپتیک)</div><div class="${fs?"fsGrid":"wxRow"}">${pre||'<span class="hint">—</span>'}${chip("پاک کردن همه",false,'data-ovl-clr="1"')}</div>
   <div class="${H}">خطوط و پر باد (همان مدل و ساعت)</div><div class="${fs?"fsGrid":"wxRow"}">${lines}</div>
   <div class="${H}">میدان رنگی هم‌پوشان</div><div class="nvOvlRow"><select data-ovl-f="1"><option value="">— بدون —</option>${opts}</select><label>شفافیت <input type="range" min="0.15" max="0.9" step="0.05" value="${c.a}" data-ovl-a="1"></label></div>`;
}
function nvOvlRefresh(reload){
  document.querySelectorAll(".nvOvlBody").forEach(b=>{ b.innerHTML=nvOvlHtml(b.dataset.k); });
  const n=(OVL.cfg.lines||[]).length+(OVL.cfg.field?1:0); document.querySelectorAll(".nvOvlCnt").forEach(s=>{ s.textContent=n?` (${FA(n)})`:""; });
  if(reload!==false) nvResolve();
}
document.addEventListener("click",e=>{ const b=e.target.closest&&e.target.closest("[data-ovl-l],[data-ovl-pre],[data-ovl-clr]"); if(!b) return; const c=OVL.cfg, d=b.dataset;
  if(d.ovlL){ const s=new Set(c.lines||[]); s.has(d.ovlL)?s.delete(d.ovlL):s.add(d.ovlL); c.lines=[...s]; }
  else if(d.ovlPre){ c.lines=d.ovlPre.split(","); }
  else if(d.ovlClr){ c.lines=[]; c.field=""; }
  nvOvlSave(); nvOvlRefresh(); });
document.addEventListener("change",e=>{ const t=e.target; if(!t||!t.dataset) return; if(t.dataset.ovlF!==undefined){ OVL.cfg.field=t.value; nvOvlSave(); nvOvlRefresh(); } });
document.addEventListener("input",e=>{ const t=e.target; if(t&&t.dataset&&t.dataset.ovlA!==undefined){ OVL.cfg.a=+t.value; const en=NV.entry; if(en&&en.ovl){ en.ovl.forEach(o=>{ if(o.mode==="field") o.a=OVL.cfg.a; }); nvDraw(); nvOvlSave(); } else { nvOvlSave(); nvResolve(); } } });
