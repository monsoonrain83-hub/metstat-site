/* ===== کارگاه تغییر اقلیم و خشکسالی — فاز ۲: تغییر اقلیم مشاهده‌ای (r60+)
   روند (شیب سن + بازهٔ اطمینان ۹۵٪ + من–کندال با پیش‌سفیدسازی TFPW)، نقطهٔ تغییر پتیت، نوار اقلیمی، میانگین ناهنجاری ایستگاه‌ها،
   مقایسهٔ نرمال‌ها و نقشهٔ روند. هیچ دادهٔ خام عددی دانلودی تولید نمی‌شود؛ فقط آمارهٔ مشتق‌شده و تصویر. */
const CC={scope:"st", v:"tmean", per:"year", base:"wmo", sid:null, y0:null, y1:null, minN:30, busy:false};
const CC_VARS=["tmean","tmax","tmin","prcp","txx","tnn","fd","hd","rd","pmax"];
const CC_PCT=v=>CA_P[v].kind==="p";                       // بارش‌محورها: ناهنجاری و روند به درصد
const CC_T_COL=["#08306b","#2166ac","#4393c3","#92c5de","#d1e5f0","#f7f7f7","#fddbc7","#f4a582","#d6604d","#b2182b","#67001f"];   // ۱۱ طبقهٔ گسسته (سرد → گرم)
const CC_P_COL=["#543005","#8c510a","#bf812d","#dfc27d","#f6e8c3","#f5f5f5","#c7eae5","#80cdc1","#35978f","#01665e","#003c30"];   // خشک → تر
const ccFa=(v,d)=>FA(caF(v,d==null?2:d));
const ccPer=per=>caPerName(per);
function ccSeriesOf(st,v){ if(!st||!st.d[v]) return null; const m=caAgg(caSeries(st,v),CC.per,CA_P[v].agg), ys=[...m.keys()].filter(y=>y>=CC.y0&&y<=CC.y1).sort((a,b)=>a-b); return {years:ys, vals:ys.map(y=>m.get(y))}; }
function ccStat(xs,ys){ const s=MET.dr.sen(xs,ys); if(!s) return null; const ci=MET.dr.senCI(xs,ys,0.05), mk=MET.dr.mkTFPW(xs,ys); if(!mk) return null; return {b:s.slope,a:s.icpt,lo:ci?ci.lo:NaN,hi:ci?ci.hi:NaN,p:mk.p,pRaw:mk.pRaw,pw:mk.pw,r1:mk.r1,n:mk.n}; }
function ccBaseRange(){ const r=DR_REFS[CC.base][2]; return r; }
function ccBaseMean(years,vals){ const r=ccBaseRange(); let s=0,n=0; for(let i=0;i<years.length;i++){ if(r&&(years[i]<r[0]||years[i]>r[1])) continue; if(vals[i]===vals[i]){ s+=vals[i]; n++; } } return n>=(r?15:20)?s/n:NaN; }
function ccAnom(v,vals,mean){ return CC_PCT(v)?(mean>0?vals.map(x=>(x-mean)/mean*100):vals.map(()=>NaN)):vals.map(x=>x-mean); }
const ccUnit=v=>CC_PCT(v)?"%":(CA_P[v].ue||"");
const ccUnitFa=v=>CC_PCT(v)?"٪":CA_P[v].u;
function ccStripeInfo(v,anoms){ if(CC_PCT(v)) return {step:12,col:CC_P_COL,lab:"%"}; if(CA_P[v].kind==="t") return {step:0.4,col:CC_T_COL,lab:"°C"};
  const f=anoms.filter(a=>a===a), sd=Math.sqrt(f.reduce((a,b)=>a+b*b,0)/Math.max(1,f.length))||1, st=Math.max(0.1,Math.round(sd*0.5*10)/10);
  return {step:st,col:CA_P[v].kind==="c"?CC_T_COL.slice().reverse():CC_T_COL,lab:CA_P[v].ue||""}; }
const ccCls=(a,info)=>Math.max(0,Math.min(10,Math.round(a/info.step)+5));

/* ---------- نمودارها ---------- */
function ccChartSeries(title, sub, yrs, vals, o){   // o:{unit,col,stat,pet,petYears,runW}
  const W=1000,H=520,[c,x]=caCanvas(W,H), L=66,R=W-26,T=92,B=H-96, f=vals.filter(v=>v===v); if(f.length<3) return null;
  caFrame(x,W,H,title,sub); let lo=Math.min(...f), hi=Math.max(...f); const pad=(hi-lo)*0.08||1; lo-=pad; hi+=pad;
  const A=caAxes(x,L,T,R,B,0,1,lo,hi,{ylab:o.unit,zero:true}), ymin=yrs[0], ymax=yrs[yrs.length-1], X=y=>L+(y-ymin+0.5)/(ymax-ymin+1)*(R-L);
  for(let y=ymin;y<=ymax;y++) if(y%(ymax-ymin>45?10:5)===0){ x.strokeStyle="#cbd5e1"; x.beginPath(); x.moveTo(X(y),B); x.lineTo(X(y),B+5); x.stroke(); txt(x,FA(y),X(y),B+20,`12px ${FT.body}`,{align:"center",color:"#64748b",dir:"ltr"}); }
  x.strokeStyle="#94a3b8"; x.lineWidth=1; x.beginPath(); let st=false; yrs.forEach((y,i)=>{ const v=vals[i]; if(!(v===v)){ st=false; return; } if(!st){ x.moveTo(X(y),A.Y(v)); st=true; } else x.lineTo(X(y),A.Y(v)); }); x.stroke();
  yrs.forEach((y,i)=>{ const v=vals[i]; if(!(v===v)) return; x.fillStyle="#64748b"; x.beginPath(); x.arc(X(y),A.Y(v),2.6,0,6.3); x.fill(); });
  const full=[],fy=[]; const idx=[]; yrs.forEach((y,i)=>{ if(vals[i]===vals[i]){ full.push(vals[i]); fy.push(y); idx.push(i); } });
  const rm=MET.dr.runMean(yrs.map((y,i)=>vals[i]),o.runW||11); x.strokeStyle=o.col; x.lineWidth=3; x.beginPath(); st=false; yrs.forEach((y,i)=>{ const v=rm[i]; if(!(v===v)){ st=false; return; } if(!st){ x.moveTo(X(y),A.Y(v)); st=true; } else x.lineTo(X(y),A.Y(v)); }); x.stroke();
  if(o.stat){ x.setLineDash([7,5]); x.strokeStyle="#111827"; x.lineWidth=1.8; x.beginPath(); x.moveTo(X(ymin),A.Y(o.stat.a+o.stat.b*ymin)); x.lineTo(X(ymax),A.Y(o.stat.a+o.stat.b*ymax)); x.stroke(); x.setLineDash([]); }
  if(o.pet&&o.pet.p<0.05){ const cy=fy[o.pet.t], cx=(X(cy)+X(fy[o.pet.t+1]))/2; x.setLineDash([3,4]); x.strokeStyle="#7c3aed"; x.lineWidth=1.6; x.beginPath(); x.moveTo(cx,T); x.lineTo(cx,B); x.stroke(); x.setLineDash([]);
    x.strokeStyle="#7c3aed"; x.lineWidth=2.2; x.beginPath(); x.moveTo(L,A.Y(o.pet.mean1)); x.lineTo(cx,A.Y(o.pet.mean1)); x.moveTo(cx,A.Y(o.pet.mean2)); x.lineTo(R,A.Y(o.pet.mean2)); x.stroke(); }
  x.lineWidth=1; const en=LANG==="en"; let LX=en?L+12:R-12, LY=T+16; const items=[[o.col,drT(`میانگین متحرک ${FA(o.runW||11)} ساله`,`${o.runW||11}-yr running mean`),3],["#111827",drT("روند خطی (شیب سن)","Linear trend (Sen slope)"),2]]; if(o.pet&&o.pet.p<0.05) items.push(["#7c3aed",drT(`نقطهٔ تغییر پتیت (${FA(fy[o.pet.t+1])})`,`Pettitt change point (${fy[o.pet.t+1]})`),2]);
  items.forEach((it,j)=>{ x.fillStyle=it[0]; x.fillRect(en?LX:LX-22,LY+j*19-3,22,it[2]); txt(x,it[1],en?LX+28:LX-28,LY+j*19+3,`12px ${FT.body}`,{align:en?"left":"right",color:"#334155",dir:en?"ltr":"rtl"}); });
  caBrand(x,W,H); return c; }
function ccChartStripes(title, sub, yrs, anoms, info, v){
  const W=1000,H=330,[c,x]=caCanvas(W,H), L=30,R=W-30,T=86,B=H-98, ymin=yrs[0], ymax=yrs[yrs.length-1], cw=(R-L)/(ymax-ymin+1);
  caFrame(x,W,H,title,sub); x.fillStyle="#fff"; x.fillRect(L,T,R-L,B-T);
  yrs.forEach((y,i)=>{ const a=anoms[i]; if(!(a===a)) return; x.fillStyle=info.col[ccCls(a,info)]; x.fillRect(L+(y-ymin)*cw,T,cw+0.6,B-T); });
  for(let y=ymin;y<=ymax;y++) if(y%10===0) txt(x,FA(y),L+(y-ymin+0.5)*cw,B+18,`12px ${FT.body}`,{align:"center",color:"#64748b",dir:"ltr"});
  const en=LANG==="en"; x.font=`11px ${FT.body}`; const bw=34, gap=4, tot=11*bw+10*gap, sx=(W-tot)/2, sy=H-56;
  for(let i=0;i<11;i++){ x.fillStyle=info.col[i]; x.fillRect(sx+i*(bw+gap),sy,bw,12); const k=i-5; if(i%2===0||true) txt(x,(k>0?"+":"")+FA(caF(k*info.step,info.step<1?1:0)),sx+i*(bw+gap)+bw/2,sy+26,`10.5px ${FT.body}`,{align:"center",color:"#475569",dir:"ltr"}); }
  txt(x,drT(`هر ستون یک سال؛ رنگ = ناهنجاری نسبت به دورهٔ پایه (واحد: ${info.lab==="%"?"درصد":info.lab})`,`Each column is one year; colour = anomaly vs the baseline (${info.lab})`),W/2,sy-8,`12px ${FT.body}`,{align:"center",color:"#475569",dir:en?"ltr":"rtl"});
  caBrand(x,W,H); return c; }
function ccChartMonths(name, v, rows){   // rows: [{lab,col,vals[12]}]
  const P=CA_P[v], W=1000,H=520,[c,x]=caCanvas(W,H), L=66,R=W-26,T=96,B=H-96, all=rows.flatMap(r=>r.vals).filter(a=>a===a); if(!all.length) return null;
  caFrame(x,W,H,drT(`نرمال‌های ماهانه — ${P.fa} — ${name}`,`Monthly normals — ${P.en} — ${name}`),drT("میانگین هر ماه در هر دوره (هر ماه دست‌کم ۱۵ سال دادهٔ معتبر)","Mean of each month per period (≥15 valid years per month)"));
  const lo=Math.min(0,...all), hi=Math.max(...all)*1.1||1, A=caAxes(x,L,T,R,B,0,1,lo,hi,{ylab:CA_T(P.u,P.ue),zero:true}), months=LANG==="en"?CA_MNE:CA_MN, gw=(R-L)/12, bw=Math.min(22,(gw-8)/rows.length);
  months.forEach((m,i)=>{ const gx=L+i*gw+gw/2; txt(x,m,gx,B+18,`11.5px ${FT.body}`,{align:"center",color:"#64748b"}); rows.forEach((r,j)=>{ const val=r.vals[i]; if(!(val===val)) return; const bx=gx-rows.length*bw/2+j*bw; x.fillStyle=r.col; x.fillRect(bx,Math.min(A.Y(0),A.Y(val)),bw-1,Math.abs(A.Y(val)-A.Y(0))); }); });
  let LX=LANG==="en"?L+12:R-12; rows.forEach((r,j)=>{ const en=LANG==="en"; x.fillStyle=r.col; x.fillRect(en?LX:LX-14,T+14+j*19-9,14,12); txt(x,r.lab,en?LX+20:LX-20,T+14+j*19+1,`12px ${FT.body}`,{align:en?"left":"right",color:"#334155",dir:en?"ltr":"rtl"}); });
  caBrand(x,W,H); return c; }

/* ---------- جدول‌های HTML ---------- */
function ccStatRow(label, st, v, mean, pet, yrs){
  if(!st) return `<tr><td>${label}</td><td colspan="6">${drT("دادهٔ کافی نیست (دست‌کم ۱۰ سال)","insufficient data (≥10 years)")}</td></tr>`;
  const k=CC_PCT(v)&&mean>0?10/mean*100:10, u=CC_PCT(v)&&mean>0?drT("٪ در دهه","% / decade"):drT(`${ccUnitFa(v)} در دهه`,`${ccUnit(v)} / decade`);
  const sig=st.p<0.05, pc=pet&&pet.p<0.05?drT(`${FA(yrs[pet.t+1])} (${ccFa(pet.mean1,1)}→${ccFa(pet.mean2,1)})`,`${yrs[pet.t+1]} (${caF(pet.mean1,1)}→${caF(pet.mean2,1)})`):"—";
  return `<tr class="${sig?"dwSig":""}"><td>${label}</td><td>${FA(st.n)}</td><td><b>${ccFa(st.b*k)}</b> ${u}</td><td>${ccFa(st.lo*k)} … ${ccFa(st.hi*k)}</td><td>${FA(caF(st.p,3))}${st.pw?" *":""}</td><td>${sig?drT("معنی‌دار","significant"):drT("معنی‌دار نیست","not significant")}</td><td>${pc}</td></tr>`; }
const CC_TH=()=>`<tr><th>${drT("دوره","Period")}</th><th>${drT("سال داده","Years")}</th><th>${drT("روند","Trend")}</th><th>${drT("بازهٔ اطمینان ۹۵٪","95% CI")}</th><th>p</th><th>${drT("نتیجه","Result")}</th><th>${drT("نقطهٔ تغییر معنی‌دار (پتیت)","Significant change point (Pettitt)")}</th></tr>`;

/* ---------- تحلیل ایستگاهی ---------- */
function ccStation(){ return CLIM_META.st.find(s=>String(s.id)===String(CC.sid)); }
async function ccRunStation(){
  if(CC.busy) return; CC.busy=true;
  try{ await caLoad(); await document.fonts.ready; const st=ccStation(), v=CC.v, P=CA_P[v]; if(!st) throw new Error(drT("ایستگاه را انتخاب کنید","Select a station")); if(!st.d[v]) throw new Error(drT("این ایستگاه برای این پارامتر دادهٔ ماهانه ندارد","This station has no monthly data for this parameter"));
    drStatus(drT("در حال محاسبه…","Computing…")); await new Promise(r=>setTimeout(r,20)); const name=caStName(st), S=ccSeriesOf(st,v); if(!S||S.years.length<10) throw new Error(drT("برای روند دست‌کم ۱۰ سال دادهٔ کامل در این دوره لازم است","At least 10 complete years are needed for a trend in this period"));
    const grp=document.createElement("div"), host={prepend:n=>grp.append(n)}; grp.style.display="contents"; const ST=ccStat(S.years,S.vals), pet=MET.dr.pettitt(S.vals), mean=ccBaseMean(S.years,S.vals), tag=`${P.fa} — ${ccPer(CC.per)}`, tagE=`${P.en} — ${ccPer(CC.per)}`;
    const col=CC_PCT(v)?"#1d4ed8":"#b91c1c", k=CC_PCT(v)&&mean>0?10/mean*100:10, uTxt=CC_PCT(v)&&mean>0?drT("٪ در دهه (نسبت به میانگین پایه)","% per decade (vs baseline mean)"):drT(`${P.u} در دهه`,`${P.ue} per decade`);
    // ۱) سری زمانی
    const c1=ccChartSeries(drT(`${tag} — ${name}`,`${tagE} — ${name}`),drT(`${FA(S.years[0])} تا ${FA(S.years[S.years.length-1])} · ${FA(S.years.length)} سال`,`${S.years[0]} – ${S.years[S.years.length-1]} · ${S.years.length} years`),S.years,S.vals,{unit:CA_T(P.u,P.ue),col,stat:ST,pet,runW:11});
    caCard(drT(`سری سالانه و روند — ${name}`,`Annual series and trend — ${name}`),c1,ST?drT(`روند: ${ccFa(ST.b*k)} ${uTxt} (۹۵٪: ${ccFa(ST.lo*k)} تا ${ccFa(ST.hi*k)}) · من–کندال${ST.pw?" با پیش‌سفیدسازی TFPW (خودهمبستگی مرتبهٔ ۱ معنی‌دار بود)":""}: p = ${FA(caF(ST.p,3))}${ST.pw?` (بدون اصلاح: ${FA(caF(ST.pRaw,3))})`:""} · ${ST.p<0.05?"معنی‌دار در سطح ۵٪":"معنی‌دار نیست"}.`,`Trend: ${caF(ST.b*k,2)} ${uTxt} (95%: ${caF(ST.lo*k,2)} to ${caF(ST.hi*k,2)}) · Mann–Kendall${ST.pw?" with TFPW pre-whitening (lag-1 autocorrelation significant)":""}: p = ${caF(ST.p,3)}${ST.pw?` (unadjusted ${caF(ST.pRaw,3)})`:""} · ${ST.p<0.05?"significant at 5%":"not significant"}.`):"",host);
    // ۲) نوار اقلیمی
    if(mean===mean){ const an=ccAnom(v,S.vals,mean), info=ccStripeInfo(v,an), c2=ccChartStripes(drT(`نوار اقلیمی — ${tag} — ${name}`,`Climate stripes — ${tagE} — ${name}`),drT(`دورهٔ پایه: ${DR_REFS[CC.base][0]}`,`Baseline: ${DR_REFS[CC.base][1]}`),S.years,an,info,v); caCard(drT(`نوار اقلیمی — ${name}`,`Climate stripes — ${name}`),c2,drT("رنگ‌ها گسسته‌اند (هر طبقه یک گام ثابت)؛ سال‌های بدون داده کامل خالی می‌مانند.","Colours are discrete (fixed step per class); years without complete data stay blank."),host); }
    else drHtmlCard(drT("نوار اقلیمی","Climate stripes"),`<p class="hint">${drT("در دورهٔ پایهٔ انتخابی برای این ایستگاه دست‌کم ۱۵ سال داده نیست؛ دورهٔ پایه را «کل دورهٔ ایستگاه» بگذارید.","Fewer than 15 baseline years at this station; set the baseline to “Whole record”.")}</p>`,host);
    // ۳) جدول فصل‌ها
    const rows=[["year",drT("سال شمسی","Year")],["s1",drT("بهار","Spring")],["s2",drT("تابستان","Summer")],["s3",drT("پاییز","Autumn")],["s4",drT("زمستان","Winter")]].map(([pr,lab])=>{ const m=caAgg(caSeries(st,v),pr,P.agg), ys=[...m.keys()].filter(y=>y>=CC.y0&&y<=CC.y1).sort((a,b)=>a-b), vs=ys.map(y=>m.get(y)); const s2=ys.length>=10?ccStat(ys,vs):null; const mn=vs.length?vs.reduce((a,b)=>a+b,0)/vs.length:NaN; return ccStatRow(lab,s2,v,mn,ys.length>=10?MET.dr.pettitt(vs):null,ys); }).join("");
    drHtmlCard(drT(`روند فصلی — ${P.fa} — ${name}`,`Seasonal trends — ${P.en} — ${name}`),`<div class="dwTblW"><table class="dwTbl">${CC_TH()}${rows}</table></div><p class="hint">${drT("* = من–کندال با پیش‌سفیدسازی (TFPW) به‌کار رفته. بازهٔ اطمینان شیب سن به روش Sen (1968) است. نقطهٔ تغییر فقط وقتی نشان داده می‌شود که p پتیت < ۰٫۰۵ باشد؛ نقطهٔ تغییر لزوماً علت اقلیمی ندارد و می‌تواند ناشی از جابه‌جایی ایستگاه یا تغییر ابزار باشد (داده همگن‌سازی نشده است).","* = Mann–Kendall with TFPW pre-whitening. Sen slope CI per Sen (1968). A change point is shown only when Pettitt p < 0.05; it need not be climatic and may stem from station relocation or instrument changes (the data are not homogenised).")}</p>`,host);
    // ۴) نرمال‌های ماهانه
    const sr=caSeries(st,v), jy0=CLIM_META.jy0, NYY=Math.floor(sr.length/12), per=[["old",drT("۱۳۴۰–۱۳۶۹ (≈۱۹۶۱–۹۰)","1340–69 (≈1961–90)"),"#64748b",[1340,1369]],["wmo",drT("۱۳۷۰–۱۳۹۹ (≈۱۹۹۱–۲۰۲۰)","1370–99 (≈1991–2020)"),"#0ea5e9",[1370,1399]],["rec",drT("۲۰ سال اخیر","Last 20 years"),col,[jy0+NYY-20,jy0+NYY-1]]];
    const mrows=per.map(([k2,lab,cl,rg])=>({lab,col:cl,vals:Array.from({length:12},(_,m)=>{ let s=0,n=0; for(let y=Math.max(rg[0],jy0);y<=Math.min(rg[1],jy0+NYY-1);y++){ const val=sr[(y-jy0)*12+m]; if(val===val){ s+=val; n++; } } return n>=15?s/n:NaN; })}));
    const c4=ccChartMonths(name,v,mrows); if(c4) caCard(drT(`مقایسهٔ نرمال‌های ماهانه — ${name}`,`Monthly normals comparison — ${name}`),c4,drT("«۲۰ سال اخیر» ممکن است برای برخی ماه‌ها کمتر از ۱۵ سال داشته باشد؛ در آن صورت ستون رسم نمی‌شود.","The last-20-year column is dropped for months with fewer than 15 valid years."),host);
    $("drCards").prepend(grp); drStatus("");
  }catch(e){ console.error(e); drStatus("⚠ "+e.message); }
  CC.busy=false; }

/* ---------- تحلیل منطقه‌ای ---------- */
async function ccRunRegion(){
  if(CC.busy) return; CC.busy=true;
  try{ await caLoad(); await document.fonts.ready; const v=CC.v, P=CA_P[v]; drStatus(drT("روند هر ایستگاه…","Trend at each station…")); await new Promise(r=>setTimeout(r,30));
    const sts=CLIM_META.st.filter(s=>s.d[v]&&s.lat!=null), pts=[], anomAll=new Map(); let nUsed=0, nSig=0, nUp=0, nUpSig=0, nDnSig=0; const sl=[];
    for(const s of sts){ const S=ccSeriesOf(s,v); if(!S||S.years.length<CC.minN) continue; const T=ccStat(S.years,S.vals); if(!T) continue; const mean=S.vals.reduce((a,b)=>a+b,0)/S.vals.length;
      const val=CC_PCT(v)?(mean>0?T.b*10/mean*100:NaN):T.b*10; if(val!==val) continue; nUsed++; sl.push(val); if(val>0) nUp++; if(T.p<0.05){ nSig++; if(val>0) nUpSig++; else nDnSig++; }
      pts.push({lat:s.lat,lon:s.lon,elev:s.elev||0,v:val,sig:T.p<0.05,name:caStName(s),uv:s.vs==="unverified",ty:s.type});
      const bm=ccBaseMean(S.years,S.vals); if(bm===bm){ const an=ccAnom(v,S.vals,bm); S.years.forEach((y,i)=>{ if(an[i]===an[i]){ const a=anomAll.get(y)||[]; a.push(an[i]); anomAll.set(y,a); } }); } }
    if(pts.length<8) throw new Error(drT(`فقط ${FA(pts.length)} ایستگاه دست‌کم ${FA(CC.minN)} سال داده دارند؛ بازهٔ سال را بزرگ‌تر یا «حداقل سال» را کمتر کنید.`,`Only ${pts.length} stations have ≥${CC.minN} years; widen the window or lower the minimum.`));
    sl.sort((a,b)=>a-b); const med=sl[sl.length>>1], grp=document.createElement("div"), host={prepend:n=>grp.append(n)}; grp.style.display="contents";
    // ۱) میانگین ناهنجاری ایستگاه‌ها
    const yrs=[...anomAll.keys()].filter(y=>anomAll.get(y).length>=8).sort((a,b)=>a-b), mv=yrs.map(y=>{ const a=anomAll.get(y); return a.reduce((p,q)=>p+q,0)/a.length; }), cnt=yrs.map(y=>anomAll.get(y).length);
    if(yrs.length>=10){ const T=ccStat(yrs,mv), pet=MET.dr.pettitt(mv), col=CC_PCT(v)?"#1d4ed8":"#b91c1c", unitLab=CC_PCT(v)?"%":CA_T(P.u,P.ue), tag=`${P.fa} — ${ccPer(CC.per)}`, tagE=`${P.en} — ${ccPer(CC.per)}`;
      const c1=ccChartSeries(drT(`میانگین ناهنجاری ایستگاه‌ها — ${tag}`,`Station-mean anomaly — ${tagE}`),drT(`نسبت به ${DR_REFS[CC.base][0]} · ${FA(yrs.length)} سال · هر سال دست‌کم ۸ ایستگاه (میانهٔ تعداد: ${FA(cnt.slice().sort((a,b)=>a-b)[cnt.length>>1])})`,`vs ${DR_REFS[CC.base][1]} · ${yrs.length} years · ≥8 stations per year (median count ${cnt.slice().sort((a,b)=>a-b)[cnt.length>>1]})`),yrs,mv,{unit:unitLab,col,stat:T,pet,runW:11});
      if(c1) caCard(drT(`ناهنجاری میانگین ایران — ${P.fa}`,`Iran station-mean anomaly — ${P.en}`),c1,T?drT(`روند: ${ccFa(T.b*10)} ${CC_PCT(v)?"درصد":ccUnitFa(v)} در دهه (۹۵٪: ${ccFa(T.lo*10)} تا ${ccFa(T.hi*10)}) · p = ${FA(caF(T.p,3))}${T.pw?" (TFPW)":""}. میانگین ساده روی ایستگاه‌های موجود هر سال است؛ تغییر شبکهٔ ایستگاه‌ها و همگن‌نبودن داده می‌تواند روی نتیجه اثر بگذارد.`,`Trend: ${caF(T.b*10,2)} ${CC_PCT(v)?"%":ccUnit(v)} per decade (95%: ${caF(T.lo*10,2)} to ${caF(T.hi*10,2)}) · p = ${caF(T.p,3)}${T.pw?" (TFPW)":""}. Simple mean over the stations available each year; network changes and inhomogeneities can influence the result.`):"",host);
      const info=ccStripeInfo(v,mv), c2=ccChartStripes(drT(`نوار اقلیمی ایران — ${tag}`,`Iran climate stripes — ${tagE}`),drT(`میانگین ناهنجاری ایستگاه‌ها نسبت به ${DR_REFS[CC.base][0]}`,`Station-mean anomaly vs ${DR_REFS[CC.base][1]}`),yrs,mv,info,v); if(c2) caCard(drT("نوار اقلیمی ایران","Iran climate stripes"),c2,"",host); }
    // ۲) نقشهٔ روند
    drStatus(drT("درون‌یابی و ترسیم نقشه…","Interpolating and drawing the map…")); await new Promise(r=>setTimeout(r,30)); if(!$("caPalSel")||!$("caRes")) caBuildUI();
    const brk=CC_PCT(v)?[-30,-20,-10,-5,5,10,20,30]:(P.kind==="t"?[-1,-0.6,-0.4,-0.2,0.2,0.4,0.6,1]:undefined), ttl=drT(`روند ${P.fa} — ${ccPer(CC.per)}`,`${P.en} trend — ${ccPer(CC.per)}`);
    const cv=await caMap({pts,title:ttl,sub:drT(`شیب سن در هر دهه · ${FA(CC.y0)} تا ${FA(CC.y1)} · ${FA(pts.length)} ایستگاه با دست‌کم ${FA(CC.minN)} سال`,`Sen slope per decade · ${CC.y0}–${CC.y1} · ${pts.length} stations with ≥${CC.minN} years`),unit:CC_PCT(v)?drT("درصد در دهه نسبت به میانگین ایستگاه (نقطهٔ سیاه: معنی‌دار ۵٪)","% per decade vs station mean (black dot: significant at 5%)"):drT(`${P.u} در دهه (نقطهٔ سیاه: معنی‌دار ۵٪)`,`${P.ue} per decade (black dot: significant at 5%)`),
      kind:CC_PCT(v)?"pdiv":"div",scheme:CC_PCT(v)?"panom":"tanom",center:0,breaks:brk,method:"auto",useElev:false,resKm:2,note:drT("خانه‌های دورتر از ۳۰۰ کیلومتر از نزدیک‌ترین ایستگاه و بیرون از ایران رنگ نمی‌گیرند."+(P.kind==="c"?" برای روزهای یخبندان، افزایش یعنی سردتر؛ رنگ قرمز لزوماً گرم‌شدن نیست.":""),"Cells farther than 300 km from the nearest station, and outside Iran, are left blank."+(P.kind==="c"?" For frost days an increase means colder; red does not imply warming.":""))});
    caCard(ttl,cv,drT("نقشه درون‌یابی روند ایستگاه‌هاست و در جاهای بدون ایستگاه تقریبی است.","The map interpolates station trends and is approximate away from stations."),host);
    // ۳) خلاصهٔ شمارشی
    const pc=x=>FA(Math.round(x/nUsed*100)), mm=CC_PCT(v)?drT("٪ در دهه","% / decade"):drT(`${P.u} در دهه`,`${P.ue} / decade`);
    drHtmlCard(drT(`خلاصهٔ روند ایستگاه‌ها — ${P.fa}`,`Station trend summary — ${P.en}`),`<div class="dwTblW"><table class="dwTbl"><tr><th>${drT("شاخص","Item")}</th><th>${drT("مقدار","Value")}</th></tr>
      <tr><td>${drT("ایستگاه‌های بررسی‌شده","Stations analysed")}</td><td>${FA(nUsed)}</td></tr><tr><td>${drT("میانهٔ روند","Median trend")}</td><td><b>${ccFa(med)}</b> ${mm}</td></tr>
      <tr><td>${drT("ایستگاه با روند مثبت","Stations with a positive trend")}</td><td>${FA(nUp)} (${pc(nUp)}٪)</td></tr><tr><td>${drT("روند مثبت معنی‌دار (۵٪)","Significant positive (5%)")}</td><td>${FA(nUpSig)} (${pc(nUpSig)}٪)</td></tr>
      <tr><td>${drT("روند منفی معنی‌دار (۵٪)","Significant negative (5%)")}</td><td>${FA(nDnSig)} (${pc(nDnSig)}٪)</td></tr></table></div>
      <p class="hint">${drT(`با ۵٪ سطح معنی‌داری و ${FA(nUsed)} آزمون، حدود ${FA(Math.max(1,Math.round(nUsed*0.05)))} ایستگاه به‌طور تصادفی معنی‌دار درمی‌آیند؛ همبستگی مکانی ایستگاه‌ها هم باعث می‌شود شمار معنی‌دارها را نتوان «مستقل» دانست.`,`At the 5% level with ${nUsed} tests, about ${Math.max(1,Math.round(nUsed*0.05))} stations are expected significant by chance; spatial correlation also means the tests are not independent.`)}</p>`,host);
    $("drCards").prepend(grp); drStatus("");
  }catch(e){ console.error(e); drStatus("⚠ "+e.message); }
  CC.busy=false; }

/* ---------- رابط ---------- */
function ccStationOptions(q){ q=(q||"").trim().toLowerCase(); const v=CC.v; const arr=CLIM_META.st.filter(s=>s.d[v]).map(s=>({s,n:caStName(s),len:s.d[v][2]})).filter(o=>!q||o.n.toLowerCase().includes(q)||String(o.s.id).includes(q));
  arr.sort((a,b)=>b.len-a.len); return arr.slice(0,400).map(o=>`<option value="${drEsc(o.s.id)}"${String(o.s.id)===String(CC.sid)?" selected":""}>${drEsc(o.n)} · ${FA(Math.round(o.len/12))} ${drT("سال","yr")}</option>`).join(""); }
function ccPick(){ const v=CC.v; const cur=ccStation(); if(cur&&cur.d[v]) return; let best=null; for(const s of CLIM_META.st) if(s.d[v]&&s.lat!=null&&(!best||s.d[v][2]>best.d[v][2])) best=s; CC.sid=best?best.id:null; }
function ccInit(){ if(CC.y0!=null) return; const jy0=CLIM_META.jy0, jy1=jy0+Math.floor((CA.db.NM-1)/12); CC.y0=Math.max(jy0,1340); CC.y1=jy1-(((CA.db.NM-1)%12)<11?1:0); }   // آخرین سال ناقص کنار گذاشته می‌شود
function ccHTML(){ ccInit(); ccPick(); const jy0=CLIM_META.jy0, jy1=jy0+Math.floor((CA.db.NM-1)/12), yrs=[]; for(let y=jy0;y<=jy1;y++) yrs.push(y);
  const per=CA_PER.filter(p=>["year","wy","s1","s2","s3","s4"].includes(p[0])).map(p=>`<option value="${p[0]}"${CC.per===p[0]?" selected":""}>${CA_T(p[1],p[2])}</option>`).join("");
  const common=`<label>${drT("پارامتر","Parameter")}<select id="ccV">${CC_VARS.map(v=>`<option value="${v}"${CC.v===v?" selected":""}>${CA_T(CA_P[v].fa,CA_P[v].en)}</option>`).join("")}</select></label><label>${drT("دورهٔ سال","Season")}<select id="ccPer">${per}</select></label>
    <label>${drT("از سال","From year")}<select id="ccY0">${drOpts(yrs,CC.y0,v=>FA(v))}</select></label><label>${drT("تا سال","To year")}<select id="ccY1">${drOpts(yrs.slice().reverse(),CC.y1,v=>FA(v))}</select></label>
    <label>${drT("دورهٔ پایه برای ناهنجاری","Baseline for anomalies")}<select id="ccBase">${Object.keys(DR_REFS).map(k=>`<option value="${k}"${CC.base===k?" selected":""}>${drT(DR_REFS[k][0],DR_REFS[k][1])}</option>`).join("")}</select></label>`;
  const stn=`<div class="dwCtl"><label>${drT("جست‌وجوی ایستگاه","Find station")}<input id="ccQ" type="search" placeholder="${drT("مثلاً تبریز","e.g. Tabriz")}"></label><label>${drT("ایستگاه (به ترتیب طول دوره)","Station (by record length)")}<select id="ccSt" size="1">${ccStationOptions("")}</select></label>${common}<button class="btn main" type="button" id="ccGo">${drT("تحلیل روند ایستگاه","Analyse station trend")}</button></div>`;
  const rg=`<div class="dwCtl">${common}<label>${drT("حداقل سال داده برای هر ایستگاه","Minimum years per station")}<select id="ccMin">${drOpts([20,25,30,35,40],CC.minN,v=>FA(v))}</select></label><button class="btn main" type="button" id="ccGoR">${drT("نقشهٔ روند و ناهنجاری ایران","Trend map & Iran anomaly")}</button></div>`;
  return `<div class="dwSub"><button type="button" data-s="st" class="${CC.scope==="st"?"on":""}">${drT("ایستگاه","Station")}</button><button type="button" data-s="rg" class="${CC.scope==="rg"?"on":""}">${drT("منطقه / کل ایران","Region / all Iran")}</button></div>${CC.scope==="st"?stn:rg}
    <p class="hint">${drT("روش: شیب سن با بازهٔ اطمینان ۹۵٪، آزمون من–کندال (با پیش‌سفیدسازی TFPW در صورت خودهمبستگی)، نقطهٔ تغییر پتیت، میانگین ناهنجاری ایستگاه‌ها. داده همگن‌سازی نشده است.","Method: Sen slope with 95% CI, Mann–Kendall (TFPW pre-whitening when autocorrelated), Pettitt change point, station-mean anomalies. The data are not homogenised.")}</p>`; }
function ccWire(m){ const g=id=>m.querySelector("#"+id), on=(id,f)=>{ const e=g(id); if(e) e.onchange=()=>f(e.value); };
  m.querySelectorAll(".dwSub button[data-s]").forEach(b=>b.onclick=()=>{ CC.scope=b.dataset.s; drRender(); });
  on("ccV",v=>{ CC.v=v; drRender(); }); on("ccPer",v=>CC.per=v); on("ccY0",v=>CC.y0=+v); on("ccY1",v=>CC.y1=+v); on("ccBase",v=>CC.base=v); on("ccSt",v=>CC.sid=v); on("ccMin",v=>CC.minN=+v);
  const q=g("ccQ"); if(q) q.oninput=()=>{ const s=g("ccSt"); s.innerHTML=ccStationOptions(q.value); if(s.options.length){ s.selectedIndex=0; CC.sid=s.value; } };
  const go=g("ccGo"); if(go) go.onclick=ccRunStation; const gr=g("ccGoR"); if(gr) gr.onclick=ccRunRegion; }
