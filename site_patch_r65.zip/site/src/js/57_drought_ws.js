/* ===== کارگاه تغییر اقلیم و خشکسالی (r59 · فاز ۱: خشکسالی) =====
   صفحهٔ جدا و افزودنی؛ به پایگاه دادهٔ ماهانهٔ اطلس (CLIM_META، caSeries) فقط می‌خواند و هیچ چیز آن را تغییر نمی‌دهد.
   محاسبه: MET.dr (src/js/met/dr_core.js؛ آزمون در tests/met/run_dr.js). دادهٔ خام عددی دانلود نمی‌شود؛ فقط تصویر نمودار/نقشه و جدول‌های مشتق‌شده (قاعدهٔ اطلس). */
const DR={tab:"st", sid:null, idx:"spi", k:3, ref:"wmo", win:40, onset:-1, busy:false, kr:3, ry:null, rm:null, rwin:40};
const drT=(fa,en)=>LANG==="en"?en:fa;
const DR_SCALES=[1,2,3,4,6,9,12,18,24];
const DR_COL=["#1e3a8a","#2563eb","#7cb4f5","#e5e7eb","#fbbf24","#f97316","#b91c1c"];   // رنگ‌های گسسته (بدون اختلاط): خیلی تر … خشکی بسیار شدید
const DR_REFS={all:["کل دورهٔ ایستگاه","Whole record",null],wmo:["۱۳۷۰ تا ۱۳۹۹ (نرمال WMO ≈ ۱۹۹۱–۲۰۲۰)","1370–1399 (WMO normal ≈ 1991–2020)",[1370,1399]],old:["۱۳۴۰ تا ۱۳۶۹ (≈ ۱۹۶۱–۱۹۹۰)","1340–1369 (≈ 1961–1990)",[1340,1369]]};
const drEsc=s=>String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const drCls=z=>!(z===z)?-1:z>=2?0:z>=1.5?1:z>=1?2:z>-1?3:z>-1.5?4:z>-2?5:6;
const drClsName=i=>[drT("بسیار شدید تر","Extremely wet"),drT("خیلی تر","Very wet"),drT("نسبتاً تر","Moderately wet"),drT("نزدیک نرمال","Near normal"),drT("خشکی متوسط","Moderately dry"),drT("خشکی شدید","Severely dry"),drT("خشکی بسیار شدید","Extremely dry")][i];
const drTlab=t=>{ const jy=CLIM_META.jy0+Math.floor(t/12), m=t%12; return (LANG==="en"?CA_MNE:CA_MN)[m]+" "+FA(jy); };
const drIdxName=(i,k)=>(i==="spei"?"SPEI":"SPI")+"-"+FA(k);
/* r65: عنوان نقشه با «دورهٔ» صریح: مثلاً «دورهٔ یک‌ساله منتهی به پایان شهریور ۱۴۰۵» (هر ماه از داده به پایان همان ماه ختم می‌شود) */
const DR_KFA={1:"یک‌ماهه",2:"دو‌ماهه",3:"سه‌ماهه",4:"چهار‌ماهه",6:"شش‌ماهه",9:"نه‌ماهه",12:"یک‌ساله",18:"یک‌ونیم‌ساله",24:"دو‌ساله",36:"سه‌ساله",48:"چهار‌ساله",60:"پنج‌ساله"};
const drPerTxt=(k,t)=>{ try{ return drT(`دورهٔ ${DR_KFA[k]||(FA(k)+" ماهه")} منتهی به پایان ${drTlab(t)}`,`${k}-month period ending at the end of ${drTlab(t)}`); }catch(e){ return ""; } };

function drRefYears(NY){ const r=DR_REFS[DR.ref][2]; if(!r) return [0,NY-1]; return [Math.max(0,r[0]-CLIM_META.jy0), Math.min(NY-1,r[1]-CLIM_META.jy0)]; }
const drArr=a=>a?Float64Array.from(a):null;
function drSeries(st){ const g=p=>st.d[p]?drArr(caSeries(st,p)):null; return {P:g("prcp"), Tx:g("tmax"), Tn:g("tmin"), Tm:g("tmean")}; }
/* ET0 ماهانه (mm): هارگریوز با دمای بیشینه/کمینه؛ وگرنه تورنت‌وایت با دمای میانگین. بدون هیچ‌کدام ⇒ null */
function drPet(st, S, N){
  const D=MET.dr; if(st.lat==null) return null;
  if(S.Tx&&S.Tn){ const o=new Float64Array(N).fill(NaN); for(let t=0;t<N;t++){ const jy=CLIM_META.jy0+Math.floor(t/12), m=t%12+1; o[t]=D.hargreaves(S.Tx[t],S.Tn[t],st.lat,m,D.daysInMonth(m,jy)); } return {pet:o, method:"hargreaves"}; }
  if(S.Tm){ const cl=new Array(12).fill(0).map((_,m)=>{ let s=0,n=0; for(let t=m;t<N;t+=12) if(S.Tm[t]===S.Tm[t]){ s+=S.Tm[t]; n++; } return n>=10?s/n:NaN; }); const f=D.thornthwaiteClim(cl,st.lat); if(!f) return null;
    const o=new Float64Array(N).fill(NaN); for(let t=0;t<N;t++){ const jy=CLIM_META.jy0+Math.floor(t/12), m=t%12+1; o[t]=f(S.Tm[t],m,D.daysInMonth(m,jy)); } return {pet:o, method:"thornthwaite"}; }
  return null; }
/* شاخص یک ایستگاه ⇒ {z, fit, nref, method, why} */
function drIndex(st, idx, k, S){
  S=S||drSeries(st); if(!S.P) return {why:"no_prcp"}; const N=S.P.length, NY=Math.floor(N/12), ref=drRefYears(NY); let x=S.P, method="";
  if(idx==="spei"){ const pe=drPet(st,S,N); if(!pe) return {why:"no_pet"}; method=pe.method; x=new Float64Array(N); for(let t=0;t<N;t++) x[t]=(S.P[t]===S.P[t]&&pe.pet[t]===pe.pet[t])?S.P[t]-pe.pet[t]:NaN; }
  const r=MET.dr.standardize(x,{scale:k,method:idx==="spei"?"spei":"spi",ref,minYears:20}); return {z:r.z, fits:r.fits, nref:r.nref, method, ref, why:r.fits.every(f=>!f)?"fit_failed":""}; }
const drWhy=w=>({no_prcp:drT("این ایستگاه دادهٔ بارش ماهانه ندارد","No monthly precipitation for this station"),no_pet:drT("برای SPEI به مختصات و دمای (بیشینه/کمینه یا میانگین) ایستگاه نیاز است","SPEI needs coordinates and temperature"),fit_failed:drT("برازش توزیع در دورهٔ مرجع ممکن نشد (دادهٔ کم یا نامناسب)","Distribution fit failed over the reference period")}[w]||w);

/* ---------- ابزار رسم ---------- */
function drLastValid(z){ for(let t=z.length-1;t>=0;t--) if(z[t]===z[t]) return t; return -1; }
function drWindow(z,win){ const last=drLastValid(z); if(last<0) return null; const n=win==="all"?z.length:win*12, t1=last, t0=Math.max(0,t1-n+1); let f=t0; while(f<=t1&&!(z[f]===z[f])) f++; return {t0:f,t1}; }
function drYearTicks(x,L,R,B,t0,t1,step){ const n=t1-t0+1, w=(R-L)/n; for(let t=t0;t<=t1;t++) if(t%12===0){ const jy=CLIM_META.jy0+t/12; if(jy%step) continue; const X=L+(t-t0+0.5)*w; x.strokeStyle="#cbd5e1"; x.beginPath(); x.moveTo(X,B); x.lineTo(X,B+5); x.stroke(); txt(x,FA(jy),X,B+20,`12px ${FT.body}`,{align:"center",color:"#64748b",dir:"ltr"}); } }
function drLegend(x,W,Y){ const en=LANG==="en"; let X=en?30:W-30; const items=[0,1,2,3,4,5,6]; x.font=`12px ${FT.body}`;
  for(const i of items){ const lab=drClsName(i), w=x.measureText(lab).width+26; if(en){ x.fillStyle=DR_COL[i]; x.fillRect(X,Y-10,14,14); txt(x,lab,X+19,Y+2,`12px ${FT.body}`,{align:"left",color:"#334155",dir:"ltr"}); X+=w+8; } else { x.fillStyle=DR_COL[i]; x.fillRect(X-14,Y-10,14,14); txt(x,lab,X-19,Y+2,`12px ${FT.body}`,{align:"right",color:"#334155"}); X-=w+8; } } }
function drChartBars(name, z, idx, k, win, refTxt){
  const W=1000,H=470,[c,x]=caCanvas(W,H), L=62,R=W-26,T=92,B=H-92, w=drWindow(z,win); if(!w) return null;
  caFrame(x,W,H,`${drIdxName(idx,k)} — ${name}`, drT(`${drTlab(w.t0)} تا ${drTlab(w.t1)} · دورهٔ مرجع: ${refTxt}`,`${drTlab(w.t0)} – ${drTlab(w.t1)} · reference: ${refTxt}`));
  const A=caAxes(x,L,T,R,B,0,1,-3.3,3.3,{zero:true,ylab:drIdxName(idx,k)}), n=w.t1-w.t0+1, bw=(R-L)/n;
  x.setLineDash([4,4]); x.strokeStyle="#94a3b8"; for(const v of [-2,-1.5,-1,1,1.5,2]){ x.beginPath(); x.moveTo(L,A.Y(v)); x.lineTo(R,A.Y(v)); x.stroke(); } x.setLineDash([]);
  for(let t=w.t0;t<=w.t1;t++){ const v=z[t]; if(!(v===v)) continue; const cl=drCls(v), X=L+(t-w.t0)*bw, y0=A.Y(0), y1=A.Y(Math.max(-3.3,Math.min(3.3,v))); x.fillStyle=DR_COL[cl]; x.fillRect(X,Math.min(y0,y1),Math.max(1,bw-(bw>3?0.6:0)),Math.abs(y1-y0)); }
  x.strokeStyle="#cbd5e1"; x.strokeRect(L,T,R-L,B-T); drYearTicks(x,L,R,B,w.t0,w.t1,n/12>35?10:n/12>16?5:2); drLegend(x,W,H-30); caBrand(x,W,H); return c; }
function drChartHeat(name, rows, idx, win, refTxt){   // rows: [{k,z}] از بالا به پایین
  const z0=rows[0].z, w=drWindow(z0,win); if(!w) return null; const W=1000,H=140+rows.length*30,[c,x]=caCanvas(W,H), L=70,R=W-26,T=92,B=H-80, n=w.t1-w.t0+1, cw=(R-L)/n, rh=(B-T)/rows.length;
  caFrame(x,W,H,drT(`نمای چندمقیاسهٔ ${idx==="spei"?"SPEI":"SPI"} — ${name}`,`Multi-scale ${idx==="spei"?"SPEI":"SPI"} — ${name}`),drT(`${drTlab(w.t0)} تا ${drTlab(w.t1)} · هر ردیف یک مقیاس زمانی (ماه) · دورهٔ مرجع: ${refTxt}`,`${drTlab(w.t0)} – ${drTlab(w.t1)} · one row per time scale (months) · reference: ${refTxt}`));
  x.fillStyle="#fff"; x.fillRect(L,T,R-L,B-T);
  rows.forEach((r,i)=>{ const Y=T+i*rh; for(let t=w.t0;t<=w.t1;t++){ const v=r.z[t]; if(!(v===v)) continue; x.fillStyle=DR_COL[drCls(v)]; x.fillRect(L+(t-w.t0)*cw,Y,cw+0.6,rh+0.6); }
    txt(x,FA(r.k),L-8,Y+rh/2+4,`12px ${FT.body}`,{align:"right",color:"#475569",dir:"ltr"}); });
  x.strokeStyle="#cbd5e1"; x.strokeRect(L,T,R-L,B-T); drYearTicks(x,L,R,B,w.t0,w.t1,n/12>35?10:n/12>16?5:2); drLegend(x,W,H-28); caBrand(x,W,H); return c; }
function drChartSdf(name, s, refTxt){
  const W=1000,H=470,[c,x]=caCanvas(W,H), L=70,R=W-30,T=92,B=H-80; const all=s.table.flat().filter(v=>v!=null&&isFinite(v)); if(!all.length) return null;
  caFrame(x,W,H,drT(`منحنی شدت–مدت–بسامد خشکسالی (SDF) — ${name}`,`Drought severity–duration–frequency (SDF) — ${name}`),drT("بیشینهٔ سالانهٔ کمبود تجمعی SPI-1 برای هر مدت؛ برازش گامبل با گشتاورهای L","Annual maximum cumulative SPI-1 deficit per duration; Gumbel fit by L-moments"));
  const A=caAxes(x,L,T,R,B,0,1,0,Math.max(...all)*1.08,{ylab:drT("شدت کل (مجموع کمبود SPI)","Total severity (Σ SPI deficit)")}), nT=s.T.length, X=i=>L+(i+0.5)/nT*(R-L), pal=["#0ea5e9","#22c55e","#f59e0b","#ef4444","#7c3aed"];
  s.T.forEach((t,i)=>txt(x,FA(t),X(i),B+20,`12px ${FT.body}`,{align:"center",color:"#64748b",dir:"ltr"})); txt(x,drT("دورهٔ بازگشت (سال)","Return period (years)"),(L+R)/2,B+42,`12px ${FT.body}`,{align:"center",color:"#475569",dir:LANG==="en"?"ltr":"rtl"});
  s.durs.forEach((d,j)=>{ const row=s.table[j]; x.strokeStyle=pal[j%5]; x.lineWidth=2.4; x.beginPath(); let st=false; row.forEach((v,i)=>{ if(v==null||!isFinite(v)) return; const px=X(i), py=A.Y(v); if(!st){ x.moveTo(px,py); st=true; } else x.lineTo(px,py); }); x.stroke();
    row.forEach((v,i)=>{ if(v==null||!isFinite(v)) return; x.fillStyle=pal[j%5]; x.beginPath(); x.arc(X(i),A.Y(v),3.4,0,6.3); x.fill(); }); });
  x.lineWidth=1; let LX=LANG==="en"?L+10:R-10; s.durs.forEach((d,j)=>{ const lab=drT(`${FA(d)} ماه`,`${d} mo`); x.fillStyle=pal[j%5]; x.fillRect(LANG==="en"?LX:LX-14,T+12+j*20-9,14,4); txt(x,lab,LANG==="en"?LX+19:LX-19,T+12+j*20,`12px ${FT.body}`,{align:LANG==="en"?"left":"right",color:"#334155"}); });
  x.strokeStyle="#cbd5e1"; x.strokeRect(L,T,R-L,B-T); caBrand(x,W,H); return c; }
function drChartArea(frac, n, idx, k, win){
  const last=(()=>{ for(let t=frac.length-1;t>=0;t--) if(frac[t]===frac[t]) return t; return -1; })(); if(last<0) return null; const t1=last, t0=Math.max(0,t1-(win==="all"?frac.length:win*12)+1);
  const W=1000,H=450,[c,x]=caCanvas(W,H), L=62,R=W-26,T=92,B=H-88, bw=(R-L)/(t1-t0+1);
  caFrame(x,W,H,drT(`سهم ایستگاه‌ها در خشکسالی — ${drIdxName(idx,k)}`,`Share of stations in drought — ${drIdxName(idx,k)}`),drT(`${drTlab(t0)} تا ${drTlab(t1)} · ایستگاه‌های دارای داده در همان ماه (حداقل ۵)`,`${drTlab(t0)} – ${drTlab(t1)} · stations with data that month (min. 5)`));
  const A=caAxes(x,L,T,R,B,0,1,0,100,{ylab:drT("درصد ایستگاه‌ها","% of stations")});
  for(let t=t0;t<=t1;t++){ const v=frac[t]; if(!(v===v)) continue; const a=A.Y(v[0]*100), b=A.Y(v[1]*100); x.fillStyle=DR_COL[4]; x.fillRect(L+(t-t0)*bw,a,Math.max(1,bw-0.5),A.Y(0)-a); x.fillStyle=DR_COL[6]; x.fillRect(L+(t-t0)*bw,b,Math.max(1,bw-0.5),A.Y(0)-b); }
  x.strokeStyle="#cbd5e1"; x.strokeRect(L,T,R-L,B-T); drYearTicks(x,L,R,B,t0,t1,(t1-t0)/12>35?10:(t1-t0)/12>16?5:2);
  x.fillStyle=DR_COL[4]; x.fillRect(LANG==="en"?L+10:R-24,T+8,14,10); x.fillStyle=DR_COL[6]; x.fillRect(LANG==="en"?L+10:R-24,T+26,14,10);
  txt(x,drT("شاخص ≤ −۱ (خشکی متوسط یا بیشتر)","index ≤ −1 (moderate or worse)"),LANG==="en"?L+30:R-30,T+18,`12px ${FT.body}`,{align:LANG==="en"?"left":"right",color:"#334155"}); txt(x,drT("شاخص ≤ −۲ (خشکی بسیار شدید)","index ≤ −2 (extreme)"),LANG==="en"?L+30:R-30,T+36,`12px ${FT.body}`,{align:LANG==="en"?"left":"right",color:"#334155"});
  caBrand(x,W,H); return c; }

/* ---------- جدول رخدادها ---------- */
function drEventsHtml(z, k, idx){
  const ev=MET.dr.events(z,{onset:DR.onset,end:0}); if(!ev.length) return `<p class="hint">${drT("در این سری رخداد خشکسالی با شرط انتخاب‌شده دیده نشد.","No drought events under the chosen threshold.")}</p>`;
  const by=[...ev].sort((a,b)=>b.sev-a.sev).slice(0,15), mean=a=>a.reduce((s,v)=>s+v,0)/a.length, longest=ev.reduce((a,b)=>b.dur>a.dur?b:a), worst=ev.reduce((a,b)=>b.sev>a.sev?b:a);
  const sum=drT(`${FA(ev.length)} رخداد · میانگین مدت ${FA((Math.round(mean(ev.map(e=>e.dur))*10)/10))} ماه · میانگین شدت ${FA((Math.round(mean(ev.map(e=>e.sev))*100)/100))} · طولانی‌ترین: ${FA(longest.dur)} ماه (${drTlab(longest.start)}) · شدیدترین: ${FA(Math.round(worst.sev*100)/100)} (${drTlab(worst.start)})`,
    `${ev.length} events · mean duration ${Math.round(mean(ev.map(e=>e.dur))*10)/10} mo · mean severity ${Math.round(mean(ev.map(e=>e.sev))*100)/100} · longest ${longest.dur} mo (${drTlab(longest.start)}) · most severe ${Math.round(worst.sev*100)/100} (${drTlab(worst.start)})`);
  const rows=by.map((e,i)=>`<tr><td>${FA(i+1)}</td><td>${drEsc(drTlab(e.start))}</td><td>${drEsc(drTlab(e.end))}${e.open?" ⟳":""}</td><td>${FA(e.dur)}</td><td>${caF(e.sev,2)}</td><td>${caF(e.intensity,2)}</td><td>${caF(e.peak,2)}</td><td><i class="dwDot" style="background:${DR_COL[drCls(e.peak)]}"></i>${drEsc(drClsName(drCls(e.peak)))}</td></tr>`).join("");
  return `<p class="hint">${sum}</p><div class="dwTblW fit"><table class="dwTbl"><thead><tr><th>#</th><th>${drT("آغاز","Start")}</th><th>${drT("پایان","End")}</th><th>${drT("مدت (ماه)","Duration (mo)")}</th><th>${drT("شدت کل","Severity")}</th><th>${drT("شدت متوسط","Intensity")}</th><th>${drT("اوج","Peak")}</th><th>${drT("رده","Class")}</th></tr></thead><tbody>${rows}</tbody></table></div>
  <p class="hint">${drT(`رخداد: آغاز وقتی ${idx==="spei"?"SPEI":"SPI"} ≤ ${FA(DR.onset)} و پایان وقتی > ۰ (نظریهٔ ران‌ها). شدت کل = مجموع |شاخص| در طول رخداد؛ شدت متوسط = شدت کل ÷ مدت. ⟳ = رخداد هنوز ادامه دارد یا دادهٔ بعد از آن ندارد.`,`Event: starts when the index ≤ ${DR.onset}, ends when > 0 (theory of runs). Severity = Σ|index|; intensity = severity ÷ duration. ⟳ = ongoing or no later data.`)}</p>`; }
function drSdfHtml(s){ const hd=s.T.map(t=>`<th>${FA(t)} ${drT("ساله","y")}</th>`).join(""), rows=s.durs.map((d,j)=>`<tr><td>${drT(`${FA(d)} ماه`,`${d} mo`)}</td>${s.table[j].map(v=>`<td>${v==null?"—":caF(v,2)}</td>`).join("")}<td>${FA(s.n[j])}</td></tr>`).join("");
  return `<div class="dwTblW fit"><table class="dwTbl"><thead><tr><th>${drT("مدت","Duration")}</th>${hd}<th>${drT("سال‌های دادهٔ کامل","Years used")}</th></tr></thead><tbody>${rows}</tbody></table></div>
  <p class="hint">${drT("مقدار هر خانه = شدت کل کمبود (مجموع کمبود SPI-1) که به‌طور میانگین یک بار در دورهٔ بازگشت رخ می‌دهد. با کمتر از ۱۵ سال داده برآورد دورهٔ بازگشت بلند (۲۵ و ۵۰ ساله) قابل اعتماد نیست.","Each cell = total deficit (Σ SPI-1 deficit) exceeded on average once per return period. With <15 years the 25/50-year estimates are unreliable.")}</p>`; }

/* ---------- کارت‌ها ---------- */
function drHtmlCard(title, html, host){ const a=document.createElement("article"); a.className="card wide"; const h=document.createElement("header"); h.innerHTML="<h3></h3>"; h.querySelector("h3").textContent=title; const d=document.createElement("div"); d.className="dwBody"; d.innerHTML=html; a.append(h,d); (host||$("drCards")).prepend(a); return a; }
const drStatus=(t)=>{ const e=$("drStatus"); if(!e) return; e.hidden=!t; e.textContent=t||""; };
function drStation(){ const id=DR.sid; return CLIM_META.st.find(s=>String(s.id)===String(id)); }

async function drRunStation(){
  if(DR.busy) return; DR.busy=true;
  try{ await caLoad(); await document.fonts.ready; const st=drStation(); if(!st) throw new Error(drT("ایستگاه را انتخاب کنید","Select a station"));
    drStatus(drT("در حال محاسبه…","Computing…")); await new Promise(r=>setTimeout(r,20)); const S=drSeries(st), name=caStName(st), refTxt=drT(DR_REFS[DR.ref][0],DR_REFS[DR.ref][1]), idx=DR.idx;
    const main=drIndex(st,idx,DR.k,S); if(main.why&&!main.z) throw new Error(drWhy(main.why)); if(main.why==="fit_failed") throw new Error(drWhy(main.why));
    const NY=Math.floor(S.P.length/12), nFit=main.fits.filter(f=>f).length, grp=document.createElement("div"), host={prepend:n=>grp.append(n)}; grp.style.display="contents";
    // ۱) سری زمانی شاخص
    const c1=drChartBars(name,main.z,idx,DR.k,DR.win,refTxt); if(c1) caCard(drT(`${drIdxName(idx,DR.k)} — ${name}`,`${drIdxName(idx,DR.k)} — ${name}`),c1,drT(`روش: ${idx==="spei"?"SPEI (لوگ‌لجستیک سه‌پارامتری، گشتاور وزنی ناریب؛ ET0 "+(main.method==="hargreaves"?"هارگریوز–سامانی":"تورنت‌وایت")+")":"SPI (گامای Thom با جرم صفر)"} · برازش در ${FA(nFit)} از ۱۲ ماه تقویمی موفق بود · سال‌های دورهٔ مرجع: ${FA(main.nref.reduce((a,b)=>Math.max(a,b),0))}`,
      `Method: ${idx==="spei"?"SPEI (3-parameter log-logistic, unbiased PWM; ET0 "+main.method+")":"SPI (Thom gamma with zero mass)"} · fit succeeded in ${nFit} of 12 calendar months · reference years: ${main.nref.reduce((a,b)=>Math.max(a,b),0)}`),host);
    // ۲) چندمقیاسه
    const rows=DR_SCALES.map(k=>{ const r=k===DR.k?main:drIndex(st,idx,k,S); return r.z?{k,z:r.z}:null; }).filter(Boolean);
    if(rows.length>1){ const c2=drChartHeat(name,rows,idx,DR.win,refTxt); if(c2) caCard(drT(`نمای چندمقیاسه — ${name}`,`Multi-scale view — ${name}`),c2,drT("مقیاس‌های کوتاه (۱ تا ۳ ماه) خشکسالی هواشناسی و رطوبت خاک؛ ۶ تا ۱۲ ماه جریان و ذخیرهٔ آب؛ ۱۸ و ۲۴ ماه خشکسالی هیدرولوژیک و آب زیرزمینی را نشان می‌دهند (راهنمای WMO ۲۰۱۲).","Short scales (1–3 mo) reflect meteorological drought and soil moisture; 6–12 mo streamflow and storage; 18–24 mo hydrological/groundwater drought (WMO 2012)."),host); }
    // ۳) رخدادها
    drHtmlCard(drT(`رخدادهای خشکسالی — ${drIdxName(idx,DR.k)} — ${name}`,`Drought events — ${drIdxName(idx,DR.k)} — ${name}`), drEventsHtml(main.z,DR.k,idx), host);
    // ۴) SDF (از شاخص یک‌ماهه)
    const one=drIndex(st,idx,1,S); if(one.z){ const sdf=MET.dr.sdf(one.z); const c4=drChartSdf(name,sdf,refTxt); if(c4){ const cd=caCard(drT(`شدت–مدت–بسامد خشکسالی — ${name}`,`Drought SDF — ${name}`),c4,"",host); const d=document.createElement("div"); d.className="dwBody"; d.innerHTML=drSdfHtml(sdf); cd.insertBefore(d,cd.querySelector(".dl")); } }
    $("drCards").replaceChildren(grp); drStatus("");
  }catch(e){ console.error(e); drStatus("⚠ "+e.message); }
  DR.busy=false; }

async function drRunRegion(){
  if(DR.busy) return; DR.busy=true;
  try{ await caLoad(); await document.fonts.ready; drStatus(drT("محاسبهٔ شاخص برای همهٔ ایستگاه‌ها…","Computing the index for all stations…")); await new Promise(r=>setTimeout(r,30));
    const idx=DR.idx, k=DR.kr, sts=CLIM_META.st.filter(s=>s.d.prcp&&s.lat!=null), N=CA.db.NM, jy0=CLIM_META.jy0, t=(DR.ry-jy0)*12+(DR.rm-1); if(!(t>=0&&t<N)) throw new Error(drT("ماه/سال خارج از دورهٔ داده است","Month/year outside the data range"));
    const pts=[], zs=[], refTxt=drT(DR_REFS[DR.ref][0],DR_REFS[DR.ref][1]); let skipped=0;
    for(const s of sts){ const r=drIndex(s,idx,k); if(!r.z){ skipped++; continue; } zs.push(r.z); const v=r.z[t]; if(v===v) pts.push({lat:s.lat,lon:s.lon,elev:s.elev||0,v,name:caStName(s),uv:s.vs==="unverified",ty:s.type}); }
    if(pts.length<10) throw new Error(drT(`فقط ${FA(pts.length)} ایستگاه برای ${drTlab(t)} مقدار دارد؛ برای نقشه دست‌کم ۱۰ ایستگاه لازم است.`,`Only ${pts.length} stations have a value for ${drTlab(t)}; at least 10 are needed.`));
    drStatus(drT("درون‌یابی و ترسیم نقشه…","Interpolating and drawing the map…")); await new Promise(r=>setTimeout(r,30));
    if(!$("caPalSel")||!$("caRes")) caBuildUI();
    const grp=document.createElement("div"), host={prepend:n=>grp.append(n)}; grp.style.display="contents"; const ttl=drT(`${drIdxName(idx,k)} — ${drPerTxt(k,t)}`,`${drIdxName(idx,k)} — ${drPerTxt(k,t)}`), cv=await caMap({ws:1,pts,title:ttl,sub:drT(`${idx==="spei"?"شاخص استاندارد بارش–تبخیر":"شاخص استاندارد بارش"} در مقیاس ${FA(k)} ماهه · ${FA(pts.length)} ایستگاه · دورهٔ مرجع ${refTxt}`,`${idx==="spei"?"Standardized Precip.–Evapotranspiration Index":"Standardized Precipitation Index"}, ${k}-month scale · ${pts.length} stations · reference ${refTxt}`),
      unit:drT("بدون بعد (≤ −۲ خشکی بسیار شدید، ≥ +۲ بسیار تر)","dimensionless (≤ −2 extremely dry, ≥ +2 extremely wet)"),kind:"pdiv",scheme:"panom",center:0,breaks:[-3,-2,-1.5,-1,-0.5,0.5,1,1.5,2,3],method:"auto",useElev:false,resKm:2,
      note:drT("خانه‌های دورتر از ۳۰۰ کیلومتر از نزدیک‌ترین ایستگاه و بیرون از ایران رنگ نمی‌گیرند.","Cells farther than 300 km from the nearest station, and outside Iran, are left blank.")});
    caCard(ttl,cv,drT(`${FA(skipped)} ایستگاه به‌دلیل نبود دادهٔ کافی کنار رفتند. نقشه درون‌یابی است؛ در جاهای بدون ایستگاه تقریبی است.`,`${skipped} stations were skipped (insufficient data). The map is interpolated; values away from stations are approximate.`),host);
    const fr=MET.dr.areaFraction(zs,-1), fr2=MET.dr.areaFraction(zs,-2), comb=new Array(N).fill(NaN); for(let i=0;i<N;i++) if(fr.frac[i]===fr.frac[i]) comb[i]=[fr.frac[i],fr2.frac[i]];
    const ca=drChartArea(comb,fr.n,idx,k,DR.rwin); if(ca) caCard(drT(`روند سهم ایستگاه‌ها در خشکسالی — ${drIdxName(idx,k)}`,`Share of stations in drought — ${drIdxName(idx,k)}`),ca,drT("همهٔ ایستگاه‌های دارای مقدار در هر ماه؛ تغییر تعداد ایستگاه در طول زمان می‌تواند روی نمودار اثر بگذارد.","All stations with data each month; changes in station count over time can influence the chart."),host);
    $("drCards").replaceChildren(grp); drStatus("");
  }catch(e){ console.error(e); drStatus("⚠ "+e.message); }
  DR.busy=false; }

/* ---------- صفحه ---------- */
function drStationOptions(q){ q=(q||"").trim().toLowerCase(); const arr=CLIM_META.st.filter(s=>s.d.prcp).map(s=>({s,n:caStName(s),len:s.d.prcp[2]})).filter(o=>!q||o.n.toLowerCase().includes(q)||(s=>String(s.id).includes(q))(o.s));
  arr.sort((a,b)=>b.len-a.len); return arr.slice(0,400).map(o=>`<option value="${drEsc(o.s.id)}"${String(o.s.id)===String(DR.sid)?" selected":""}>${drEsc(o.n)} · ${FA(Math.round(o.len/12))} ${drT("سال","yr")}</option>`).join(""); }
function drOpts(a,cur,f){ return a.map(v=>`<option value="${v}"${String(v)===String(cur)?" selected":""}>${f?f(v):v}</option>`).join(""); }
function drHTML(){ const jy0=CLIM_META.jy0, N=CA.db.NM, jy1=jy0+Math.floor((N-1)/12), months=(LANG==="en"?CA_MNE:CA_MN);
  const common=`<label>${drT("شاخص","Index")}<select id="drIdx"><option value="spi"${DR.idx==="spi"?" selected":""}>SPI — ${drT("بارش","precipitation")}</option><option value="spei"${DR.idx==="spei"?" selected":""}>SPEI — ${drT("بارش منهای تبخیر–تعرق","precip. minus ET0")}</option></select></label>
    <label>${drT("دورهٔ مرجع (نرمال)","Reference period")}<select id="drRef">${Object.keys(DR_REFS).map(k=>`<option value="${k}"${DR.ref===k?" selected":""}>${drT(DR_REFS[k][0],DR_REFS[k][1])}</option>`).join("")}</select></label>`;
  const st=`<div class="dwCtl"><label>${drT("جست‌وجوی ایستگاه","Find station")}<input id="drQ" type="search" placeholder="${drT("مثلاً شیراز","e.g. Shiraz")}"></label><label>${drT("ایستگاه (به ترتیب طول دوره)","Station (by record length)")}<select id="drSt" size="1">${drStationOptions("")}</select></label>${common}
    <label>${drT("مقیاس زمانی (ماه)","Time scale (months)")}<select id="drK">${drOpts(DR_SCALES,DR.k,v=>FA(v))}</select></label><label>${drT("نمایش آخرین … سال","Show last … years")}<select id="drWin">${drOpts([20,30,40,60,"all"],DR.win,v=>v==="all"?drT("همه","all"):FA(v))}</select></label>
    <label>${drT("آستانهٔ آغاز رخداد","Event onset threshold")}<select id="drOn">${drOpts([-0.5,-1,-1.5],DR.onset,v=>FA(v))}</select></label><button class="btn main" type="button" id="drGo">${drT("تحلیل ایستگاه","Analyse station")}</button></div>`;
  const reg=`<div class="dwCtl">${common}<label>${drT("مقیاس زمانی (ماه)","Time scale (months)")}<select id="drKr">${drOpts(DR_SCALES,DR.kr,v=>FA(v))}</select></label><label>${drT("سال شمسی","Year")}<select id="drRy">${drOpts(Array.from({length:jy1-jy0+1},(_,i)=>jy1-i),DR.ry,v=>FA(v))}</select></label>
    <label>${drT("ماه","Month")}<select id="drRm">${months.map((m,i)=>`<option value="${i+1}"${DR.rm===i+1?" selected":""}>${m}</option>`).join("")}</select></label><label>${drT("نمودار روند: آخرین … سال","Trend chart: last … years")}<select id="drRwin">${drOpts([20,30,40,60,"all"],DR.rwin,v=>v==="all"?drT("همه","all"):FA(v))}</select></label><button class="btn main" type="button" id="drGoR">${drT("ترسیم نقشه و روند","Draw map & trend")}</button></div>`;
  const info=`<div class="dwInfo"><h3>${drT("روش‌ها","Methods")}</h3><ul>
  <li><b>SPI</b> — ${drT("بارش انباشته‌شدهٔ k ماه برای هر ماه تقویمی جداگانه با توزیع گاما (برازش Thom، جرم صفر برای ماه‌های بی‌باران) استانداردسازی می‌شود (McKee و همکاران ۱۹۹۳).","k-month accumulated precipitation, fitted per calendar month with a gamma distribution (Thom fit, zero mass) and standardized (McKee et al. 1993).")}</li>
  <li><b>SPEI</b> — ${drT("به‌جای بارش، کمبود آب D = P − ET0 با لوگ‌لجستیک سه‌پارامتری (گشتاورهای وزنی احتمالی ناریب) استاندارد می‌شود (Vicente-Serrano و همکاران ۲۰۱۰). ET0 با هارگریوز–سامانی (دمای بیشینه/کمینه) یا اگر نبود، تورنت‌وایت (دمای میانگین).","D = P − ET0 is standardized with a 3-parameter log-logistic (unbiased PWM) (Vicente-Serrano et al. 2010). ET0: Hargreaves–Samani (Tmax/Tmin) or Thornthwaite (Tmean).")}</li>
  <li><b>${drT("رخداد","Events")}</b> — ${drT("نظریهٔ ران‌ها: آغاز با شاخص ≤ آستانه و پایان با شاخص > ۰؛ مدت، شدت کل، شدت متوسط و اوج.","Theory of runs: onset at index ≤ threshold, end at > 0; duration, total and mean severity, peak.")}</li>
  <li><b>SDF</b> — ${drT("بیشینهٔ سالانهٔ کمبود تجمعی SPI-1 در پنجره‌های ۱ تا ۲۴ ماهه و برازش گامبل (گشتاورهای L) برای دورهٔ بازگشت ۲ تا ۵۰ سال.","Annual maxima of cumulative SPI-1 deficit over 1–24-month windows with a Gumbel fit (L-moments) for 2–50-year return periods.")}</li></ul>
  <h3>${drT("محدودیت‌ها (صریح)","Limitations (explicit)")}</h3><ul><li>${drT("پایگاه داده ماهانه و بر پایهٔ ماه شمسی است؛ رخدادهای کوتاه‌تر از یک ماه و بارش‌های روزانه دیده نمی‌شوند.","The database is monthly (Solar Hijri months); sub-monthly events and daily extremes are not resolved.")}</li>
  <li>${drT("مجموع انباشتهٔ هر پنجره فقط وقتی حساب می‌شود که همهٔ ماه‌هایش داده داشته باشند؛ ماه مفقود هرگز صفر فرض نمی‌شود. برای هر ماه تقویمی دست‌کم ۲۰ سال داده در دورهٔ مرجع لازم است.","A window is computed only if every month has data; missing is never treated as zero. At least 20 reference years per calendar month are required.")}</li>
  <li>${drT("شاخص‌ها به ±۳٫۰۹ بریده می‌شوند (احتمال ۰٫۰۰۱ تا ۰٫۹۹۹). در مقیاس‌های بلند SPEI گاهی برازش لوگ‌لجستیک نامعتبر است و آن ماه خالی می‌ماند.","Indices are clipped to ±3.09 (probabilities 0.001–0.999). At long SPEI scales the log-logistic fit is sometimes invalid; that calendar month stays empty.")}</li>
  <li>${drT("ET0 هارگریوز تقریبی است (بدون تابش، باد و رطوبت)؛ ایستگاه‌های بدون دما در SPEI کنار می‌روند. SDF با ۱۵ سال یا کمتر دادهٔ کامل برای دوره‌های بازگشت بلند قابل اعتماد نیست.","Hargreaves ET0 is approximate (no radiation, wind, humidity); stations without temperature are skipped for SPEI. SDF with ≤15 years is unreliable for long return periods.")}</li>
  <li>${drT("نقشه‌ها درون‌یابی از ایستگاه‌اند و خارج از ایستگاه‌ها تقریبی‌اند. تغییر اقلیم مشاهده‌ای و پیش‌نگری CMIP6 هرکدام تب خودشان را دارند.","Maps are station interpolations and approximate away from stations. Observed climate change and CMIP6 projections have their own tabs.")}</li></ul>
  <p class="hint">${drT("درستی عددی هستهٔ SPI/SPEI/ET0/روند در برابر numpy/scipy آزموده شده است (۴۰ آزمون)؛ با بستهٔ R «SPEI» هنوز مقایسه نشده است.","Numerical core (SPI/SPEI/ET0/trend) is verified against numpy/scipy (40 tests); it has not yet been compared with the R 'SPEI' package.")}</p></div>`;
  const body=DR.tab==="st"?st:DR.tab==="reg"?reg:DR.tab==="cc"?ccHTML():DR.tab==="cm"?cmHTML():"";
  return `<div class="dwHead"><h2>${drT("کارگاه تغییر اقلیم و خشکسالی","Climate change & drought workshop")}</h2><p class="hint">${drT("تحلیل علمی خشکسالی از پایگاه دادهٔ ماهانهٔ ایستگاه‌ها: SPI و SPEI چندمقیاسه، رخدادها، منحنی شدت–مدت–بسامد و نقشهٔ منطقه‌ای. بخش‌های تغییر اقلیم مشاهداتی و پیش‌نگری CMIP6 در فازهای بعد اضافه می‌شوند.","Scientific drought analysis from the monthly station database: multi-scale SPI/SPEI, events, severity–duration–frequency and regional maps. Observed climate change and CMIP6 projections come in later phases.")}</p></div>
  <nav class="dwTabs"><button type="button" data-t="st" class="${DR.tab==="st"?"on":""}">${drT("تحلیل ایستگاهی","Station analysis")}</button><button type="button" data-t="reg" class="${DR.tab==="reg"?"on":""}">${drT("وضعیت منطقه‌ای","Regional status")}</button><button type="button" data-t="info" class="${DR.tab==="info"?"on":""}">${drT("روش‌ها و محدودیت‌ها","Methods & limits")}</button><button type="button" data-t="cc" class="${DR.tab==="cc"?"on":""}">${drT("تغییر اقلیم مشاهده‌ای","Observed climate change")}</button><button type="button" data-t="cm" class="${DR.tab==="cm"?"on":""}">${drT("پیش‌نگری آینده (CMIP6)","Future projections (CMIP6)")}</button></nav>
  <section class="dwPanel">${DR.tab==="info"?info:body}</section><div class="status" id="drStatus" hidden></div><div class="grid" id="drCards"></div>`; }
function drPick(){ if(DR.sid!=null) return; let best=null; for(const s of CLIM_META.st) if(s.d.prcp&&s.lat!=null&&(!best||s.d.prcp[2]>best.d.prcp[2])) best=s; DR.sid=best?best.id:null; }
function drWire(){ const m=$("drMain"), g=id=>m.querySelector("#"+id), on=(id,f)=>{ const e=g(id); if(e) e.onchange=()=>f(e.value); };
  m.querySelectorAll(".dwTabs button[data-t]").forEach(b=>b.onclick=()=>{ DR.tab=b.dataset.t; drRender(); });
  on("drIdx",v=>DR.idx=v); on("drRef",v=>DR.ref=v); on("drSt",v=>DR.sid=v); on("drK",v=>DR.k=+v); on("drWin",v=>DR.win=v==="all"?"all":+v); on("drOn",v=>DR.onset=+v); on("drKr",v=>DR.kr=+v); on("drRy",v=>DR.ry=+v); on("drRm",v=>DR.rm=+v); on("drRwin",v=>DR.rwin=v==="all"?"all":+v);
  const q=g("drQ"); if(q) q.oninput=()=>{ g("drSt").innerHTML=drStationOptions(q.value); const f=g("drSt"); if(f.options.length){ f.selectedIndex=0; DR.sid=f.value; } };
  if(DR.tab==="cc") ccWire(m); if(DR.tab==="cm") cmWire(m); const go=g("drGo"); if(go) go.onclick=drRunStation; const gr=g("drGoR"); if(gr) gr.onclick=drRunRegion; }
function drRender(){ const keep=$("drCards")?[...$("drCards").children]:[]; $("drMain").innerHTML=drHTML(); if(keep.length&&DR.tab!=="info") $("drCards").append(...keep); drWire(); }
async function openDR(){
  for(const id of ["landing","app","dsApp","cvApp","ltApp","wnApp","cqcApp","caApp","onApp","ciApp","saApp","anApp","labApp"]) if($(id)) $(id).hidden=true; $("drApp").hidden=false; store.set("mode","dr"); window.scrollTo(0,0);
  const m=$("drMain"); if(!CA.db){ m.innerHTML=`<p class="hint">${drT("بارگذاری پایگاه داده…","Loading database…")}</p>`; } await caLoad(); drPick();
  if(DR.ry==null){ const N=CA.db.NM, I16=CA.db.I16; let t=N-1; for(; t>0; t--){ let cnt=0; for(const s of CLIM_META.st){ const a=s.d.prcp; if(a&&t>=a[1]&&t<a[1]+a[2]&&I16[a[0]+t-a[1]]!==-32768&&++cnt>=40) break; } if(cnt>=40) break; }   // آخرین ماهی که دست‌کم ۴۰ ایستگاه دادهٔ بارش دارد
    DR.ry=CLIM_META.jy0+Math.floor(t/12); DR.rm=t%12+1; }
  drRender(); }
/* با رفتن به هر صفحهٔ دیگر، این صفحه پنهان می‌شود (همان الگوی صفحهٔ شاخص‌های اقلیمی) */
for(const fn of ["switchMode","showLanding","openCQC","openDS","openCV","openLT","openWN","openCA","openON","openSA","openAN","openCI"]){ const f=window[fn]; if(typeof f!=="function") continue; window[fn]=function(...a){ if($("drApp")) $("drApp").hidden=true; return f.apply(this,a); }; }
document.addEventListener("langchange",()=>{ if($("drApp")&&!$("drApp").hidden&&CA.db) drRender(); });
