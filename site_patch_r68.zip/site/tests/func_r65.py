# r65: نام دکمه‌های منو، آیکون، آکاردئون، رنگ وضعیت مدل‌ها، فاز ساعت‌ها (به وقت ایران)
import sys, asyncio, functools
print = functools.partial(print, flush=True)
from playwright.async_api import async_playwright
URL = sys.argv[1] if len(sys.argv) > 1 else 'http://localhost:8098/index.html'
async def run(b, name, vp, mobile):
    ctx = await b.new_context(viewport=vp, locale='fa-IR', has_touch=mobile, is_mobile=mobile)
    await ctx.add_init_script('localStorage.setItem("mmap.lang", JSON.stringify("fa")); localStorage.setItem("mmap.seats.on","false")')
    pg = await ctx.new_page(); errs = []
    pg.on('pageerror', lambda e: errs.append('PAGEERR ' + str(e)[:300]))
    await pg.goto(URL); await pg.wait_for_timeout(1500)
    await pg.evaluate('(async()=>{ await openON(); })()'); await pg.wait_for_timeout(3500)
    ok = {}
    r = await pg.evaluate("""(()=>{ nvWx(); const hd=[...document.querySelectorAll("#nvWx .wxHd")].map(b=>b.textContent.replace(/\\s+/g," ").trim()); return hd; })()""")
    print(name, 'headers', r)
    ok['no_taghir'] = not any('تغییر' in h for h in r)
    ok['names'] = any(h.endswith('مدل‌ها') for h in r) and any(h.endswith('پارامتر') for h in r)
    ok['icons'] = await pg.evaluate('document.querySelectorAll("#nvWx .wxHd .wxIco").length') == 5
    # آکاردئون
    r = await pg.evaluate("""(()=>{ const clk=k=>document.querySelector('#nvWx [data-tg="'+k+'"]').click(); clk("mod"); const a=Object.entries(NVW.open).filter(([k,v])=>v).map(x=>x[0]); clk("par"); const b=Object.entries(NVW.open).filter(([k,v])=>v).map(x=>x[0]); return {a,b}; })()""")
    print(name, 'accordion', r); ok['accordion'] = r['a'] == ['mod'] and r['b'] == ['par']
    # وضعیت مدل‌ها: چهار مدل ساختگی (کپی مدل موجود) با اجرا/وضعیت متفاوت
    r = await pg.evaluate("""(()=>{ const M=ON.man.models, k0=Object.keys(M)[0]; const items0=ON.man.items.filter(i=>i.m===k0);
      const defs={zg:["2026102106","partial","00/06/12/18"],zb:["2026102106","complete","00/06/12/18"],zr:["2026102100","complete","00/06/12/18"],zc:["2026102100","complete","00/12"]};
      for(const [k,[run,st,cyc]] of Object.entries(defs)){ M[k]=JSON.parse(JSON.stringify(M[k0])); M[k].fa="مدل "+k; M[k].name="M-"+k; M[k].run=run; M[k].status=st; M[k].info.cyc=cyc; ON.man.items.push(...items0.map(i=>Object.assign({},i,{m:k}))); }
      M[k0].run="2026102106"; M[k0].status="complete";
      const st=Object.keys(defs).map(k=>nvMState(k)); NV.s.tc="daily"; NVW.open.mod=true; nvWx(); const n=document.querySelectorAll("#nvWx .wxM").length;
      const dots=Object.keys(defs).map(k=>{ const c=document.querySelector('#nvWx .wxM[data-m="'+k+'"]'); return c?getComputedStyle(c).backgroundColor:null; });
      Object.keys(defs).forEach(k=>delete M[k]); ON.man.items=ON.man.items.filter(i=>!(i.m in defs)); return {st,n,dots}; })()""")
    print(name, 'states', r)
    ok['state_g'] = r['st'][0] == 'ms-g'; ok['state_b'] = r['st'][1] == 'ms-b'; ok['state_r'] = r['st'][2] == 'ms-r'; ok['state_cyc12'] = r['st'][3] == 'ms-b'
    ok['menu_all_models'] = r['n'] >= 5
    ok['colors'] = r['dots'][0] == 'rgb(22, 163, 74)' and r['dots'][1] == 'rgb(37, 99, 235)' and r['dots'][2] == 'rgb(220, 38, 38)'
    # فاز ساعت: گام ۳ ساعته و بازهٔ ۶ ساعته → دو فاز؛ ساعت‌های ایران ۰۰:۳۰ ... در فاز دوم
    r = await pg.evaluate("""(()=>{ const base=Date.UTC(2026,9,21,0); const mk=s=>{ const d=new Date(base+s*3600e3); const v=d.getUTCFullYear()+String(d.getUTCMonth()+1).padStart(2,"0")+String(d.getUTCDate()).padStart(2,"0")+String(d.getUTCHours()).padStart(2,"0")+"00"; return {s,v,p:"t2m",m:NV.s.m,r:"me"}; };
      const it=[]; for(let s=0;s<=72;s+=3) it.push(mk(s)); NV.items=it; NVW.open.time=true; NVW.ivl=6; NVW.ph=undefined; nvWx();
      const ph=[...document.querySelectorAll("#nvWx .wxPhase .wxChip")].map(c=>c.textContent); const n0=document.querySelectorAll("#nvWx .wxRow.fr .wxChip").length;
      document.querySelectorAll("#nvWx .wxPhase .wxChip")[1].click(); const cs=[...document.querySelectorAll("#nvWx .wxRow.fr .wxChip")].map(c=>c.dataset.fr.slice(8,10)); return {ph,n0,cs:cs.slice(0,5),ph2:NVW.ph}; })()""")
    print(name, 'phase', r)
    ok['phase_chips'] = len(r['ph']) == 2 and r['n0'] == 13 and r['ph2'] == 3 and r['cs'][:4] == ['03', '09', '15', '21']
    ok['no_errors'] = not [e for e in errs if 'favicon' not in e]
    if not ok['no_errors']: print(name, 'ERRS', errs[:5])
    print(name, {k: ('PASS' if v else 'FAIL') for k, v in ok.items()}); await ctx.close(); return all(ok.values())
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(); res = []
        for name, vp, mob in (('desktop', {'width': 1280, 'height': 900}, False), ('mobile', {'width': 390, 'height': 800}, True)): res.append(await run(b, name, vp, mob))
        await b.close(); print('ALL PASS' if all(res) else 'SOME FAIL'); sys.exit(0 if all(res) else 1)
asyncio.run(main())
