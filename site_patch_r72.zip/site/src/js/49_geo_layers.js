/* ===================== لایه‌های جغرافیایی (مرحلهٔ ۲): روستا/شهر، رودها، جاده‌ها، دریاچه‌ها، مرز کشورها =====================
   داده: online/data/geo.json (ساختهٔ geo_layers.py از GeoNames، OpenStreetMap و Natural Earth). اگر فایل نباشد، سایت مثل قبل کار می‌کند.
   نمایش سلسله‌مراتبی بر حسب زوم (kc = پیکسل CSS در هر درجه): رود رتبهٔ ۰ خاورمیانه، ۱ ایران، ۲ استان، ۳ شهرستان؛ جاده ۱–۳؛ مکان سطح ۰–۴.
   خطوط رود و جاده کم‌رنگ‌اند و برچسب‌ها کم‌رنگ و با هالهٔ سفید نوشته می‌شوند تا نقشه شلوغ نشود. هیچ جدول عددی نمایش داده نمی‌شود. */
/* نام لاتین در نسخهٔ فارسی: بعضی نام‌های «fa» در GeoNames لاتین‌اند (مثل Darab، Firuzabad). اول از واژه‌نامهٔ شهرها برمی‌گردانیم، بعد نزدیک‌ترین مرکز شهرستان (≤ حدود ۳ کیلومتر)؛ وگرنه برچسب نمایش داده نمی‌شود. */
const GEO_FAC=/[\u0600-\u06FF]/; let GEO_REV=null;
function geoRev(){ if(GEO_REV) return GEO_REV; GEO_REV=new Map(); try{ for(const [k,v] of Object.entries(I18N_D)) if(typeof v==="string"&&GEO_FAC.test(k)&&!GEO_FAC.test(v)&&k.length<30){ const q=v.toLowerCase().replace(/[^a-z]/g,""); if(q&&!GEO_REV.has(q)) GEO_REV.set(q,k); } }catch(e){} return GEO_REV; }
function geoFaName(n,la,lo){ if(!n||GEO_FAC.test(n)) return n; const r=geoRev().get(String(n).toLowerCase().replace(/[^a-z]/g,"")); if(r) return r;
  if(isFinite(la)&&isFinite(lo)&&typeof SEATS!=="undefined"){ let b=null,bd=1e9; for(const q of SEATS){ const d=Math.hypot(q[1]-la,(q[2]-lo)*Math.cos(la*Math.PI/180)); if(d<bd){ bd=d; b=q; } } if(b&&bd<0.03) return b[0]; } return ""; }
/* نام شهر برای نمایش: فارسی در نسخهٔ فارسی؛ در نسخهٔ انگلیسی نام انگلیسی (از داده، وگرنه واژه‌نامه)؛ اگر نبود "" (برچسب نمایش داده نمی‌شود تا فارسی و انگلیسی قاطی نشود) */
function geoLabel(n,en){ if(typeof LANG==="undefined"||LANG!=="en"||!n) return n; if(en&&!GEO_FAC.test(en)) return en; let t=n; try{ t=tr(n); }catch(e){} return GEO_FAC.test(t)?"":t; }
const GEO={d:null, ok:false, tried:false, busy:false, paths:null};
const GEO_RK_KC=[5,30,90,190], GEO_RK_LBL=[12,45,120,260], GEO_RD_KC=[0,40,90,170], GEO_LV_KC=[70,110,170,300,600];
const GEO_T_KC=[0,60,170], GEO_TC=["#c81e1e","#111","#1d4ed8","#8a5a1c"], GEO_TT=["#8b1010","#111","#1e3a8a","#5b3a0f"], GEO_TF=[13.5,12,11,10], GEO_TR=[3.4,2.8,2.8,2.4];
async function geoLoad(){
  if(GEO.tried||GEO.busy) return; GEO.busy=true;
  try{ const r=await fetch((typeof ON!=="undefined"&&ON.base?ON.base:"online/")+"data/geo.json?"+(Date.now()/36e5|0),{cache:"default"}); if(!r.ok) throw new Error(r.status);
    const d=await r.json(); GEO.d=d; GEO.paths=null; GEO.ok=!!(d&&(d.places&&d.places.length||d.rivers&&d.rivers.length||d.roads&&d.roads.length||d.lakes&&d.lakes.length)); }
  catch(e){ GEO.ok=false; console.warn("geo.json",e&&e.message); }
  GEO.tried=true; GEO.busy=false; try{ if(GEO.ok) nvDraw(false); }catch(e){}
}
function geoPrep(){
  if(GEO.paths) return GEO.paths; const d=GEO.d||{}, P={rv:[0,1,2,3].map(()=>new Path2D()), rd:[0,0,0,0].map(()=>new Path2D()), lk:new Path2D(), bd:null, co:null, rl:[[],[],[],[]], ll:[]};
  const ln=(path,l)=>{ l.forEach((q,i)=>i?path.lineTo(q[0],q[1]):path.moveTo(q[0],q[1])); };
  for(const r of (d.rivers||[])){ const rk=Math.max(0,Math.min(3,r.rk|0)); let best=null, bl=0; for(const l of r.l){ ln(P.rv[rk],l); if(l.length>bl){ bl=l.length; best=l; } } const rn=geoFaName(r.n); if(best&&rn) P.rl[rk].push({n:rn,en:r.en,l:best}); }
  for(const r of (d.roads||[])){ const c=Math.max(1,Math.min(3,r.c|0)); ln(P.rd[c],r.l); }
  for(const L of (d.lakes||[])){ let sx=0,sy=0,n=0; for(const ring of L.r){ ring.forEach((q,i)=>i?P.lk.lineTo(q[0],q[1]):P.lk.moveTo(q[0],q[1])); P.lk.closePath(); } const big=L.r.slice().sort((a,b)=>b.length-a.length)[0]||[]; for(const q of big){ sx+=q[0]; sy+=q[1]; n++; } if(n){ const ln_=geoFaName(L.n); if(ln_) P.ll.push({n:ln_,en:L.en,lo:sx/n,la:sy/n}); } }
  try{ const NP=nvPaths(); if(d.borders&&d.borders.length){ const bp=new Path2D(); for(const l of d.borders){ let open=false; for(const q of l){ if(NP.GO&&nvSegNear(NP.GO,q[0],q[1],0.06)){ open=false; continue; } if(open) bp.lineTo(q[0],q[1]); else { bp.moveTo(q[0],q[1]); open=true; } } } P.bd=bp; } }catch(e){}
  try{ if(d.coast&&d.coast.length){ const cp=new Path2D(); for(const l of d.coast){ l.forEach((q,i)=>i?cp.lineTo(q[0],q[1]):cp.moveTo(q[0],q[1])); } P.co=cp; } }catch(e){} /* r65: ساحل بیرون از کادر خاورمیانه (کادر اروپا) */
  const pl=(d.places||[]).filter(p=>p&&p[0]&&isFinite(p[1])&&isFinite(p[2])).map(p=>{ const q=geoFaName(p[0],p[1],p[2]); return q===p[0]?p:q?[q].concat(p.slice(1)):null; }).filter(Boolean); /* r65: هم‌نامی روستا با مرکز یک شهرستان (مثلاً روستای «زاهدان» فسا) نباید برچسب بگیرد؛ مکانی با نام مرکز شهرستان که بیش از ~۰٫۲۵° از آن مرکز دور است حذف می‌شود */
  const SN=(typeof SEATS!=="undefined")?SEATS:[], nrm=t=>String(t||"").replace(/[\s‌]+/g,"").replace(/ي/g,"ی").replace(/ك/g,"ک"), byN={}; for(const q of SN){ (byN[nrm(q[0])]=byN[nrm(q[0])]||[]).push(q); }
  P.pl=pl.filter(p=>{ const a=byN[nrm(p[0])]; if(!a) return true; return a.some(q=>Math.abs(q[1]-p[1])<0.25&&Math.abs(q[2]-p[2])<0.3); }); return GEO.paths=P;
}
/* خطوط (داخل تبدیل جغرافیایی). w(px) = ضخامت بر حسب پیکسل */
function geoLines(x,S,kc,w){
  if(!GEO.ok) return; const P=geoPrep(); x.lineJoin="round"; x.lineCap="round";
  if(S.lake!==false && kc>=5){ x.save(); x.setLineDash([w(5),w(3.2)]); x.strokeStyle="#2468b8"; x.lineWidth=w(1.3); x.stroke(P.lk); x.restore(); }
  const zf=Math.max(0.85,Math.min(1.5,1+Math.log2(Math.max(kc,5)/60)*0.16));          // با زوم بیشتر کمی ضخیم‌تر
  // جاده: ۱ آزادراه/بزرگراه = قرمز آجری ضخیم با حاشیهٔ سفید، ۲ جادهٔ اصلی ملی = نارنجی، ۳ جادهٔ اصلی استانی = قهوه‌ای کم‌رنگ و نازک (از زوم‌های عمیق‌تر)
  if(S.road!==false){ const RS={1:["#b8321f",1.9,3.4],2:["#e08a2e",1.4,0],3:["#c8a878",0.95,0]};
    for(let c=3;c>=1;c--){ if(kc<GEO_RD_KC[c]) continue; const [col,wd,cs]=RS[c]; if(cs){ x.setLineDash([]); x.strokeStyle="rgba(255,255,255,.85)"; x.lineWidth=w(cs*zf); x.stroke(P.rd[c]); }
      x.strokeStyle=col; x.lineWidth=w(wd*zf); x.setLineDash([]); x.stroke(P.rd[c]); } }
  // رود: رتبهٔ ۰ اصلی (آبی تیره، ضخیم)، ۱ مهم، ۲ متوسط، ۳ فرعی (آبی روشن، خط‌چین)
  if(S.riv!==false){ const RV={0:["#2468b8",2.1,null],1:["#3a86dc",1.6,null],2:["#68a7ec",1.15,null],3:["#8fc0f3",0.85,[3.2,2.2]]};
    for(let r=3;r>=0;r--){ if(kc<GEO_RK_KC[r]) continue; const [col,wd,dash]=RV[r]; x.strokeStyle=col; x.lineWidth=w(wd*zf); x.setLineDash(dash?dash.map(q=>w(q)):[]); x.stroke(P.rv[r]); } x.setLineDash([]); }
}
/* مرز کشورهای همسایه از Natural Earth؛ true = رسم شد و مرز قدیمی کشورها نباید رسم شود */
function geoBorders(x,kc,w){ if(!GEO.ok) return false; const P=geoPrep(); if(P.co){ x.strokeStyle="#111"; x.lineWidth=w(1.2); x.stroke(P.co); } if(!P.bd) return false; x.strokeStyle="#111"; x.lineWidth=w(1.5); x.stroke(P.bd); return true; }
/* برچسب‌ها (پیکسل). occ: مستطیل‌های اشغال‌شده برای جلوگیری از شلوغی */
function geoLabels(x,W,H,k,x0,y0,S,scale,kc){
  const P=GEO.ok?geoPrep():{pl:[],ll:[],rl:[[],[],[],[]]}, occ=[]; const fit=(a,b,c,d)=>{ for(const o of occ) if(a<o[2]&&c>o[0]&&b<o[3]&&d>o[1]) return false; occ.push([a,b,c,d]); return true; };
  x.save(); x.lineJoin="round"; x.textAlign="center"; x.direction="rtl";
  // نام دریاچه‌ها و رودها (کم‌رنگ)
  if(S.lake!==false && kc>=14){ x.font=`italic 600 ${10.5*scale}px ${FT.body}`; x.textBaseline="middle";
    for(const l of P.ll){ const X=(l.lo-x0)*k, Y=(y0-l.la)*k; if(X<0||Y<0||X>W||Y>H) continue; const ln2=geoLabel(l.n,l.en); if(!ln2) continue; const w_=x.measureText(ln2).width; if(!fit(X-w_/2,Y-7*scale,X+w_/2,Y+7*scale)) continue;
      x.lineWidth=3*scale; x.strokeStyle="rgba(255,255,255,.85)"; x.strokeText(ln2,X,Y); x.fillStyle="rgba(86,140,200,.95)"; x.fillText(ln2,X,Y); } }
  if(S.riv!==false){ x.font=`italic 600 ${10*scale}px ${FT.body}`; x.textBaseline="middle"; let nl=0;
    for(let r=0;r<4;r++){ if(kc<GEO_RK_LBL[r]) continue;
      for(const R of P.rl[r]){ if(nl>60) break; const l=R.l; let i0=-1,i1=-1; for(let i=0;i<l.length;i++){ const X=(l[i][0]-x0)*k, Y=(y0-l[i][1])*k; if(X>20&&Y>20&&X<W-20&&Y<H-20){ if(i0<0) i0=i; i1=i; } }
        if(i0<0||i1-i0<2) continue; const m=(i0+i1)>>1, a=l[Math.max(0,m-1)], b=l[Math.min(l.length-1,m+1)], X=(l[m][0]-x0)*k, Y=(y0-l[m][1])*k; let ang=Math.atan2(-(b[1]-a[1]),(b[0]-a[0])); if(ang>Math.PI/2) ang-=Math.PI; if(ang<-Math.PI/2) ang+=Math.PI;
        const rn2=geoLabel(R.n,R.en); if(!rn2) continue; const w_=x.measureText(rn2).width, hw=Math.abs(Math.cos(ang))*w_/2+6, hh=Math.abs(Math.sin(ang))*w_/2+7; if(!fit(X-hw,Y-hh,X+hw,Y+hh)) continue;
        x.save(); x.translate(X,Y); x.rotate(ang); x.lineWidth=3*scale; x.strokeStyle="rgba(255,255,255,.8)"; x.strokeText(rn2,0,-5*scale); x.fillStyle="rgba(92,150,214,.95)"; x.fillText(rn2,0,-5*scale); x.restore(); nl++; } } }
  // نقاط سلسله‌مراتبی (اولویت از بالا): ۰ مرکز استان ■ قرمز · ۱ مرکز شهرستان ● مشکی · ۲ سایر شهرها ◆ آبی · ۳ روستا ▲ قهوه‌ای (فقط در زوم شهرستان و عمیق‌تر)
  x.textBaseline="bottom"; let n=0; const seats=(typeof SEATS!=="undefined")?SEATS:[];
  const mark=(t,X,Y,r)=>{ x.beginPath(); if(t===0){ x.rect(X-r,Y-r,2*r,2*r); } else if(t===2){ x.moveTo(X,Y-r*1.25); x.lineTo(X+r*1.1,Y); x.lineTo(X,Y+r*1.25); x.lineTo(X-r*1.1,Y); x.closePath(); } else if(t===3){ x.moveTo(X,Y-r*1.2); x.lineTo(X+r*1.1,Y+r*.8); x.lineTo(X-r*1.1,Y+r*.8); x.closePath(); } else x.arc(X,Y,r,0,6.2832);
    x.lineWidth=1.6*scale; x.strokeStyle="#fff"; x.stroke(); x.fillStyle=GEO_TC[t]; x.fill(); };
  const draw=(t,nm,la,lo)=>{ const X=(lo-x0)*k, Y=(y0-la)*k; if(X<-10||Y<-10||X>W+10||Y>H+10) return;
    const fs=GEO_TF[t]*scale, r=GEO_TR[t]*scale; x.font=`${t<=1?700:600} ${fs}px ${FT.body}`; const w_=x.measureText(nm).width;
    if(!fit(X-w_/2-1,Y-fs-r-2,X+w_/2+1,Y+r+1)) return; if(++n>420) return;
    mark(t,X,Y,r); x.lineWidth=3*scale; x.strokeStyle="rgba(255,255,255,.88)"; x.strokeText(nm,X,Y-r-1*scale); x.fillStyle=GEO_TT[t]; x.fillText(nm,X,Y-r-1*scale); };
  if(S.city){
    for(const q of seats){ if(q[4]===1) draw(0,geoLabel(q[0],q[3])||"",q[1],q[2]); }
    if(kc>=GEO_T_KC[1]) for(const q of seats){ if(q[4]===0) draw(1,geoLabel(q[0],q[3])||"",q[1],q[2]); }
    if(kc>=GEO_T_KC[2]) for(const q of seats){ if(q[4]===2) draw(2,geoLabel(q[0],q[3])||"",q[1],q[2]); }
  }
  if(GEO.ok){ const near=(la,lo,d)=>{ for(const q of seats){ if(Math.abs(q[1]-la)<d&&Math.abs(q[2]-lo)<d*1.2) return true; } return false; };
    const pl=P.pl; if(S.city) for(const p of pl){ const lv=p[3]|0; if(lv>2||kc<GEO_LV_KC[lv]) continue; if(near(p[1],p[2],0.05)) continue; const pn=geoLabel(p[0],p[6]); if(pn) draw(2,pn,p[1],p[2]); }
    if(S.vill!==false && kc>=GEO_LV_KC[3]){ let nv=0; const cap=Math.round(14+kc/12);
      for(const p of (P.vl||(P.vl=pl.filter(q=>(q[3]|0)>=3).sort((a,b)=>(b[4]||0)-(a[4]||0))))){ const lv=p[3]|0; if(kc<GEO_LV_KC[lv]) continue; if(nv>=cap) break; if(near(p[1],p[2],0.03)) continue; const pn=geoLabel(p[0],p[6]); if(!pn) continue; const m=n; draw(3,pn,p[1],p[2]); if(n>m) nv++; } } }
  x.restore(); return true;
}
