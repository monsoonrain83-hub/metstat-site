/* ===== ذرات باد روی نمایشگر نقشه‌های آنلاین (فاز ۵) =====
   لایهٔ اختیاری (پیش‌فرض خاموش) روی بوم جدا؛ نقشهٔ رنگی دست نمی‌خورد و در خروجی PNG نمی‌آید.
   داده: «کاشی باد» me/{pid}W_{vt}.webp که nwp_maps می‌سازد (wind_tile.py): ۱۸۰×۱۲۱، ۰٫۲۵°، R=u و G=v بر حسب گره، سرایند در ردیف ۰.
   نقشهٔ باد (w10، w200، w250، w300، w500) کاشی خودش را می‌گیرد؛ هر نقشهٔ دیگرِ همان مدل و همان زمان معتبر از کاشی باد ۱۰ متری همان مدل (w10) استفاده می‌کند.
   مدلی که کاشی باد ندارد: لایه خالی می‌ماند و دلیل نوشته می‌شود (چیزی ساختگی نمی‌شود). */
const WPT={on:store.get("nv.wind",false), cfg:Object.assign({lv:"auto",den:1,wid:1,col:"spd"},store.get("nv.wind.cfg",{})), tile:null, ek:"", cv:null, p:[], sig:"", raf:0, last:0, st:"", cache:new Map()};
const WPT_PIDS=["w10","w200","w250","w300","w500"], WPT_BOX=[20,42];       // lon0، lat1 کاشی (۰٫۲۵°)
function nvwEn(){ return typeof LANG!=="undefined"&&LANG==="en"; }
const WPT_LV=[["auto","هماهنگ با نقشهٔ فعلی","Match the current map"],["sfc","سطح زمین (باد ۱۰ متری)","Surface (10 m wind)"],["1000","۱۰۰۰ هکتوپاسکال","1000 hPa"],["925","۹۲۵ هکتوپاسکال","925 hPa"],["850","۸۵۰ هکتوپاسکال","850 hPa"],["700","۷۰۰ هکتوپاسکال","700 hPa"],["500","۵۰۰ هکتوپاسکال","500 hPa"],["300","۳۰۰ هکتوپاسکال","300 hPa"],["250","۲۵۰ هکتوپاسکال","250 hPa"],["200","۲۰۰ هکتوپاسکال","200 hPa"]];
function nvwUrl(){
  const e=NV.entry; if(!e||!e.item||!e.item.f) return null; if(e.item.r=="eu") return null; const it=e.item, lv=WPT.cfg.lv||"auto";      /* r65: ذرات باد فقط روی کاشی خاورمیانه */
  const mk=pid=>ON.base+it.f.replace(/\/([a-zA-Z0-9]+)_(\d{10}\.webp)$/,"/"+pid+"W_$2")+nvRunQ();
  if(lv==="sfc") return mk("w10");
  if(lv!=="auto") return mk("w"+lv);
  let src=it;
  if(!WPT_PIDS.includes(it.p)){ src=nvMeItems(NV.s.m).find(i=>i.p==="w10"&&i.v===it.v); if(!src) return null; }
  return ON.base+src.f.replace(/\/([a-zA-Z0-9]+)_(\d{10}\.webp)$/,"/$1W_$2")+nvRunQ(); }
function nvwLoad(url){
  if(WPT.cache.has(url)) return WPT.cache.get(url);
  const pr=new Promise(res=>{ const im=new Image(); im.crossOrigin="anonymous";
    im.onload=()=>{ try{ const w=im.naturalWidth, h=im.naturalHeight-1; if(w<8||h<8) return res(null); const c=document.createElement("canvas"); c.width=im.naturalWidth; c.height=im.naturalHeight;
      const x=c.getContext("2d",{willReadFrequently:true}); x.drawImage(im,0,0); const d=x.getImageData(0,0,c.width,c.height).data, sc=d[0]/10, ver=d[1]; if(!(sc>0)||ver!==1) return res(null);
      const U=new Float32Array(w*h), V=new Float32Array(w*h);
      for(let i=0;i<w*h;i++){ const q=(w+i)*4, a=d[q], b=d[q+1]; U[i]=a?(a-128)*sc:NaN; V[i]=b?(b-128)*sc:NaN; }
      res({w:w,h:h,U:U,V:V}); }catch(err){ res(null); } };
    im.onerror=()=>res(null); im.src=url; });
  WPT.cache.set(url,pr); if(WPT.cache.size>8) WPT.cache.delete(WPT.cache.keys().next().value); return pr; }
function nvwSample(lon,lat){
  const T=WPT.tile; if(!T) return null; const gx=(lon-WPT_BOX[0])*4-0.5, gy=(WPT_BOX[1]-lat)*4-0.5;
  if(gx<0||gy<0||gx>=T.w-1||gy>=T.h-1) return null; const x0=gx|0, y0=gy|0, fx=gx-x0, fy=gy-y0, i=y0*T.w+x0, j=i+T.w;
  const u=(T.U[i]*(1-fx)+T.U[i+1]*fx)*(1-fy)+(T.U[j]*(1-fx)+T.U[j+1]*fx)*fy, v=(T.V[i]*(1-fx)+T.V[i+1]*fx)*(1-fy)+(T.V[j]*(1-fx)+T.V[j+1]*fx)*fy;
  return (u!==u||v!==v)?null:[u,v]; }
function nvwCfgSave(){ store.set("nv.wind.cfg",WPT.cfg); }
function nvwUi(){
  const c=$("nvWindChk"); if(!c||c.__nvw) return; c.__nvw=1; c.checked=!!WPT.on;
  const box=$("nvWindBox"), lv=$("nvWindLv"), den=$("nvWindDen"), wid=$("nvWindWid"), col=$("nvWindCol");
  const upd=()=>{ if(box) box.classList.toggle("off",!WPT.on); };
  c.onchange=()=>{ WPT.on=c.checked; store.set("nv.wind",WPT.on); WPT.ek=""; upd(); nvwSync(); try{ if(NVF&&NVF.on) nvfFillDd("lay"); }catch(e){} };
  if(lv){ lv.innerHTML=WPT_LV.map(([k,f,e])=>`<option value="${k}">${nvwEn()?e:f}</option>`).join(""); lv.value=WPT.cfg.lv||"auto"; if(lv.value!==(WPT.cfg.lv||"auto")) lv.value="auto";
    lv.onchange=()=>{ WPT.cfg.lv=lv.value; nvwCfgSave(); WPT.ek=""; nvwSync(); try{ if(NVF&&NVF.on) nvfFillDd("lay"); }catch(e){} }; }
  if(den){ den.value=WPT.cfg.den; den.oninput=()=>{ WPT.cfg.den=+den.value; nvwCfgSave(); WPT.sig=""; nvwSync(); }; }
  if(wid){ wid.value=WPT.cfg.wid; wid.oninput=()=>{ WPT.cfg.wid=+wid.value; nvwCfgSave(); }; }
  if(col){ col.value=WPT.cfg.col||"spd"; col.onchange=()=>{ WPT.cfg.col=col.value; nvwCfgSave(); const g=WPT.cv&&WPT.cv.getContext("2d"); if(g) g.clearRect(0,0,WPT.cv.width,WPT.cv.height); nvwSync(); }; }
  upd(); nvwTxt(); }
function nvwTxt(){ const t=$("nvWindT"), s=$("nvWindSt"); if(t) t.textContent=nvwEn()?"🌬️ Wind particles":"🌬️ ذرات باد"; if(s) s.textContent=WPT.on?WPT.st:"";
  const d=$("nvWindDt"); if(d) d.textContent=nvwEn()?"Lines":"تراکم و ضخامت خطوط"; const a=$("nvWindDl"), b=$("nvWindWl"); if(a) a.firstChild.textContent=nvwEn()?"Density ":"تراکم "; if(b) b.firstChild.textContent=nvwEn()?"Thickness ":"ضخامت "; }
function nvwStop(){ if(WPT.raf){ cancelAnimationFrame(WPT.raf); WPT.raf=0; } }
function nvwCanvas(){ const st=$("nvStage"), cv=$("nvCv"); if(!st||!cv) return null; let c=$("nvWind");
  if(!c){ c=document.createElement("canvas"); c.id="nvWind"; c.setAttribute("aria-hidden","true"); c.style.pointerEvents="none"; cv.insertAdjacentElement("afterend",c); } return WPT.cv=c; }
function nvwSeed(n,v){ const W=NV.cw, H=NV.ch, P=[]; for(let i=0;i<n;i++) P.push({x:Math.random()*W,y:Math.random()*H,age:Math.floor(Math.random()*90),max:70+Math.random()*60}); return P; }
function nvwSync0(){
  nvwUi(); nvwTxt(); const c=nvwCanvas(), cv=$("nvCv"); if(!c||!cv) return;
  const ok=WPT.on&&NV.entry&&NV.entry.img&&NV.view; if(!ok){ nvwStop(); c.style.display="none"; return; }
  if(c.width!==cv.width||c.height!==cv.height){ c.width=cv.width; c.height=cv.height; WPT.sig=""; }
  const url=nvwUrl(), key=url||("none|"+(NV.entry.item.f||""));
  if(key!==WPT.ek){ WPT.ek=key; WPT.tile=null; WPT.st=""; nvwStop(); c.style.display="none";
    if(!url){ WPT.st=nvwEn()?"(no wind tile for this map/model)":"(برای این نقشه/مدل کاشی باد نیست)"; nvwTxt(); return; }
    WPT.st=nvwEn()?"(loading…)":"(در حال بارگذاری…)"; nvwTxt();
    nvwLoad(url).then(T=>{ if(WPT.ek!==key) return; WPT.tile=T; WPT.sig=""; WPT.st=T?"":(nvwEn()?"(wind tile not available on host)":"(کاشی باد روی هاست نیست)"); nvwTxt(); nvwSync(); }); return; }
  if(!WPT.tile){ c.style.display="none"; return; }
  c.style.display="block"; const v=NV.view, sig=[v.k,v.x0,v.y0,NV.cw,NV.ch].join("|");
  if(sig!==WPT.sig){ WPT.sig=sig; const g=c.getContext("2d"); g.clearRect(0,0,c.width,c.height); WPT.p=nvwSeed(Math.max(200,Math.min(9000,Math.round(Math.max(500,Math.min(3500,NV.cw*NV.ch/500))*(WPT.cfg.den||1)))),v); }
  if(!WPT.raf) WPT.raf=requestAnimationFrame(nvwFrame);
}
function nvwFrame(t){
  WPT.raf=0; const st=$("nvStage"), c=WPT.cv; if(!WPT.on||!WPT.tile||!c||!st||st.offsetParent===null||document.hidden||!NV.view) return;
  const v=NV.view, d=NV.d||1, k=v.k, g=c.getContext("2d"), dt=Math.min(2.5,WPT.last?(t-WPT.last)/16.7:1); WPT.last=t;
  g.globalCompositeOperation="destination-out"; g.fillStyle="rgba(0,0,0,"+(0.07*dt).toFixed(3)+")"; g.fillRect(0,0,c.width,c.height); g.globalCompositeOperation="source-over"; g.lineCap="round";
  const spd=WPT.cfg.col==="spd", B=spd?[[],[],[],[],[],[],[],[]]:[[],[],[]], W=NV.cw, H=NV.ch, S=0.075*dt;                               // پیکسل CSS در هر گره در هر فریم
  for(const p of WPT.p){
    const w=nvwSample(v.x0+p.x/k, v.y0-p.y/k);
    if(!w||p.age++>p.max||p.x<0||p.y<0||p.x>W||p.y>H){ p.x=Math.random()*W; p.y=Math.random()*H; p.age=0; p.max=70+Math.random()*60; continue; }
    const sp=Math.hypot(w[0],w[1]), nx=p.x+w[0]*S, ny=p.y-w[1]*S; B[spd?nvwBand(sp):(sp<10?0:(sp<25?1:2))].push(p.x*d,p.y*d,nx*d,ny*d); p.x=nx; p.y=ny; }
  const st3=spd?WPT_SC.c.map((c,i)=>[c,0.9+i*0.1]):[["rgba(15,23,42,.42)",0.9],["rgba(15,23,42,.66)",1.2],["rgba(15,23,42,.88)",1.6]], wm=WPT.cfg.wid||1;
  for(let b=0;b<B.length;b++){ const a=B[b]; if(!a.length) continue; g.strokeStyle=st3[b][0]; g.lineWidth=st3[b][1]*d*wm; g.beginPath(); for(let i=0;i<a.length;i+=4){ g.moveTo(a[i],a[i+1]); g.lineTo(a[i+2],a[i+3]); } g.stroke(); }
  WPT.raf=requestAnimationFrame(nvwFrame);
}
/* r57: ذرات رنگی بر حسب سرعت (گره) + نوار رنگ زیر نقشه؛ طبقه‌ها گسسته‌اند (بدون رنگ واسطه) */
const WPT_SC={c:["#2b6cb0","#2c7a7b","#2f855a","#b7791f","#dd6b20","#c53030","#97266d","#44337a"],e:[0,5,10,15,20,30,40,50]};
const WPT_CUT=[5,10,15,20,30,40,50];
function nvwBand(sp){ let i=0; while(i<WPT_CUT.length&&sp>=WPT_CUT[i]) i++; return i; }
function nvwOn(){ return !!(WPT.on&&WPT.tile&&WPT.cv&&WPT.cv.style.display!=="none"); }
function nvwLegend(){ if(!nvwOn()||WPT.cfg.col!=="spd") return null; return {sc:WPT_SC,unit:(nvwEn()?"Wind particles (kt)":"ذرات باد (گره)")}; }
function nvwSync(){ nvwSync0(); const f=!!nvwLegend(); if(f!==WPT.legOn){ WPT.legOn=f; try{ nvLegend(); }catch(e){} } }
/* نمایشگر هر بار نقشه را می‌کشد، لایه همگام می‌شود؛ پنج‌ثانیه‌ای هم اگر حلقه ایستاده بود (تب پنهان بوده و برگشته) دوباره بالا می‌آید */
(function(){
  const o=window.nvDraw; if(typeof o!=="function") return;
  window.nvDraw=function(){ const r=o.apply(this,arguments); try{ nvwSync(); }catch(e){ console.warn("nvwind",e); } return r; };
  document.addEventListener("visibilitychange",()=>{ if(!document.hidden){ try{ nvwSync(); }catch(e){} } });
  document.addEventListener("langchange",()=>{ try{ nvwTxt(); }catch(e){} });
  setInterval(()=>{ try{ if(WPT.on&&!WPT.raf&&WPT.tile&&$("nvStage")&&$("nvStage").offsetParent) nvwSync(); }catch(e){} },2000);
})();
