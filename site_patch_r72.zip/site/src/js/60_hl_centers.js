/* ===== r63: مراکز فشار و ارتفاع (L قرمز / H آبی) روی نقشه‌های فشار سطح دریا و ارتفاع ژئوپتانسیل ۸۵۰/۷۰۰/۵۰۰ =====
   لایهٔ شفاف {pid}H را مولد (hl_centers.py) می‌سازد؛ این‌جا فقط بارگذاری و روشن/خاموش‌کردن است. اگر برای یک ساعت لایه‌ای نباشد
   (مرکز معتبری پیدا نشده یا نقشهٔ قدیمی)، چیزی نمایش داده نمی‌شود. ذخیرهٔ انتخاب: store «nv.hl». */
const HL_LV={sfc:"msl",w10:"msl",z850:"850",z700:"700",z500:"500"};
const HL_LAB=[["msl","فشار سطح دریا"],["850","ارتفاع ۸۵۰ هکتوپاسکال"],["700","ارتفاع ۷۰۰ هکتوپاسکال"],["500","ارتفاع ۵۰۰ هکتوپاسکال"]];
const HLC=Object.assign({msl:true,"850":true,"700":true,"500":true},(function(){ try{ return store.get("nv.hl",{}); }catch(e){ return {}; } })());
function hlSave(){ try{ store.set("nv.hl",HLC); }catch(e){} }
function hlLevel(){ try{ return HL_LV[nvPid()]||HL_LV[NV.s.p]||null; }catch(e){ return null; } }
function hlUrl(cur){ const lv=cur&&HL_LV[cur.p]; if(!lv||!HLC[lv]) return null;
  return ON.base+cur.f.replace(/\/([a-zA-Z0-9]+)_(\d{10}\.webp)$/,"/$1H_$2")+nvRunQ(); }
function hlHtml(k){ const fs=k==="fs", cur=hlLevel();
  const chip=(lv,t)=>`<button type="button" class="${fs?"fsChip":"hlChip"}${HLC[lv]?" on":""}" data-hl="${lv}">${HLC[lv]?"☑":"☐"} ${t}${lv===cur?" ◄":""}</button>`;
  return `<div class="${fs?"fsH":"hint"}">مراکز کم‌فشار/کم‌ارتفاع (L، قرمز) و پرفشار/پرارتفاع (H، آبی)</div><div class="${fs?"fsGrid":"wxRow"}">${HL_LAB.map(([lv,t])=>chip(lv,t)).join("")}</div>
   <div class="hint">مراکز با روش خودکار (کمینه/بیشینهٔ محلی با آستانهٔ برجستگی) از خروجی مدل پیدا می‌شوند؛ زیر زمین‌ماندهٔ ۸۵۰ و ۷۰۰ هکتوپاسکال روی ارتفاعات حذف می‌شود.</div>`; }
function hlSync(){ const cur=hlLevel();
  document.querySelectorAll(".nvHlDd").forEach(d=>{ d.hidden=!cur; const b=d.querySelector(".nvHlBody"); if(b) b.innerHTML=hlHtml("main"); });
  document.querySelectorAll(".nvHlFs").forEach(b=>{ b.hidden=!cur; b.innerHTML=cur?hlHtml("fs"):""; });
  const n=Object.values(HLC).filter(Boolean).length; document.querySelectorAll(".nvHlCnt").forEach(s=>{ s.textContent=` (${FA(n)})`; }); }
document.addEventListener("click",e=>{ const b=e.target.closest&&e.target.closest("[data-hl]"); if(!b) return;
  const lv=b.dataset.hl; HLC[lv]=!HLC[lv]; hlSave(); hlSync();
  try{ const en=NV.entry; if(en&&HL_LV[en.item&&en.item.p]===lv) nvResolve(); }catch(err){} });
