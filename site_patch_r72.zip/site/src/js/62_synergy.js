/* ===== r66 — «سینرژی» نسخهٔ ۲: تحلیل شبکه‌ای (ECMWF و GFS) با نقشهٔ تعاملی =====
   بستهٔ MSG1 (data/grid/<model>/…) ← مشتق‌ها و شاخص‌ها در مرورگر ← رنگ‌بندی گسسته (هرگز میان‌رنگ ندارد) + هر تعداد خط همتراز + باد + جبهه.
   نقشه: زوم/پن (ماوس، لمس، دو انگشت)، تمام‌صفحه، مرز ساحل/کشور/استان، اسکیوتی و هودوگراف و شاخص‌ها با کلیک (از هستهٔ MET آزمایشگاه).
   صادقانه: جبهه‌ها «مرز احتمالی» ‌اند؛ آستانه‌ها تجربی‌اند. لایه‌های ابر همرفتی «شاخص مساعدت» ‌اند نه پیش‌بینی ابر. */
const SYN={model:"ecmwf", M:{}, run:null, step:0, idx:0, cache:{}, P:null, G:null, F:{}, SEG:{}, fr:null, frKey:"", probe:null, prof:null, view:null, col:{}, busy:false,
  st:Object.assign({shade:{lay:"vo",lev:850}, shade2:{lay:"",lev:850,a:0.5}, lines:[{lay:"gh",lev:850}], wind:false, windLev:850, fr:false, frLev:850, thr:4, reg:"me", bnd:{coast:1,ctry:1,prov:1,cnty:0}, sk:false, parcel:"SB"},(function(){ try{ return store.get("syn.st2",{})||{}; }catch(e){ return {}; } })())};
const SYN_R=6371000, SYN_RD=287.04, SYN_CP=1005.7, SYN_LV=2.501e6, SYN_EPS=0.622;
const SYN_REG={me:[20,65,12,42,"خاورمیانه","Middle East"],ir:[43,64,24,40.5,"ایران","Iran"],eu:[10,70,15,62,"اروپا (شرقی)–آسیای غربی","E. Europe–W. Asia"],all:[10,90,5,65,"کل شبکه","Whole grid"]};
const SYN_EXT=[10,90,5,65];
const synEn=()=>typeof LANG!=="undefined"&&LANG==="en";
/* ---------- رمزگشایی ---------- */
async function synInflate(buf){ const ds=new DecompressionStream("deflate"); const s=new Blob([buf]).stream().pipeThrough(ds); return new Uint8Array(await new Response(s).arrayBuffer()); }
async function synDecode(ab){
  const u=new Uint8Array(ab); if(String.fromCharCode(u[0],u[1],u[2],u[3])!=="MSG1") throw new Error("magic"); const n=new DataView(ab).getUint32(4,true);
  const hd=JSON.parse(new TextDecoder().decode(u.subarray(8,8+n))); const raw=await synInflate(u.subarray(8+n)); const a=new Int16Array(raw.buffer,raw.byteOffset,raw.byteLength>>1);
  return {hd,a};
}
function synField(P,v,lev){ const {hd,a}=P, vi=hd.vars.indexOf(v), li=hd.levels.indexOf(lev); if(vi<0||li<0) return null; const N=hd.nlat*hd.nlon, o=(vi*hd.levels.length+li)*N, q=hd.q[v], out=new Float32Array(N); let ok=0;
  for(let i=0;i<N;i++){ const z=a[o+i]; if(z===hd.missing) out[i]=NaN; else { out[i]=z/q.sc+q.off; ok++; } } return ok?out:null; }
const synSfc=(P,k)=>synField(P,k,1000);
function synMaskBelow(f,sp,lev){ if(!f||!sp) return f; const o=Float32Array.from(f); for(let i=0;i<o.length;i++) if(sp[i]<lev) o[i]=NaN; return o; }
/* ---------- مشتق‌ها (کروی؛ lat کاهشی) ---------- */
function synGrid(hd){ const lat=[],lon=[]; for(let j=0;j<hd.nlat;j++) lat.push(hd.lat0+j*hd.dlat); for(let i=0;i<hd.nlon;i++) lon.push(hd.lon0+i*hd.dlon); return {nj:hd.nlat,ni:hd.nlon,lat,lon,dlat:hd.dlat*Math.PI/180,dlon:hd.dlon*Math.PI/180,dl:hd.dlon,dt:hd.dlat}; }
function synDdx(f,G){ const {nj,ni}=G, o=new Float32Array(nj*ni); for(let j=0;j<nj;j++){ const c=SYN_R*Math.cos(G.lat[j]*Math.PI/180); for(let i=0;i<ni;i++){ const a=i>0?i-1:i, b=i<ni-1?i+1:i; o[j*ni+i]=(f[j*ni+b]-f[j*ni+a])/((b-a)*G.dlon*c); } } return o; }
function synDdy(f,G){ const {nj,ni}=G, o=new Float32Array(nj*ni); for(let j=0;j<nj;j++){ const a=j>0?j-1:j, b=j<nj-1?j+1:j; for(let i=0;i<ni;i++) o[j*ni+i]=(f[b*ni+i]-f[a*ni+i])/((b-a)*G.dlat*SYN_R); } return o; }
const synMap2=(f,g,fn)=>{ const o=new Float32Array(f.length); for(let i=0;i<o.length;i++) o[i]=fn(f[i],g[i],i); return o; };
function synVort(u,v,G){ const vx=synDdx(v,G), uy=synDdy(u,G), {ni}=G; return synMap2(vx,uy,(a,b,k)=>a-b+u[k]*Math.tan(G.lat[(k/ni)|0]*Math.PI/180)/SYN_R); }
function synDiv(u,v,G){ const ux=synDdx(u,G), vy=synDdy(v,G), {ni}=G; return synMap2(ux,vy,(a,b,k)=>a+b-v[k]*Math.tan(G.lat[(k/ni)|0]*Math.PI/180)/SYN_R); }
function synAdv(f,u,v,G){ const fx=synDdx(f,G), fy=synDdy(f,G), o=new Float32Array(f.length); for(let k=0;k<o.length;k++) o[k]=-(u[k]*fx[k]+v[k]*fy[k]); return o; }
function synSmooth(f,G,n){ const {nj,ni}=G; let a=Float32Array.from(f); for(let t=0;t<n;t++){ const b=Float32Array.from(a); for(let j=1;j<nj-1;j++) for(let i=1;i<ni-1;i++){ const k=j*ni+i; const s=a[k-1]+a[k+1]+a[k-ni]+a[k+ni]; b[k]=(s===s&&a[k]===a[k])?0.5*a[k]+0.125*s:a[k]; } a=b; } return a; }
/* ---------- ترمودینامیک ---------- */
const synEs=T=>{ const c=T-273.15; return 6.112*Math.exp(17.67*c/(c+243.5)); };
const synRs=(T,p)=>{ const e=synEs(T); return SYN_EPS*e/Math.max(p-e,1e-3); };
function synTd(T,rh){ const c=T-273.15, g=Math.log(Math.max(rh,0.01)/100)+17.67*c/(c+243.5); return 243.5*g/(17.67-g)+273.15; }
function synTw(T,rh,p){ const e=synEs(T)*rh/100, r=SYN_EPS*e/Math.max(p-e,1e-3); let lo=Math.min(synTd(T,rh)-1,T), hi=T; for(let n=0;n<28;n++){ const m=0.5*(lo+hi), f=SYN_CP*(T-m)-SYN_LV*(synRs(m,p)-r); if(f<0) hi=m; else lo=m; } return 0.5*(lo+hi); }
function synThE(T,rh,p){ const Td=synTd(T,rh), e=synEs(T)*rh/100, r=SYN_EPS*e/Math.max(p-e,1e-3), TL=1/(1/(Td-56)+Math.log(T/Td)/800)+56; return T*Math.pow(1000/(p-e),0.2854)*Math.exp((3.376/TL-0.00254)*(r*1000)*(1+0.81*r)); }
const synTheta=(T,p)=>T*Math.pow(1000/p,SYN_RD/SYN_CP);
/* ---------- رنگ‌بندی گسسته ---------- */
function synPal(stops,n){ const hx=h=>[1,3,5].map(i=>parseInt(h.slice(i,i+2),16)); const S=stops.map(hx), out=[]; for(let k=0;k<n;k++){ const t=n>1?k/(n-1)*(S.length-1):0, i=Math.min(S.length-2,Math.floor(t)), f=t-i; out.push(S[i].map((c,q)=>Math.round(c+(S[i+1][q]-c)*f))); } return out; }  /* رنگِ هر رده ثابت است؛ نقشه میان‌رنگ ندارد */
const SYN_DIV=["#1d4ed8","#60a5fa","#e5e7eb","#fdba74","#dc2626"], SYN_SEQ=["#312e81","#2563eb","#22c55e","#facc15","#ea580c","#7f1d1d"], SYN_SEQ2=["#f8fafc","#bae6fd","#38bdf8","#16a34a","#facc15","#dc2626","#7e22ce"];
const synSym=br=>br.slice().reverse().map(x=>-x).concat(br);
const synRange=(a,b,s)=>{ const o=[]; for(let v=a;v<=b+1e-9;v+=s) o.push(+v.toFixed(6)); return o; };
const SYN_ALLP=[925,850,700,500,300,200];
const SYN_LAY={
  gh:{fa:"ارتفاع ژئوپتانسیل",en:"Geopotential height",u:"dam",lev:[925,850,700,600,500,400,300,250,200],br:[],stops:SYN_SEQ,lineOnly:1,ls:l=>l>=700?3:(l>=500?6:12),fn:(P,G,l,B)=>B.z&&B.z.map(x=>x/10)},
  vo:{fa:"تاوایی نسبی",en:"Relative vorticity",u:"×10⁻⁵ s⁻¹",lev:SYN_ALLP,br:synSym([1,2,4,6,8,10,15,20,30,50]),stops:SYN_DIV,ls:()=>5,fn:(P,G,l,B)=>B.u&&B.v&&synVort(B.u,B.v,G).map(x=>x*1e5),note:"مثبت = چرخش پادساعتگرد (سیکلونی)"},
  dv:{fa:"واگرایی",en:"Divergence",u:"×10⁻⁵ s⁻¹",lev:SYN_ALLP,br:synSym([1,2,3,5,7,10,15,20]),stops:["#7c2d12","#fb923c","#f3f4f6","#86efac","#14532d"].reverse(),ls:()=>5,fn:(P,G,l,B)=>B.u&&B.v&&synDiv(B.u,B.v,G).map(x=>x*1e5),note:"مثبت = واگرایی؛ منفی = همگرایی"},
  ta:{fa:"فرارفت دما",en:"Temperature advection",u:"K/h",lev:[925,850,700,500],br:synSym([0.1,0.25,0.5,1,1.5,2,3]),stops:SYN_DIV,ls:()=>1,fn:(P,G,l,B)=>B.t&&B.u&&B.v&&synAdv(synSmooth(B.t,G,1),B.u,B.v,G).map(x=>x*3600),note:"مثبت = فرارفت گرم؛ منفی = فرارفت سرد"},
  tw:{fa:"دمای تر",en:"Wet-bulb temperature",u:"°C",lev:[925,850,700],br:synRange(-30,30,3),stops:SYN_SEQ,ls:()=>2,fn:(P,G,l,B)=>B.t&&B.r&&synMap2(B.t,B.r,(T,r)=>synTw(T,r,l)-273.15)},
  te:{fa:"دمای پتانسیل هم‌ارز (θe)",en:"Equivalent potential temp.",u:"K",lev:[925,850,700],br:synRange(250,360,5),stops:SYN_SEQ,ls:()=>5,fn:(P,G,l,B)=>B.t&&B.r&&synMap2(B.t,B.r,(T,r)=>synThE(T,r,l))},
  t:{fa:"دما",en:"Temperature",u:"°C",lev:SYN_ALLP,br:synRange(-70,45,5),stops:SYN_SEQ,ls:l=>l>=700?4:5,fn:(P,G,l,B)=>B.t&&B.t.map(x=>x-273.15)},
  rh:{fa:"رطوبت نسبی",en:"Relative humidity",u:"%",lev:[925,850,700,500,300],br:[10,20,30,40,50,60,70,80,90,100],stops:["#92400e","#fde68a","#bbf7d0","#2563eb"],ls:()=>20,fn:(P,G,l,B)=>B.r},
  ws:{fa:"تندی باد",en:"Wind speed",u:"m/s",lev:[925,850,700,500,300,250,200],br:synRange(5,60,5),stops:["#e0f2fe","#38bdf8","#16a34a","#facc15","#dc2626","#7e22ce"],ls:()=>10,fn:(P,G,l,B)=>B.u&&B.v&&synMap2(B.u,B.v,(a,b)=>Math.hypot(a,b))},
  w:{fa:"حرکت قائم (ω)",en:"Vertical motion (omega)",u:"hPa/h",lev:[850,700,500,300],br:synSym([1,3,6,10,20,40]),stops:["#7c2d12","#fdba74","#f3f4f6","#93c5fd","#1d4ed8"].reverse(),ls:()=>10,fn:(P,G,l,B)=>B.w&&B.w.map(x=>x*36),note:"منفی = صعود؛ مثبت = نزول (ω بر حسب hPa/h)"},
  th:{fa:"ضخامت ۱۰۰۰–۵۰۰ هکتوپاسکال",en:"1000–500 hPa thickness",u:"dam",lev:[0],br:synRange(480,590,6),stops:SYN_SEQ,ls:()=>6,fn:(P,G,l,B)=>{ const a=synField(P,"gh",500), b=synField(P,"gh",1000); return a&&b&&synMap2(a,b,(x,y)=>(x-y)/10); },note:"خط ۵۴۰ دکامتر مرز تقریبی باران/برف"},
  msl:{fa:"فشار تراز دریا (MSLP)",en:"Mean sea-level pressure",u:"hPa",lev:[0],br:synRange(980,1048,4),stops:["#4c1d95","#2563eb","#e5e7eb","#fb923c","#b91c1c"],ls:()=>4,fn:(P)=>synSfc(P,"msl")},
  t2:{fa:"دمای ۲ متری",en:"2 m temperature",u:"°C",lev:[0],br:synRange(-30,50,4),stops:SYN_SEQ,ls:()=>4,fn:(P)=>{ const a=synSfc(P,"t2"); return a&&a.map(x=>x-273.15); }},
  ws10:{fa:"تندی باد ۱۰ متری",en:"10 m wind speed",u:"m/s",lev:[0],br:synRange(2,30,2),stops:["#e0f2fe","#38bdf8","#16a34a","#facc15","#dc2626","#7e22ce"],ls:()=>4,fn:(P)=>{ const u=synSfc(P,"u10"),v=synSfc(P,"v10"); return u&&v&&synMap2(u,v,(a,b)=>Math.hypot(a,b)); }},
  pw:{fa:"آب قابل بارش (PW)",en:"Precipitable water",u:"mm",lev:[0],br:synRange(5,60,5),stops:SYN_SEQ2,ls:()=>10,note:"انتگرال q روی ترازهای بالای سطح زمین؛ تقریبی",fn:(P,G)=>{ const sp=synSfc(P,"sp"), L=[1000,925,850,700,600,500,400,300,250,200], q=L.map(l=>synMaskBelow(synField(P,"q",l),sp,l)); if(!q[2]) return null; const N=G.nj*G.ni, o=new Float32Array(N);
      for(let k=0;k<N;k++){ let s=0,n=0; for(let i=0;i<L.length-1;i++){ const a=q[i]&&q[i][k], b=q[i+1]&&q[i+1][k]; if(a===a&&b===b&&a!=null&&b!=null){ s+=0.5*(a+b)*(L[i]-L[i+1])*100/9.80665; n++; } } o[k]=n?s:NaN; } return o; }},
  mfc:{fa:"همگرایی شار رطوبت ۸۵۰",en:"850 moisture-flux convergence",u:"g/kg/h",lev:[0],br:synSym([0.25,0.5,1,2,3,5]),stops:["#7c2d12","#fdba74","#f3f4f6","#86efac","#14532d"].reverse(),ls:()=>1,note:"مثبت = همگرایی رطوبت (−∇·qV)",fn:(P,G)=>{ const B=synBase(P,850); if(!(B.u&&B.v&&B.q)) return null; const qu=synMap2(B.q,B.u,(a,b)=>a*b), qv=synMap2(B.q,B.v,(a,b)=>a*b); return synMap2(synDdx(qu,G),synDdy(qv,G),(a,b)=>-(a+b)*1e3*3600); }},
  ki:{fa:"شاخص K",en:"K index",u:"",lev:[0],br:synRange(10,45,5),stops:SYN_SEQ2,ls:()=>5,fn:(P,G)=>{ const a=synBase(P,850),b=synBase(P,700),c=synBase(P,500); if(!(a.t&&a.r&&b.t&&b.r&&c.t)) return null; const N=a.t.length,o=new Float32Array(N); for(let k=0;k<N;k++){ const td8=synTd(a.t[k],a.r[k]), td7=synTd(b.t[k],b.r[k]); o[k]=(a.t[k]-c.t[k])+(td8-273.15)-((b.t[k]-273.15)-(td7-273.15)); } return o; }},
  tt:{fa:"Total Totals",en:"Total Totals",u:"",lev:[0],br:synRange(30,60,3),stops:SYN_SEQ2,ls:()=>3,fn:(P,G)=>{ const a=synBase(P,850),c=synBase(P,500); if(!(a.t&&a.r&&c.t)) return null; return synMap2(a.t,c.t,(t8,t5,k)=>(t8-t5)+(synTd(t8,a.r[k])-t5)); }},
  dte:{fa:"ناپایداری همرفتی (θe۵۰۰ − θe۸۵۰)",en:"Convective instability (θe500−θe850)",u:"K",lev:[0],br:synRange(-24,12,4),stops:["#7f1d1d","#ea580c","#facc15","#e5e7eb","#2563eb"],ls:()=>4,note:"منفی = ناپایداری پتانسیلی (θe با ارتفاع کم می‌شود)",fn:(P,G)=>{ const a=synBase(P,850),c=synBase(P,500); if(!(a.t&&a.r&&c.t&&c.r)) return null; return synMap2(synMap2(c.t,c.r,(T,r)=>synThE(T,r,500)),synMap2(a.t,a.r,(T,r)=>synThE(T,r,850)),(x,y)=>x-y); }},
  lr:{fa:"آهنگ کاهش دما ۷۰۰–۵۰۰",en:"700–500 lapse rate",u:"K/km",lev:[0],br:synRange(4,9,0.5),stops:SYN_SEQ2,ls:()=>0.5,fn:(P,G)=>{ const a=synBase(P,700),c=synBase(P,500); if(!(a.t&&c.t&&a.z&&c.z)) return null; return synMap2(a.t,c.t,(t7,t5,k)=>(t7-t5)/Math.max(c.z[k]-a.z[k],1)*1000); }},
  shr:{fa:"برش باد (۱۰ متر تا ۵۰۰ هکتوپاسکال)",en:"Bulk shear (10 m–500 hPa)",u:"m/s",lev:[0],br:synRange(5,40,5),stops:SYN_SEQ2,ls:()=>10,fn:(P,G)=>{ const c=synBase(P,500),u=synSfc(P,"u10"),v=synSfc(P,"v10"); if(!(c.u&&c.v&&u&&v)) return null; return synMap2(c.u,c.v,(a,b,k)=>Math.hypot(a-u[k],b-v[k])); }},
  gtw:{fa:"گرادیان θw (۸۵۰)",en:"θw gradient (850)",u:"K/100km",lev:[0],br:[1,2,3,4,5,6,8,10,12,15],stops:SYN_SEQ2,ls:()=>2,note:"پشتیبان جبهه‌یابی؛ مقدار بزرگ = پهنهٔ جبهه‌ای",fn:(P,G)=>{ const th=synThetaW(P,G,850,2); if(!th) return null; const tx=synDdx(th,G),ty=synDdy(th,G); return synMap2(tx,ty,(a,b)=>Math.hypot(a,b)*1e5); }},
  cape:{fa:"CAPE (پارسل سطحی)",en:"CAPE (surface parcel)",u:"J/kg",lev:[0],br:[50,100,250,500,1000,1500,2000,3000,4000],stops:SYN_SEQ2,ls:()=>500,col:"cape",note:"از ستون ۱۰ ترازی با هستهٔ MET؛ ترازهای شبکه درشت‌اند و CAPE کم‌برآورد است"},
  cin:{fa:"CIN (پارسل سطحی)",en:"CIN (surface parcel)",u:"J/kg",lev:[0],br:[-300,-200,-100,-50,-25,-10],stops:["#7f1d1d","#ea580c","#facc15","#e5e7eb"],ls:()=>50,col:"cin"},
  li:{fa:"شاخص بالابری (LI)",en:"Lifted index",u:"K",lev:[0],br:synRange(-10,6,2),stops:["#7f1d1d","#ea580c","#facc15","#e5e7eb","#2563eb"],ls:()=>2,col:"li"},
  cc:{fa:"شاخص مساعدت ابر همرفتی (تجربی)",en:"Convective-cloud favourability (experimental)",u:"۰ تا ۵",lev:[0],br:[1,2,3,4,5],stops:["#e5e7eb","#bae6fd","#38bdf8","#facc15","#dc2626","#7e22ce"],ls:()=>1,note:"جمع ۵ معیار: ناپایداری θe، K≥۲۶، RH700≥۶۰٪، همگرایی رطوبت ۸۵۰>۰٫۵، صعود ω۷۰۰<−۳؛ شاخص ساده است، نه پیش‌بینی ابر",
    fn:(P,G)=>{ const a=SYN_LAY.dte.fn(P,G), k=SYN_LAY.ki.fn(P,G), m=SYN_LAY.mfc.fn(P,G), r=synBase(P,700), w=synBase(P,700).w; if(!(a||k||r.r)) return null; const N=G.nj*G.ni, o=new Float32Array(N); for(let i=0;i<N;i++){ let s=0,n=0; if(a&&a[i]===a[i]){ n++; if(a[i]<-4) s++; } if(k&&k[i]===k[i]){ n++; if(k[i]>=26) s++; } if(r.r&&r.r[i]===r.r[i]){ n++; if(r.r[i]>=60) s++; } if(m&&m[i]===m[i]){ n++; if(m[i]>0.5) s++; } if(w&&w[i]===w[i]){ n++; if(w[i]*36<-3) s++; } o[i]=n>=3?s:NaN; } return o; }}
};
const synLabOf=(k)=>{ const L=SYN_LAY[k]; return synEn()?L.en:L.fa; };
const synLev0=l=>(l&&l>0)?l:0;
/* ---------- میدان یک لایه ---------- */
function synBase(P,lev){ const sp=synSfc(P,"sp"), g=n=>synMaskBelow(synField(P,n,lev),sp,lev); return {t:g("t"),r:g("r"),u:g("u"),v:g("v"),z:g("gh"),q:g("q"),w:g("w"),sp}; }
function synThetaW(P,G,lev,sm){ const B=synBase(P,lev); if(!(B.t&&B.r)) return null; const tw=synMap2(B.t,B.r,(t,r)=>synTw(t,r,lev)); return synSmooth(synMap2(tw,tw,x=>synTheta(x,lev)),G,sm||2); }
function synCols(){ /* CAPE/CIN/LI ستونی؛ یک‌بار برای هر گام و در تکه‌های کوچک */
  const key=SYN.model+"|"+SYN.step; if(SYN.col[key]) return SYN.col[key]; const M=globalThis.MET; if(!M||!M.parcel) return null; const P=SYN.P, G=SYN.G, N=G.nj*G.ni;
  const L=[1000,925,850,700,600,500,400,300,250,200], A={}; for(const v of ["gh","t","r","u","v"]) A[v]=L.map(l=>synField(P,v,l)); const sp=synSfc(P,"sp"), t2=synSfc(P,"t2"), d2=synSfc(P,"d2"), u10=synSfc(P,"u10"), v10=synSfc(P,"v10");
  const R={cape:new Float32Array(N).fill(NaN),cin:new Float32Array(N).fill(NaN),li:new Float32Array(N).fill(NaN),done:0,N}; SYN.col[key]=R; let k0=0;
  const step=()=>{ const t0=performance.now(); while(k0<N&&performance.now()-t0<14){ const k=k0++; if(!sp||!(sp[k]>300)||!t2||!(t2[k]>200)){ continue; } const raw={p:[sp[k]],T:[t2[k]-273.15],Td:[Math.min(d2[k],t2[k])-273.15],z:[NaN],u:[u10?u10[k]:NaN],v:[v10?v10[k]:NaN]};
      for(let i=0;i<L.length;i++){ if(L[i]>=sp[k]-2) continue; const t=A.t[i]&&A.t[i][k], r=A.r[i]&&A.r[i][k]; if(!(t===t&&r===r)) continue; raw.p.push(L[i]); raw.T.push(t-273.15); raw.Td.push(synTd(t,r)-273.15); raw.z.push(A.gh[i]?A.gh[i][k]:NaN); raw.u.push(A.u[i]?A.u[i][k]:NaN); raw.v.push(A.v[i]?A.v[i][k]:NaN); }
      try{ const cl=M.profile.clean(raw); if(!cl.ok) continue; const pr=cl.prof, c=M.parcel.sbCapeCin(pr); if(c&&c.v!=null){ R.cape[k]=c.v; R.cin[k]=c.cin!=null?-Math.abs(c.cin):0; } else { R.cape[k]=0; R.cin[k]=0; } const li=M.indices.liftedIndex(pr); if(li&&li.v!=null) R.li[k]=li.v; }catch(e){} }
    R.done=k0; synRender(); if(k0<N) setTimeout(step,0); else { SYN.F={}; synRender(); synMsg(""); } synMsg(k0<N?(synEn()?"Computing CAPE… ":"محاسبهٔ CAPE… ")+Math.round(100*k0/N)+"٪":""); };
  setTimeout(step,0); return R; }
function synCompute(lay,lev){ const L=SYN_LAY[lay], P=SYN.P, G=SYN.G; if(L.col){ const R=synCols(); return R?R[L.col]:null; } const B=L.lev[0]?synBase(P,lev):{}; try{ return L.fn(P,G,lev,B)||null; }catch(e){ console.warn("synCompute",lay,e); return null; } }
function synGet(lay,lev){ const L=SYN_LAY[lay]; if(!L) return null; const lv=L.lev[0]?(L.lev.includes(lev)?lev:L.lev[0]):0, key=SYN.model+"|"+SYN.step+"|"+lay+"|"+lv; if(SYN.F[key]!==undefined) return SYN.F[key]; const f=synCompute(lay,lv); if(!L.col||SYN.col[SYN.model+"|"+SYN.step]&&SYN.col[SYN.model+"|"+SYN.step].done>=SYN.col[SYN.model+"|"+SYN.step].N) SYN.F[key]=f; else return f; const ks=Object.keys(SYN.F); if(ks.length>40) delete SYN.F[ks[0]]; return f; }
/* ---------- خط همتراز و جبهه ---------- */
function synSegs(f,G,thr){ const {nj,ni}=G, S=[];
  for(let j=0;j<nj-1;j++) for(let i=0;i<ni-1;i++){ const a=f[j*ni+i],b=f[j*ni+i+1],c=f[(j+1)*ni+i+1],d=f[(j+1)*ni+i]; if(!(a===a&&b===b&&c===c&&d===d)) continue;
    const pts=[]; const ed=(p,q,x1,y1,x2,y2)=>{ if((p<thr)!==(q<thr)){ const t=(thr-p)/(q-p); pts.push([x1+(x2-x1)*t,y1+(y2-y1)*t]); } };
    const x0=G.lon[i],x1=G.lon[i+1],y0=G.lat[j],y1=G.lat[j+1]; ed(a,b,x0,y0,x1,y0); ed(b,c,x1,y0,x1,y1); ed(d,c,x0,y1,x1,y1); ed(a,d,x0,y0,x0,y1);
    if(pts.length===2) S.push([pts[0],pts[1]]); else if(pts.length===4){ S.push([pts[0],pts[1]]); S.push([pts[2],pts[3]]); } }
  return S; }
function synChain(S){ const key=p=>p[0].toFixed(4)+","+p[1].toFixed(4), ends=new Map(); S.forEach((s,k)=>{ for(const e of [0,1]){ const kk=key(s[e]); if(!ends.has(kk)) ends.set(kk,[]); ends.get(kk).push([k,e]); } });
  const used=new Uint8Array(S.length), out=[];
  for(let k=0;k<S.length;k++){ if(used[k]) continue; used[k]=1; let line=[S[k][0],S[k][1]];
    for(const dir of [1,0]){ let guard=0; for(;;){ if(++guard>6000) break; const tip=dir?line[line.length-1]:line[0], cand=(ends.get(key(tip))||[]).find(([q])=>!used[q]); if(!cand) break; used[cand[0]]=1; const s=S[cand[0]], nx=cand[1]===0?s[1]:s[0]; if(dir) line.push(nx); else line.unshift(nx); } }
    out.push(line); }
  return out; }
function synChaikin(l,n){ let a=l; for(let t=0;t<n;t++){ if(a.length<3) break; const b=[a[0]]; for(let i=0;i<a.length-1;i++){ const p=a[i],q=a[i+1]; b.push([0.75*p[0]+0.25*q[0],0.75*p[1]+0.25*q[1]],[0.25*p[0]+0.75*q[0],0.25*p[1]+0.75*q[1]]); } b.push(a[a.length-1]); a=b; } return a; }
function synContours(f,G,key,v){ const k=key+"|"+v; if(SYN.SEG[k]) return SYN.SEG[k]; const r=synChain(synSegs(f,G,v)); const ks=Object.keys(SYN.SEG); if(ks.length>1500) SYN.SEG={}; return SYN.SEG[k]=r; }
/* جبهه (Renard–Clarke/Hewson): صفر TFP روی θw، فقط بیشینهٔ گرادیان و |∇θw| بیش از آستانه؛ زنجیرهٔ بلند؛ نوع از V·∇θw؛ نرم‌سازی منحنی */
function synFronts(P,G,lev,thrK100){
  const T0=synBase(P,lev); if(!(T0.t&&T0.r&&T0.u&&T0.v)) return null; const th=synThetaW(P,G,lev,3), tx=synDdx(th,G), ty=synDdy(th,G), g=synMap2(tx,ty,(a,b)=>Math.hypot(a,b));
  const gs=synSmooth(g,G,1), gx=synDdx(gs,G), gy=synDdy(gs,G), N=th.length, tfp=new Float32Array(N); for(let k=0;k<N;k++) tfp[k]=-(gx[k]*tx[k]+gy[k]*ty[k])/Math.max(g[k],1e-12);
  const tfx=synDdx(tfp,G), tfy=synDdy(tfp,G), thr=thrK100/1e5, {ni}=G, U=T0.u, V=T0.v;
  const at=(F,x,y)=>{ const fi=(x-G.lon[0])/G.dl, fj=(y-G.lat[0])/G.dt, i=Math.max(0,Math.min(G.ni-2,Math.floor(fi))), j=Math.max(0,Math.min(G.nj-2,Math.floor(fj))), a=fi-i, b=fj-j; return F[j*ni+i]*(1-a)*(1-b)+F[j*ni+i+1]*a*(1-b)+F[(j+1)*ni+i]*(1-a)*b+F[(j+1)*ni+i+1]*a*b; };
  const keep=[]; for(const s of synSegs(tfp,G,0)){ const mx=(s[0][0]+s[1][0])/2, my=(s[0][1]+s[1][1])/2, gg=at(g,mx,my); if(!(gg>=thr)) continue; const gxx=at(tx,mx,my), gyy=at(ty,mx,my), n=Math.max(gg,1e-12); if(!((at(tfx,mx,my)*gxx+at(tfy,mx,my)*gyy)/n>0)) continue; keep.push(s); }
  const res=[]; for(const ch of synChain(keep)){ if(ch.length<7) continue;
    const vn=ch.map(p=>{ const gg=Math.max(at(g,p[0],p[1]),1e-12); return (at(U,p[0],p[1])*at(tx,p[0],p[1])+at(V,p[0],p[1])*at(ty,p[0],p[1]))/gg; });
    /* تقسیم به دنباله‌های هم‌نوع (با میانگین‌گیری کشویی)؛ دنبالهٔ کوتاه‌تر از ۴ نقطه به همسایه می‌پیوندد */
    const sm=vn.map((_,i)=>{ let s=0,n=0; for(let q=Math.max(0,i-2);q<=Math.min(vn.length-1,i+2);q++){ s+=vn[q]; n++; } return s/n; }), ty_=sm.map(m=>m>1.5?"cold":(m<-1.5?"warm":"stat"));
    let st=0; for(let i=1;i<=ch.length;i++){ if(i===ch.length||ty_[i]!==ty_[st]){ if(i-st>=4||i===ch.length&&st===0){ const seg=ch.slice(Math.max(0,st-1),Math.min(ch.length,i+1)); res.push({pts:synChaikin(seg,2),type:ty_[st],grad:at(g,seg[seg.length>>1][0],seg[seg.length>>1][1])*1e5,gx:seg.map(p=>[at(tx,p[0],p[1]),at(ty,p[0],p[1])])}); } st=i; } }
  }
  return res; }
/* ---------- بارگیری ---------- */
const synBaseUrl=m=>((typeof ON!=="undefined"&&ON.base?ON.base:"online/"))+"data/grid/"+m+"/";
async function synFetchMan(m){ if(SYN.M[m]) return SYN.M[m]; const b=synBaseUrl(m), l=await fetch(b+"latest.json?"+(Date.now()/6e5|0)); if(!l.ok) throw new Error(m+" latest "+l.status); const lj=await l.json(); const r=await fetch(b+lj.run+"/manifest.json?"+(Date.now()/6e5|0)); if(!r.ok) throw new Error(m+" manifest "+r.status); const man=await r.json(); man.base=b+lj.run+"/"; return SYN.M[m]=man; }
async function synLoadStep(i){
  const man=SYN.M[SYN.model], e=man.steps[i]; if(!e) return; const key=SYN.model+"|"+e.f; let P=SYN.cache[key];
  if(!P){ const r=await fetch(man.base+e.f); if(!r.ok) throw new Error(e.f+" "+r.status); P=await synDecode(await r.arrayBuffer()); const ks=Object.keys(SYN.cache); if(ks.length>5) delete SYN.cache[ks[0]]; SYN.cache[key]=P; }
  SYN.P=P; SYN.step=e.step; SYN.idx=i; SYN.G=synGrid(P.hd); SYN.F={}; SYN.fr=null; if(SYN.probe) synProbeUpdate(); }
const synIran=s=>{ try{ return new Date(s).toLocaleString(synEn()?"en-GB":"fa-IR",{timeZone:"Asia/Tehran",weekday:"short",month:"numeric",day:"numeric",hour:"2-digit",minute:"2-digit"}); }catch(e){ return s; } };
/* ---------- نمایش ---------- */
const SYN_LC=["#b91c1c","#1d4ed8","#15803d","#a16207","#7e22ce","#0e7490","#be185d","#374151"];
const synNice=(s)=>{ const p=Math.pow(10,Math.floor(Math.log10(s))), f=s/p; return (f<1.5?1:f<3.5?2:f<7.5?5:10)*p; };
function synValAt(f,lon,lat){ const G=SYN.G; if(!f||!G) return NaN; const fi=(lon-G.lon[0])/G.dl, fj=(lat-G.lat[0])/G.dt; if(fi<0||fj<0||fi>G.ni-1||fj>G.nj-1) return NaN; const i=Math.min(G.ni-2,fi|0), j=Math.min(G.nj-2,fj|0), a=fi-i, b=fj-j, k=j*G.ni+i; return f[k]*(1-a)*(1-b)+f[k+1]*a*(1-b)+f[k+G.ni]*(1-a)*b+f[k+G.ni+1]*a*b; }
function synRaster(f,L,V,W,H){ const img=new ImageData(W,H), d=img.data, br=L.br, nbr=br.length, pal=synPal(L.stops,nbr+1), G=SYN.G, ni=G.ni, nj=G.nj, s=V.s;
  for(let py=0;py<H;py++){ const lat=V.la1-(py+0.5)/s, fj=(lat-G.lat[0])/G.dt; for(let px=0;px<W;px++){ const lon=V.lo0+(px+0.5)/s, fi=(lon-G.lon[0])/G.dl, o=(py*W+px)*4;
      if(fi<0||fj<0||fi>ni-1||fj>nj-1){ d[o+3]=0; continue; } const i=Math.min(ni-2,fi|0), j=Math.min(nj-2,fj|0), a=fi-i, b=fj-j, k=j*ni+i;
      const v=f[k]*(1-a)*(1-b)+f[k+1]*a*(1-b)+f[k+ni]*(1-a)*b+f[k+ni+1]*a*b; if(v!==v){ d[o]=d[o+1]=d[o+2]=226; d[o+3]=255; continue; }
      let c=0; while(c<nbr&&v>=br[c]) c++; const col=pal[c]; d[o]=col[0]; d[o+1]=col[1]; d[o+2]=col[2]; d[o+3]=255; } }
  return img; }
function synView(cv){ const st=SYN.st, R=SYN_REG[st.reg]||SYN_REG.me, W=cv.width, H=cv.height; if(!SYN.view){ const ppd=Math.min(W/(R[1]-R[0]),H/(R[3]-R[2])); SYN.view={cx:(R[0]+R[1])/2,cy:(R[2]+R[3])/2,ppd:ppd/(SYN.dpr||1)}; }
  const v=SYN.view, s=v.ppd*(SYN.dpr||1), lo0=v.cx-W/(2*s), la1=v.cy+H/(2*s); return {s,lo0,la1,lo1:lo0+W/s,la0:la1-H/s}; }
function synClampView(cv){ const v=SYN.view; if(!v) return; const s=v.ppd*(SYN.dpr||1), hw=cv.width/(2*s), hh=cv.height/(2*s); v.cx=Math.max(SYN_EXT[0]-hw*0.3,Math.min(SYN_EXT[1]+hw*0.3,v.cx)); v.cy=Math.max(SYN_EXT[2]-hh*0.3,Math.min(SYN_EXT[3]+hh*0.3,v.cy)); const minP=Math.min(cv.width/(SYN_EXT[1]-SYN_EXT[0]),cv.height/(SYN_EXT[3]-SYN_EXT[2]))/(SYN.dpr||1)*0.6; v.ppd=Math.max(minP,Math.min(v.ppd,600)); }
function synBasemap(x,V,st){
  x.save(); x.setTransform(V.s,0,0,-V.s,-V.lo0*V.s,V.la1*V.s); x.lineJoin="round"; x.lineCap="round"; const w=px=>px*(SYN.dpr||1)/V.s;
  try{ const NP=nvPaths(); let gb=false;
    if(st.bnd.cnty&&NP.cnty){ x.strokeStyle="rgba(70,70,70,.55)"; x.lineWidth=w(0.7); x.stroke(NP.cnty2||NP.cnty); }
    if(st.bnd.prov&&NP.ostanIn){ x.strokeStyle="rgba(40,40,40,.8)"; x.lineWidth=w(1.0); x.setLineDash([w(4),w(3)]); x.stroke(NP.ostanIn); x.setLineDash([]); }
    if(st.bnd.coast){ x.strokeStyle="#0b0b0b"; x.lineWidth=w(1.5); x.stroke(NP.coast2||NP.coast); try{ geoPrep(); if(GEO.paths&&GEO.paths.co) x.stroke(GEO.paths.co); }catch(e){} }
    if(st.bnd.ctry){ x.strokeStyle="#111"; x.lineWidth=w(1.7); try{ if(GEO.ok){ const P=geoPrep(); if(P.bd){ x.stroke(P.bd); gb=true; } } }catch(e){} if(!gb) x.stroke(NP.ctry2||NP.ctry); if(NP.outer) x.stroke(NP.outer); }
  }catch(e){ console.warn("synBasemap",e); }
  x.restore(); }
function synFmtV(L,v){ return L.br.length&&Math.abs(L.br[1]-L.br[0])<1?(+v.toFixed(2)).toString():(+v.toFixed(1)).toString(); }
function synLegend(x,L,pal,W,H,y0,title){ const n=pal.length, bw=Math.min(W-24,Math.max(30*n,300)), cw=bw/n, dp=SYN.dpr||1, fs=10.5*dp; x.fillStyle="rgba(255,255,255,.92)"; x.fillRect(8*dp,y0-50*dp,bw+12*dp,54*dp); x.fillStyle="#111"; x.font="600 "+fs+"px sans-serif"; x.textAlign="left"; x.fillText(title,14*dp,y0-38*dp); pal.forEach((c,i)=>{ x.fillStyle="rgb("+c.join(",")+")"; x.fillRect(14*dp+i*cw,y0-32*dp,cw,13*dp); });
  x.fillStyle="#111"; x.font=fs+"px sans-serif"; x.textAlign="center"; const every=n>14?2:1; L.br.forEach((b,i)=>{ if(i%every===0) x.fillText(synFmtV(L,b),14*dp+(i+1)*cw,y0-4*dp); }); x.textAlign="left"; }
function synLineLayer(x,V,W,H,ln){ const L=SYN_LAY[ln.lay], lev=L.lev[0]?(L.lev.includes(ln.lev)?ln.lev:L.lev[0]):0, f=synGet(ln.lay,lev); if(!f) return; const G=SYN.G, col=ln.col||SYN_LC[0], dp=SYN.dpr||1; let mn=Infinity,mx=-Infinity; for(let i=0;i<f.length;i++){ const q=f[i]; if(q===q){ if(q<mn) mn=q; if(q>mx) mx=q; } } if(!(mx>mn)) return;
  let step=ln.step||L.ls(lev); if((mx-mn)/step>60) step=synNice((mx-mn)/40); const v0=Math.ceil(mn/step)*step; const key=SYN.model+"|"+SYN.step+"|"+ln.lay+"|"+lev; const lbls=[], seen=new Set();
  x.save(); x.setTransform(V.s,0,0,-V.s,-V.lo0*V.s,V.la1*V.s); x.lineJoin="round"; x.strokeStyle=col;
  for(let v=v0,n=0;v<=mx&&n<90;v+=step,n++){ const vv=+v.toFixed(6); x.lineWidth=(Math.abs(vv%(step*4))<1e-6||L.key&&vv===L.key?2.2:1.3)*dp/V.s; for(const l of synContours(f,G,key,vv)){ if(l.length<3) continue; x.beginPath(); l.forEach((p,i)=>i?x.lineTo(p[0],p[1]):x.moveTo(p[0],p[1])); x.stroke(); if(l.length>=8){ const p=l[l.length>>1]; lbls.push([p[0],p[1],vv]); } } }
  x.restore(); x.font="700 "+(11*dp)+"px sans-serif"; x.textAlign="center"; for(const [lo,la,v] of lbls){ const px=(lo-V.lo0)*V.s, py=(V.la1-la)*V.s; if(px<30||py<20||px>W-30||py>H-20) continue; const kk=Math.round(px/(110*dp))+","+Math.round(py/(70*dp)); if(seen.has(kk)) continue; seen.add(kk); const t=synFmtV({br:[0,step]},v); x.fillStyle="rgba(255,255,255,.82)"; x.fillRect(px-13*dp,py-8*dp,26*dp,15*dp); x.fillStyle=col; x.fillText(t,px,py+4*dp); } }
function synFrontsDraw(x,V){ const st=SYN.st, k=SYN.model+"|"+SYN.step+"|"+st.frLev+"|"+st.thr; if(SYN.frKey!==k){ SYN.fr=synFronts(SYN.P,SYN.G,st.frLev,+st.thr); SYN.frKey=k; } const dp=SYN.dpr||1; if(!SYN.fr) return;
  for(const fr of SYN.fr){ const col=fr.type==="cold"?"#1d4ed8":(fr.type==="warm"?"#dc2626":"#7e22ce"); const P=fr.pts.map(p=>[(p[0]-V.lo0)*V.s,(V.la1-p[1])*V.s]);
    x.lineJoin="round"; x.lineCap="round"; x.strokeStyle="rgba(255,255,255,.9)"; x.lineWidth=6*dp; x.setLineDash([]); x.beginPath(); P.forEach((p,i)=>i?x.lineTo(p[0],p[1]):x.moveTo(p[0],p[1])); x.stroke();
    x.strokeStyle=col; x.fillStyle=col; x.lineWidth=3*dp; x.setLineDash(fr.type==="stat"?[10*dp,6*dp]:[]); x.beginPath(); P.forEach((p,i)=>i?x.lineTo(p[0],p[1]):x.moveTo(p[0],p[1])); x.stroke(); x.setLineDash([]);
    if(fr.type!=="stat"){ let acc=0; for(let i=1;i<P.length;i++){ const dx=P[i][0]-P[i-1][0], dy=P[i][1]-P[i-1][1], d=Math.hypot(dx,dy); if(!d) continue; acc+=d; if(acc<38*dp) continue; acc=0; const nx=-dy/d, ny=dx/d, g=fr.gx[Math.min(i,fr.gx.length-1)], wx=g[0], wy=-g[1];   /* سوی گرم = ∇θ (در دستگاه صفحه: y وارونه) */
        const sg=(nx*wx+ny*wy)>=0?1:-1, sd=fr.type==="cold"?sg:-sg, px=P[i][0], py=P[i][1], tx=dx/d, ty=dy/d, h=9*dp;
        if(fr.type==="cold"){ x.beginPath(); x.moveTo(px-tx*7*dp,py-ty*7*dp); x.lineTo(px+nx*sd*h,py+ny*sd*h); x.lineTo(px+tx*7*dp,py+ty*7*dp); x.closePath(); x.fill(); }
        else { const a0=Math.atan2(ny*sd,nx*sd); x.beginPath(); x.arc(px,py,6.5*dp,a0-Math.PI/2,a0+Math.PI/2,false); x.fill(); } } } } }
function synPaint(cvIn,exp){
  const cv=cvIn||SYN.cv; if(!cv||!SYN.P) return; const st=SYN.st, x=cv.getContext("2d"), W=cv.width, H=cv.height; const dpS=SYN.dpr; let V;
  if(exp){ const V0=SYN.V, cssW=SYN.cv.width/(dpS||1); SYN.dpr=W/cssW; V={s:W/(V0.lo1-V0.lo0),lo0:V0.lo0,la1:V0.la1,lo1:V0.lo1,la0:V0.la1-H/(W/(V0.lo1-V0.lo0))}; }
  else { synClampView(cv); V=synView(cv); SYN.V=V; }
  try{ synPaintBody(cv,x,W,H,V,st,!!exp); } finally { if(exp) SYN.dpr=dpS; } }
function synPaintBody(cv,x,W,H,V,st,exp){ const dp=SYN.dpr||1;
  x.setTransform(1,0,0,1,0,0); x.fillStyle="#fff"; x.fillRect(0,0,W,H);
  const A=SYN_LAY[st.shade.lay], levA=A&&A.lev[0]?(A.lev.includes(st.shade.lev)?st.shade.lev:A.lev[0]):0; let fa=A&&!A.lineOnly?synGet(st.shade.lay,levA):null;
  if(fa){ x.putImageData(synRaster(fa,A,V,W,H),0,0); }
  const B=st.shade2.lay&&SYN_LAY[st.shade2.lay]; if(B&&!B.lineOnly){ const lb=B.lev[0]?(B.lev.includes(st.shade2.lev)?st.shade2.lev:B.lev[0]):0, fb=synGet(st.shade2.lay,lb); if(fb){ const t=document.createElement("canvas"); t.width=W; t.height=H; t.getContext("2d").putImageData(synRaster(fb,B,V,W,H),0,0); x.globalAlpha=st.shade2.a; x.drawImage(t,0,0); x.globalAlpha=1; } }
  synBasemap(x,V,st);
  st.lines.forEach((ln,i)=>{ ln.col=ln.col||SYN_LC[i%SYN_LC.length]; synLineLayer(x,V,W,H,ln); });
  if(st.wind){ const lv=st.windLev, U=lv?synBase(SYN.P,lv):null; const u=lv===0?synSfc(SYN.P,"u10"):U.u, v=lv===0?synSfc(SYN.P,"v10"):U.v; if(u&&v){ x.strokeStyle="rgba(0,0,0,.8)"; x.lineWidth=1.3*dp; const sp=40*dp; for(let py=sp/2;py<H;py+=sp) for(let px=sp/2;px<W;px+=sp){ const lon=V.lo0+px/V.s, lat=V.la1-py/V.s, uu=synValAt(u,lon,lat), vv=synValAt(v,lon,lat); if(!(uu===uu&&vv===vv)) continue; const s=Math.hypot(uu,vv), len=Math.min(sp*0.8,(6+s*0.8)*dp), a=Math.atan2(-vv,uu), ex=px+Math.cos(a)*len, ey=py+Math.sin(a)*len;
        x.beginPath(); x.moveTo(px,py); x.lineTo(ex,ey); x.lineTo(ex-Math.cos(a-0.45)*6*dp,ey-Math.sin(a-0.45)*6*dp); x.moveTo(ex,ey); x.lineTo(ex-Math.cos(a+0.45)*6*dp,ey-Math.sin(a+0.45)*6*dp); x.stroke(); } } }
  if(st.fr) synFrontsDraw(x,V);
  if(SYN.probe&&!exp){ const px=(SYN.probe.lon-V.lo0)*V.s, py=(V.la1-SYN.probe.lat)*V.s; x.strokeStyle="#000"; x.fillStyle="#fff"; x.lineWidth=2.5*dp; x.beginPath(); x.arc(px,py,7*dp,0,6.3); x.fill(); x.stroke(); x.beginPath(); x.moveTo(px-12*dp,py); x.lineTo(px+12*dp,py); x.moveTo(px,py-12*dp); x.lineTo(px,py+12*dp); x.stroke(); }
  if(exp) return;
  /* عنوان و راهنما */
  const hd=SYN.P.hd, nm=hd.model==="gfs"?"GFS 0.25°":"ECMWF IFS", ttl=(A?synLabOf(st.shade.lay)+(levA?" "+levA+" hPa":""):"")+(B?" + "+synLabOf(st.shade2.lay):"");
  x.fillStyle="rgba(255,255,255,.88)"; x.fillRect(0,0,W,30*dp); x.fillStyle="#111"; x.font="700 "+(15*dp)+"px Vazirmatn,Tahoma,sans-serif"; x.textAlign="right"; x.direction="rtl"; x.fillText(ttl,W-10*dp,20*dp); x.direction="ltr"; x.textAlign="left"; x.font=(12*dp)+"px sans-serif"; x.fillText(nm+" · run "+hd.run+" · +"+hd.step+"h · valid "+(hd.valid||"").replace("T"," ").replace(":00Z"," UTC"),10*dp,19*dp);
  let ly=H-8*dp; if(A&&!A.lineOnly&&fa){ synLegend(x,A,synPal(A.stops,A.br.length+1),W,H,ly,A.u); ly-=58*dp; } if(B&&!B.lineOnly){ synLegend(x,B,synPal(B.stops,B.br.length+1),W,H,ly,synLabOf(st.shade2.lay)+" · "+B.u); }
  x.textAlign="right"; x.font=(11*dp)+"px sans-serif"; x.fillStyle="#333"; x.fillText("MetStat · wtafkik.ir",W-8*dp,H-8*dp); x.textAlign="left"; x.strokeStyle="#000"; x.lineWidth=2*dp; x.strokeRect(1,1,W-2,H-2);
  if(SYN.cur) synCursor();
}
function synRender(){ if(SYN.raf) return; SYN.raf=requestAnimationFrame(()=>{ SYN.raf=0; try{ synPaint(); }catch(e){ console.warn("synPaint",e); } }); }
function synMsg(t){ const e=document.getElementById("synMsg"); if(e) e.textContent=t||""; }
function synCursor(){ const e=document.getElementById("synCur"); if(!e||!SYN.cur) return; const {lon,lat}=SYN.cur, A=SYN_LAY[SYN.st.shade.lay], lv=A&&A.lev[0]?(A.lev.includes(SYN.st.shade.lev)?SYN.st.shade.lev:A.lev[0]):0, f=A&&!A.lineOnly?synGet(SYN.st.shade.lay,lv):null, v=f?synValAt(f,lon,lat):NaN; e.textContent=lat.toFixed(2)+"°N  "+lon.toFixed(2)+"°E"+(v===v?"  ·  "+synFmtV(A,v)+" "+A.u:""); }
/* ---------- اسکیوتی (با کلیک) ---------- */
function synProfileAt(lon,lat){ const P=SYN.P, G=SYN.G; if(!P) return null; const L=[1000,925,850,700,600,500,400,300,250,200], sp=synValAt(synSfc(P,"sp"),lon,lat), t2=synValAt(synSfc(P,"t2"),lon,lat), d2=synValAt(synSfc(P,"d2"),lon,lat), u10=synValAt(synSfc(P,"u10"),lon,lat), v10=synValAt(synSfc(P,"v10"),lon,lat);
  const raw={p:[],T:[],Td:[],z:[],u:[],v:[]}; let z0=NaN; if(sp===sp&&t2===t2&&d2===d2){ raw.p.push(sp); raw.T.push(t2-273.15); raw.Td.push(Math.min(d2,t2)-273.15); raw.z.push(NaN); raw.u.push(u10); raw.v.push(v10); }
  for(const l of L){ if(sp===sp&&l>=sp-2) continue; const t=synValAt(synField(P,"t",l),lon,lat), r=synValAt(synField(P,"r",l),lon,lat); if(!(t===t&&r===r)) continue; raw.p.push(l); raw.T.push(t-273.15); raw.Td.push(synTd(t,r)-273.15); raw.z.push(synValAt(synField(P,"gh",l),lon,lat)); raw.u.push(synValAt(synField(P,"u",l),lon,lat)); raw.v.push(synValAt(synField(P,"v",l),lon,lat)); }
  return raw; }
function synProbeUpdate(){ const pn=document.getElementById("synSk"); if(!pn||!SYN.probe||!SYN.st.sk){ if(pn) pn.hidden=true; return; } const M=globalThis.MET; if(!M||!M.lab){ pn.hidden=false; pn.textContent="MET not loaded"; return; }
  const raw=synProfileAt(SYN.probe.lon,SYN.probe.lat); if(!raw||raw.p.length<4){ pn.hidden=false; pn.innerHTML='<div class="labMsg bad">'+(synEn()?"No valid profile here (below ground / no data).":"در این نقطه پروفایل معتبر نیست (زیر سطح زمین یا بدون داده).")+"</div>"; return; }
  const res=M.lab.analyze(raw,{parcel:SYN.st.parcel}); if(!res.ok){ pn.hidden=false; pn.innerHTML='<div class="labMsg bad">'+(M.lab.ioWhyText?M.lab.ioWhyText(res.why,synEn()):res.why)+"</div>"; return; }
  SYN.prof=res; const en=synEn(), hd=SYN.P.hd, ttl=SYN.probe.lat.toFixed(2)+"°N "+SYN.probe.lon.toFixed(2)+"°E · "+(hd.model==="gfs"?"GFS":"ECMWF")+" +"+hd.step+"h · "+SYN.st.parcel;
  pn.hidden=false; pn.innerHTML='<div class="lab" dir="'+(en?"ltr":"rtl")+'"><section class="labOut"><div class="labBtns"><b>'+ttl+'</b><span>'+["SB","ML","MU"].map(k=>'<button type="button" data-par="'+k+'"'+(k===SYN.st.parcel?' class="on"':"")+">"+k+"</button>").join("")+'</span><button type="button" id="synAn1" class="labAnB">'+(en?"Scientific Skew-T analysis":"تحلیل علمی اسکیوتی")+'</button><button type="button" id="synAn2" class="labAnB">'+(en?"Full analysis":"تحلیل کامل")+'</button><button type="button" id="synSkClose">✕</button></div>'+
    '<div class="labGrid2"><div class="labPanel"><div id="synSkSvg"></div><div id="synSkInfo" class="labSub"></div></div><div class="labPanel labHodoP"><h4>'+(en?"Hodograph":"هودوگراف")+'</h4><div id="synHodo"></div></div></div><div id="synAn" class="labAn" hidden></div><div id="synCards"></div></section></div>';
  const sk=pn.querySelector("#synSkSvg"); try{ sk.innerHTML=M.skewt2.svg(res,{en:en,parcel:SYN.st.parcel,title:ttl}); M.skewt2.attach(sk,res,pn.querySelector("#synSkInfo")); }catch(e){ sk.textContent="skew-T: "+e.message; }
  try{ pn.querySelector("#synHodo").innerHTML=M.skewt.hodograph(res,{en:en})||""; }catch(e){}
  try{ pn.querySelector("#synCards").innerHTML=M.ui&&M.ui.cardsHtml?M.ui.cardsHtml(res):""; }catch(e){ console.warn(e); }
  pn.querySelectorAll("[data-par]").forEach(b=>b.onclick=()=>{ SYN.st.parcel=b.dataset.par; synSave(); synProbeUpdate(); });
  pn.querySelector("#synSkClose").onclick=()=>{ SYN.st.sk=false; synSave(); const c=document.getElementById("synSkOn"); if(c) c.checked=false; pn.hidden=true; synRender(); };
  const an=k=>{ const box=pn.querySelector("#synAn"); let a; try{ a=k==="lab"?M.analysis.lab(res,{en:en}):M.analysis.skewt(res,{en:en}); }catch(e){ box.hidden=false; box.textContent=e.message; return; } box.hidden=false; box.innerHTML=M.analysis.html(a,en); };
  pn.querySelector("#synAn1").onclick=()=>an("skewt"); pn.querySelector("#synAn2").onclick=()=>an("lab"); }
/* خروجی PNG هم‌سبک صفحهٔ اول: تیتر، زیرعنوان، کادر، راهنمای رنگ، لوگو و منبع */
function synExport(W){
  const P=SYN.P, st=SYN.st, hd=P.hd; if(!P||!SYN.V) return null; W=W||1800; const V0=SYN.V, asp=SYN.cv.height/SYN.cv.width, mapH=Math.round(W*asp), hdH=210, ftH=150;
  const A=SYN_LAY[st.shade.lay], levA=A&&A.lev[0]?(A.lev.includes(st.shade.lev)?st.shade.lev:A.lev[0]):0, B=st.shade2.lay&&SYN_LAY[st.shade2.lay];
  const legs=[]; if(A&&!A.lineOnly) legs.push([A,synLabOf(st.shade.lay)+(levA?" "+levA+" hPa":"")+" · "+A.u]); if(B&&!B.lineOnly) legs.push([B,synLabOf(st.shade2.lay)+" · "+B.u]);
  const h1=Math.round(W/760*60), lgH=legs.length*h1+(st.lines.length?Math.round(W/760*30):0);
  const mc=document.createElement("canvas"); mc.width=W; mc.height=mapH; synPaint(mc,true);
  const c=document.createElement("canvas"); c.width=W; c.height=hdH+mapH+lgH+ftH; const x=c.getContext("2d"); x.fillStyle="#fff"; x.fillRect(0,0,c.width,c.height);
  x.drawImage(mc,0,hdH); x.strokeStyle="#000"; x.lineWidth=2; x.strokeRect(1,hdH,W-2,mapH);
  const ttl=(A&&!A.lineOnly?synLabOf(st.shade.lay)+(levA?" "+levA+" hPa":""):(st.lines[0]?synLabOf(st.lines[0].lay):""))+(B?" + "+synLabOf(st.shade2.lay):"");
  const nm=hd.model==="gfs"?"GFS 0.25°":"ECMWF IFS", vt=(()=>{ try{ return typeof onFmtValid==="function"?onFmtValid(hd.valid):synIran(hd.valid); }catch(e){ return synIran(hd.valid); } })();
  txt(x,ttl,W-28,92,`78px ${FT.titr}`,{maxW:W-56});
  txt(x,`${nm} · run ${hd.run} UTC · اعتبار: ${vt} · ${typeof FA==="function"?FA(hd.step):hd.step} ساعت`,W-28,172,`46px ${FT.body}`,{color:"#111",maxW:W-56});
  const y0=hdH+mapH; x.fillStyle="#fff"; x.fillRect(0,y0,W,lgH);
  const dpS=SYN.dpr; legs.forEach(([L,t],i)=>{ const l=document.createElement("canvas"); l.width=W; l.height=h1; const lx=l.getContext("2d"); lx.fillStyle="#fff"; lx.fillRect(0,0,W,h1); SYN.dpr=W/760*1.45; try{ synLegend(lx,L,synPal(L.stops,L.br.length+1),W,h1,h1-6*SYN.dpr,t); }finally{ SYN.dpr=dpS; } x.drawImage(l,0,y0+i*h1); });
  if(st.lines.length){ x.font=`${Math.round(W/760*12)}px sans-serif`; x.textAlign="left"; let xx=24; st.lines.forEach((l,i)=>{ const col=l.col||SYN_LC[i%SYN_LC.length], tx=synLabOf(l.lay)+(SYN_LAY[l.lay].lev[0]?" "+l.lev:"")+" ("+(l.step||SYN_LAY[l.lay].ls(l.lev))+")"; x.fillStyle=col; x.fillRect(xx,y0+legs.length*h1+8,40,6); x.fillStyle="#111"; x.fillText(tx,xx+48,y0+legs.length*h1+Math.round(W/760*22)); xx+=60+x.measureText(tx).width; }); }
  const fy=y0+lgH, fh=ftH-34, flg=typeof nvFlagCode==="function"?nvFlagCode(hd.model==="gfs"?"gfs":"ecmwf"):null, fw=Math.round(fh*1.5); let bx=20;
  try{ if(flg&&nvFlag(x,flg,20,fy+17,fw,fh)) bx=20+fw+26; }catch(e){}
  txt(x,`داده: ${hd.model==="gfs"?"NOAA GFS 0.25°":"ECMWF Open Data (CC BY 4.0)"} · محاسبهٔ مشتق‌ها: MetStat`,W-28,fy+62,`40px ${FT.body}`,{color:"#222"});
  txt(x,`MetStat — wtafkik.ir`,W-28,fy+118,`bold 44px ${FT.body}`,{color:"#0a3d8f",dir:"ltr"});
  try{ drawBrand(x,{brand:$("brand")?$("brand").value.trim():"",handle:$("handle")?$("handle").value.trim():"",logoImg:state.logoImg},bx,fy+8,Math.round(W*0.4),ftH-16,{side:true,align:"left",fs:36}); }catch(err){}
  return c; }
const synSave=()=>{ try{ store.set("syn.st2",SYN.st); }catch(e){} };
/* ---------- رابط ---------- */
function synInit(root){
  if(root.dataset.ok){ synRefresh(); return; } root.dataset.ok="1"; const en=synEn(), S=SYN.st;
  const opt=(a,sel)=>a.map(([v,t])=>`<option value="${v}"${String(v)===String(sel)?" selected":""}>${t}</option>`).join("");
  const layOpts=(sel,none)=>(none?`<option value="">${en?"— none —":"— بدون —"}</option>`:"")+opt(Object.keys(SYN_LAY).map(k=>[k,synLabOf(k)]),sel);
  root.innerHTML=`<section class="card synCard" dir="${en?"ltr":"rtl"}"><h3>${en?"Synergy — gridded analysis":"سینرژی — تحلیل شبکه‌ای"}</h3>
  <p class="muted" style="margin:.2em 0 .6em;font-size:.88em">${en?"ECMWF/GFS gridded data (0.5°) on the host; discrete colours; fronts are probable boundaries.":"داده‌ٔ شبکه‌ای ECMWF و GFS (۰٫۵°) روی هاست؛ رنگ‌بندی گسسته؛ جبهه‌ها «مرز احتمالی» ‌اند."}</p>
  <div class="synRow"><label>${en?"Model":"مدل"} <select id="synModel"><option value="ecmwf">ECMWF IFS</option><option value="gfs">GFS</option></select></label>
   <label>${en?"Region":"منطقه"} <select id="synReg">${opt(Object.entries(SYN_REG).map(([k,v])=>[k,en?v[5]:v[4]]),S.reg)}</select></label>
   <label class="synChk"><input type="checkbox" id="synSkOn"> ${en?"Skew-T on click":"اسکیوتی با کلیک"}</label></div>
  <div class="synRow"><b>${en?"Colour layer":"لایهٔ رنگی"}</b><select id="synLay">${layOpts(S.shade.lay)}</select><select id="synLev"></select>
   <b>${en?"2nd colour (transparent)":"لایهٔ رنگی دوم (شفاف)"}</b><select id="synLay2">${layOpts(S.shade2.lay,1)}</select><select id="synLev2"></select><input type="range" id="synA2" min="0.15" max="0.85" step="0.05" style="width:80px"></div>
  <div class="synRow"><b>${en?"Contour lines":"خطوط همتراز"}</b><span id="synLines"></span><select id="synAddL">${layOpts("")}</select><select id="synAddLv"></select><button type="button" id="synAddB">+ ${en?"add":"افزودن"}</button></div>
  <div class="synRow"><label class="synChk"><input type="checkbox" id="synW"> ${en?"Wind":"باد"}</label><select id="synWLev">${opt([[0,"10 m"],...SYN_ALLP.map(v=>[v,v+" hPa"])],S.windLev)}</select>
   <label class="synChk"><input type="checkbox" id="synF"> ${en?"Fronts":"جبهه‌ها"}</label><select id="synFLev">${opt([925,850,700].map(v=>[v,v+" hPa"]),S.frLev)}</select>
   <label class="synFr">${en?"sensitivity":"حساسیت"} <input type="range" id="synThr" min="2" max="9" step="0.5" style="width:90px"> <b id="synThrV"></b> K/100km</label></div>
  <div class="synRow"><b>${en?"Boundaries":"مرزها"}</b><label class="synChk"><input type="checkbox" data-b="coast"> ${en?"coast":"ساحل"}</label><label class="synChk"><input type="checkbox" data-b="ctry"> ${en?"countries":"کشورها"}</label><label class="synChk"><input type="checkbox" data-b="prov"> ${en?"provinces":"استان‌ها"}</label><label class="synChk"><input type="checkbox" data-b="cnty"> ${en?"counties":"شهرستان‌ها"}</label></div>
  <div class="synRow"><button type="button" id="synPrev">◀</button><input type="range" id="synStep" min="0" max="0" value="0" style="flex:1;min-width:120px"><button type="button" id="synNext">▶</button><button type="button" id="synPlay">▶▶</button></div>
  <div id="synTime" class="synTime"></div>
  <div id="synBox" class="synBox"><canvas id="synCv"></canvas>
   <div class="synTools"><button type="button" id="synZi" title="+">+</button><button type="button" id="synZo" title="−">−</button><button type="button" id="synFit" title="${en?"Fit":"جای‌گذاری"}">⤢</button><button type="button" id="synFs" title="${en?"Fullscreen":"تمام‌صفحه"}">⛶</button><button type="button" id="synPng" title="PNG">↓</button></div>
   <div id="synCur" class="synCur"></div>
   <div class="synFsBar"><button type="button" id="synFPrev">◀</button><input type="range" id="synFStep" min="0" max="0" value="0"><button type="button" id="synFNext">▶</button><span id="synFTime"></span><select id="synFLay"></select><select id="synFLev"></select></div></div>
  <div id="synMsg" class="muted"></div><div id="synNote" class="muted" style="font-size:.85em;margin-top:.3em"></div>
  <div id="synSk" hidden></div></section>`;
  const $s=id=>root.querySelector("#"+id); SYN.cv=$s("synCv"); SYN.box=$s("synBox");
  const lvOpts=(L,sel)=>L.lev[0]?opt(L.lev.map(v=>[v,v+" hPa"]),sel):'<option value="0">—</option>';
  const linesUi=()=>{ $s("synLines").innerHTML=S.lines.map((l,i)=>{ const c=l.col||SYN_LC[i%SYN_LC.length]; return `<span class="synChip" style="border-color:${c}"><i style="background:${c}"></i>${synLabOf(l.lay)}${SYN_LAY[l.lay].lev[0]?" "+l.lev:""}<input type="number" step="any" value="${l.step||SYN_LAY[l.lay].ls(l.lev)}" data-i="${i}" title="${en?"interval":"فاصلهٔ خطوط"}"><button type="button" data-x="${i}">×</button></span>`; }).join(""); $s("synLines").querySelectorAll("[data-x]").forEach(b=>b.onclick=()=>{ S.lines.splice(+b.dataset.x,1); synSave(); linesUi(); synRender(); }); $s("synLines").querySelectorAll("input[data-i]").forEach(inp=>inp.onchange=()=>{ const v=parseFloat(inp.value); S.lines[+inp.dataset.i].step=v>0?v:null; synSave(); synRender(); }); };
  window.synRefresh=function(){ const A=SYN_LAY[S.shade.lay]; if(A.lev[0]&&!A.lev.includes(S.shade.lev)) S.shade.lev=A.lev[0]; $s("synLay").value=S.shade.lay; $s("synLev").innerHTML=lvOpts(A,S.shade.lev); $s("synLev").disabled=!A.lev[0];
    const B=S.shade2.lay?SYN_LAY[S.shade2.lay]:null; $s("synLay2").value=S.shade2.lay; $s("synLev2").innerHTML=B?lvOpts(B,S.shade2.lev):""; $s("synLev2").hidden=!B; $s("synA2").hidden=!B; $s("synA2").value=S.shade2.a;
    const AL=SYN_LAY[$s("synAddL").value||"gh"]; $s("synAddLv").innerHTML=lvOpts(AL,AL.lev[0]); $s("synAddLv").disabled=!AL.lev[0];
    $s("synW").checked=!!S.wind; $s("synF").checked=!!S.fr; $s("synThr").value=S.thr; $s("synThrV").textContent=S.thr; root.querySelector(".synFr").style.opacity=S.fr?1:.45; $s("synFLev").value=S.frLev; $s("synWLev").value=S.windLev; $s("synSkOn").checked=!!S.sk; root.querySelectorAll("[data-b]").forEach(c=>c.checked=!!S.bnd[c.dataset.b]); linesUi();
    $s("synNote").textContent=(A.note?A.note+" · ":"")+(S.fr?(en?"Fronts: blue = cold (triangles), red = warm (semicircles), purple dashed = stationary/uncertain; thresholds are experimental.":"جبهه: آبی = سرد (مثلث)، قرمز = گرم (نیم‌دایره)، بنفش خط‌چین = ایستا/نامشخص؛ آستانه‌ها تجربی و واسنجی‌نشده‌اند."):"");
    const fl=$s("synFLay"); if(fl&&!fl.options.length){ fl.innerHTML=layOpts(S.shade.lay); } if(fl) fl.value=S.shade.lay; const fv=$s("synFLev"); if(fv) fv.innerHTML=lvOpts(A,S.shade.lev);
    if(SYN.P){ const t="اعتبار: "+synIran(SYN.P.hd.valid)+" ("+(en?"Iran time":"وقت ایران")+") — +"+SYN.P.hd.step+(en?" h from run ":" ساعت از اجرای ")+SYN.P.hd.run+" UTC"; $s("synTime").textContent=t; $s("synFTime").textContent=synIran(SYN.P.hd.valid); }
    synSize(); synRender(); synProbeUpdate(); };
  function synSize(){ const cv=SYN.cv, box=SYN.box, full=document.fullscreenElement===box||box.classList.contains("synFull"), dp=Math.min(2,window.devicePixelRatio||1), cw=box.clientWidth||600; SYN.dpr=dp; const ch=full?(box.clientHeight||window.innerHeight):Math.round(cw*(cw<520?0.95:0.62)); if(!full) box.style.height=ch+"px"; else box.style.height=""; const W=Math.round(cw*dp), H=Math.round(ch*dp); if(cv.width!==W||cv.height!==H){ cv.width=W; cv.height=H; cv.style.width=cw+"px"; cv.style.height=ch+"px"; } }
  window.addEventListener("resize",()=>{ if(root.hidden) return; synSize(); synRender(); }); document.addEventListener("fullscreenchange",()=>{ box_(); setTimeout(()=>{ synSize(); synRender(); },60); });
  const box_=()=>{ SYN.box.classList.toggle("synFull",document.fullscreenElement===SYN.box||SYN.box.classList.contains("synPseudo")); };
  const go=async i=>{ synMsg(en?"Loading…":"در حال خواندن…"); try{ await synLoadStep(i); synMsg(""); }catch(e){ synMsg((en?"Error: ":"خطا: ")+e.message); return; } $s("synStep").value=i; $s("synFStep").value=i; synRefresh(); };
  const setModel=async m=>{ try{ synMsg(en?"Reading list…":"خواندن فهرست…"); const man=await synFetchMan(m); SYN.model=m; $s("synModel").value=m; const n=man.steps.length; $s("synStep").max=n-1; $s("synFStep").max=n-1; let i=0; if(SYN.P){ const t=SYN.P.hd.valid; const j=man.steps.findIndex(e=>e.valid===t); i=j>=0?j:Math.min(SYN.idx,n-1); } SYN.cache=SYN.cache; await go(i); }catch(e){ synMsg((en?"Grid pack missing for ":"بستهٔ شبکه‌ای روی هاست نیست: ")+m+" ("+e.message+")"); if(m!=="ecmwf"&&!SYN.P) setModel("ecmwf"); else if(m!=="ecmwf"){ $s("synModel").value=SYN.model; } } };
  $s("synModel").onchange=e=>setModel(e.target.value); $s("synReg").onchange=e=>{ S.reg=e.target.value; SYN.view=null; synSave(); synRefresh(); };
  $s("synLay").onchange=e=>{ S.shade.lay=e.target.value; synSave(); synRefresh(); }; $s("synLev").onchange=e=>{ S.shade.lev=+e.target.value; synSave(); synRefresh(); };
  $s("synLay2").onchange=e=>{ S.shade2.lay=e.target.value; synSave(); synRefresh(); }; $s("synLev2").onchange=e=>{ S.shade2.lev=+e.target.value; synSave(); synRefresh(); }; $s("synA2").oninput=e=>{ S.shade2.a=+e.target.value; synSave(); synRender(); };
  $s("synAddL").onchange=()=>{ const AL=SYN_LAY[$s("synAddL").value]; $s("synAddLv").innerHTML=lvOpts(AL,AL.lev[0]); $s("synAddLv").disabled=!AL.lev[0]; };
  $s("synAddB").onclick=()=>{ const k=$s("synAddL").value, L=SYN_LAY[k]; S.lines.push({lay:k,lev:L.lev[0]?+$s("synAddLv").value:0}); synSave(); linesUi(); synRender(); };
  $s("synW").onchange=e=>{ S.wind=e.target.checked; synSave(); synRender(); }; $s("synWLev").onchange=e=>{ S.windLev=+e.target.value; synSave(); synRender(); };
  $s("synF").onchange=e=>{ S.fr=e.target.checked; synSave(); synRefresh(); }; $s("synFLev").onchange=e=>{ S.frLev=+e.target.value; synSave(); synRender(); }; $s("synThr").oninput=e=>{ S.thr=+e.target.value; $s("synThrV").textContent=S.thr; }; $s("synThr").onchange=()=>{ synSave(); synRender(); };
  $s("synSkOn").onchange=e=>{ S.sk=e.target.checked; synSave(); if(S.sk&&!SYN.probe){ const R=SYN.V; if(R) SYN.probe={lon:(R.lo0+R.lo1)/2,lat:(R.la0+R.la1)/2}; } synProbeUpdate(); synRender(); };
  root.querySelectorAll("[data-b]").forEach(c=>c.onchange=()=>{ S.bnd[c.dataset.b]=c.checked?1:0; synSave(); synRender(); });
  $s("synStep").oninput=e=>go(+e.target.value); $s("synFStep").oninput=e=>go(+e.target.value);
  const nx=d=>{ const e=$s("synStep"); const v=Math.max(0,Math.min(+e.max,+e.value+d)); if(v!==+e.value) go(v); }; $s("synPrev").onclick=()=>nx(-1); $s("synNext").onclick=()=>nx(1); $s("synFPrev").onclick=()=>nx(-1); $s("synFNext").onclick=()=>nx(1);
  let pl=0; $s("synPlay").onclick=()=>{ if(pl){ clearInterval(pl); pl=0; $s("synPlay").textContent="▶▶"; return; } $s("synPlay").textContent="■"; pl=setInterval(async()=>{ const e=$s("synStep"); const v=(+e.value+1)>+e.max?0:+e.value+1; await go(v); },1400); };
  $s("synFLay").onchange=e=>{ S.shade.lay=e.target.value; synSave(); synRefresh(); }; $s("synFLev").onchange=e=>{ S.shade.lev=+e.target.value; synSave(); synRefresh(); };
  /* زوم / پن / لمس */
  const cv=SYN.cv, ptr=new Map(); let moved=0, last=null;
  const zoomAt=(f,cx,cy)=>{ const v=SYN.view; if(!v) return; const V=SYN.V; const lon=V.lo0+cx*SYN.dpr/V.s, lat=V.la1-cy*SYN.dpr/V.s; v.ppd*=f; synClampView(cv); const V2=synView(cv); const lon2=V2.lo0+cx*SYN.dpr/V2.s, lat2=V2.la1-cy*SYN.dpr/V2.s; v.cx+=lon-lon2; v.cy+=lat-lat2; synRender(); };
  cv.addEventListener("wheel",e=>{ e.preventDefault(); const r=cv.getBoundingClientRect(); zoomAt(e.deltaY<0?1.25:0.8,e.clientX-r.left,e.clientY-r.top); },{passive:false});
  cv.addEventListener("pointerdown",e=>{ cv.setPointerCapture(e.pointerId); ptr.set(e.pointerId,[e.clientX,e.clientY]); moved=0; last=null; });
  cv.addEventListener("pointermove",e=>{ const r=cv.getBoundingClientRect(), V=SYN.V; if(V){ SYN.cur={lon:V.lo0+(e.clientX-r.left)*SYN.dpr/V.s,lat:V.la1-(e.clientY-r.top)*SYN.dpr/V.s}; synCursor(); } if(!ptr.has(e.pointerId)) return; const p=ptr.get(e.pointerId), dx=e.clientX-p[0], dy=e.clientY-p[1]; ptr.set(e.pointerId,[e.clientX,e.clientY]);
    if(ptr.size===1){ moved+=Math.abs(dx)+Math.abs(dy); const v=SYN.view; if(v&&moved>4){ v.cx-=dx/v.ppd; v.cy+=dy/v.ppd; synRender(); } }
    else if(ptr.size===2){ moved+=10; const a=[...ptr.values()], d=Math.hypot(a[0][0]-a[1][0],a[0][1]-a[1][1]); if(last){ zoomAt(d/last,(a[0][0]+a[1][0])/2-r.left,(a[0][1]+a[1][1])/2-r.top); } last=d; } });
  const up=e=>{ const had=ptr.has(e.pointerId); ptr.delete(e.pointerId); if(ptr.size<2) last=null; if(had&&moved<=4&&ptr.size===0&&e.type==="pointerup"){ const r=cv.getBoundingClientRect(), V=SYN.V; if(V&&S.sk){ SYN.probe={lon:V.lo0+(e.clientX-r.left)*SYN.dpr/V.s,lat:V.la1-(e.clientY-r.top)*SYN.dpr/V.s}; synProbeUpdate(); synRender(); const pn=$s("synSk"); if(!pn.hidden) pn.scrollIntoView({behavior:"smooth",block:"nearest"}); } } };
  cv.addEventListener("pointerup",up); cv.addEventListener("pointercancel",up); cv.addEventListener("dblclick",e=>{ const r=cv.getBoundingClientRect(); zoomAt(2,e.clientX-r.left,e.clientY-r.top); }); cv.style.touchAction="none";
  $s("synZi").onclick=()=>zoomAt(1.4,cv.clientWidth/2,cv.clientHeight/2); $s("synZo").onclick=()=>zoomAt(1/1.4,cv.clientWidth/2,cv.clientHeight/2); $s("synFit").onclick=()=>{ SYN.view=null; synRender(); };
  $s("synFs").onclick=()=>{ const b=SYN.box; if(document.fullscreenElement===b||b.classList.contains("synPseudo")){ if(document.fullscreenElement) document.exitFullscreen(); b.classList.remove("synPseudo","synFull"); document.body.classList.remove("synNoScroll"); setTimeout(()=>{ synSize(); synRender(); },60); return; } if(b.requestFullscreen){ b.requestFullscreen().catch(()=>{ b.classList.add("synPseudo","synFull"); document.body.classList.add("synNoScroll"); setTimeout(()=>{ synSize(); synRender(); },60); }); } else { b.classList.add("synPseudo","synFull"); document.body.classList.add("synNoScroll"); setTimeout(()=>{ synSize(); synRender(); },60); } };
  $s("synPng").onclick=()=>{ const nm=`metstat_synergy_${S.shade.lay}_${SYN.P?SYN.P.hd.run+"_+"+SYN.P.hd.step:""}.png`; let c=null; try{ c=synExport(1800); }catch(e){ console.warn("synExport",e); } if(!c){ c=cv; } c.toBlob(b=>{ if(typeof onSave==="function") onSave(b,nm); else { const a=document.createElement("a"); a.download=nm; a.href=URL.createObjectURL(b); a.click(); } }); };
  (async()=>{ synMsg(en?"Reading grid-pack list…":"خواندن فهرست بستهٔ شبکه‌ای…"); try{ await synFetchMan("ecmwf"); }catch(e){ synMsg((en?"Grid pack not on host: ":"بستهٔ شبکه‌ای روی هاست نیست یا خوانده نشد: ")+e.message+(en?" — run workflow metstat-grid-pack.":" — workflow «metstat-grid-pack» را اجرا کنید.")); synRefresh(); return; }
    await setModel("ecmwf"); try{ await geoLoad(); synRender(); }catch(e){} try{ synFetchMan("gfs").catch(()=>{ const o=$s("synModel").querySelector('option[value="gfs"]'); if(o){ o.disabled=true; o.textContent="GFS ("+(en?"not on host":"روی هاست نیست")+")"; } }); }catch(e){} })();
  synRefresh();
}
window.openSyn=function(){ const r=document.getElementById("synApp"); if(r) synInit(r); };
