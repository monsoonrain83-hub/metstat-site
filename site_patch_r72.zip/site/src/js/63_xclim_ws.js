/* ===== کارگاه تغییر اقلیم — شاخص‌های اقلیمی به سبک xclim / ETCCDI (r72) =====
   دو راه، ترکیبی:
   (۱) نقطه: داده‌ی روزانهٔ ERA5 (Open-Meteo Archive، ۱۹۵۰ تا آخرین سال کامل) → ۳۱ شاخص سالانه (ETCCDI و تعدادی شاخص xclim) → فقط نمودار.
       صدک‌های روزانه (TX90p…) نسبت به دورهٔ پایهٔ ۱۹۶۱–۱۹۹۰، پنجرهٔ ۵ روزه. بدون بوت‌استرپ (xclim در سال‌های درون دورهٔ پایه بوت‌استرپ می‌کند). ۲۹ فوریه حذف می‌شود.
   (۲) نقشه: نرمال‌های ماهانهٔ ایستگاه‌های اطلس → شاخص‌های اقلیمی مشتق (دومارتن، گوسن، PCI، گورچینسکی، UNEP) با طبقه‌های گسسته.
   ERA5 بازتحلیل است، نه مشاهدهٔ ایستگاهی؛ خروجی‌ها فقط نمودار و نقشه‌اند (بدون جدول عددی). */
const XI={tab:"pt", loc:"st", sid:null, lat:35.7, lon:51.4, idx:"TXx", map:"dm", win:"all", busy:false, mem:new Map()};
const XI_Y0=1950, XI_B0=1961, XI_B1=1990, XI_N0=1991, XI_N1=2020;
// key, فارسی، English, واحد، گروه
const XI_DEF=[
 ["TXx","بیشینهٔ دمای بیشینه","Max of daily max temp","°C","T"],["TNn","کمینهٔ دمای کمینه","Min of daily min temp","°C","T"],
 ["TXm","میانگین دمای بیشینه","Mean daily max temp","°C","T"],["TNm","میانگین دمای کمینه","Mean daily min temp","°C","T"],["TMm","میانگین دما","Mean temperature","°C","T"],["DTR","دامنهٔ روزانهٔ دما","Diurnal temp range","°C","T"],
 ["SU25","روز تابستانی (بیشینه > ۲۵)","Summer days (Tmax>25)","روز","T"],["TX35","روز بسیار گرم (بیشینه > ۳۵)","Hot days (Tmax>35)","روز","T"],["TR20","شب گرم (کمینه > ۲۰)","Tropical nights (Tmin>20)","روز","T"],
 ["FD","روز یخبندان (کمینه < ۰)","Frost days (Tmin<0)","روز","T"],["ID","روز یخ (بیشینه < ۰)","Ice days (Tmax<0)","روز","T"],
 ["TX90p","روزهای گرمِ بیشینه (>P90)","Warm days (>P90)","٪","T"],["TX10p","روزهای سردِ بیشینه (<P10)","Cool days (<P10)","٪","T"],["TN90p","شب‌های گرم (>P90)","Warm nights (>P90)","٪","T"],["TN10p","شب‌های سرد (<P10)","Cool nights (<P10)","٪","T"],
 ["WSDI","طول دوره‌های گرم (≥۶ روز)","Warm spell duration","روز","T"],["CSDI","طول دوره‌های سرد (≥۶ روز)","Cold spell duration","روز","T"],["GSL","طول فصل رشد","Growing season length","روز","T"],
 ["HDD","درجه‌روز گرمایش (مبنا ۱۸)","Heating degree-days (18)","°C·روز","T"],["CoolDD","درجه‌روز سرمایش (مبنا ۱۸)","Cooling degree-days (18)","°C·روز","T"],
 ["PRCPTOT","بارش سالانهٔ روزهای تر","Wet-day precipitation","mm","P"],["R1mm","روز بارانی (≥۱ mm)","Wet days (≥1 mm)","روز","P"],["SDII","شدت بارش روزهای تر","Simple daily intensity","mm/روز","P"],
 ["R10","روز بارش سنگین (≥۱۰ mm)","Heavy precip days (≥10)","روز","P"],["R20","روز بارش بسیار سنگین (≥۲۰ mm)","Very heavy days (≥20)","روز","P"],
 ["Rx1day","بیشینهٔ بارش یک‌روزه","Max 1-day precip","mm","P"],["Rx5day","بیشینهٔ بارش پنج‌روزه","Max 5-day precip","mm","P"],["R95pTOT","بارش روزهای بسیار تر (>P95)","Very wet days precip","mm","P"],
 ["CDD","بیشترین روزهای خشک متوالی","Consecutive dry days","روز","P"],["CWD","بیشترین روزهای تر متوالی","Consecutive wet days","روز","P"]];
const XI_K=Object.fromEntries(XI_DEF.map(d=>[d[0],d]));
const xiName=k=>drT(XI_K[k][1],XI_K[k][2]);
const xiLastYear=()=>new Date().getFullYear()-1;

/* ---------- داده‌ی روزانه ---------- */
const xiGrid=x=>Math.round(x*4)/4;
function xiEnc(a){ const u=new Int16Array(a.length); for(let i=0;i<a.length;i++) u[i]=a[i]===a[i]?Math.max(-32767,Math.min(32767,Math.round(a[i]*10))):-32768; let s=""; const b=new Uint8Array(u.buffer); for(let i=0;i<b.length;i+=8192) s+=String.fromCharCode.apply(null,b.subarray(i,i+8192)); return btoa(s); }
function xiDec(s){ const b=atob(s), u=new Uint8Array(b.length); for(let i=0;i<b.length;i++) u[i]=b.charCodeAt(i); const q=new Int16Array(u.buffer), o=new Float64Array(q.length); for(let i=0;i<q.length;i++) o[i]=q[i]===-32768?NaN:q[i]/10; return o; }
function xiBuild(j,y1){   // آرایه‌های 365 روز × سال (۲۹ فوریه حذف)
  const D=j&&j.daily; if(!D||!D.time) throw new Error("no daily"); const ny=y1-XI_Y0+1, N=ny*365, mk=()=>new Float64Array(N).fill(NaN), R={y0:XI_Y0,ny,tm:mk(),tx:mk(),tn:mk(),pr:mk(),lat:j.latitude,lon:j.longitude,el:j.elevation};
  const cum=[0,31,59,90,120,151,181,212,243,273,304,334];
  D.time.forEach((s,i)=>{ const y=+s.slice(0,4); if(y<XI_Y0||y>y1) return; const m=+s.slice(5,7), d=+s.slice(8,10); if(m===2&&d===29) return; const k=(y-XI_Y0)*365+cum[m-1]+d-1;
    const f=(a,t)=>{ const v=a&&a[i]; if(typeof v==="number"&&isFinite(v)) t[k]=v; }; f(D.temperature_2m_mean,R.tm); f(D.temperature_2m_max,R.tx); f(D.temperature_2m_min,R.tn); f(D.precipitation_sum,R.pr); });
  for(let k=0;k<N;k++) if(!(R.tm[k]===R.tm[k])&&R.tx[k]===R.tx[k]&&R.tn[k]===R.tn[k]) R.tm[k]=(R.tx[k]+R.tn[k])/2;
  return R; }
async function xiDaily(lat,lon){
  const y1=xiLastYear(), key="xi1:"+xiGrid(lat).toFixed(2)+","+xiGrid(lon).toFixed(2)+":"+y1; if(XI.mem.has(key)) return XI.mem.get(key);
  try{ const c=JSON.parse(localStorage.getItem(key)||"null"); if(c&&c.v===1){ const R={y0:XI_Y0,ny:y1-XI_Y0+1,tm:xiDec(c.tm),tx:xiDec(c.tx),tn:xiDec(c.tn),pr:xiDec(c.pr),lat:c.la,lon:c.lo,el:c.el}; XI.mem.set(key,R); return R; } }catch(e){}
  const u="https://archive-api.open-meteo.com/v1/archive?latitude="+xiGrid(lat).toFixed(2)+"&longitude="+xiGrid(lon).toFixed(2)+"&start_date="+XI_Y0+"-01-01&end_date="+y1+"-12-31&daily=temperature_2m_mean,temperature_2m_max,temperature_2m_min,precipitation_sum&timezone=GMT";
  const r=await fetch(u), j=await r.json().catch(()=>null); if(!r.ok||!j) throw new Error("HTTP "+r.status+(j&&j.reason?" "+j.reason:""));
  const R=xiBuild(j,y1); XI.mem.set(key,R);
  try{ for(let i=0;i<localStorage.length;i++){ const k=localStorage.key(i); if(k&&k.indexOf("xi1:")===0&&k!==key){ localStorage.removeItem(k); i--; } } localStorage.setItem(key,JSON.stringify({v:1,la:R.lat,lo:R.lon,el:R.el,tm:xiEnc(R.tm),tx:xiEnc(R.tx),tn:xiEnc(R.tn),pr:xiEnc(R.pr)})); }catch(e){}
  return R; }

/* ---------- محاسبهٔ شاخص‌ها ---------- */
const xiFin=Number.isFinite;
function xiPctl(arr,ny,q,b0,b1,w){   // صدک روز-به-روز با پنجرهٔ ±w روز، دورهٔ پایه b0..b1 ⇒ Float64Array(365)
  const out=new Float64Array(365), Q=MET.dr.quantile; for(let d=0;d<365;d++){ const a=[]; for(let y=b0;y<=b1;y++){ const yi=y-XI_Y0; if(yi<0||yi>=ny) continue; for(let o=-w;o<=w;o++){ const v=arr[yi*365+((d+o+365)%365)]; if(xiFin(v)) a.push(v); } } out[d]=a.length>=Math.max(20,(b1-b0+1)*(2*w+1)*0.5)?Q(a,q):NaN; } return out; }
function xiRuns(flag,from,to,minLen){ let tot=0,run=0; for(let i=from;i<to;i++){ if(flag(i)) run++; else { if(run>=minLen) tot+=run; run=0; } } if(run>=minLen) tot+=run; return tot; }
function xiMaxRun(flag,from,to){ let mx=0,run=0; for(let i=from;i<to;i++){ if(flag(i)){ run++; if(run>mx) mx=run; } else run=0; } return mx; }
function xiCompute(R){
  const ny=R.ny, years=[]; for(let i=0;i<ny;i++) years.push(R.y0+i); const O={}; for(const d of XI_DEF) O[d[0]]=new Float64Array(ny).fill(NaN);
  const tx90=xiPctl(R.tx,ny,0.9,XI_B0,XI_B1,2), tx10=xiPctl(R.tx,ny,0.1,XI_B0,XI_B1,2), tn90=xiPctl(R.tn,ny,0.9,XI_B0,XI_B1,2), tn10=xiPctl(R.tn,ny,0.1,XI_B0,XI_B1,2);
  const wet=[]; for(let y=XI_B0;y<=XI_B1;y++){ const yi=y-XI_Y0; if(yi<0||yi>=ny) continue; for(let d=0;d<365;d++){ const v=R.pr[yi*365+d]; if(xiFin(v)&&v>=1) wet.push(v); } }
  const p95=wet.length>=100?MET.dr.quantile(wet,0.95):NaN;
  for(let yi=0;yi<ny;yi++){ const a=yi*365, b=a+365, tx=i=>R.tx[i], tn=i=>R.tn[i], tm=i=>R.tm[i], pr=i=>R.pr[i];
    const okT=(arr)=>{ let n=0; for(let i=a;i<b;i++) if(xiFin(arr[i])) n++; return n>=347; };   // ≥۹۵٪ روزها
    const cnt=(arr,f)=>{ let n=0; for(let i=a;i<b;i++) if(xiFin(arr[i])&&f(arr[i],i-a)) n++; return n; }, sum=(arr,f)=>{ let s=0; for(let i=a;i<b;i++) if(xiFin(arr[i])) s+=f(arr[i],i-a); return s; };
    const okX=okT(R.tx), okN=okT(R.tn), okM=okT(R.tm), okP=okT(R.pr);
    if(okX){ let mx=-1e9,s=0,n=0; for(let i=a;i<b;i++) if(xiFin(tx(i))){ if(tx(i)>mx) mx=tx(i); s+=tx(i); n++; } O.TXx[yi]=mx; O.TXm[yi]=s/n;
      O.SU25[yi]=cnt(R.tx,v=>v>25); O.TX35[yi]=cnt(R.tx,v=>v>35); O.ID[yi]=cnt(R.tx,v=>v<0);
      if(tx90.every(xiFin)){ O.TX90p[yi]=cnt(R.tx,(v,d)=>v>tx90[d])/n*100; O.TX10p[yi]=cnt(R.tx,(v,d)=>v<tx10[d])/n*100; O.WSDI[yi]=xiRuns(i=>xiFin(tx(i))&&tx(i)>tx90[i-a],a,b,6); } }
    if(okN){ let mn=1e9,s=0,n=0; for(let i=a;i<b;i++) if(xiFin(tn(i))){ if(tn(i)<mn) mn=tn(i); s+=tn(i); n++; } O.TNn[yi]=mn; O.TNm[yi]=s/n;
      O.TR20[yi]=cnt(R.tn,v=>v>20); O.FD[yi]=cnt(R.tn,v=>v<0);
      if(tn90.every(xiFin)){ O.TN90p[yi]=cnt(R.tn,(v,d)=>v>tn90[d])/n*100; O.TN10p[yi]=cnt(R.tn,(v,d)=>v<tn10[d])/n*100; O.CSDI[yi]=xiRuns(i=>xiFin(tn(i))&&tn(i)<tn10[i-a],a,b,6); } }
    if(okX&&okN) O.DTR[yi]=O.TXm[yi]-O.TNm[yi];
    if(okM){ let s=0,n=0; for(let i=a;i<b;i++) if(xiFin(tm(i))){ s+=tm(i); n++; } O.TMm[yi]=s/n; O.HDD[yi]=sum(R.tm,v=>Math.max(0,18-v)); O.CoolDD[yi]=sum(R.tm,v=>Math.max(0,v-18));
      let st=-1; for(let i=a;i<=b-6;i++){ let ok=true; for(let k=0;k<6;k++) if(!(tm(i+k)>5)){ ok=false; break; } if(ok){ st=i; break; } }
      if(st<0) O.GSL[yi]=0; else { let en=b; for(let i=a+181;i<=b-6;i++){ let ok=true; for(let k=0;k<6;k++) if(!(tm(i+k)<5)){ ok=false; break; } if(ok){ en=i; break; } } O.GSL[yi]=en-st; } }
    if(okP){ const wetF=v=>v>=1; O.PRCPTOT[yi]=sum(R.pr,v=>v>=1?v:0); const nw=cnt(R.pr,wetF); O.R1mm[yi]=nw; O.SDII[yi]=nw?O.PRCPTOT[yi]/nw:0; O.R10[yi]=cnt(R.pr,v=>v>=10); O.R20[yi]=cnt(R.pr,v=>v>=20);
      let mx=0; for(let i=a;i<b;i++) if(pr(i)>mx) mx=pr(i); O.Rx1day[yi]=mx; let m5=0; for(let i=a;i<=b-5;i++){ const s=pr(i)+pr(i+1)+pr(i+2)+pr(i+3)+pr(i+4); if(s>m5) m5=s; } O.Rx5day[yi]=m5;
      O.R95pTOT[yi]=xiFin(p95)?sum(R.pr,v=>v>p95?v:0):NaN; O.CDD[yi]=xiMaxRun(i=>xiFin(pr(i))&&pr(i)<1,a,b); O.CWD[yi]=xiMaxRun(i=>xiFin(pr(i))&&pr(i)>=1,a,b); } }
  return {years,idx:O}; }
function xiMonthly(R){   // دمای میانگین ماهانه و مجموع بارش ماهانه ⇒ [ny][12]
  const cum=[0,31,59,90,120,151,181,212,243,273,304,334,365], T=[], P=[];
  for(let yi=0;yi<R.ny;yi++){ const t=[],p=[]; for(let m=0;m<12;m++){ let st=0,sp=0,nt=0,np=0; for(let d=cum[m];d<cum[m+1];d++){ const i=yi*365+d; if(xiFin(R.tm[i])){ st+=R.tm[i]; nt++; } if(xiFin(R.pr[i])){ sp+=R.pr[i]; np++; } } const n=cum[m+1]-cum[m]; t.push(nt>=n*0.9?st/nt:NaN); p.push(np>=n*0.9?sp:NaN); } T.push(t); P.push(p); } return {T,P}; }

/* ---------- آمار روند ---------- */
function xiTrend(years,vals){ const X=[],Y=[]; years.forEach((y,i)=>{ if(xiFin(vals[i])){ X.push(y); Y.push(vals[i]); } }); if(X.length<20) return null; const s=MET.dr.sen(X,Y); if(!s) return null; let mk=null; try{ mk=MET.dr.mkTFPW(X,Y); }catch(e){} if(!mk){ const m=MET.dr.mannKendall(Y); mk=m?{p:m.p,Z:m.Z}:null; } if(!mk) return null;
  const mean=Y.reduce((a,b)=>a+b,0)/Y.length, sd=Math.sqrt(Y.reduce((a,b)=>a+(b-mean)*(b-mean),0)/Y.length); return {b:s.slope,a:s.icpt,p:mk.p,sig:mk.p<0.05,z:sd>1e-9?s.slope*10/sd:0,sd,n:X.length}; }

/* ---------- نمودارها (فقط بصری) ---------- */
const XI_UP="#c2410c", XI_DN="#1d4ed8", XI_NS="#94a3b8";
function xiDrawSeries(x,L,T,R,B,years,vals,tr,o){   // یک سری با خط روند سن
  const f=vals.filter(xiFin); if(f.length<5) return null; let lo=Math.min(...f), hi=Math.max(...f); const pad=(hi-lo)*0.1||1; lo-=pad; hi+=pad;
  const A=o.mini?(()=>{ x.fillStyle="#fff"; x.fillRect(L,T,R-L,B-T); x.strokeStyle="#e2e8f0"; x.strokeRect(L,T,R-L,B-T); return {Y:v=>B-(v-lo)/(hi-lo)*(B-T)}; })():caAxes(x,L,T,R,B,0,1,lo,hi,{ylab:o.unit});
  const y0=years[0], y1=years[years.length-1], X=y=>L+(y-y0+0.5)/(y1-y0+1)*(R-L);
  for(let y=y0;y<=y1;y++) if(y%(o.mini?25:10)===0){ x.strokeStyle="#cbd5e1"; x.beginPath(); x.moveTo(X(y),B); x.lineTo(X(y),B+4); x.stroke(); txt(x,FA(y),X(y),B+(o.mini?15:20),`${o.mini?10.5:12}px ${FT.body}`,{align:"center",color:"#64748b",dir:"ltr"}); }
  x.strokeStyle="#94a3b8"; x.lineWidth=1; x.beginPath(); let st=false; years.forEach((y,i)=>{ const v=vals[i]; if(!xiFin(v)){ st=false; return; } if(!st){ x.moveTo(X(y),A.Y(v)); st=true; } else x.lineTo(X(y),A.Y(v)); }); x.stroke();
  if(!o.mini) years.forEach((y,i)=>{ const v=vals[i]; if(!xiFin(v)) return; x.fillStyle="#64748b"; x.beginPath(); x.arc(X(y),A.Y(v),2.6,0,6.3); x.fill(); });
  const rm=MET.dr.runMean(vals,11); x.strokeStyle="#0f172a"; x.lineWidth=o.mini?1.6:2.2; x.beginPath(); st=false; years.forEach((y,i)=>{ const v=rm[i]; if(!xiFin(v)){ st=false; return; } if(!st){ x.moveTo(X(y),A.Y(v)); st=true; } else x.lineTo(X(y),A.Y(v)); }); x.stroke();
  if(tr){ const c=tr.sig?(tr.b>0?XI_UP:XI_DN):XI_NS; x.strokeStyle=c; x.lineWidth=o.mini?2.2:3; if(!tr.sig) x.setLineDash([6,5]); x.beginPath(); x.moveTo(X(y0),A.Y(tr.a+tr.b*y0)); x.lineTo(X(y1),A.Y(tr.a+tr.b*y1)); x.stroke(); x.setLineDash([]); }
  return A; }
function xiChartSeries(title,sub,years,vals,tr,unit){
  const W=1000,H=520,[c,x]=caCanvas(W,H), L=66,R=W-26,T=92,B=H-100; caFrame(x,W,H,title,sub);
  if(!xiDrawSeries(x,L,T,R,B,years,vals,tr,{unit})) return null;
  const en=LANG==="en"; const it=[{c:"#0f172a",t:drT("میانگین متحرک ۱۱ ساله","11-yr running mean")},{c:!tr?XI_NS:tr.sig?(tr.b>0?XI_UP:XI_DN):XI_NS,t:!tr?"":tr.sig?drT(tr.b>0?"روند سن — افزایشی، معنی‌دار (۵٪)":"روند سن — کاهشی، معنی‌دار (۵٪)",tr.b>0?"Sen trend — increasing, significant (5%)":"Sen trend — decreasing, significant (5%)"):drT("روند سن — بدون معنی‌داری (خط‌چین)","Sen trend — not significant (dashed)")}];
  caLegend(x,it,L,B+48,R-L); caBrand(x,W,H); return c; }
function xiChartPanel(title,sub,years,idx,keys){
  const cols=2, rows=Math.ceil(keys.length/cols), W=1100, ph=190, H=100+rows*ph+80, [c,x]=caCanvas(W,H); caFrame(x,W,H,title,sub); const gw=(W-60)/cols;
  keys.forEach((k,n)=>{ const col=n%cols, row=Math.floor(n/cols), L=(LANG==="en"?30+col*gw:W-30-(col+1)*gw)+52, R=L+gw-84, T=118+row*ph, B=T+ph-62, v=idx[k], tr=xiTrend(years,v);
    xiDrawSeries(x,L,T,R,B,years,v,tr,{mini:true}); const en=LANG==="en"; txt(x,k+" — "+xiName(k),en?L:R,T-8,`bold 13px ${FT.body}`,{align:en?"left":"right",color:"#0f172a",dir:en?"ltr":"rtl",maxW:R-L}); });
  const it=[{c:"#0f172a",t:drT("میانگین متحرک ۱۱ ساله","11-yr running mean")},{c:XI_UP,t:drT("روند افزایشی معنی‌دار","Significant increase")},{c:XI_DN,t:drT("روند کاهشی معنی‌دار","Significant decrease")},{c:XI_NS,t:drT("بدون روند معنی‌دار (خط‌چین)","No significant trend (dashed)")}];
  caLegend(x,it,30,H-52,W-60); caBrand(x,W,H); return c; }
function xiChartOverview(title,sub,years,idx){
  const keys=XI_DEF.map(d=>d[0]), rows=keys.map(k=>({k,tr:xiTrend(years,idx[k])})).filter(r=>r.tr), W=1000, rh=21, T=110, H=T+rows.length*rh+110, [c,x]=caCanvas(W,H), en=LANG==="en";
  caFrame(x,W,H,title,sub); const L=en?220:60, R=en?W-60:W-220, mid=(L+R)/2, half=(R-L)/2, CL=2;
  x.save(); x.shadowColor="rgba(15,23,42,.12)"; x.shadowBlur=14; x.shadowOffsetY=4; x.fillStyle="#fff"; x.fillRect(L,T-8,R-L,rows.length*rh+16); x.restore();
  x.strokeStyle="#94a3b8"; x.lineWidth=1.3; x.beginPath(); x.moveTo(mid,T-8); x.lineTo(mid,T+rows.length*rh+8); x.stroke();
  rows.forEach((r,i)=>{ const y=T+i*rh, z=Math.max(-CL,Math.min(CL,r.tr.z)), w=z/CL*half, col=r.tr.sig?(r.tr.b>0?XI_UP:XI_DN):XI_NS;
    if(i%2===0){ x.fillStyle="#f8fafc"; x.fillRect(L,y,R-L,rh); } x.fillStyle=col; x.fillRect(Math.min(mid,mid+w),y+4,Math.abs(w)||1.5,rh-8);
    txt(x,r.k+"  "+xiName(r.k),en?L-8:R+8,y+rh-6,`12px ${FT.body}`,{align:en?"right":"left",color:"#1e293b",dir:en?"ltr":"rtl",maxW:206}); });
  txt(x,drT("← کاهش     |     افزایش →","← decrease  |  increase →"),mid,T+rows.length*rh+30,`12px ${FT.body}`,{align:"center",color:"#475569",dir:"ltr"});
  caLegend(x,[{c:XI_UP,t:drT("افزایش معنی‌دار (۵٪)","Significant increase (5%)")},{c:XI_DN,t:drT("کاهش معنی‌دار (۵٪)","Significant decrease (5%)")},{c:XI_NS,t:drT("بدون روند معنی‌دار","Not significant")}],30,T+rows.length*rh+58,W-60);
  caBrand(x,W,H); return c; }
// نقشهٔ حرارتی ماه×سال با طبقه‌های گسستهٔ ناهنجاری
function xiChartHeat(title,sub,years,M,kind){   // M: [ny][12]؛ kind "T" یا "P"
  const ny=years.length, cl=[]; for(let m=0;m<12;m++){ let s=0,n=0; for(let i=0;i<ny;i++){ const y=years[i]; if(y>=XI_N0&&y<=XI_N1&&xiFin(M[i][m])){ s+=M[i][m]; n++; } } cl.push(n>=20?s/n:NaN); }
  const an=M.map(r=>r.map((v,m)=>xiFin(v)&&xiFin(cl[m])?(kind==="T"?v-cl[m]:(cl[m]>0.5?(v-cl[m])/cl[m]*100:NaN)):NaN)), info=kind==="T"?{step:1,col:CC_T_COL,lab:"°C"}:{step:25,col:CC_P_COL,lab:"%"};
  const W=1000,H=560,[c,x]=caCanvas(W,H), L=60,R=W-30,T=92,B=H-120, cw=(R-L)/ny, rh=(B-T)/12; caFrame(x,W,H,title,sub); x.fillStyle="#fff"; x.fillRect(L,T,R-L,B-T);
  const en=LANG==="en";
  for(let i=0;i<ny;i++) for(let m=0;m<12;m++){ const a=an[i][m]; if(!xiFin(a)) continue; x.fillStyle=info.col[Math.max(0,Math.min(10,Math.round(a/info.step)+5))]; x.fillRect(L+i*cw,T+m*rh,cw+0.6,rh+0.6); }
  for(let m=0;m<12;m++) txt(x,"",0,0,"1px sans-serif",{});
  const ML=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"], ML_FA=["ژانویه","فوریه","مارس","آوریل","مه","ژوئن","ژوئیه","اوت","سپتامبر","اکتبر","نوامبر","دسامبر"];
  for(let m=0;m<12;m++) txt(x,en?ML[m]:ML_FA[m],en?L-6:L-6,T+m*rh+rh/2+4,`11px ${FT.body}`,{align:"right",color:"#475569",dir:en?"ltr":"rtl"});
  for(let i=0;i<ny;i++) if(years[i]%10===0) txt(x,FA(years[i]),L+(i+0.5)*cw,B+16,`12px ${FT.body}`,{align:"center",color:"#64748b",dir:"ltr"});
  const bw=34,gap=4,tot=11*bw+10*gap,sx=(W-tot)/2,sy=H-62; for(let i=0;i<11;i++){ x.fillStyle=info.col[i]; x.fillRect(sx+i*(bw+gap),sy,bw,12); }
  txt(x,kind==="T"?drT("سردتر از نرمال  ←  →  گرم‌تر از نرمال","cooler than normal  ←  →  warmer than normal"):drT("خشک‌تر از نرمال  ←  →  تر از نرمال","drier than normal  ←  →  wetter than normal"),W/2,sy-8,`12px ${FT.body}`,{align:"center",color:"#475569",dir:en?"ltr":"rtl"});
  txt(x,drT(`هر طبقهٔ رنگ = ${FA(info.step)} ${kind==="T"?"درجه":"درصد"}؛ نرمال ${FA(XI_N0)}–${FA(XI_N1)}`,`Each colour class = ${info.step} ${kind==="T"?"°C":"%"}; normal ${XI_N0}–${XI_N1}`),W/2,sy+34,`11.5px ${FT.body}`,{align:"center",color:"#64748b",dir:en?"ltr":"rtl"});
  caBrand(x,W,H); return c; }

/* ---------- اجرای تحلیل نقطه ---------- */
function xiStation(){ return CLIM_META.st.find(s=>String(s.id)===String(XI.sid)); }
async function xiRunPoint(){
  if(XI.busy) return; XI.busy=true;
  try{ await caLoad(); await document.fonts.ready; const st=XI.loc==="st"?xiStation():null; let lat=XI.lat, lon=XI.lon; if(XI.loc==="st"){ if(!st||st.lat==null) throw new Error(drT("ایستگاه مختصات ندارد","Station has no coordinates")); lat=st.lat; lon=st.lon; }
    if(!(lat>=-60&&lat<=70&&lon>=-180&&lon<=180)) throw new Error(drT("مختصات نامعتبر است","Invalid coordinates"));
    const name=st?caStName(st):drT(`نقطه (${FA(caF(lat,2))}°N، ${FA(caF(lon,2))}°E)`,`Point (${caF(lat,2)}°N, ${caF(lon,2)}°E)`);
    drStatus(drT("دریافت داده‌ی روزانهٔ ERA5 (۷۵ سال)…","Fetching ERA5 daily data (75 years)…")); const R=await xiDaily(lat,lon);
    drStatus(drT("محاسبهٔ ۳۱ شاخص…","Computing 31 indices…")); await new Promise(r=>setTimeout(r,20)); const C=xiCompute(R), MO=xiMonthly(R), yrs=C.years;
    const grp=document.createElement("div"), host={prepend:n=>grp.append(n)}; grp.style.display="contents"; const y1=yrs[yrs.length-1], src=drT(`ERA5 (Open-Meteo) · ${FA(yrs[0])}–${FA(y1)} · شبکهٔ ۰٫۲۵°`,`ERA5 (Open-Meteo) · ${yrs[0]}–${y1} · 0.25° grid`);
    const cOv=xiChartOverview(drT(`روند شاخص‌های اقلیمی — ${name}`,`Climate-index trends — ${name}`),src+drT(" · طول میله = تغییر در هر دهه بر حسب انحراف معیار سری","  · bar = change per decade in units of the series' SD"),yrs,C.idx);
    if(cOv) caCard(drT(`نمای کلی روند ۳۱ شاخص — ${name}`,`Overview of 31 index trends — ${name}`),cOv,drT("روند: شیب سن؛ معنی‌داری: من–کندال با پیش‌سفیدسازی در سطح ۵٪. شاخص‌های صدکی نسبت به ۱۹۶۱–۱۹۹۰ بدون بوت‌استرپ‌اند.","Trend: Sen slope; significance: pre-whitened Mann–Kendall at 5%. Percentile indices use 1961–1990 without bootstrap."),host);
    const cPan=xiChartPanel(drT(`شاخص‌های کلیدی — ${name}`,`Key indices — ${name}`),src,yrs,C.idx,["TXx","TNn","TX90p","TN10p","FD","TR20","PRCPTOT","Rx1day","R95pTOT","CDD"]);
    caCard(drT(`پنل شاخص‌های کلیدی — ${name}`,`Key-index panel — ${name}`),cPan,drT("خط تیره = میانگین متحرک ۱۱ ساله؛ خط رنگی = روند سن.","Dark line = 11-year running mean; coloured line = Sen trend."),host);
    const one=xiChartSeries(`${XI.idx} — ${xiName(XI.idx)} — ${name}`,src,yrs,C.idx[XI.idx],xiTrend(yrs,C.idx[XI.idx]),XI_K[XI.idx][3]===""?"":drT(XI_K[XI.idx][3],XI_K[XI.idx][3].replace("روز","days")));
    if(one) caCard(drT(`سری شاخص ${XI.idx} — ${name}`,`Index series ${XI.idx} — ${name}`),one,"",host);
    const tmN=[],base=[]; yrs.forEach((y,i)=>{ if(xiFin(C.idx.TMm[i])&&y>=XI_N0&&y<=XI_N1) base.push(C.idx.TMm[i]); }); if(base.length>=20){ const mean=base.reduce((a,b)=>a+b,0)/base.length, an=C.idx.TMm.map(v=>v-mean), info={step:0.4,col:CC_T_COL,lab:"°C"};
      caCard(drT(`نوار اقلیمی دما — ${name}`,`Warming stripes — ${name}`),ccChartStripes(drT(`نوار اقلیمی دمای میانگین — ${name}`,`Mean-temperature stripes — ${name}`),src+drT(` · پایه ${FA(XI_N0)}–${FA(XI_N1)}`,` · baseline ${XI_N0}–${XI_N1}`),yrs,Array.from(an),info,"tmean"),drT("رنگ‌ها گسسته‌اند؛ هر ستون یک سال.","Colours are discrete; each column is one year."),host); }
    caCard(drT(`ناهنجاری ماهانهٔ دما — ${name}`,`Monthly temperature anomalies — ${name}`),xiChartHeat(drT(`ناهنجاری ماهانهٔ دما — ${name}`,`Monthly temperature anomalies — ${name}`),src,yrs,MO.T,"T"),drT("ماه‌های میلادی؛ ماه‌های با کمبود داده خالی‌اند.","Gregorian months; months with missing data are blank."),host);
    caCard(drT(`ناهنجاری ماهانهٔ بارش — ${name}`,`Monthly precipitation anomalies — ${name}`),xiChartHeat(drT(`ناهنجاری ماهانهٔ بارش — ${name}`,`Monthly precipitation anomalies — ${name}`),src,yrs,MO.P,"P"),drT("ماه‌هایی که نرمالشان زیر ۰٫۵ mm است خالی گذاشته می‌شوند.","Months with a normal below 0.5 mm are left blank."),host);
    $("drCards").prepend(grp); drStatus("");
  }catch(e){ console.error(e); drStatus("⚠ "+e.message); }
  XI.busy=false; }

/* ---------- نقشهٔ شاخص‌های مشتق از نرمال‌های اطلس ---------- */
const XI_DAYS=[31,31,31,31,31,31,30,30,30,30,30,29];
const XI_MAPS={
 dm:{fa:"شاخص خشکی دومارتن",en:"De Martonne aridity index",unit:["(مجموع بارش سالانه) ÷ (دمای میانگین + ۱۰)","annual P ÷ (annual T + 10)"],
  br:[0,5,10,20,30,60,1000],col:["#7f3b08","#c8782d","#f1c96b","#b7d98a","#4aa96c","#0f6b4d"],fmt:v=>v>=1000?"":caF(v,0),
  cls:[["بسیار خشک","hyper-arid"],["خشک","arid"],["نیمه‌خشک","semi-arid"],["مدیترانه‌ای/نیمه‌مرطوب","Mediterranean / semi-humid"],["مرطوب","humid"],["بسیار مرطوب","very humid"]]},
 gb:{fa:"شمار ماه‌های خشک گوسن–باگنول",en:"Gaussen–Bagnouls dry months",unit:["ماه‌هایی که بارش (mm) < ۲ × دما (°C)","months with P (mm) < 2 × T (°C)"],
  br:[-0.5,0.5,2.5,4.5,6.5,8.5,10.5,12.5],col:["#0f6b4d","#4aa96c","#b7d98a","#f1e089","#f1c96b","#c8782d","#7f3b08"],fmt:v=>caF(Math.ceil(v),0)},
 pci:{fa:"شاخص تمرکز بارش اولیور (PCI)",en:"Oliver precipitation concentration index",unit:["۱۰۰ × Σp² ÷ (Σp)² روی ۱۲ ماه","100 × Σp² / (Σp)² over 12 months"],
  br:[8,10,15,20,100],col:["#2c7fb8","#a1dab4","#fed976","#d7301f"],fmt:v=>caF(v,0),cls:[["تقریباً یکنواخت","near-uniform"],["فصلی متوسط","moderately seasonal"],["فصلی","seasonal"],["بسیار تمرکز‌یافته","highly concentrated"]]},
 cont:{fa:"قاره‌ای‌بودن گورچینسکی",en:"Gorczyński continentality",unit:["۱٫۷ × دامنهٔ سالانه ÷ sin(عرض+۱۰) − ۱۴","1.7 × annual range / sin(lat+10) − 14"],
  br:[-30,0,25,50,75,120],col:["#2c7fb8","#a1dab4","#fed976","#fd8d3c","#bd0026"],fmt:v=>caF(v,0)},
 ai:{fa:"شاخص خشکی UNEP (بارش ÷ تبخیر‌تعرق پتانسیل)",en:"UNEP aridity index (P ÷ PET)",unit:["بارش سالانه ÷ PET ثورنت‌ویت","annual P ÷ Thornthwaite PET"],
  br:[0,0.05,0.2,0.5,0.65,1,10],col:["#7f3b08","#c8782d","#f1c96b","#d9e8a2","#4aa96c","#0f6b4d"],fmt:v=>v>=10?"":caF(v,2),
  cls:[["بسیار خشک","hyper-arid"],["خشک","arid"],["نیمه‌خشک","semi-arid"],["نیمه‌مرطوب خشک","dry sub-humid"],["مرطوب","humid"],["بسیار مرطوب","per-humid"]]}};
function xiNormals(st,w){   // میانگین ماهانهٔ دما و بارش (۱۲ ماه شمسی) در پنجرهٔ سال‌ها
  const jy0=CLIM_META.jy0, a=w==="all"?-1e9:w[0], b=w==="all"?1e9:w[1]; if(!st.d.tmean||!st.d.prcp||st.lat==null) return null; const T=[],P=[];
  for(let k=1;k<=12;k++){ const mt=caxVals(st,"tmean","m"+k,a,b), mp=caxVals(st,"prcp","m"+k,a,b); if(mt.size<12||mp.size<12) return null; let s=0; for(const v of mt.values()) s+=v; T.push(s/mt.size); s=0; for(const v of mp.values()) s+=v; P.push(s/mp.size); }
  return {T,P}; }
function xiIdxVal(key,N,st){
  const Pa=N.P.reduce((a,b)=>a+b,0), Ta=N.T.reduce((a,b)=>a+b,0)/12;
  if(key==="dm") return Pa/(Ta+10);
  if(key==="gb"){ let n=0; for(let m=0;m<12;m++) if(N.P[m]<2*Math.max(0,N.T[m])) n++; return n; }
  if(key==="pci"){ let s2=0; for(const p of N.P) s2+=p*p; return Pa>0?100*s2/(Pa*Pa):NaN; }
  if(key==="cont"){ const A=Math.max(...N.T)-Math.min(...N.T), s=Math.sin((Math.abs(st.lat)+10)*Math.PI/180); return 1.7*A/s-14; }
  if(key==="ai"){ const f=MET.dr.thornthwaiteClim(N.T,st.lat); if(!f) return NaN; let pet=0; for(let m=0;m<12;m++) pet+=f(N.T[m],m+1,XI_DAYS[m]); return pet>0?Pa/pet:NaN; }
  return NaN; }
async function xiRunMap(){
  if(XI.busy) return; XI.busy=true;
  try{ drStatus(drT("بارگذاری پایگاه ایستگاه‌ها…","Loading station database…")); await caLoad(); await document.fonts.ready; const M=XI_MAPS[XI.map], w=XI.win==="all"?"all":XI.win.split("-").map(Number);
    drStatus(drT("محاسبهٔ شاخص در هر ایستگاه…","Computing the index at each station…")); await new Promise(r=>setTimeout(r,20)); const pts=[];
    for(const st of CLIM_META.st){ const N=xiNormals(st,w); if(!N) continue; const v=xiIdxVal(XI.map,N,st); if(xiFin(v)) pts.push({lat:st.lat,lon:st.lon,elev:st.elev||0,v,name:caStName(st)}); }
    if(pts.length<8) throw new Error(drT("ایستگاه کافی با دما و بارش کامل در این پنجره نیست؛ «کل دوره» را امتحان کنید","Not enough stations with complete temperature and precipitation in this window; try the whole record"));
    if(!$("caPalSel")||!$("caRes")) caBuildUI(); drStatus(drT("درون‌یابی و ترسیم…","Interpolating and drawing…")); await new Promise(r=>setTimeout(r,30));
    const sc={breaks:M.br,colors:M.col,fmt:M.fmt,step:1}, ttl=drT(M.fa,M.en), wl=XI.win==="all"?drT("کل دورهٔ ایستگاه","whole station record"):drT(`${FA(w[0])}–${FA(w[1])} شمسی`,`${w[0]}–${w[1]} (Solar Hijri)`);
    const cv=await caMap({ws:1,pts,title:ttl,sub:drT(`${M.unit[0]} · نرمال ماهانه: ${wl} · ${FA(pts.length)} ایستگاه`,`${M.unit[1]} · monthly normals: ${wl} · ${pts.length} stations`),unit:drT(M.unit[0],M.unit[1]),kind:"seq",scheme:sc,method:"auto",useElev:false,
      note:drT("طبقه‌ها گسسته‌اند و رنگ‌ها ترکیب نمی‌شوند. ماه‌ها شمسی‌اند (فروردین ≈ ۲۱ مارس–۲۰ آوریل).","Classes are discrete and colours are not blended. Months are Solar Hijri (Farvardin ≈ 21 Mar–20 Apr).")});
    const extra=XI.map==="ai"?drT(" PET با روش ثورنت‌ویت (فقط دما) برآورد شده و در مناطق خشک و گرم بیش‌برآورد یا کم‌برآورد دارد.",""):"";
    caCard(ttl+" — "+wl,cv,(M.cls?drT("طبقه‌ها (از کم به زیاد): ","Classes (low → high): ")+M.cls.map(c=>drT(c[0],c[1])).join(" · ")+".":"")+extra+drT(" ایستگاه‌های بدون دما یا بارش کامل در ۱۲ ماه کنار گذاشته شده‌اند."," Stations lacking complete temperature or precipitation for all 12 months are excluded."),{prepend:n=>{ $("drCards").prepend(n); }}); drStatus("");
  }catch(e){ console.error(e); drStatus("⚠ "+e.message); }
  XI.busy=false; }

/* ---------- رابط ---------- */
function xiStationOptions(q){ q=(q||"").trim().toLowerCase(); const arr=CLIM_META.st.filter(s=>s.lat!=null).map(s=>({s,n:caStName(s)})).filter(o=>!q||o.n.toLowerCase().includes(q)||String(o.s.id).includes(q)); arr.sort((a,b)=>a.n.localeCompare(b.n)); return arr.slice(0,500).map(o=>`<option value="${drEsc(o.s.id)}"${String(o.s.id)===String(XI.sid)?" selected":""}>${drEsc(o.n)}</option>`).join(""); }
function xiHTML(){
  if(XI.sid==null){ const s=CLIM_META.st.find(z=>z.lat!=null&&/تهران|tehran/i.test(caStName(z))); XI.sid=s?s.id:(CLIM_META.st[0]||{}).id; }
  const idxOpt=XI_DEF.map(d=>`<option value="${d[0]}"${XI.idx===d[0]?" selected":""}>${d[0]} — ${drT(d[1],d[2])}</option>`).join("");
  const pt=`<div class="dwCtl"><label>${drT("نوع مکان","Location type")}<select id="xiLoc"><option value="st"${XI.loc==="st"?" selected":""}>${drT("ایستگاه اطلس","Atlas station")}</option><option value="xy"${XI.loc==="xy"?" selected":""}>${drT("مختصات دلخواه","Custom coordinates")}</option></select></label>
    ${XI.loc==="st"?`<label>${drT("جست‌وجوی ایستگاه","Find station")}<input id="xiQ" type="search"></label><label>${drT("ایستگاه","Station")}<select id="xiSt" size="1">${xiStationOptions("")}</select></label>`:`<label>${drT("عرض جغرافیایی","Latitude")}<input id="xiLat" type="number" step="0.01" value="${XI.lat}"></label><label>${drT("طول جغرافیایی","Longitude")}<input id="xiLon" type="number" step="0.01" value="${XI.lon}"></label>`}
    <label>${drT("شاخص برای نمودار جداگانه","Index for the single-series chart")}<select id="xiIdx">${idxOpt}</select></label><button class="btn main" type="button" id="xiGo">${drT("محاسبه و رسم شاخص‌ها","Compute and draw indices")}</button></div>`;
  const wins=[["all",drT("کل دورهٔ ایستگاه","Whole station record")],["1361-1390",drT("۱۳۶۱–۱۳۹۰","1361–1390")],["1371-1400",drT("۱۳۷۱–۱۴۰۰","1371–1400")],["1381-1410",drT("۱۳۸۱–۱۴۱۰ (تا آخرین داده)","1381–1410 (to latest data)")]];
  const mp=`<div class="dwCtl"><label>${drT("شاخص","Index")}<select id="xiMap">${Object.keys(XI_MAPS).map(k=>`<option value="${k}"${XI.map===k?" selected":""}>${drT(XI_MAPS[k].fa,XI_MAPS[k].en)}</option>`).join("")}</select></label>
    <label>${drT("پنجرهٔ نرمال","Normals window")}<select id="xiWin">${wins.map(w=>`<option value="${w[0]}"${XI.win===w[0]?" selected":""}>${w[1]}</option>`).join("")}</select></label><button class="btn main" type="button" id="xiGoM">${drT("رسم نقشه","Draw map")}</button></div>`;
  return `<div class="dwSub"><button type="button" data-xs="pt" class="${XI.tab!=="map"?"on":""}">${drT("نقطه (داده‌ی روزانه)","Point (daily data)")}</button><button type="button" data-xs="map" class="${XI.tab==="map"?"on":""}">${drT("نقشهٔ ایران (نرمال‌های ماهانه)","Iran map (monthly normals)")}</button></div>${XI.tab==="map"?mp:pt}
    <p class="hint">${XI.tab==="map"
      ?drT("نقشه‌ها از نرمال‌های ماهانهٔ ایستگاه‌های اطلس ساخته می‌شوند و درون‌یابی‌اند؛ دومارتن، گوسن–باگنول، PCI، گورچینسکی و UNEP. طبقه‌ها گسسته‌اند.","Maps are built from the atlas stations' monthly normals and interpolated: De Martonne, Gaussen–Bagnouls, PCI, Gorczyński and UNEP. Classes are discrete.")
      :drT("۳۱ شاخص ETCCDI/xclim از داده‌ی روزانهٔ بازتحلیل ERA5 (۱۹۵۰ تا امروز) در نزدیک‌ترین نقطهٔ شبکهٔ ۰٫۲۵°؛ این داده مشاهدهٔ ایستگاهی نیست و در ارتفاع‌های ناهموار اریب دارد. فقط نمودار نمایش داده می‌شود.","31 ETCCDI/xclim indices from ERA5 reanalysis daily data (1950–present) at the nearest 0.25° grid point; this is not station observation and is biased in rough terrain. Only charts are shown.")}</p>`; }
function xiWire(m){ const g=id=>m.querySelector("#"+id), on=(id,f)=>{ const e=g(id); if(e) e.onchange=()=>f(e.value); };
  m.querySelectorAll(".dwSub button[data-xs]").forEach(b=>b.onclick=()=>{ XI.tab=b.dataset.xs; drRender(); });
  on("xiLoc",v=>{ XI.loc=v; drRender(); }); on("xiSt",v=>XI.sid=v); on("xiLat",v=>XI.lat=+v); on("xiLon",v=>XI.lon=+v); on("xiIdx",v=>XI.idx=v); on("xiMap",v=>XI.map=v); on("xiWin",v=>XI.win=v);
  const q=g("xiQ"); if(q) q.oninput=()=>{ const s=g("xiSt"); s.innerHTML=xiStationOptions(q.value); if(s.options.length){ s.selectedIndex=0; XI.sid=s.value; } };
  const a=g("xiGo"); if(a) a.onclick=xiRunPoint; const b=g("xiGoM"); if(b) b.onclick=xiRunMap; }
