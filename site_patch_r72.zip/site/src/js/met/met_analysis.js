/* ===== تحلیل علمی خودکار (r55) — Skew-T و آزمایشگاه محاسبات =====
   روش: «سامانهٔ خبرهٔ شفاف» با دو لایه:
   (۱) قواعد آستانه‌ای از جزوهٔ Skew-T (۱۳۸۵: LI، SI، TT، KI، SWEAT، EI/CAPE، CINH، CAP، HEL، SHR، EHI، BRN، PW، L57، جدول مقادیر بحرانی)
       و مراجع استاندارد (SPC، Bunkers 2000، Thompson 2003/2012، Johnson & Sugden 2014)؛
   (۲) احتمال محیطی هر پدیده با مدل لجستیک کوچک روی ویژگی‌های فازی [۰..۱]. وزن‌ها در MET.analysis.WEIGHTS ثابت و قابل‌بازرسی‌اند
       (پیش‌فرض = دانش خبره). MET.analysis.train() همان وزن‌ها را با رگرسیون لجستیک از نمونه‌های برچسب‌دار (رخداد/عدم‌رخداد) یاد می‌گیرد؛
       وزن‌های یادگرفته با MET.analysis.setWeights() جایگزین می‌شوند. هیچ‌چیز بی‌صدا یاد گرفته نمی‌شود (کنترل‌شده، آفلاین).
   مهم: «احتمال» یعنی مساعد‌بودن محیط (نه احتمال وقوع در یک نقطهٔ مشخص)؛ ماشهٔ شروع (جبهه، توپوگرافی، همگرایی) در سونداژ نیست.
   بدون DOM: در Node هم آزموده می‌شود. مقدار مفقود هرگز صفر نمی‌شود؛ بخش بدون دادهٔ کافی با علت گزارش می‌شود. */
(function(){
  "use strict";
  const M = globalThis.MET, C = M.C, T = M.thermo, PF = M.profile, W = M.wind, A = {};
  const fin = x => typeof x === "number" && isFinite(x);
  const clip = (x, a, b) => Math.min(Math.max(x, a), b);
  const ramp = (x, a, b) => fin(x) ? clip((x - a) / (b - a), 0, 1) : null;     // a→۰ و b→۱ (a>b هم مجاز: معکوس)
  const sig = z => 1 / (1 + Math.exp(-z));
  /* ---------- وزن‌ها (قابل‌جایگزینی) ---------- */
  const W0 = {
    tstorm:  {b:-2.6, w:{cape:2.8, li:1.2, ki:0.9, tt:0.8, rh:0.7, pw:0.5, cin:-1.7, cap:-1.2, lfc:-0.9}},
    severe:  {b:-3.2, w:{cape:1.7, shear:1.6, scp:1.1, srh:0.7, lr:0.5, cin:-1.3, rh:0.2}},
    hail:    {b:-3.0, w:{ship:2.4, cape:0.9, lr:0.9, shear:0.8, fzl:0.7, cin:-0.8}},
    gust:    {b:-3.0, w:{dcape:1.6, dry:1.0, lr03:1.0, cape:0.8, wind:0.7, cin:-0.5}},
    rain:    {b:-2.5, w:{pw:1.5, warm:1.0, cape:0.9, rh:1.0, slow:0.8, cin:-0.6}},
    tornado: {b:-4.4, w:{stp:2.2, srh1:1.0, lcl:0.9, shear:0.8, cape:0.6}}
  };
  let WT = JSON.parse(JSON.stringify(W0));
  A.WEIGHTS = () => JSON.parse(JSON.stringify(WT));
  A.setWeights = w => { if(w && typeof w === "object"){ for(const k in W0) if(w[k] && fin(w[k].b) && w[k].w) WT[k] = {b:w[k].b, w:Object.assign({}, W0[k].w, w[k].w)}; } };
  A.resetWeights = () => { WT = JSON.parse(JSON.stringify(W0)); };
  const score = (k, f) => { const m = WT[k]; let s = m.b; for(const n in m.w){ const v = f[n]; if(fin(v)) s += m.w[n] * v; } return s; };
  /* آموزش لجستیک (گام‌های گرادیان با L2 کوچک): rows=[{f:{..}, y:0|1}] ؛ خروجی وزن جدید برای hazard */
  A.train = function(hazard, rows, o){
    o = o || {}; const keys = Object.keys(W0[hazard].w), lr = o.lr || 0.3, it = o.iter || 1500, l2 = o.l2 == null ? 0.01 : o.l2;
    if(!rows || rows.length < 20) return {ok:false, why:"need_at_least_20_samples"};
    const pos = rows.filter(r => r.y === 1).length; if(pos < 5 || rows.length - pos < 5) return {ok:false, why:"need_5_events_and_5_nonevents"};
    let b = WT[hazard].b; const w = {}; keys.forEach(k => { w[k] = WT[hazard].w[k]; });
    for(let n = 0; n < it; n++){ let gb = 0; const g = {}; keys.forEach(k => { g[k] = 0; });
      for(const r of rows){ let s = b; keys.forEach(k => { if(fin(r.f[k])) s += w[k] * r.f[k]; }); const e = sig(s) - r.y; gb += e; keys.forEach(k => { if(fin(r.f[k])) g[k] += e * r.f[k]; }); }
      b -= lr * gb / rows.length; keys.forEach(k => { w[k] -= lr * (g[k] / rows.length + l2 * (w[k] - W0[hazard].w[k])); }); }
    let ll = 0; for(const r of rows){ let s = b; keys.forEach(k => { if(fin(r.f[k])) s += w[k] * r.f[k]; }); const p = clip(sig(s), 1e-6, 1 - 1e-6); ll -= r.y * Math.log(p) + (1 - r.y) * Math.log(1 - p); }
    return {ok:true, weights:{b, w}, logloss:ll / rows.length, n:rows.length, events:pos};
  };
  /* ---------- ویژگی‌ها از نتیجهٔ MET.lab.analyze ---------- */
  function meanLayer(wp, z0, z1){ if(!wp) return null; const n = Math.max(2, Math.round((z1 - z0) / 100)); let u = 0, v = 0, c = 0;
    for(let i = 0; i <= n; i++){ const z = z0 + (z1 - z0) * i / n, zz = wp.zAgl; if(z > zz[zz.length - 1] + 1e-6) return null; let k = 0; while(k < zz.length - 2 && zz[k + 1] < z) k++; const f = (z - zz[k]) / ((zz[k + 1] - zz[k]) || 1); u += wp.u[k] + f * (wp.u[k + 1] - wp.u[k]); v += wp.v[k] + f * (wp.v[k + 1] - wp.v[k]); c++; }
    return {u:u / c, v:v / c}; }
  const stullTw = (t, rh) => t * Math.atan(0.151977 * Math.sqrt(rh + 8.313659)) + Math.atan(t + rh) - Math.atan(rh - 1.676331) + 0.00391838 * Math.pow(rh, 1.5) * Math.atan(0.023101 * rh) - 4.686035;
  A.features = function(res){
    const prof = res.prof, I = res.items, sv = res.severe || {}, X = {}, n = prof.p.length, has = p => p <= prof.p[0] + 1e-9 && p >= prof.p[n - 1] - 1e-9;
    const lin = (p, k) => has(p) ? PF.interpLin(p, prof.p, prof[k]) : NaN, tc = p => lin(p, "Tk") - C.zeroC, tdc = p => lin(p, "Tdk") - C.zeroC;
    const z0 = fin(prof.z && prof.z[0]) ? prof.z[0] : null, agl = p => { const z = M.lab.heightAtP(prof, p); return fin(z) && z0 != null ? z - z0 : null; };
    X.p0 = prof.p[0]; X.T0 = prof.Tk[0] - C.zeroC; X.Td0 = prof.Tdk[0] - C.zeroC; X.spread0 = X.T0 - X.Td0; X.z0 = z0; X.rh0 = T.rhFromDewpoint(prof.Tk[0], prof.Tdk[0]) * 100;
    X.top = prof.p[n - 1]; X.n = n; X.hasWind = !!res.hasWind;
    for(const l of [850, 700, 500, 300]){ X["T" + l] = tc(l); X["Td" + l] = tdc(l); }
    X.has850 = has(850); X.has500 = has(500);
    X.cape = I.CAPE.v, X.cin = I.CIN.v, X.lclP = I.LCL.v, X.lclAgl = I.LCL.v != null ? agl(I.LCL.v) : null; X.lfcP = res.lfc, X.elP = res.el;
    X.lfcAgl = res.lfc != null ? agl(res.lfc) : null; X.elAgl = res.el != null ? agl(res.el) : null; X.noLfc = I.CAPE.note === "no_lfc";
    X.li = I.LI.v; X.si = I.SHOWALTER.v; X.k = I.K.v; X.tt = I.TT.v; X.vt = I.VT.v; X.ct = I.CT.v; X.pwat = I.PWAT.v;
    X.s01 = I.SHEAR.s01.v; X.s03 = I.SHEAR.s03.v; X.s06 = I.SHEAR.s06.v; X.srh01 = I.SRH.s01.v; X.srh03 = I.SRH.s03.v;
    X.scp = sv.SCP && sv.SCP.v; X.stpf = sv.STPF && sv.STPF.v; X.stpe = sv.STPE && sv.STPE.v; X.ship = sv.SHIP && sv.SHIP.v; X.lr75 = sv.LR75 && sv.LR75.v; X.fzl = sv.FZL && sv.FZL.v;
    X.parcels = {}; for(const k of ["SB", "ML", "MU"]){ const q = res.parcels[k]; X.parcels[k] = q && q.v != null ? {cape:q.v, cin:q.cin, lfc:q.lfc ? q.lfc.p : null, el:q.el ? q.el.p : null, lcl:q.lcl ? q.lcl.p : null} : null; }
    /* ردهٔ همرفتی: میانگین RH از سطح تا ۵۰۰ hPa (وزن فشاری) */
    { const top = Math.max(500, X.top), ps = prof.p.filter(p => p >= top - 1e-9); if(ps.length > 1){ const rh = ps.map((p, i) => T.rhFromDewpoint(prof.Tk[prof.p.indexOf(p)], prof.Tdk[prof.p.indexOf(p)]) * 100); X.rhMean = PF.trapz(rh, ps) / (ps[ps.length - 1] - ps[0]); X.rhTopP = top; } }
    /* آهنگ کاهش دما لایه‌ها (K/km) */
    const lapse = (pa, pb) => { const za = M.lab.heightAtP(prof, pa), zb = M.lab.heightAtP(prof, pb); if(!fin(za) || !fin(zb) || zb <= za) return null; const ta = lin(pa, "Tk"), tb = lin(pb, "Tk"); return (ta - tb) / ((zb - za) / 1000); };
    if(z0 != null){ const p3 = (() => { const wz = z0 + 3000; for(let i = 0; i < n - 1; i++){ if(fin(prof.z[i]) && fin(prof.z[i + 1]) && prof.z[i] <= wz && prof.z[i + 1] >= wz){ const f = (wz - prof.z[i]) / (prof.z[i + 1] - prof.z[i]); return Math.exp(Math.log(prof.p[i]) + f * (Math.log(prof.p[i + 1]) - Math.log(prof.p[i]))); } } return null; })(); X.p3km = p3; X.lr03 = p3 ? lapse(prof.p[0], p3) : null; }
    X.lr7 = X.lr75; X.lrSfc700 = has(700) ? lapse(prof.p[0], 700) : null;
    /* وارونگی‌ها (زیر ۵۰۰ hPa): لایه‌های پیوستهٔ افزایش دما با ارتفاع */
    X.inv = []; { let a = -1; for(let i = 0; i < n - 1; i++){ if(prof.p[i] < 450) break; const up = prof.Tk[i + 1] > prof.Tk[i] + 0.05; if(up && a < 0) a = i; if((!up || i === n - 2) && a >= 0){ const b = up ? i + 1 : i; const dT = prof.Tk[b] - prof.Tk[a]; if(dT >= 0.5) X.inv.push({base:prof.p[a], top:prof.p[b], dT, surf:a === 0, baseAgl:agl(prof.p[a]), topAgl:agl(prof.p[b])}); a = -1; } } }
    /* تراز انجماد و دمای تر صفر (Stull 2011، تقریب) */
    X.fzlP = null; for(let i = 0; i < n - 1; i++) if(prof.Tk[i] > C.zeroC && prof.Tk[i + 1] <= C.zeroC){ const f = (prof.Tk[i] - C.zeroC) / (prof.Tk[i] - prof.Tk[i + 1]); X.fzlP = Math.exp(Math.log(prof.p[i]) + f * (Math.log(prof.p[i + 1]) - Math.log(prof.p[i]))); break; }
    X.fzlAgl = X.fzlP ? agl(X.fzlP) : null;
    const tw = prof.p.map((p, i) => { const t = prof.Tk[i] - C.zeroC, rh = clip(T.rhFromDewpoint(prof.Tk[i], prof.Tdk[i]) * 100, 5, 99); return (t > -20 && t < 50) ? stullTw(t, rh) : null; });
    X.Tw0 = tw[0]; X.wbzP = null; for(let i = 0; i < n - 1; i++) if(fin(tw[i]) && fin(tw[i + 1]) && tw[i] > 0 && tw[i + 1] <= 0){ const f = tw[i] / (tw[i] - tw[i + 1]); X.wbzP = Math.exp(Math.log(prof.p[i]) + f * (Math.log(prof.p[i + 1]) - Math.log(prof.p[i]))); break; }
    X.wbzAgl = X.wbzP ? agl(X.wbzP) : null;
    /* لایه‌های ابری (RH≥۸۵٪ پیوسته) و لایهٔ خشک (RH<۳۰٪) */
    const rhA = prof.p.map((p, i) => T.rhFromDewpoint(prof.Tk[i], prof.Tdk[i]) * 100); X.rhProf = rhA;
    X.clouds = []; { let a = -1; for(let i = 0; i <= n; i++){ const wet = i < n && rhA[i] >= 85; if(wet && a < 0) a = i; if(!wet && a >= 0){ X.clouds.push({base:prof.p[a], top:prof.p[i - 1], baseAgl:agl(prof.p[a]), topAgl:agl(prof.p[i - 1]), n:i - a}); a = -1; } } }
    X.dryMid = null; { const ps = prof.p.map((p, i) => i).filter(i => prof.p[i] <= X.p0 - 150 && prof.p[i] >= 400); if(ps.length){ X.dryMid = Math.min(...ps.map(i => rhA[i])); } }
    /* CCL و دمای همرفت Tc (PDF) */
    { const w0 = T.satMixingRatio(prof.p[0], prof.Tdk[0]); let ccl = null; for(let i = 0; i < n - 1; i++){ const f = i2 => T.dewpointFromE(T.vaporPressure(prof.p[i2], w0)); const d0 = prof.Tk[i] - f(i), d1 = prof.Tk[i + 1] - f(i + 1); if(d0 >= 0 && d1 < 0){ const fr = d0 / (d0 - d1); ccl = {p:Math.exp(Math.log(prof.p[i]) + fr * (Math.log(prof.p[i + 1]) - Math.log(prof.p[i]))), T:prof.Tk[i] + fr * (prof.Tk[i + 1] - prof.Tk[i])}; break; } }
      if(ccl){ X.cclP = ccl.p; X.cclAgl = agl(ccl.p); X.Tc = T.dryLapse(prof.p[0], ccl.T, ccl.p) - C.zeroC; } }
    /* ظرفیت CAP: بیشینهٔ اختلاف (محیط − پارسل سطحی) زیر LFC */
    X.capStr = null; { const pc = M.lab.parcelCurve(prof, "SB"); if(pc && X.lfcP != null){ let mx = 0; pc.p.forEach((p, i) => { if(p <= prof.p[0] - 5 && p >= X.lfcP){ const te = PF.interpLog(p, prof.p, prof.Tk); if(fin(te) && fin(pc.Tk[i])) mx = Math.max(mx, te - pc.Tk[i]); } }); X.capStr = mx; } }
    /* DCAPE تقریبی: ترازی با کمینهٔ θe در ۴۰۰ hPa اول؛ فرود آدیاباتیک اشباع تا سطح */
    X.dcape = null; { const lim = prof.p[0] - 400, idx = prof.p.map((p, i) => i).filter(i => prof.p[i] >= lim && prof.p[i] < prof.p[0] - 30); if(idx.length && fin(prof.z && prof.z[0])){ let bi = idx[0], bm = Infinity; idx.forEach(i => { const te = T.thetaE(prof.p[i], prof.Tk[i], prof.Tdk[i]); if(te < bm){ bm = te; bi = i; } });
        const tw0 = tw[bi]; if(fin(tw0)){ const pd = []; for(let p = prof.p[bi]; p <= prof.p[0]; p += 10) pd.push(p); if(pd[pd.length - 1] < prof.p[0]) pd.push(prof.p[0]); const tpar = T.moistLapse(pd, tw0 + C.zeroC, prof.p[bi]); let sum = 0;
          for(let k = 0; k < pd.length - 1; k++){ const te = PF.interpLog((pd[k] + pd[k + 1]) / 2, prof.p, prof.Tk), tp = (tpar[k] + tpar[k + 1]) / 2, dz = C.Rd * te / C.g * Math.log(pd[k + 1] / pd[k]); if(fin(te) && fin(tp)) sum += C.g * (te - tp) / te * dz; } X.dcape = Math.max(0, sum); X.dcapeP = prof.p[bi]; } } }
    /* باد */
    const wp = W.windProfile(prof); X.wp = !!wp;
    if(wp){ const m06 = meanLayer(wp, 0, 6000), m05 = meanLayer(wp, 0, 500); if(m06){ X.meanWind06 = Math.hypot(m06.u, m06.v); X.meanDir06 = W.direction(m06.u, m06.v); }
      if(m06 && m05 && fin(X.cape)){ const U = Math.hypot(m06.u - m05.u, m06.v - m05.v); if(U > 0) X.brn = X.cape / (0.5 * U * U); X.brnU = U; }
      const spdAt = p => { const u = PF.interpLog(p, prof.p, prof.u), v = PF.interpLog(p, prof.p, prof.v); return fin(u) && fin(v) ? Math.hypot(u, v) / W.KT : NaN; };
      const dirAt = p => { const u = PF.interpLog(p, prof.p, prof.u), v = PF.interpLog(p, prof.p, prof.v); return fin(u) && fin(v) ? W.direction(u, v) : NaN; };
      if(has(850) && has(500) && fin(X.Td850) && fin(X.tt)){ const t2 = Math.max(X.tt - 49, 0), sh = 125 * (Math.sin((dirAt(500) - dirAt(850)) * Math.PI / 180) + 0.2); X.sweat = 12 * Math.max(X.Td850, 0) + 20 * t2 + 2 * spdAt(850) + spdAt(500) + (spdAt(850) >= 15 && spdAt(500) >= 15 && dirAt(850) >= 130 && dirAt(850) <= 250 && dirAt(500) >= 210 && dirAt(500) <= 310 && dirAt(500) - dirAt(850) > 0 ? sh : 0); } }
    X.shr03 = X.s03 != null ? X.s03 / 3 : null;                    // m/s بر km = ‎×۱۰⁻³ s⁻¹ (SHR جزوه)
    X.ehi01 = fin(X.cape) && fin(X.srh01) ? X.cape * X.srh01 / 160000 : null; X.ehi03 = fin(X.cape) && fin(X.srh03) ? X.cape * X.srh03 / 160000 : null;
    X.wmax = fin(X.cape) ? Math.sqrt(2 * Math.max(X.cape, 0)) : null;
    X.pwMm = X.pwat;
    /* ویژگی‌های فازی [۰..۱] */
    const f = {};
    const cape = fin(X.cape) ? X.cape : 0;
    f.cape = ramp(cape, 0, 1800); f.li = ramp(X.li, 0, -6); f.ki = ramp(X.k, 15, 35); f.tt = ramp(X.tt, 44, 54);
    f.rh = ramp(X.rhMean, 35, 75); f.pw = ramp(X.pwMm, 10, 40); f.cin = ramp(fin(X.cin) ? -X.cin : 0, 20, 200); f.cap = ramp(X.capStr, 1, 6);
    f.lfc = ramp(X.lfcAgl, 1500, 5000); f.shear = ramp(X.s06, 8, 25); f.scp = ramp(X.scp, 0, 4); f.srh = ramp(X.srh03, 80, 300); f.lr = ramp(X.lr75, 6, 8.5);
    f.ship = ramp(X.ship, 0, 2); f.fzl = X.fzlAgl != null ? ramp(X.fzlAgl, 1500, 3200) * ramp(X.fzlAgl, 6000, 4200) : null; if(f.fzl == null && X.fzlAgl != null) f.fzl = 0;
    f.dcape = ramp(X.dcape, 300, 1300); f.dry = ramp(X.spread0, 8, 28); f.lr03 = ramp(X.lr03, 7, 9.5); f.wind = ramp(X.meanWind06, 6, 20);
    f.warm = X.lclAgl != null && X.fzlAgl != null ? ramp(X.fzlAgl - X.lclAgl, 1500, 4500) : null; f.slow = ramp(X.meanWind06, 14, 5);
    f.stp = ramp(fin(X.stpe) ? X.stpe : X.stpf, 0, 3); f.srh1 = ramp(X.srh01, 40, 200); f.lcl = ramp(X.lclAgl, 2200, 800);
    X.f = f; return X;
  };
  A.probs = function(X){
    const out = []; const R = (id, fa, en, k, note) => { const s = score(k, X.f), p = Math.round(sig(s) * 100); out.push({id, fa, en, p, lv:p < 10 ? 0 : p < 25 ? 1 : p < 50 ? 2 : p < 75 ? 3 : 4, drivers:drivers(k, X.f), note}); };
    const drivers = (k, f) => { const m = WT[k], arr = []; for(const n in m.w){ if(fin(f[n]) && Math.abs(m.w[n] * f[n]) >= 0.35) arr.push([n, m.w[n] * f[n]]); } return arr.sort((a, b) => Math.abs(b[1]) - Math.abs(a[1])).slice(0, 4); };
    R("tstorm", "رعدوبرق / همرفت عمیق", "Thunderstorms / deep convection", "tstorm");
    R("severe", "توفان شدید (ترکیبی)", "Severe convective storm (combined)", "severe", !X.hasWind ? "no_wind" : null);
    R("hail", "تگرگ", "Hail", "hail");
    R("gust", "تندبادهای همرفتی / ریزجهندهٔ خشک", "Convective wind gusts / microbursts", "gust");
    R("rain", "بارش سنگین / سیلاب لحظه‌ای", "Heavy rain / flash flooding", "rain");
    R("tornado", "گردباد (تورنادو، آستانهٔ پایین)", "Tornado (low-end threshold)", "tornado", !X.hasWind ? "no_wind" : null);
    return out;
  };
  A.LV = [["بسیار کم", "Very low"], ["کم", "Low"], ["متوسط", "Moderate"], ["زیاد", "High"], ["بسیار زیاد", "Very high"]];
  /* ---------- متن ---------- */
  const NM = {cape:"CAPE", li:"LI", ki:"KI", tt:"TT", rh:["رطوبت میانگین", "mean RH"], pw:["آب قابل بارش", "PW"], cin:"CIN", cap:["سرپوش", "cap"], lfc:["ارتفاع LFC", "LFC height"], shear:["برش ۰–۶km", "0–6 km shear"], scp:"SCP", srh:"SRH", lr:["آهنگ ۷۰۰–۵۰۰", "700–500 lapse"], ship:"SHIP", fzl:["تراز انجماد", "freezing level"], dcape:"DCAPE", dry:["لایهٔ زیرابری خشک", "dry sub-cloud layer"], lr03:["آهنگ ۰–۳km", "0–3 km lapse"], wind:["باد میانی", "mid-level wind"], warm:["ضخامت لایهٔ گرم", "warm-cloud depth"], slow:["حرکت کند", "slow motion"], stp:"STP", srh1:["SRH ۰–۱km", "SRH 0–1 km"], lcl:["LCL پایین", "low LCL"]};
  function make(res, o, kind){
    o = o || {}; const en = !!o.en, t = (fa, en_) => en ? en_ : fa, X = A.features(res), P = A.probs(X), S = [], B = (h, lines, id) => { lines = lines.filter(Boolean); if(lines.length) S.push({id:id || "", h, lines}); };
    const SEP = en ? "; " : "؛ ", CM = en ? ", " : "، ", num = (v, d) => fin(v) ? "⁦" + (Math.round(v * Math.pow(10, d || 0)) / Math.pow(10, d || 0)).toString() + "⁩" : "—";
    const hp = (p) => num(p, 0) + " hPa", lvl = (p, a) => fin(p) ? hp(p) + (fin(a) ? " (" + num(a, 0) + " m AGL)" : "") : "—";
    const cls = (v, arr) => { for(const [lim, fa, e] of arr) if(v < lim) return t(fa, e); return t(arr[arr.length - 1][1], arr[arr.length - 1][2]); };
    /* ۱) وضعیت سطح و ساختار کلی */
    const head = [];
    head.push(t("سونداژ از ", "Sounding from ") + hp(X.p0) + t(" (سطح) تا ", " (surface) to ") + hp(X.top) + t("، با ", ", with ") + num(X.n) + t(" تراز معتبر", " valid levels") + (fin(X.z0) ? t("؛ ارتفاع سطح ≈ ", "; surface elevation ≈ ") + num(X.z0) + " m" : "") + ".");
    head.push(t("دمای سطح ", "Surface temperature ") + num(X.T0, 1) + " °C" + t("، نقطهٔ شبنم ", ", dew point ") + num(X.Td0, 1) + " °C" + t("، رطوبت نسبی ", ", RH ") + num(X.rh0) + "%" + t("، گسترهٔ T−Td ", ", T−Td spread ") + num(X.spread0, 1) + " °C" +
      (X.spread0 > 20 ? t(" ← هوای سطحی بسیار خشک؛ پایهٔ ابر بلند و تبخیر بارش در زیر ابر (ویرگا) محتمل است.", " ← very dry surface air; high cloud base and sub-cloud rain evaporation (virga) likely.") : X.spread0 < 3 ? t(" ← هوای نزدیک اشباع؛ مه/ابر پست و رطوبت بالای سطح.", " ← near-saturated air; fog/low cloud and high surface humidity.") : ""));
    if(!X.has850) head.push(t("سطح ۸۵۰ hPa زیر سطح زمین است؛ شاخص‌های کلاسیک وابسته به ۸۵۰ (SI، TT، KI، SWEAT) در ارتفاع‌های بلند ایران تعریف‌پذیر نیستند و به‌جای آن CAPE/CIN و شاخص‌های پارسل مبنای قضاوت‌اند.", "The 850 hPa level is below ground; classical 850-based indices (SI, TT, KI, SWEAT) are undefined at high Iranian elevations, so parcel-based CAPE/CIN guide the assessment."));
    B(t("۱. وضعیت سطحی و ساختار کلی پروفایل", "1. Surface state and profile overview"), head, "overview");
    /* ۲) پایداری و آهنگ کاهش دما (جزوه: ELR در برابر DALR/MALR؛ L57) */
    const st = [];
    if(fin(X.lrSfc700)) st.push(t("آهنگ کاهش دما سطح→۷۰۰ hPa: ", "Lapse rate surface→700 hPa: ") + num(X.lrSfc700, 1) + " K/km" + (X.lrSfc700 > 9.8 ? t(" — بیش از آدیاباتیک خشک (فوق‌آدیاباتیک): ناپایداری مطلق، آمیختگی شدید همرفتی لایهٔ مرزی.", " — exceeds the dry adiabatic rate (super-adiabatic): absolute instability, vigorous boundary-layer mixing.") : X.lrSfc700 > 6.5 ? t(" — بین آدیاباتیک اشباع و خشک: ناپایداری مشروط.", " — between moist and dry adiabats: conditional instability.") : t(" — کمتر از آهنگ استاندارد: پایدار تا خنثی.", " — below standard lapse rate: stable to neutral.")));
    if(fin(X.lr75)) st.push(t("L57 (آهنگ ۷۰۰–۵۰۰ hPa): ", "L57 (700–500 hPa lapse rate): ") + num(X.lr75, 1) + " K/km — " + (X.lr75 < 5.5 ? t("هوا پایدار است (L57<5.5).", "stable (L57 < 5.5).") : X.lr75 < 9 ? t("ناپایداری شرطی (۵٫۵<L57<۹)؛ در حضور رطوبت کافی در لایهٔ مرزی ناپایدار می‌شود.", "conditionally unstable (5.5 < L57 < 9); becomes unstable with sufficient boundary-layer moisture.") : t("بسیار ناپایدار (L57>۹).", "very unstable (L57 > 9).")) + (X.lr75 >= 7.5 ? t(" مقادیر ≥۷٫۵ آهنگ‌های میان‌ترازی تند و مساعد برای تگرگ‌اند.", " Values ≥ 7.5 are steep mid-level lapse rates favourable for hail.") : ""));
    if(fin(X.lr03)) st.push(t("آهنگ ۰–۳ km: ", "0–3 km lapse rate: ") + num(X.lr03, 1) + " K/km" + (X.lr03 >= 8 ? t(" — پروفایل «V وارونه» (لایهٔ زیرابری خشک و عمیق): پتانسیل تندباد و ریزجهندهٔ خشک.", " — inverted-V type profile (deep dry sub-cloud layer): wet/dry microburst potential.") : ""));
    if(X.inv.length){ const s = X.inv.slice(0, 3).map(v => (v.surf ? t("وارونگی سطحی ", "surface inversion ") : t("وارونگی مرتفع ", "elevated inversion ")) + hp(v.base) + "→" + hp(v.top) + " (+" + num(v.dT, 1) + " K)").join(SEP); st.push(t("وارونگی/لایهٔ پایدار: ", "Inversions / stable layers: ") + s + t(". وارونگی مانع صعود پارسل و حبس آلاینده‌ها/رطوبت زیر خود می‌شود.", ". An inversion caps parcel ascent and traps pollutants/moisture beneath it.")); }
    else st.push(t("وارونگی قابل‌توجه (≥۰٫۵ K) زیر ۴۵۰ hPa دیده نمی‌شود.", "No notable inversion (≥ 0.5 K) found below 450 hPa."));
    if(fin(X.fzlP)) st.push(t("تراز صفر درجه: ", "Freezing level: ") + lvl(X.fzlP, X.fzlAgl) + (fin(X.wbzP) ? t("؛ دمای تر صفر (تقریب Stull): ", "; wet-bulb zero (Stull approx.): ") + lvl(X.wbzP, X.wbzAgl) : "") + ".");
    else if(X.T0 <= 0) st.push(t("دمای سطح زیر صفر است؛ کل ستون زیر انجماد در لایهٔ سطحی.", "Surface is at or below freezing."));
    if(fin(X.Tw0)) st.push(t("دمای تر سطحی ≈ ", "Surface wet-bulb ≈ ") + num(X.Tw0, 1) + " °C" + (X.T0 <= 4 && X.Tw0 <= 1 ? t(" — اگر بارشی رخ دهد، نوع آن به برف/آب‌نیم‌یخ متمایل است.", " — precipitation, if any, tends toward snow/sleet.") : X.Tw0 > 1 ? t(" — بارش، در صورت وقوع، به‌صورت باران است.", " — precipitation, if any, would fall as rain.") : ""));
    B(t("۲. پایداری، آهنگ کاهش دما و لایه‌بندی", "2. Stability, lapse rates and layering"), st, "stab");
    /* ۳) انرژی و پارسل */
    const en2 = [];
    if(fin(X.cape)){ const c = X.cape; en2.push(t("CAPE پارسل ", "CAPE of the ") + res.parcelType + ": " + num(c) + " J/kg — " + (c < 1 ? t("بدون انرژی مثبت (EI<1): صعود شناور وجود ندارد.", "no positive buoyancy (EI < 1): no free ascent.") : c < 1500 ? t("انرژی همرفتی مثبت؛ همرفت ضعیف تا متوسط.", "positive convective energy; weak to moderate convection.") : c < 2500 ? t("انرژی بزرگ (۱۵۰۰–۲۵۰۰): همرفت قوی.", "large energy (1500–2500): strong convection.") : t("انرژی بسیار زیاد (>۲۵۰۰): همرفت بسیار قوی/شدید.", "extreme energy (> 2500): very strong/severe convection.")));
      if(c > 0) en2.push(t("بیشینهٔ سرعت صعود نظری √(2·CAPE) ≈ ", "Theoretical maximum updraft √(2·CAPE) ≈ ") + num(X.wmax, 0) + " m/s.");
      en2.push("CIN: " + num(X.cin) + " J/kg — " + (!fin(X.cin) ? "—" : X.cin > -25 ? t("بازدارندگی ناچیز؛ شروع همرفت آسان.", "negligible inhibition; initiation is easy.") : X.cin > -100 ? t("بازدارندگی متوسط؛ به ماشه (گرمایش روزانه، همگرایی، کوه) نیاز است.", "moderate inhibition; needs a trigger (daytime heating, convergence, terrain).") : X.cin > -200 ? t("بازدارندگی قوی؛ همرفت سطحی بعید و شروع فقط با ماشهٔ قوی.", "strong inhibition; surface-based convection unlikely without a strong trigger.") : t("سرپوش بسیار قوی؛ همرفت سطحی عملاً مهار می‌شود.", "very strong cap; surface-based convection effectively suppressed.")));
      if(fin(X.capStr)) en2.push(t("شدت سرپوش (بیشینهٔ T_env−T_parcel زیر LFC) ≈ ", "Cap strength (max T_env−T_parcel below LFC) ≈ ") + num(X.capStr, 1) + " K" + (X.capStr > 2 ? t(" (CAP>2: طبق جزوه تا دست‌کم دو ساعت همرفت روی نمی‌دهد مگر با ماشه).", " (CAP > 2: per the handbook, no convection for at least 2 h without a trigger).") : "."));
      en2.push("LCL: " + lvl(X.lclP, X.lclAgl) + (X.lclAgl != null ? (X.lclAgl > 2500 ? t(" — پایهٔ ابر بسیار بلند (جوّ خشک)؛ ابرها کم‌بارش‌تر و تندباد محتمل‌تر.", " — very high cloud base (dry atmosphere): lower rain efficiency, gusts more likely.") : X.lclAgl < 1000 ? t(" — پایهٔ ابر پست (مرطوب)؛ مساعد بارش کارآمد.", " — low cloud base (moist): favourable for efficient rain.") : "") : ""));
      if(X.noLfc) en2.push(t("پارسل به LFC نمی‌رسد؛ CAPE صفر معتبر است (جو در برابر صعود پارسل پایدار).", "The parcel never reaches an LFC; CAPE is a valid zero (stable to parcel ascent)."));
      else { en2.push("LFC: " + lvl(X.lfcP, X.lfcAgl) + (fin(X.lfcP) ? (X.lfcP >= 600 ? t(" — پایین‌تر از تراز ۶۰۰ hPa؛ طبق تجربهٔ جزوه احتمال رعدوبرق وجود دارد.", " — below the 600 hPa level (higher pressure); per the handbook experience, thunderstorm occurrence is possible.") : t(" — LFC بالاتر از ۶۰۰ hPa؛ همرفت مرتفع/پایه‌بلند (ابرهای میانی) محتمل‌تر از رعدوبرق عمیق.", " — LFC above 600 hPa; elevated/high-based convection is likelier than deep thunderstorms.")) : "")); en2.push("EL: " + lvl(X.elP, X.elAgl) + (fin(X.elP) && fin(X.cape) ? t(" — بالاترین رشد ابر تا این تراز؛ هرچه EL بالاتر، سندان بلندتر و رعدوبرق شدیدتر.", " — cloud tops grow up to about this level; the higher the EL, the taller the anvil and the stronger the lightning.") : "")); }
      const pcs = X.parcels, ks = ["SB", "ML", "MU"].filter(k => pcs[k]); if(ks.length > 1) en2.push(t("حساسیت به نوع پارسل: ", "Parcel-type sensitivity: ") + ks.map(k => k + " " + num(pcs[k].cape) + "/" + num(pcs[k].cin)).join(" · ") + t(" (CAPE/CIN). اختلاف زیاد یعنی نتیجه به آمیختگی لایهٔ مرزی وابسته است.", " (CAPE/CIN). A large spread means the outcome depends on boundary-layer mixing."));
      if(fin(X.cclP) && fin(X.Tc)) en2.push(t("CCL ≈ ", "CCL ≈ ") + lvl(X.cclP, X.cclAgl) + t("؛ دمای همرفت Tc ≈ ", "; convective temperature Tc ≈ ") + num(X.Tc, 1) + " °C" + t(" — اگر بیشینهٔ دمای روز از Tc بیشتر شود همرفت سطحی (ابر کومولوس) شروع می‌شود، وگرنه همرفت خشک/بی‌ابر می‌ماند.", " — if the daytime maximum exceeds Tc, surface-based cumulus convection starts; otherwise convection stays dry/cloud-free."));
    } else en2.push(t("CAPE محاسبه نشد: ", "CAPE not computed: ") + M.lab.whyText(I_(res).CAPE.why, en));
    B(t("۳. انرژی همرفتی و پارسل", "3. Convective energy and parcel"), en2, "energy");
    function I_(r){ return r.items; }
    /* ۴) شاخص‌ها — با آستانه‌های جزوه */
    const ix = [];
    if(fin(X.li)) ix.push("LI = " + num(X.li, 1) + " °C: " + (X.li > 0 ? t("جو پایدار", "stable") : X.li > -4 ? t("کمی ناپایدار", "slightly unstable") : X.li > -7 ? t("نسبتاً ناپایدار", "fairly unstable") : X.li > -11 ? t("شدیداً ناپایدار", "highly unstable") : t("ناپایداری بسیار وخیم", "extremely unstable")) + t(" (آستانه‌های ۰/−۴/−۷/−۱۰)", " (thresholds 0/−4/−7/−10)"));
    if(fin(X.si)) ix.push("SI = " + num(X.si, 1) + " °C: " + (X.si > 3 ? t("پایدار", "stable") : X.si > 1 ? t("رعد و برق رگبار و گاهی محتمل نیست مگر ماشه قوی باشد", "showers possible, thunder rare") : X.si > -3 ? t("رگبار و گاهی رعد و برق", "showers and occasional thunder") : X.si > -6 ? t("رعد و برق زیاد", "thunderstorms likely") : t("رعد و برق شدید", "severe thunderstorms")) + t(" (شوالتر؛ برش ۸۵۰→۵۰۰)", " (Showalter; 850→500)"));
    if(fin(X.tt)) ix.push("TT = " + num(X.tt, 0) + ": " + (X.tt < 44 ? t("همرفت بعید", "convection unlikely") : X.tt < 51 ? t("همرفت محتمل", "convection possible") : X.tt < 53 ? t("توفان‌های شدید و جدا از هم محتمل", "isolated severe storms possible") : X.tt < 56 ? t("توفان‌های شدید پراکنده در مقیاس وسیع", "widely scattered severe storms") : t("توفان‌های شدید پراکنده", "numerous severe storms")) + t(" (VT=", " (VT=") + num(X.vt, 0) + ", CT=" + num(X.ct, 0) + ")");
    if(fin(X.k)) ix.push("KI = " + num(X.k, 0) + ": " + (X.k < 15 ? t("احتمال همرفت وجود ندارد", "no convection expected") : X.k < 26 ? t("پتانسیل اندک", "low potential") : X.k < 40 ? t("پتانسیل متوسط", "moderate potential") : t("پتانسیل بالا", "high potential")) + t(" (فقط پتانسیل؛ نه شدت)", " (potential only; not severity)"));
    if(fin(X.sweat)) ix.push("SWEAT = " + num(X.sweat, 0) + ": " + (X.sweat < 150 ? t("زیر آستانه", "below threshold") : X.sweat < 300 ? t("توفان شدید نسبتاً محتمل", "severe storms fairly likely") : X.sweat < 400 ? t("امکان توفان‌های شدید", "severe storms possible") : t("احتمال توفندهای شدید", "tornadic storms possible")));
    if(fin(X.pwMm)) ix.push("PW = " + num(X.pwMm, 1) + " mm (" + num(X.pwMm / 25.4, 2) + " in): " + (X.pwMm > 44.5 ? t("جو مرطوب (PW>۱٫۷۵ in)", "moist atmosphere (PW > 1.75 in)") : X.pwMm < 19 ? t("جو نسبتاً خشک (PW<۰٫۷۵ in)", "relatively dry atmosphere (PW < 0.75 in)") : t("رطوبت متوسط", "moderate moisture")));
    if(fin(X.rhMean)) ix.push(t("RH میانگین سطح→", "Mean RH surface→") + num(X.rhTopP) + " hPa = " + num(X.rhMean, 0) + "%: " + (X.rhMean <= 40 ? t("بسیار کم", "very low") : X.rhMean <= 60 ? t("کم", "low") : X.rhMean <= 80 ? t("متوسط", "moderate") : t("بسیار مرطوب", "very moist")));
    if(fin(X.dcape)) ix.push("DCAPE ≈ " + num(X.dcape, 0) + " J/kg " + t("(تقریب)", "(approx.)") + ": " + (X.dcape < 500 ? t("تندباد نزولی ضعیف", "weak downdraft winds") : X.dcape < 1000 ? t("تندباد نزولی متوسط تا قوی", "moderate-to-strong downdraft winds") : t("تندباد/ریزجهندهٔ شدید محتمل", "damaging downburst winds possible")) + (fin(X.dcape) ? t("؛ بیشینهٔ نظری ≈ ", "; theoretical max ≈ ") + num(Math.sqrt(2 * X.dcape), 0) + " m/s" : ""));
    B(t("۴. شاخص‌های ناپایداری (آستانه‌های جزوه و مراجع)", "4. Instability indices (handbook and literature thresholds)"), ix, "idx");
    /* جدول مقادیر بحرانی */
    const crit = [["RH", fin(X.rhMean) ? X.rhMean > 61 : null], ["L57", fin(X.lr75) ? X.lr75 > 5.5 : null], ["LI", fin(X.li) ? X.li < -5 : null], ["SI", fin(X.si) ? X.si < -5 : null], ["TT", fin(X.tt) ? X.tt > 44 : null], ["KI", fin(X.k) ? X.k > 26 : null], ["SWEAT", fin(X.sweat) ? X.sweat > 150 : null], ["EI(CAPE)", fin(X.cape) ? X.cape > 1500 : null], ["CAP", fin(X.capStr) ? X.capStr < 2 : null], ["HEL(SRH03)", fin(X.srh03) ? X.srh03 > 150 : null], ["SHR", fin(X.shr03) ? X.shr03 > 6 : null], ["EHI", fin(X.ehi03) ? X.ehi03 > 1 : null], ["BRN", fin(X.brn) ? X.brn > 8 : null], ["PW>1.75in", fin(X.pwMm) ? X.pwMm > 44.5 : null]];
    const avail = crit.filter(c => c[1] !== null), hit = avail.filter(c => c[1]);
    if(avail.length) B(t("۵. جدول مقادیر بحرانی جزوه", "5. Handbook critical-value table"), [t("از ", "Of ") + num(avail.length) + t(" معیار قابل‌محاسبه، ", " computable criteria, ") + num(hit.length) + t(" معیار از مقدار بحرانی عبور کرده است: ", " exceed their critical value: ") + (hit.map(c => c[0]).join(CM) || "—") + ".",
      t("هرچه تعداد معیارهای بحرانی بیشتر باشد، جو به آستانهٔ ناپایداری/توفان نزدیک‌تر است؛ معیارهای وابسته به ۸۵۰ hPa یا باد در صورت نبود داده شمرده نشده‌اند.", "The more criteria exceed critical values, the closer the atmosphere is to the instability/storm threshold; 850-hPa- or wind-dependent criteria are skipped when data are missing.")], "crit");
    /* ۶) باد و برش */
    const wd = [];
    if(X.hasWind){
      wd.push(t("برش بردار: ۰–۱ km = ", "Bulk shear: 0–1 km = ") + num(X.s01, 1) + " · 0–3 km = " + num(X.s03, 1) + " · 0–6 km = " + num(X.s06, 1) + " m/s" + (fin(X.s06) ? " — " + (X.s06 < 10 ? t("برش ضعیف: تک‌سلول/پالسی و کم‌دوام.", "weak shear: single-cell/pulse, short-lived.") : X.s06 < 18 ? t("برش متوسط: چندسلولی سازمان‌یافته.", "moderate shear: organised multicells.") : X.s06 < 25 ? t("برش قوی: امکان ابرسلول و خط توفان.", "strong shear: supercells and squall lines possible.") : t("برش بسیار قوی: ابرسلول بادوام محتمل.", "very strong shear: long-lived supercells likely.")) : ""));
      if(fin(X.shr03)) wd.push("SHR (0–3 km) = " + num(X.shr03, 1) + " ×10⁻³ s⁻¹: " + (X.shr03 <= 3 ? t("ضعیف", "weak") : X.shr03 <= 5 ? t("متوسط", "moderate") : X.shr03 <= 8 ? t("زیاد", "high") : t("خیلی زیاد", "very high")) + t(" (آستانه‌های جزوه ۳/۵/۸)", " (handbook 3/5/8)"));
      if(fin(X.srh03)) wd.push("SRH: " + t("۰–۱ km = ", "0–1 km = ") + num(X.srh01, 0) + t("، ۰–۳ km = ", ", 0–3 km = ") + num(X.srh03, 0) + " m²/s² — " + (X.srh03 > 400 ? t("امکان توفان‌های تورنادویی (HEL>۴۰۰)", "tornadic storms possible (HEL > 400)") : X.srh03 > 300 ? t("توفان شدید ابرسلولی", "severe supercell storms") : X.srh03 > 150 ? t("امکان ابرسلول (HEL>۱۵۰)", "supercell possible (HEL > 150)") : t("چرخندگی نسبی کم", "limited storm-relative rotation")));
      if(fin(X.ehi03)) wd.push("EHI = " + num(X.ehi03, 2) + t(" (۰–۳ km)", " (0–3 km)") + (fin(X.ehi01) ? " / " + num(X.ehi01, 2) + t(" (۰–۱ km)", " (0–1 km)") : "") + ": " + (X.ehi03 > 5 ? t("پتانسیل تورنادوهای قوی", "strong-tornado potential") : X.ehi03 > 1 ? t("پتانسیل ابرسلول و گردباد", "supercell/tornado potential") : t("زیر آستانهٔ ابرسلول", "below supercell threshold")));
      if(fin(X.brn)) wd.push("BRN = " + num(X.brn, 0) + ": " + (X.brn < 10 ? t("برش بسیار قوی نسبت به CAPE؛ ابرسلول محتمل، ولی ممکن است صعود را «پاره» کند اگر CAPE خیلی کم باشد", "very strong shear relative to CAPE; supercell likely (but too little CAPE can shear updrafts apart)") : X.brn < 45 ? t("بازهٔ مساعد ابرسلول (۱۰–۴۵)", "supercell-favourable range (10–45)") : t("برش ضعیف نسبت به CAPE؛ همرفت چندسلولی/نامنظم", "weak shear relative to CAPE; multicell/disorganised convection")));
      if(fin(X.meanWind06)) wd.push(t("باد میانگین ۰–۶ km: ", "0–6 km mean wind: ") + num(X.meanWind06, 1) + " m/s " + t("از جهت ", "from ") + num(X.meanDir06, 0) + "°" + (X.meanWind06 < 6 ? t(" — حرکت کند توفان؛ تجمع بارش و خطر سیلاب لحظه‌ای.", " — slow storm motion; rain accumulation and flash-flood risk.") : X.meanWind06 > 18 ? t(" — حرکت سریع؛ تندباد همراه و بارش کوتاه‌مدت.", " — fast motion; gusty with short-lived rain.") : ""));
      if(fin(X.cape) && fin(X.s06)){ const mode = X.cape < 300 ? t("همرفت کم‌انرژی/ضعیف", "low-energy/weak convection") : X.s06 < 10 ? t("تک‌سلول/پالسی", "single-cell / pulse storms") : X.s06 < 18 ? t("چندسلولی (خوشه‌ای)", "multicell clusters") : (X.srh03 > 150 && X.cape > 800 ? t("ابرسلول", "supercells") : t("خط توفان/سازمان‌یافته", "squall-line / organised mode")); wd.push(t("حالت محتمل همرفت: ", "Likely convective mode: ") + mode + "."); }
    } else wd.push(t("دادهٔ باد/ارتفاع کافی نیست؛ تحلیل برش، SRH، EHI، BRN و حالت همرفت ممکن نیست (مقداری ساخته نشد).", "Not enough wind/height data; shear, SRH, EHI, BRN and convective-mode analysis are unavailable (nothing was fabricated)."));
    B(t("۶. باد، برش و سازمان‌یافتگی توفان", "6. Wind, shear and storm organisation"), wd, "wind");
    /* ۷) ابر و رطوبت */
    const cl = [];
    if(X.clouds.length) cl.push(t("لایه‌های مرطوب/ابری (RH≥۸۵٪): ", "Moist/cloudy layers (RH ≥ 85%): ") + X.clouds.slice(0, 4).map(c => hp(c.base) + "→" + hp(c.top) + (fin(c.baseAgl) ? " (" + num(c.baseAgl, 0) + "–" + num(c.topAgl, 0) + " m AGL)" : "")).join(SEP) + ".");
    else cl.push(t("لایهٔ ابری قطعی (RH≥۸۵٪) در سونداژ دیده نمی‌شود؛ آسمان عمدتاً صاف تا کم‌ابر مگر همرفت محلی.", "No definite cloud layer (RH ≥ 85%) in the sounding; mostly clear to few clouds unless local convection."));
    if(fin(X.dryMid)) cl.push(t("کمینهٔ RH در میان‌تراز (۴۰۰ تا سطح−۱۵۰ hPa): ", "Minimum mid-level RH: ") + num(X.dryMid, 0) + "%" + (X.dryMid < 30 ? t(" — لایهٔ خشک میانی: ورود هوای خشک به ابر تبخیر و سرمایش و تندباد نزولی را تقویت می‌کند و ریزش گردوغبار را ممکن می‌سازد.", " — dry mid-level layer: entrainment strengthens evaporative cooling and downdrafts.") : ""));
    B(t("۷. ابر و رطوبت", "7. Cloud and moisture"), cl, "cloud");
    /* ۸) احتمالات */
    const pl = P.map(p => (en ? p.en : p.fa) + ": " + num(p.p) + "% (" + t(A.LV[p.lv][0], A.LV[p.lv][1]) + ")" + (p.drivers.length ? " ← " + p.drivers.map(d => ((NM[d[0]] && NM[d[0]].map ? NM[d[0]][en ? 1 : 0] : NM[d[0]]) || d[0]) + (d[1] < 0 ? "−" : "+")).join(" ") : ""));
    pl.push(t("«درصد» = مساعدبودن محیط برای پدیده (احتمال شرطی به وجود ماشه)، با مدل لجستیک شفاف با وزن‌های ثابت؛ برای تبدیل به احتمال وقوع باید با رصد واقعی واسنجی شود (MET.analysis.train).", "“Percent” = environmental favourability (conditional on a trigger) from a transparent logistic model with fixed weights; convert to occurrence probability only after calibration against observations (MET.analysis.train)."));
    B(t("۸. احتمالات محیطی", "8. Environmental probabilities"), pl, "prob");
    /* ۹) جمع‌بندی */
    const sm = []; const top = P.slice().sort((a, b) => b.p - a.p)[0];
    const stab = !fin(X.cape) || X.cape < 50 ? t("پایدار (همرفت عمیق بعید)", "stable (deep convection unlikely)") : X.cape < 500 ? t("ناپایداری ضعیف", "weakly unstable") : X.cape < 1500 ? t("ناپایداری متوسط", "moderately unstable") : t("ناپایداری قوی", "strongly unstable");
    sm.push(t("وضعیت کلی: ", "Overall: ") + stab + (fin(X.cin) && X.cin < -100 && X.cape > 300 ? t(" اما با سرپوش قوی (CIN=", " but strongly capped (CIN=") + num(X.cin) + ")" : "") + ".");
    sm.push(t("بیشترین مساعدت محیطی: ", "Highest environmental favourability: ") + (en ? top.en : top.fa) + " (" + num(top.p) + "%).");
    if(top.p < 10) sm.push(t("هیچ پدیدهٔ همرفتی شدید در این سونداژ مساعد نیست؛ هوای آرام/پایدار یا ابرناکی لایه‌ای است.", "No severe convective hazard is favoured by this sounding; calm/stable or stratiform conditions prevail."));
    sm.push(t("محدودیت‌ها: سونداژ خروجی مدل با تفکیک افقی ≈ ۹–۲۵ km و حدود ۱۹ تراز فشاری است؛ جزئیات لایهٔ مرزی، توپوگرافی کوچک‌مقیاس و ماشه‌های همدیدی را نمی‌بیند. برای تصمیم عملیاتی با نقشه‌ها و رصد تلفیق شود.", "Limitations: the sounding is model output (≈ 9–25 km, ~19 pressure levels); it cannot see fine boundary-layer structure, small-scale terrain or synoptic triggers. Combine with maps and observations for operational use."));
    B(t("۹. جمع‌بندی", "9. Summary"), sm, "sum");
    /* مرحلهٔ آزمایشگاه: خلاصهٔ متئوگرام چندمدلی */
    if(kind === "lab" && o.mg && o.mg.mods && o.mg.mods.length){ const ml = mgLines(o.mg, o, t, num); if(ml.length) B(t("۱۰. چشم‌انداز چندمدلی (متئوگرام)", "10. Multi-model outlook (meteogram)"), ml, "mg"); }
    return {ok:true, kind, en, X, probs:P, sections:S};
  }
  /* خلاصهٔ روزانهٔ متئوگرام: میانهٔ مدل‌ها و پراکندگی */
  function mgLines(D, o, t, num){
    const out = [], mods = D.mods, med = M.mg ? M.mg.median : null; if(!med) return out; const days = {}; D.T.forEach((s, i) => { const d = s.slice(0, 10); (days[d] = days[d] || []).push(i); });
    const keys = Object.keys(days).slice(0, o.mgDays || 5);
    out.push(t("مدل‌های دارای داده: ", "Models with data: ") + num(mods.length) + " (" + mods.map(m => m.name).join(CM) + ").");
    for(const d of keys){ const idx = days[d]; const tx = [], tn = [], gs = [], cc = [], pr = [];
      for(const m of mods){ const tv = idx.map(i => m.s.t[i]).filter(fin), gv = idx.map(i => m.s.wg[i]).filter(fin), cv = idx.map(i => m.s.cc[i]).filter(fin); if(tv.length >= 12){ tx.push(Math.max(...tv)); tn.push(Math.min(...tv)); } if(gv.length) gs.push(Math.max(...gv)); if(cv.length) cc.push(cv.reduce((a, b) => a + b, 0) / cv.length); const di = D.DT.indexOf(d); if(di >= 0 && fin(m.dpr[di])) pr.push(m.dpr[di]); }
      const mm = a => a.length >= 2 ? med(a) : (a.length ? a[0] : null), rg = a => a.length > 1 ? num(Math.min(...a), 0) + "–" + num(Math.max(...a), 0) : "";
      const parts = []; if(tx.length) parts.push("Tmax " + num(mm(tx), 1) + " °C (" + rg(tx) + ")"), parts.push("Tmin " + num(mm(tn), 1) + " °C (" + rg(tn) + ")");
      if(pr.length){ const pm = mm(pr), ag = pr.filter(v => v >= 1).length; parts.push(t("بارش ", "rain ") + num(pm, 1) + " mm (" + t("بیشینهٔ مدل‌ها ", "max model ") + num(Math.max(...pr), 1) + "; " + num(ag) + "/" + num(pr.length) + t(" مدل ≥۱ mm", " models ≥ 1 mm") + ")"); }
      if(gs.length) parts.push(t("تندباد ", "gust ") + num(mm(gs), 0) + " km/h"); if(cc.length) parts.push(t("ابرناکی ", "cloud ") + num(mm(cc), 0) + "%");
      if(parts.length) out.push(d + ": " + parts.join(" · ")); }
    const spreadT = []; mods.length > 1 && keys.length && (() => { const d = keys[0], idx = days[d]; const v = mods.map(m => Math.max(...idx.map(i => m.s.t[i]).filter(fin))).filter(fin); if(v.length > 1) spreadT.push(Math.max(...v) - Math.min(...v)); })();
    if(spreadT.length) out.push(t("پراکندگی مدل‌ها برای بیشینهٔ دمای امروز: ", "Model spread for today's max temperature: ") + num(spreadT[0], 1) + " °C" + (spreadT[0] > 4 ? t(" (عدم‌قطعیت زیاد)", " (high uncertainty)") : spreadT[0] < 2 ? t(" (توافق خوب)", " (good agreement)") : ""));
    out.push(t("هرچه پراکندگی مدل‌ها بیشتر باشد اطمینان به پیش‌بینی همان روز کمتر است؛ میانه اطمینان بیشتری از هر مدل منفرد دارد.", "The larger the model spread, the lower the confidence for that day; the median is usually more reliable than any single model."));
    return out;
  }
  A.skewt = (res, o) => make(res, o, "skewt");
  A.lab = (res, o) => make(res, o, "lab");
  /* ---------- خروجی HTML/متن ---------- */
  const esc = s => String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  A.html = function(a, en){
    const t = (fa, e) => en ? e : fa;
    let h = '<div class="anBox" dir="' + (en ? "ltr" : "rtl") + '"><h4 class="anH">' + esc(a.kind === "lab" ? t("تحلیل علمی آزمایشگاه محاسبات", "Scientific analysis — computation lab") : t("تحلیل علمی Skew-T", "Scientific analysis — Skew-T")) + "</h4>";
    h += '<div class="anProb">' + a.probs.map(p => '<div class="anP l' + p.lv + '"><span class="anPl">' + esc(en ? p.en : p.fa) + '</span><span class="anPb"><i style="width:' + p.p + '%"></i></span><b>' + p.p + "%</b></div>").join("") + "</div>";
    for(const s of a.sections){ h += '<section class="anS"><h5>' + esc(s.h) + "</h5>" + s.lines.map(l => "<p>" + esc(l) + "</p>").join("") + "</section>"; }
    return h + "</div>";
  };
  A.text = function(a){ return a.sections.map(s => s.h + "\n" + s.lines.map(l => "• " + l).join("\n")).join("\n\n"); };
  M.analysis = A;
})();
