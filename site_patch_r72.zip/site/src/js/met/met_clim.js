/* ===== نرمال اقلیمی ۱۹۹۱–۲۰۲۰ برای متئوگرام (r71) =====
   منبع: بازتحلیل ERA5 از Open-Meteo Archive API (CC BY 4.0)، یک درخواست ۳۰ ساله برای هر نقطه (شبکهٔ ۰٫۲۵°)، محاسبه در مرورگر و ذخیره در localStorage.
   برای هر روز سال: میانگین دمای روزانه، میانگین کمینه و بیشینهٔ روزانه، و میانگین بارش روزانه، با پنجرهٔ ±۷ روز (۱۵ روز × ۳۰ سال).
   نرمال «مقدار توصیفی گذشته» است؛ پیش‌بینی نیست. ۲۹ فوریه با ۲۸ فوریه یکی گرفته می‌شود. */
(function(M){
  "use strict";
  const fin = x => typeof x === "number" && isFinite(x), r1 = x => Math.round(x * 10) / 10, W = 7, Y0 = 1991, Y1 = 2020;
  const MD = (() => { const a = []; for(let m = 0; m < 12; m++){ const n = new Date(Date.UTC(2001, m + 1, 0)).getUTCDate(); for(let d = 1; d <= n; d++) a.push([m + 1, d]); } return a; })();   // ۳۶۵ روز
  const doyOf = (m, d) => { let k = 0; for(let i = 0; i < m - 1; i++) k += new Date(Date.UTC(2001, i + 1, 0)).getUTCDate(); return k + Math.min(d, new Date(Date.UTC(2001, m, 0)).getUTCDate()) - 1; };
  const grid = x => Math.round(x * 4) / 4, key = (la, lo) => "mgclim1:" + grid(la).toFixed(2) + "," + grid(lo).toFixed(2);
  function build(j){
    const D = j && j.daily; if(!D || !D.time) throw new Error("no daily");
    const ser = {tm:D.temperature_2m_mean, tx:D.temperature_2m_max, tn:D.temperature_2m_min, pr:D.precipitation_sum}, byDoy = {tm:[], tx:[], tn:[], pr:[]};
    for(const k in byDoy) for(let i = 0; i < 365; i++) byDoy[k].push([]);
    D.time.forEach((s, i) => { const y = +s.slice(0, 4); if(y < Y0 || y > Y1) return; const m = +s.slice(5, 7), d = +s.slice(8, 10); if(m === 2 && d === 29) return; const q = doyOf(m, d); for(const k in ser){ const v = ser[k] && ser[k][i]; if(fin(v)) byDoy[k][q].push(v); } });
    const out = {v:1, la:j.latitude, lo:j.longitude, el:j.elevation, tm:[], tx:[], tn:[], p10:[], p90:[], pr:[], n:0};
    const win = (k, q) => { const a = []; for(let o = -W; o <= W; o++){ const b = byDoy[k][(q + o + 365) % 365]; for(const v of b) a.push(v); } return a; };
    for(let q = 0; q < 365; q++){
      const a = win("tm", q).sort((x, y) => x - y), mean = L => L.reduce((s, v) => s + v, 0) / (L.length || 1);
      if(a.length < 100){ for(const k of ["tm", "tx", "tn", "p10", "p90", "pr"]) out[k].push(null); continue; }
      out.n = Math.max(out.n, a.length); out.tm.push(r1(mean(a))); out.p10.push(r1(a[Math.floor(a.length * 0.1)])); out.p90.push(r1(a[Math.floor(a.length * 0.9)]));
      out.tx.push(r1(mean(win("tx", q)))); out.tn.push(r1(mean(win("tn", q)))); out.pr.push(Math.round(mean(win("pr", q)) * 100) / 100);
    }
    return out;
  }
  const MEMC = new Map();
  async function get(lat, lon, signal){
    const k = key(lat, lon); if(MEMC.has(k)) return MEMC.get(k);
    try{ const c = JSON.parse(localStorage.getItem(k) || "null"); if(c && c.v === 1){ MEMC.set(k, c); return c; } }catch(e){}
    const u = "https://archive-api.open-meteo.com/v1/archive?latitude=" + grid(lat).toFixed(2) + "&longitude=" + grid(lon).toFixed(2) + "&start_date=" + Y0 + "-01-01&end_date=" + Y1 + "-12-31&daily=temperature_2m_mean,temperature_2m_max,temperature_2m_min,precipitation_sum&timezone=Asia%2FTehran";
    const r = await fetch(u, {signal}); const j = await r.json().catch(() => null); if(!r.ok || !j) throw new Error("HTTP " + r.status + (j && j.reason ? " " + j.reason : ""));
    const c = build(j); MEMC.set(k, c); try{ localStorage.setItem(k, JSON.stringify(c)); }catch(e){} return c;
  }
  const at = (c, k, s) => { if(!c) return null; const m = +s.slice(5, 7), d = +s.slice(8, 10); const v = c[k][doyOf(m, d)]; return fin(v) ? v : null; };
  M.clim = {get, at, build, doyOf, years:[Y0, Y1]};
})(globalThis.MET);
