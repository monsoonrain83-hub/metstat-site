/* ===== Skew-T مدرن و پرجزئیات (r55) — دوبعدی و سه‌بعدی =====
   SVG خالص و مستقل (استایل درون‌خطی) تا ذخیرهٔ SVG/PNG وفادار بماند. محاسبه‌ها همه از هستهٔ MET (M.lab / M.thermo / M.analysis)؛ رنگ‌ها فقط نمایشی‌اند.
   نمایش سه‌بعدی یک تصویر شبه‌سه‌بعدی (تصویر مایل با زاویهٔ قابل‌چرخش) است: هر منحنی روی یک «شیشهٔ» جدا و پرده‌ای بیرون‌آمده؛ عمق فقط جنبهٔ نمایشی دارد و مقدار نمی‌سازد. */
(function(){
  "use strict";
  const M = globalThis.MET, C = M.C, T = M.thermo, PF = M.profile, W = M.wind, S = {};
  const fin = x => typeof x === "number" && isFinite(x);
  const f1 = x => (Math.round(x * 10) / 10).toString(), f0 = x => Math.round(x).toString();
  const esc = s => String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;");
  const G = {W:980, H:690, ML:66, MT:40, MB:46, pw:610, ph:604, pb:1050, pt:100, Tmin:-40, Trange:86, k:0.82};
  function geom(pTop){
    const g = Object.assign({}, G); g.pt = pTop || 100; g.sx = g.pw / g.Trange; const lr = Math.log(g.pb / g.pt);
    g.y = p => g.MT + g.ph * (Math.log(p / g.pt) / lr); g.yb = g.MT + g.ph;
    g.x = (tc, p) => g.ML + (tc - g.Tmin) * g.sx + (g.yb - g.y(p)) * g.k;
    g.pFromY = y => g.pt * Math.exp(lr * (y - g.MT) / g.ph); return g;
  }
  const pts = a => a.map(q => f1(q[0]) + "," + f1(q[1])).join(" ");
  const poly = (a, st, fill) => '<polyline points="' + pts(a) + '" fill="' + (fill || "none") + '" ' + st + "/>";
  const L = (en, fa, e) => en ? e : fa;
  const BC = {t:"#e11d48", td:"#16a34a", tw:"#0891b2", par:"#111827"};
  /* فشار در ارتفاع AGL داده‌شده (از z پروفایل) */
  function pAtZ(prof, zAgl){ const z0 = prof.z[0]; if(!fin(z0)) return null; const zt = z0 + zAgl; for(let i = 0; i < prof.p.length - 1; i++){ const a = prof.z[i], b = prof.z[i + 1]; if(fin(a) && fin(b) && a <= zt && b >= zt && b > a){ const f = (zt - a) / (b - a); return Math.exp(Math.log(prof.p[i]) + f * (Math.log(prof.p[i + 1]) - Math.log(prof.p[i]))); } } return null; }
  function levelP(prof, tc){ for(let i = 0; i < prof.p.length - 1; i++) if(prof.Tk[i] - C.zeroC > tc && prof.Tk[i + 1] - C.zeroC <= tc){ const f = (prof.Tk[i] - C.zeroC - tc) / (prof.Tk[i] - prof.Tk[i + 1]); return Math.exp(Math.log(prof.p[i]) + f * (Math.log(prof.p[i + 1]) - Math.log(prof.p[i]))); } return null; }
  const stull = (t, rh) => t * Math.atan(0.151977 * Math.sqrt(rh + 8.313659)) + Math.atan(t + rh) - Math.atan(rh - 1.676331) + 0.00391838 * Math.pow(rh, 1.5) * Math.atan(0.023101 * rh) - 4.686035;
  function twProf(prof){ return prof.p.map((p, i) => { const t = prof.Tk[i] - C.zeroC, rh = Math.min(99, Math.max(5, T.rhFromDewpoint(prof.Tk[i], prof.Tdk[i]) * 100)); return (t > -20 && t < 50) ? stull(t, rh) : null; }); }
  function barb(x, y, u, v, len, col){
    const spd = Math.hypot(u, v) / W.KT, dir = W.direction(u, v), c = col || "#1e293b";
    if(spd < 2.5) return '<circle cx="' + f1(x) + '" cy="' + f1(y) + '" r="3" fill="none" stroke="' + c + '" stroke-width="1"/>';
    let s = Math.round(spd / 5) * 5, d = "M0,0 L0," + (-len), yy = 0; const step = 4.5, bl = 11;
    while(s >= 50){ d += " M0," + (-len + yy) + " L" + bl + "," + (-len + yy + 3) + " L0," + (-len + yy + 6) + " Z"; yy += 7; s -= 50; }
    if(yy) yy += 1; while(s >= 10){ d += " M0," + (-len + yy) + " l" + bl + ",-4"; yy += step; s -= 10; } if(s >= 5){ if(yy === 0) yy += step; d += " M0," + (-len + yy) + " l" + (bl / 2) + ",-2"; }
    return '<g transform="translate(' + f1(x) + "," + f1(y) + ") rotate(" + f1(dir) + ')"><path d="' + d + '" stroke="' + c + '" stroke-width="1.25" fill="' + c + '"/></g>';
  }
  const spdCol = ms => { const k = ms / W.KT; return k < 15 ? "#64748b" : k < 30 ? "#0284c7" : k < 50 ? "#7c3aed" : k < 70 ? "#c2410c" : "#be123c"; };
  /* برچسب‌های ترازها با فاصله‌گذاری عمودی */
  function spread(items, minGap, lo, hi){ items.sort((a, b) => a.y - b.y); for(let i = 1; i < items.length; i++) if(items[i].y - items[i - 1].y < minGap) items[i].y = items[i - 1].y + minGap;
    const over = items.length ? items[items.length - 1].y - hi : 0; if(over > 0) for(let i = items.length - 1; i >= 0; i--){ items[i].y -= over; if(i && items[i].y - items[i - 1].y < minGap) continue; } items.forEach(it => { if(it.y < lo) it.y = lo; }); return items; }
  function marks(res, X, en, prof){
    const m = []; const add = (p, lab, col) => { if(fin(p)) m.push({p, lab, col}); };
    add(res.items.LCL.v, "LCL", "#0d9488"); add(res.lfc, "LFC", "#b45309"); add(res.el, "EL", "#7e22ce"); add(X.cclP, "CCL", "#0369a1"); add(X.fzlP, L(en, "۰°C", "0°C"), "#2563eb"); add(X.wbzP, "WBZ", "#0891b2");
    for(const t of [-10, -20, -30]){ add(levelP(prof, t), t + "°C", "#64748b"); } return m;
  }
  /* ---------- نمای دوبعدی ---------- */
  S.svg = function(res, o){
    o = o || {}; const en = !!o.en, prof = res.prof, g = geom(100), X = (M.analysis ? M.analysis.features(res) : {}), uid = "s2" + Math.floor(Math.random() * 1e6);
    const opt = Object.assign({moist:true, mix:true, wet:true, barbs:true, marks:true, panel:true, hail:true}, o.layers || {});
    const hasZ = fin(prof.z && prof.z[0]);
    let b = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + g.W + " " + g.H + '" font-family="Vazirmatn,Tahoma,sans-serif" font-size="10.5" style="width:100%;height:auto;display:block;background:#f1f5f9;direction:ltr" role="img" aria-label="Skew-T log-p">';
    b += '<defs><clipPath id="' + uid + 'c"><rect x="' + g.ML + '" y="' + g.MT + '" width="' + g.pw + '" height="' + g.ph + '"/></clipPath>' +
      '<linearGradient id="' + uid + 'bg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#e8f0fb"/><stop offset=".55" stop-color="#f8fafc"/><stop offset="1" stop-color="#fdf6e9"/></linearGradient>' +
      '<linearGradient id="' + uid + 'cp" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#f97316" stop-opacity=".62"/><stop offset="1" stop-color="#dc2626" stop-opacity=".30"/></linearGradient>' +
      '<linearGradient id="' + uid + 'ci" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#3b82f6" stop-opacity=".5"/><stop offset="1" stop-color="#1d4ed8" stop-opacity=".22"/></linearGradient>' +
      '<filter id="' + uid + 'gl" x="-5%" y="-5%" width="110%" height="110%"><feDropShadow dx="0" dy="1.4" stdDeviation="1.6" flood-color="#0f172a" flood-opacity=".32"/></filter>' +
      '<filter id="' + uid + 'ps" x="-10%" y="-30%" width="120%" height="170%"><feDropShadow dx="0" dy="1" stdDeviation="1" flood-color="#0f172a" flood-opacity=".25"/></filter></defs>';
    b += '<rect width="' + g.W + '" height="' + g.H + '" fill="#f1f5f9"/>';
    b += '<rect x="' + g.ML + '" y="' + g.MT + '" width="' + g.pw + '" height="' + g.ph + '" rx="10" fill="url(#' + uid + 'bg)" stroke="#cbd5e1" filter="url(#' + uid + 'ps)"/>';
    b += '<g clip-path="url(#' + uid + 'c)">';
    const yg = g.y(prof.p[0]); if(yg < g.yb) b += '<rect x="' + g.ML + '" y="' + f1(yg) + '" width="' + g.pw + '" height="' + f1(g.yb - yg) + '" fill="#a8a29e" opacity=".5"/><line x1="' + g.ML + '" x2="' + (g.ML + g.pw) + '" y1="' + f1(yg) + '" y2="' + f1(yg) + '" stroke="#78716c" stroke-width="1.5"/>';
    // منطقهٔ رشد تگرگ (−۱۰ تا −۳۰ °C)
    if(opt.hail){ const a = levelP(prof, -10), c = levelP(prof, -30); if(fin(a) && fin(c)) b += '<rect x="' + g.ML + '" y="' + f1(g.y(c)) + '" width="' + g.pw + '" height="' + f1(g.y(a) - g.y(c)) + '" fill="#60a5fa" opacity=".10"/><text x="' + (g.ML + 8) + '" y="' + f1(g.y(c) + 12) + '" font-size="9.5" fill="#3b82f6" opacity=".85">' + esc(L(en, "منطقهٔ رشد تگرگ (−۱۰ تا −۳۰ °C)", "Hail growth zone (−10 to −30 °C)")) + "</text>"; }
    for(let t = -140; t <= 60; t += 10){ const z = t === 0; b += '<line x1="' + f1(g.x(t, g.pb)) + '" y1="' + f1(g.y(g.pb)) + '" x2="' + f1(g.x(t, g.pt)) + '" y2="' + f1(g.y(g.pt)) + '" stroke="' + (z ? "#3b82f6" : "#cbd5e1") + '" stroke-width="' + (z ? 1.3 : 0.7) + '"' + (z ? ' stroke-dasharray="6 3"' : "") + "/>"; }
    for(let p = 1000; p >= 100; p -= 50){ const major = p % 100 === 0; b += '<line x1="' + g.ML + '" x2="' + (g.ML + g.pw) + '" y1="' + f1(g.y(p)) + '" y2="' + f1(g.y(p)) + '" stroke="' + (major ? "#94a3b8" : "#e2e8f0") + '" stroke-width="' + (major ? 0.9 : 0.5) + '"/>'; }
    const pg = []; for(let p = g.pb; p >= g.pt - 1e-9; p -= 25) pg.push(p);
    for(let th = 250; th <= 520; th += 10){ const q = pg.map(p => [g.x(T.dryLapse(p, th, 1000) - C.zeroC, p), g.y(p)]); b += poly(q, 'stroke="#f0c9a0" stroke-width="0.75"'); }
    if(opt.moist) for(let t0 = -10; t0 <= 36; t0 += 4){ const pp = []; for(let p = 1000; p >= g.pt - 1e-9; p -= 25) pp.push(p); const tk = T.moistLapse(pp, t0 + C.zeroC, 1000);
      if(tk){ b += poly(pp.map((p, i) => [g.x(tk[i] - C.zeroC, p), g.y(p)]), 'stroke="#86efac" stroke-width="0.8" stroke-dasharray="4 2.5"'); const j = Math.min(pp.length - 1, 11); b += '<text x="' + f1(g.x(tk[j] - C.zeroC, pp[j]) + 3) + '" y="' + f1(g.y(pp[j])) + '" font-size="8" fill="#16a34a" opacity=".8">' + t0 + "</text>"; } }
    if(opt.mix) for(const w of [0.4, 1, 2, 4, 7, 10, 14, 20, 28]){ const q = []; for(let p = g.pb; p >= 600; p -= 25) q.push([g.x(T.dewpointFromE(T.vaporPressure(p, w / 1000)) - C.zeroC, p), g.y(p)]); b += poly(q, 'stroke="#a3e635" stroke-width="0.8" stroke-dasharray="1.5 3.5"'); const e = q[q.length - 1]; b += '<text x="' + f1(e[0]) + '" y="' + f1(e[1] - 3) + '" fill="#65a30d" font-size="8.5" text-anchor="middle">' + w + "</text>"; }
    // CAPE/CIN
    const pc = M.lab.parcelCurve(prof, o.parcel || res.parcelType);
    if(pc){ const envT = p => PF.interpLog(p, prof.p, prof.Tk), P = pc.p, d = P.map((p, i) => pc.Tk[i] - envT(p)), lfc = res.lfc;
      if(fin(lfc)) for(let i = 0; i < P.length - 1; i++){ const a = {p:P[i], tp:pc.Tk[i], te:envT(P[i]), d:d[i]}, c = {p:P[i + 1], tp:pc.Tk[i + 1], te:envT(P[i + 1]), d:d[i + 1]}; if(!fin(a.d) || !fin(c.d)) continue;
        const parts = []; if(a.d * c.d < 0){ const f = a.d / (a.d - c.d), pm = Math.exp(Math.log(a.p) + f * (Math.log(c.p) - Math.log(a.p))), tm = envT(pm); parts.push([a, {p:pm, tp:tm, te:tm, d:0}]); parts.push([{p:pm, tp:tm, te:tm, d:0}, c]); } else parts.push([a, c]);
        for(const [s0, s1] of parts){ const m = (s0.d + s1.d) / 2, pm = Math.sqrt(s0.p * s1.p); if(m === 0) continue; const pos = m > 0; if(pos && pm > lfc + 1e-6) continue; if(!pos && pm < lfc - 1e-6) continue;
          const q = [[g.x(s0.tp - C.zeroC, s0.p), g.y(s0.p)], [g.x(s1.tp - C.zeroC, s1.p), g.y(s1.p)], [g.x(s1.te - C.zeroC, s1.p), g.y(s1.p)], [g.x(s0.te - C.zeroC, s0.p), g.y(s0.p)]]; b += '<polygon points="' + pts(q) + '" fill="url(#' + uid + (pos ? "cp" : "ci") + ')"/>'; } } }
    // ناحیهٔ اختلاف دما-شبنم (رطوبت): سایهٔ آبی کم‌رنگ
    { const a = prof.p.map((p, i) => [g.x(prof.Tk[i] - C.zeroC, p), g.y(p)]), c = prof.p.map((p, i) => [g.x(prof.Tdk[i] - C.zeroC, p), g.y(p)]).reverse(); b += '<polygon points="' + pts(a.concat(c)) + '" fill="#38bdf8" opacity=".10"/>'; }
    // منحنی‌ها
    if(opt.wet){ const tw = twProf(prof); const q = []; prof.p.forEach((p, i) => { if(fin(tw[i])) q.push([g.x(tw[i], p), g.y(p)]); }); if(q.length > 1) b += poly(q, 'stroke="' + BC.tw + '" stroke-width="1.5" stroke-dasharray="5 3"'); }
    b += '<g filter="url(#' + uid + 'gl)">' + poly(prof.p.map((p, i) => [g.x(prof.Tdk[i] - C.zeroC, p), g.y(p)]), 'stroke="' + BC.td + '" stroke-width="2.8" stroke-linejoin="round" stroke-linecap="round"') + poly(prof.p.map((p, i) => [g.x(prof.Tk[i] - C.zeroC, p), g.y(p)]), 'stroke="' + BC.t + '" stroke-width="3" stroke-linejoin="round" stroke-linecap="round"') + "</g>";
    if(pc) b += poly(pc.p.map((p, i) => [g.x(pc.Tk[i] - C.zeroC, p), g.y(p)]), 'stroke="' + BC.par + '" stroke-width="2" stroke-dasharray="7 3.5"');
    // ترازها: خط ریز + برچسب قرصی در لبهٔ راست
    const mk = opt.marks ? spread(marks(res, X, en, prof).filter(m => m.p >= g.pt && m.p <= g.pb).map(m => Object.assign(m, {y:g.y(m.p), y0:g.y(m.p)})), 14, g.MT + 8, g.yb - 8) : [];
    for(const m of mk) b += '<line x1="' + (g.ML + g.pw - 78) + '" x2="' + (g.ML + g.pw) + '" y1="' + f1(m.y0) + '" y2="' + f1(m.y0) + '" stroke="' + m.col + '" stroke-width="1.2" opacity=".7" stroke-dasharray="3 2"/>';
    b += "</g>";
    for(const m of mk){ const w = 12 + (m.lab.length + 5) * 5.6, x = g.ML + g.pw - w - 4; b += '<g filter="url(#' + uid + 'ps)"><rect x="' + f1(x) + '" y="' + f1(m.y - 8) + '" width="' + f1(w) + '" height="15" rx="7.5" fill="#fff" stroke="' + m.col + '"/><text x="' + f1(x + w / 2) + '" y="' + f1(m.y + 3) + '" text-anchor="middle" font-size="9.5" font-weight="700" fill="' + m.col + '"><tspan>' + esc(m.lab) + "</tspan> <tspan>" + f0(m.p) + "</tspan></text></g>"; }
    // محورها
    for(let p = 1000; p >= 100; p -= 100) b += '<text x="' + (g.ML - 6) + '" y="' + f1(g.y(p) + 3.5) + '" text-anchor="end" fill="#475569" font-weight="600">' + p + "</text>";
    b += '<text x="14" y="' + f1(g.MT + g.ph / 2) + '" fill="#475569" font-weight="700" transform="rotate(-90 14 ' + f1(g.MT + g.ph / 2) + ')" text-anchor="middle">hPa</text>';
    if(hasZ) for(let km = 1; km <= 14; km++){ const p = pAtZ(prof, km * 1000); if(!fin(p) || p < g.pt) continue; const y = g.y(p); b += '<line x1="' + g.ML + '" x2="' + (g.ML + 6) + '" y1="' + f1(y) + '" y2="' + f1(y) + '" stroke="#7c3aed" stroke-width="1.4"/><text x="' + (g.ML + 9) + '" y="' + f1(y + 3.5) + '" font-size="9" fill="#7c3aed" font-weight="700">' + km + " km</text>"; }
    for(let t = -40; t <= 40; t += 10) b += '<text x="' + f1(g.x(t, g.pb)) + '" y="' + (g.yb + 14) + '" text-anchor="middle" fill="#475569" font-weight="600">' + t + "</text>";
    b += '<text x="' + f1(g.ML + g.pw / 2) + '" y="' + (g.H - 10) + '" text-anchor="middle" fill="#475569" font-weight="700">' + esc(L(en, "دما در تراز ۱۰۵۰ hPa (°C)", "Temperature at 1050 hPa (°C)")) + "</text>";
    // بارب باد
    const wi = []; for(let i = 0; i < prof.p.length; i++) if(fin(prof.u[i]) && fin(prof.v[i])) wi.push(i);
    const bx = g.ML + g.pw + 24;
    if(opt.barbs && wi.length){ b += '<line x1="' + bx + '" x2="' + bx + '" y1="' + g.MT + '" y2="' + g.yb + '" stroke="#e2e8f0" stroke-width="1.2"/>'; let last = -99;
      for(const i of wi){ const y = g.y(prof.p[i]); if(y < g.MT || y > g.yb || Math.abs(y - last) < 15) continue; last = y; b += barb(bx, y, prof.u[i], prof.v[i], 23, spdCol(Math.hypot(prof.u[i], prof.v[i]))); }
      b += '<text x="' + bx + '" y="' + (g.MT - 10) + '" text-anchor="middle" font-size="9" fill="#64748b">' + esc(L(en, "باد (kt)", "wind (kt)")) + "</text>"; }
    b += '<text x="' + (g.ML) + '" y="' + (g.MT - 12) + '" font-size="13" font-weight="800" fill="#0f172a">' + esc(o.title || "Skew-T log-p") + "</text>";
    b += '<g id="skCur2" style="display:none"><line id="skCl2" x1="' + g.ML + '" x2="' + (g.ML + g.pw) + '" y1="0" y2="0" stroke="#f59e0b" stroke-width="1.2"/><circle id="skCT2" r="4" fill="' + BC.t + '" stroke="#fff" stroke-width="1.5"/><circle id="skCD2" r="4" fill="' + BC.td + '" stroke="#fff" stroke-width="1.5"/></g>';
    b += '<rect id="skHit2" x="' + g.ML + '" y="' + g.MT + '" width="' + g.pw + '" height="' + g.ph + '" fill="transparent" style="touch-action:pan-y;cursor:crosshair"/>';
    if(opt.panel) b += panel(res, X, g, en, uid);
    return b + "</svg>";
  };
  /* پنل کناری: شاخص‌ها + هودوگراف */
  const SEV = [["#16a34a", "#dcfce7"], ["#ca8a04", "#fef9c3"], ["#ea580c", "#ffedd5"], ["#dc2626", "#fee2e2"]];
  function panel(res, X, g, en, uid){
    const x0 = g.ML + g.pw + 54, w = g.W - x0 - 10; let y = g.MT, b = '<g>';
    b += '<rect x="' + x0 + '" y="' + y + '" width="' + w + '" height="' + (g.H - g.MT - 30) + '" rx="10" fill="#fff" stroke="#cbd5e1" filter="url(#' + uid + 'ps)"/>';
    y += 20; b += '<text x="' + (x0 + 12) + '" y="' + y + '" font-size="11.5" font-weight="800" fill="#0f172a">' + esc(L(en, "پارامترهای کلیدی", "Key parameters")) + " · " + res.parcelType + "</text>"; y += 8;
    const sev = (v, a) => v == null ? -1 : v < a[0] ? 0 : v < a[1] ? 1 : v < a[2] ? 2 : 3;
    const row = (lab, val, unit, s) => { y += 17; const c = s >= 0 ? SEV[s] : ["#64748b", "#f1f5f9"]; let r = '<text x="' + (x0 + 12) + '" y="' + y + '" font-size="10.5" fill="#475569">' + esc(lab) + '</text><rect x="' + (x0 + w - 98) + '" y="' + (y - 11.5) + '" width="86" height="15" rx="7.5" fill="' + c[1] + '"/><text x="' + (x0 + w - 55) + '" y="' + (y - 0.5) + '" font-size="10.5" font-weight="800" text-anchor="middle" fill="' + c[0] + '">' + (val != null ? esc(val) : "—") + (val != null && unit ? " " + esc(unit) : "") + "</text>"; return r; };
    const I = res.items, sv = res.severe || {}, v = k => k && fin(k.v) ? k.v : null, r1 = x => fin(x) ? f1(x) : null, r0 = x => fin(x) ? f0(x) : null;
    const cape = v(I.CAPE), cin = v(I.CIN);
    b += row("CAPE", r0(cape), "J/kg", sev(cape, [300, 1000, 2500])); b += row("CIN", r0(cin), "J/kg", cin == null ? -1 : cin > -25 ? 0 : cin > -100 ? 1 : cin > -200 ? 2 : 3);
    b += row("LCL", r0(I.LCL.v), "hPa", -1); b += row("LFC", r0(res.lfc), "hPa", -1); b += row("EL", r0(res.el), "hPa", -1);
    b += row("LI", r1(v(I.LI)), "°C", v(I.LI) == null ? -1 : v(I.LI) > 0 ? 0 : v(I.LI) > -4 ? 1 : v(I.LI) > -7 ? 2 : 3);
    b += row("K", r0(v(I.K)), "", sev(v(I.K), [20, 30, 35])); b += row("TT", r0(v(I.TT)), "", sev(v(I.TT), [44, 50, 55]));
    b += row("PW", r1(v(I.PWAT)), "mm", -1); b += row(L(en, "شیب ۷۰۰–۵۰۰", "LR 700–500"), r1(v(sv.LR75)), "K/km", sev(v(sv.LR75), [6, 7.5, 8.5]));
    b += row(L(en, "برش ۰–۶ km", "Shear 0–6 km"), r1(v(I.SHEAR.s06)), "m/s", sev(v(I.SHEAR.s06), [10, 18, 25])); b += row("SRH 0–3 km", r0(v(I.SRH.s03)), "m²/s²", sev(v(I.SRH.s03), [100, 250, 400]));
    b += row("SCP", r1(v(sv.SCP)), "", sev(v(sv.SCP), [1, 4, 10])); b += row("STP", r1(v(sv.STPE) != null ? v(sv.STPE) : v(sv.STPF)), "", sev(v(sv.STPE) != null ? v(sv.STPE) : v(sv.STPF), [1, 3, 6])); b += row("SHIP", r1(v(sv.SHIP)), "", sev(v(sv.SHIP), [1, 2, 4]));
    b += row(L(en, "تراز انجماد", "Freezing lvl"), fin(X.fzlAgl) ? f0(X.fzlAgl) : null, "m AGL", -1);
    y += 14; const h = M.skewt && M.skewt.hodograph ? M.skewt.hodograph(res, {en}) : null, hs = Math.min(w - 20, g.H - y - 44);
    if(h && hs > 90){ b += '<text x="' + (x0 + 12) + '" y="' + (y + 4) + '" font-size="11" font-weight="800" fill="#0f172a">' + esc(L(en, "هودوگراف", "Hodograph")) + "</text>"; b += h.replace(/^<svg[^>]*>/, '<svg x="' + f1(x0 + (w - hs) / 2) + '" y="' + (y + 10) + '" width="' + f1(hs) + '" height="' + f1(hs) + '" viewBox="0 0 300 300">'); }
    return b + "</g>";
  }
  S.attach = function(host, res, infoEl){
    const svg = host.querySelector("svg"); if(!svg) return; const g = geom(100), prof = res.prof, hit = svg.querySelector("#skHit2"), cur = svg.querySelector("#skCur2"), cl = svg.querySelector("#skCl2"), cT = svg.querySelector("#skCT2"), cD = svg.querySelector("#skCD2"); if(!hit) return;
    const wi = []; for(let i = 0; i < prof.p.length; i++) if(fin(prof.u[i]) && fin(prof.v[i])) wi.push(i); const tw = twProf(prof);
    function at(ev){ const r = svg.getBoundingClientRect(), sc = g.W / r.width, y = (ev.clientY - r.top) * sc; const p = Math.max(Math.min(g.pFromY(y), prof.p[0]), prof.p[prof.p.length - 1]);
      const t = PF.interpLog(p, prof.p, prof.Tk), td = PF.interpLog(p, prof.p, prof.Tdk); if(!fin(t) || !fin(td)) return; const yy = g.y(p); cur.style.display = ""; cl.setAttribute("y1", yy); cl.setAttribute("y2", yy);
      cT.setAttribute("cx", g.x(t - C.zeroC, p)); cT.setAttribute("cy", yy); cD.setAttribute("cx", g.x(td - C.zeroC, p)); cD.setAttribute("cy", yy);
      const z = M.lab.heightAtP(prof, p), rh = T.rhFromDewpoint(t, td) * 100, thE = T.thetaE(p, t, td), twv = PF.interpLog(p, prof.p, tw.map(x => fin(x) ? x : NaN)); let w = "";
      if(wi.length > 1){ const pp = wi.map(i => prof.p[i]), u = PF.interpLog(p, pp, wi.map(i => prof.u[i])), v = PF.interpLog(p, pp, wi.map(i => prof.v[i])); if(fin(u) && fin(v)) w = " · " + f0(W.direction(u, v)) + "°/" + f1(Math.hypot(u, v)) + " m/s"; }
      if(infoEl) infoEl.textContent = f0(p) + " hPa" + (fin(z) ? " · " + f0(z) + " m" : "") + " · T " + f1(t - C.zeroC) + " °C · Td " + f1(td - C.zeroC) + " °C · Tw " + (fin(twv) ? f1(twv) : "—") + " °C · RH " + f0(rh) + "%" + (fin(thE) ? " · θe " + f0(thE) + " K" : "") + w; }
    hit.addEventListener("pointermove", at); hit.addEventListener("pointerdown", at); };
  /* ---------- نمای سه‌بعدی (تصویر مایل با زاویهٔ قابل‌چرخش) ---------- */
  S.svg3d = function(res, o){
    o = o || {}; const en = !!o.en, prof = res.prof, g = geom(100), rot = fin(o.rot) ? o.rot : 38, a = rot * Math.PI / 180, uid = "s3" + Math.floor(Math.random() * 1e6), X = M.analysis ? M.analysis.features(res) : {};
    const DEP = 58, Zn = 3.6, ox = Math.cos(a) * DEP, oy = Math.sin(a) * DEP * 0.9, W3 = 980, H3 = 720, Hh = 430, SX = 5.2, SK = 0.55, PX = 70, tx0 = -40, tx1 = 45, pBot = prof.p[0], pTop = 100;
    const hh = p => Hh * Math.log(pBot / p) / Math.log(pBot / pTop), PYB = 70 + oy * Zn + Hh;
    const px = (tc, p, z) => PX + (tc - tx0) * SX + hh(p) * SK + ox * z, py = (p, z) => PYB - hh(p) - oy * z;
    const Pq = (tc, p, z) => [px(tc, p, z), py(p, z)];
    let b = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + W3 + " " + H3 + '" font-family="Vazirmatn,Tahoma,sans-serif" font-size="10.5" style="width:100%;height:auto;display:block;background:#0f172a;direction:ltr" role="img" aria-label="Skew-T 3D">';
    b += '<defs><linearGradient id="' + uid + 'bg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#0f172a"/><stop offset="1" stop-color="#1e293b"/></linearGradient>' +
      '<linearGradient id="' + uid + 'wl" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#38bdf8" stop-opacity=".10"/><stop offset="1" stop-color="#38bdf8" stop-opacity=".02"/></linearGradient>' +
      '<filter id="' + uid + 'gl"><feGaussianBlur stdDeviation="2.2" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs><rect width="' + W3 + '" height="' + H3 + '" fill="url(#' + uid + 'bg)"/>';
    // دیوار پشتی: ایزوبارها و ایزوترم‌ها (z = Zn)
    const wallP = [[px(tx0, pBot, Zn), py(pBot, Zn)], [px(tx1, pBot, Zn), py(pBot, Zn)], [px(tx1 + 0, pTop, Zn), py(pTop, Zn)], [px(tx0, pTop, Zn), py(pTop, Zn)]];
    b += '<polygon points="' + pts(wallP) + '" fill="url(#' + uid + 'wl)" stroke="#334155"/>';
    for(let p = 1000; p >= 100; p -= 100) if(p <= pBot) b += '<line x1="' + f1(px(tx0, p, Zn)) + '" y1="' + f1(py(p, Zn)) + '" x2="' + f1(px(tx1, p, Zn)) + '" y2="' + f1(py(p, Zn)) + '" stroke="#334155" stroke-width=".8"/>';
    for(let t = -40; t <= 40; t += 10){ const q1 = Pq(t, pBot, Zn), q2 = Pq(t + (g.yb - g.y(pTop)) * 0, pTop, Zn); b += '<line x1="' + f1(q1[0]) + '" y1="' + f1(q1[1]) + '" x2="' + f1(q2[0]) + '" y2="' + f1(q2[1]) + '" stroke="' + (t === 0 ? "#3b82f6" : "#273449") + '" stroke-width="' + (t === 0 ? 1.2 : .7) + '"/>'; }
    // کف
    const fl = [Pq(tx0, pBot, 0), Pq(tx1, pBot, 0), Pq(tx1, pBot, Zn), Pq(tx0, pBot, Zn)];
    b += '<polygon points="' + pts(fl) + '" fill="#78716c" opacity=".35" stroke="#57534e"/>';
    for(let t = -40; t <= 40; t += 10){ const q = Pq(t, pBot, 0); b += '<text x="' + f1(q[0]) + '" y="' + f1(q[1] + 14) + '" text-anchor="middle" fill="#94a3b8" font-size="10">' + t + "</text>"; }
    for(let p = 1000; p >= 100; p -= 100) if(p <= pBot){ const q = Pq(tx0, p, 0); b += '<text x="' + f1(q[0] - 6) + '" y="' + f1(q[1] + 3.5) + '" text-anchor="end" fill="#94a3b8" font-size="10">' + p + "</text>"; }
    // کنارهٔ چپ پایین (لبهٔ جلویی)
    b += '<line x1="' + f1(px(tx0, pBot, 0)) + '" y1="' + f1(py(pBot, 0)) + '" x2="' + f1(px(tx0, pTop, 0)) + '" y2="' + f1(py(pTop, 0)) + '" stroke="#475569"/>';
    // پرده‌ها: هر منحنی روی «شیشه» خودش؛ ترتیب از عقب به جلو
    const ribbon = (xs, ps, z0, thick, col, op) => { let s = ""; for(let i = 0; i < ps.length - 1; i++){ const q = [Pq(xs[i], ps[i], z0), Pq(xs[i + 1], ps[i + 1], z0), Pq(xs[i + 1], ps[i + 1], z0 + thick), Pq(xs[i], ps[i], z0 + thick)]; s += '<polygon points="' + pts(q) + '" fill="' + col + '" opacity="' + op + '"/>'; } return s; };
    const line3 = (xs, ps, z, col, w, glow) => { const q = ps.map((p, i) => Pq(xs[i], p, z)); return poly(q, 'stroke="' + col + '" stroke-width="' + w + '" stroke-linejoin="round" stroke-linecap="round"' + (glow ? ' filter="url(#' + uid + 'gl)"' : "")); };
    const Ts = prof.Tk.map(x => x - C.zeroC), Ds = prof.Tdk.map(x => x - C.zeroC), keep = prof.p.map((p, i) => i).filter(i => prof.p[i] >= pTop);
    const pcv = M.lab.parcelCurve(prof, o.parcel || res.parcelType);
    // CAPE/CIN به‌صورت حجم (منشور) روی صفحهٔ پارسل
    if(pcv && fin(res.lfc)){ const envT = p => PF.interpLog(p, prof.p, prof.Tk); const zP = 2.4, th = 0.7; let up = [], lo = [];
      const segs = []; let cur = null; for(let i = 0; i < pcv.p.length; i++){ const p = pcv.p[i], d = pcv.Tk[i] - envT(p); if(!fin(d) || p < pTop) continue; const pos = d > 0 && p <= res.lfc + 1e-6, neg = d < 0 && p >= res.lfc - 1e-6, kind = pos ? "p" : (neg ? "n" : null); if(kind && (!cur || cur.k !== kind)){ cur = {k:kind, p:[]}; segs.push(cur); } if(kind) cur.p.push([p, pcv.Tk[i] - C.zeroC, envT(p) - C.zeroC]); if(!kind) cur = null; }
      for(const s of segs){ if(s.p.length < 2) continue; const col = s.k === "p" ? "#f97316" : "#3b82f6"; for(const [z, op] of [[zP + th, .22], [zP, .55]]){ const poly2 = s.p.map(q => Pq(q[1], q[0], z)).concat(s.p.slice().reverse().map(q => Pq(q[2], q[0], z))); b += '<polygon points="' + pts(poly2) + '" fill="' + col + '" opacity="' + op + '" stroke="' + col + '" stroke-width=".6"/>'; }
        for(const q of [s.p[0], s.p[s.p.length - 1]]){ const a1 = Pq(q[1], q[0], zP), a2 = Pq(q[1], q[0], zP + th), b1 = Pq(q[2], q[0], zP), b2 = Pq(q[2], q[0], zP + th); b += '<polygon points="' + pts([a1, a2, b2, b1]) + '" fill="' + col + '" opacity=".4"/>'; } } }
    if(pcv){ const xs = pcv.Tk.map(x => x - C.zeroC); b += ribbon(xs, pcv.p, 2.4, 0.7, "#e2e8f0", 0.22) + line3(xs, pcv.p, 2.4, "#e2e8f0", 1.8) ; }
    b += ribbon(keep.map(i => Ds[i]), keep.map(i => prof.p[i]), 1.2, 0.7, "#22c55e", 0.30) + line3(keep.map(i => Ds[i]), keep.map(i => prof.p[i]), 1.2, "#4ade80", 2.4, true);
    b += ribbon(keep.map(i => Ts[i]), keep.map(i => prof.p[i]), 0, 0.7, "#fb7185", 0.34) + line3(keep.map(i => Ts[i]), keep.map(i => prof.p[i]), 0, "#fb7185", 3, true);
    // صفحهٔ باد: سرعت به‌صورت منحنی روی دیوار کناری
    let windTag = null; const wi = []; for(let i = 0; i < prof.p.length; i++) if(fin(prof.u[i]) && fin(prof.v[i]) && prof.p[i] >= pTop) wi.push(i);
    if(wi.length > 2){ const smax = Math.max(20, ...wi.map(i => Math.hypot(prof.u[i], prof.v[i]))), x0 = tx1 + 2, scx = 13 / smax;      // ۲۶ °C-معادل روی محور x
      const xs = wi.map(i => x0 + Math.hypot(prof.u[i], prof.v[i]) * scx), ps = wi.map(i => prof.p[i]); const base = ps.map(() => x0);
      b += '<polygon points="' + pts(ps.map((p, i) => Pq(xs[i], p, 0.6)).concat(ps.slice().reverse().map(p => Pq(x0, p, 0.6)))) + '" fill="#a78bfa" opacity=".35"/>' + line3(xs, ps, 0.6, "#c4b5fd", 2);
      windTag = L(en, "سرعت باد (تا " + f0(smax) + " m/s)", "wind speed (to " + f0(smax) + " m/s)"); }
    // اتصال ترازها: صفحه‌های افقی نیمه‌شفاف + برچسب
    const mk = marks(res, X, en, prof).filter(m => m.p >= pTop && m.p <= pBot);
    for(const m of mk){ const q = [Pq(tx0, m.p, 0), Pq(tx1, m.p, 0), Pq(tx1, m.p, Zn), Pq(tx0, m.p, Zn)]; b += '<polygon points="' + pts(q) + '" fill="' + m.col + '" opacity=".07"/><line x1="' + f1(q[1][0]) + '" y1="' + f1(q[1][1]) + '" x2="' + f1(q[2][0]) + '" y2="' + f1(q[2][1]) + '" stroke="' + m.col + '" stroke-width="1" opacity=".8"/>'; }
    const lab = spread(mk.map(m => Object.assign({}, m, {y:py(m.p, Zn)})), 15, 20, H3 - 40); for(const m of lab){ const x = px(tx1 + 17, m.p, Zn) + 8; b += '<text x="' + f1(x) + '" y="' + f1(m.y + 3.5) + '" fill="' + m.col + '" font-size="10.5" font-weight="700">' + esc(m.lab) + " " + f0(m.p) + "</text>"; }
    // برچسب پرده‌ها
    const tag = (txt, z, col) => { const q = Pq(tx0, pTop, z); return '<g><rect x="' + f1(q[0] + 4) + '" y="' + f1(q[1] - 20) + '" width="' + (txt.length * 6.4 + 14) + '" height="17" rx="8.5" fill="' + col + '" opacity=".92"/><text x="' + f1(q[0] + 11) + '" y="' + f1(q[1] - 8) + '" font-size="10.5" font-weight="700" fill="#0f172a">' + esc(txt) + "</text></g>"; };
    b += tag(L(en, "دما T", "Temperature T"), 0, "#fb7185") + tag(L(en, "شبنم Td", "Dew point Td"), 1.2, "#4ade80") + tag(L(en, "پارسل", "Parcel") + " " + res.parcelType, 2.4, "#e2e8f0") + (windTag ? tag(windTag, 0.6, "#c4b5fd").replace(/y="([\d.]+)"/g, (m0, v) => 'y="' + (+v + 24) + '"') : "");
    b += '<text x="20" y="28" fill="#e2e8f0" font-size="14" font-weight="800">' + esc(o.title || "Skew-T 3D") + '</text><text x="20" y="46" fill="#94a3b8" font-size="10.5">' + esc(L(en, "نمایش سه‌بعدی شبه‌مایل؛ زاویه را بچرخانید. عمق صرفاً نمایشی است.", "Oblique pseudo-3D view; rotate with the slider. Depth is purely visual.")) + "</text>";
    return b + "</svg>";
  };
  M.skewt2 = S;
})();
