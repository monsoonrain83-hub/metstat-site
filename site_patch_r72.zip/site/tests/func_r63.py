# r63: چیدمان دکمه‌های ساعت پیش‌بینی + لایهٔ L/H + منو (دادهٔ ساختگی nwp_maps --mock)
import sys, asyncio, functools
print = functools.partial(print, flush=True)
from playwright.async_api import async_playwright
URL = sys.argv[1] if len(sys.argv) > 1 else 'http://localhost:8098/index.html'
async def run(b, name, vp, mobile):
    ctx = await b.new_context(viewport=vp, locale='fa-IR', has_touch=mobile, is_mobile=mobile)
    await ctx.add_init_script('localStorage.setItem("mmap.lang", JSON.stringify("fa")); localStorage.setItem("mmap.seats.on","false")')
    pg = await ctx.new_page(); errs = []
    pg.on('pageerror', lambda e: errs.append('PAGEERR ' + str(e)[:300]))
    pg.on('console', lambda m: errs.append('CONSOLE ' + m.text[:200]) if m.type == 'error' else None)
    await pg.goto(URL); await pg.wait_for_timeout(1500)
    await pg.evaluate('(async()=>{ await openON(); })()'); await pg.wait_for_timeout(3500)
    ok = {}
    # ---- ۱) چیدمان ساعت‌ها: دادهٔ ساختگی ۰۲۴..۳۸۴ با گام‌های ۱،۳،۶
    r = await pg.evaluate("""(()=>{ const base=new Date(Date.UTC(2026,9,20,0)); const mk=s=>{ const d=new Date(base.getTime()+s*3600e3); const v=d.getUTCFullYear()+String(d.getUTCMonth()+1).padStart(2,"0")+String(d.getUTCDate()).padStart(2,"0")+String(d.getUTCHours()).padStart(2,"0"); return {s,v,p:NV.s.p,f:"x"}; };
      const it=[]; for(let s=24;s<=384;s++){ if(s<=120||(s<=240&&s%3===0)||s%6===0) it.push(mk(s)); }
      NV.items=it; NVW.open.time=true; const out={};
      for(const iv of [0,3,6,12,24]){ NVW.ivl=iv; nvWx(); const g=document.querySelector("#nvWx .wxRow.fr.wxGrid"); const cs=[...g.querySelectorAll(".wxChip")];
        const cols=cs.map(c=>c.style.gridColumn||""); const cv=getComputedStyle(g).gridTemplateColumns.split(" ").length;
        out[iv]={n:cs.length,cols:cv,style:g.getAttribute("style"),first:cols.slice(0,10).join("|"),lab:cs.slice(0,3).map(c=>c.textContent).join(",")}; }
      return out; })()""")
    print(name, 'layout', r)
    ok['grid8_all'] = r['0']['cols'] == 8 and r['24']['cols'] == 8
    ok['day3'] = r['3']['cols'] == 8 and r['3']['first'].startswith('1|2|3|4|5|6|7|8|1|2')   # از ۰۰ UTC شروع؛ هر ۸ تا یک روز
    ok['day6'] = r['6']['cols'] == 4 and r['6']['first'].startswith('1|2|3|4|1|2|3|4')
    ok['day12'] = r['12']['cols'] == 2
    # ---- ۲) L/H
    r = await pg.evaluate("""(async()=>{ NV.s.m="ecmwf"; NV.s.p="sfc"; NV.s.cat=nvPar("sfc").cat; nvFillCat(); await new Promise(r=>setTimeout(r,1500));
      const o={lvl:hlLevel(), hidden:document.querySelector(".nvHlDd").hidden, hl:!!(NV.entry&&NV.entry.hl), url:hlUrl(NV.entry.item)};
      HLC.msl=false; hlSave(); await nvResolve(); o.off_hl=!!NV.entry.hl; HLC.msl=true; hlSave(); await nvResolve(); o.on_hl=!!NV.entry.hl; return o; })()""")
    print(name, 'hl', r)
    ok['hl_level'] = r['lvl'] == 'msl'; ok['hl_menu_visible'] = r['hidden'] is False; ok['hl_loaded'] = r['hl'] is True
    ok['hl_off'] = r['off_hl'] is False and r['on_hl'] is True
    # پیکسل‌های قرمز/آبی روی بوم
    px = await pg.evaluate("""(()=>{ const c=document.getElementById("nvCv"), x=c.getContext("2d"), d=x.getImageData(0,0,c.width,c.height).data; let red=0,blue=0; for(let i=0;i<d.length;i+=4){ const r=d[i],g=d[i+1],b=d[i+2]; if(r>190&&g<60&&b<60) red++; if(b>190&&r<60&&g>60&&g<110) blue++; } return {red,blue,w:c.width,h:c.height}; })()""")
    print(name, 'pixels', px); ok['hl_pixels'] = px['red'] > 200 and px['blue'] > 200
    # منو برای پارامتر بدون مرکز پنهان شود
    r = await pg.evaluate("""(()=>{ const keep=NV.s.p; NV.s.p="t2m"; hlSync(); const h=document.querySelector(".nvHlDd").hidden; NV.s.p=keep; hlSync(); return {p:"t2m", hidden:h, back:document.querySelector(".nvHlDd").hidden}; })()""")
    print(name, 'hidden for other', r); ok['hl_hidden_other'] = r['hidden'] is True and r['back'] is False
    # ---- ۳) تمام‌صفحه: بخش L/H در پنل «لایه‌ها و گزینه‌ها»
    r = await pg.evaluate("""(async()=>{ document.getElementById("nvFsBtn").click(); await new Promise(r=>setTimeout(r,1000)); document.querySelector('[data-dd="lay"] .fsDdB').click(); await new Promise(r=>setTimeout(r,600));
      const h=document.querySelector(".nvHlFs"); const n=h?h.querySelectorAll("[data-hl]").length:0; const b=h&&h.querySelector('[data-hl="msl"]'); const was=b&&b.classList.contains("on"); if(b) b.click(); await new Promise(r=>setTimeout(r,800));
      return {n,was,now:HLC.msl,still:document.querySelectorAll(".nvHlFs [data-hl=msl].on").length}; })()""")
    print(name, 'fullscreen hl', r); ok['fs_hl_chips'] = r['n'] == 4 and r['was'] is True and r['now'] is False and r['still'] == 0
    ok['no_errors'] = not [e for e in errs if 'favicon' not in e and 'Failed to load resource' not in e]
    if not ok['no_errors']: print(name, 'ERRS', errs[:6])
    print(name, {k: ('PASS' if v else 'FAIL') for k, v in ok.items()}); await ctx.close(); return all(ok.values())
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(); res = []
        for name, vp, mob in (('desktop', {'width': 1280, 'height': 900}, False), ('mobile', {'width': 390, 'height': 800}, True)): res.append(await run(b, name, vp, mob))
        await b.close(); print('ALL PASS' if all(res) else 'SOME FAIL'); sys.exit(0 if all(res) else 1)
asyncio.run(main())
