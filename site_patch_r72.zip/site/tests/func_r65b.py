# r65b: دکمهٔ تحلیل و ذخیرهٔ PNG جدول در کارگاه‌ها
import sys, asyncio, functools
print = functools.partial(print, flush=True)
from playwright.async_api import async_playwright
URL = sys.argv[1] if len(sys.argv) > 1 else 'http://localhost:8098/index.html'
async def run(b, name, vp, mobile):
    ctx = await b.new_context(viewport=vp, locale='fa-IR', has_touch=mobile, is_mobile=mobile, accept_downloads=True)
    await ctx.add_init_script('localStorage.setItem("mmap.lang", JSON.stringify("fa")); localStorage.setItem("mmap.seats.on","false")')
    pg = await ctx.new_page(); errs = []
    pg.on('pageerror', lambda e: errs.append('PAGEERR ' + str(e)[:300]))
    await pg.goto(URL); await pg.wait_for_timeout(1500)
    ok = {}
    r = await pg.evaluate("""(()=>{ const host=document.createElement("div"); host.id="tHost"; document.body.append(host); host.style.cssText="position:fixed;inset:0;overflow:auto;background:#fff;z-index:99999";
      const html='<div class="dwTblW fit"><table><tr><th>شروع</th><th>پایان</th><th>مدت (ماه)</th><th>شدت</th></tr><tr><td>۱۳۹۸/۰۳</td><td>۱۳۹۹/۰۱</td><td>۱۲</td><td>-۱٫۸</td></tr><tr><td>۱۴۰۱/۰۶</td><td>۱۴۰۲/۰۲</td><td>۹</td><td>-۱٫۴</td></tr></table></div>';
      const c=drHtmlCard("جدول رخدادهای خشکسالی",html,host); const cv=document.createElement("canvas"); cv.width=300; cv.height=150; cv.getContext("2d").fillRect(0,0,50,50);
      const c2=caCard("نقشهٔ SPI دورهٔ یک‌ساله",cv,"",host);
      const b1=c.querySelectorAll(".wsAnRow button").length, b2=c2.querySelectorAll(".wsAnRow button").length; const tw=c.querySelector(".dwTblW"); return {b1,b2,fit:tw.classList.contains("fit"),sw:tw.scrollWidth,cw:tw.clientWidth,txt:[...c.querySelectorAll(".wsAnRow button")].map(x=>x.textContent)}; })()""")
    print(name, r); ok['btn_table'] = r['b1'] >= 2; ok['btn_map'] = r['b2'] >= 1; ok['no_hscroll'] = r['sw'] <= r['cw'] + 1
    async with pg.expect_download() as d:
        await pg.evaluate("[...document.querySelectorAll('#tHost .wsAnRow button')].find(b=>b.textContent.includes('PNG')).click()")
    dl = await d.value; ok['png'] = dl.suggested_filename.endswith('.png'); print(name, dl.suggested_filename)
    await pg.evaluate("[...document.querySelectorAll('#tHost .wsAnRow button')].find(b=>b.textContent.includes('تحلیل')).click()"); await pg.wait_for_timeout(500)
    r = await pg.evaluate("(()=>{ const d=document.querySelector('.wsandlg'); return d?{len:d.textContent.length,tts:!!d.querySelector('[class*=tts],.ttsBar,button[data-tts]')}:null; })()"); print(name, 'dialog', r)
    ok['dialog'] = bool(r) and r['len'] > 80
    ok['no_errors'] = not [e for e in errs if 'favicon' not in e]
    if errs: print(errs[:3])
    print(name, {k: ('PASS' if v else 'FAIL') for k, v in ok.items()}); await ctx.close(); return all(ok.values())
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(); res = []
        for name, vp, mob in (('desktop', {'width': 1280, 'height': 900}, False), ('mobile', {'width': 390, 'height': 800}, True)): res.append(await run(b, name, vp, mob))
        await b.close(); print('ALL PASS' if all(res) else 'SOME FAIL'); sys.exit(0 if all(res) else 1)
asyncio.run(main())
