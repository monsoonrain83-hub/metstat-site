# r65c: کادر «اروپا» (کاشی eu) در نمایشگر — هندسه، فهرست، بازگشت به خاورمیانه، مالتی‌مدل
import sys, asyncio, functools, os
print = functools.partial(print, flush=True)
from playwright.async_api import async_playwright
URL = sys.argv[1] if len(sys.argv) > 1 else 'http://localhost:8098/index.html'
EU = '/tmp/eu_out/ecmwf/2026102100/eu/sfc_2026102100.webp'
async def run(b, name, vp, mobile):
    ctx = await b.new_context(viewport=vp, locale='fa-IR', has_touch=mobile, is_mobile=mobile)
    await ctx.add_init_script('localStorage.setItem("mmap.lang", JSON.stringify("fa")); localStorage.setItem("mmap.seats.on","false")')
    pg = await ctx.new_page(); errs = []
    pg.on('pageerror', lambda e: errs.append('PAGEERR ' + str(e)[:300]))
    async def eu_tile(route): await route.fulfill(path=EU, content_type='image/webp')
    await pg.route('**/eu/**', eu_tile)
    await pg.goto(URL); await pg.wait_for_timeout(1500)
    await pg.evaluate('(async()=>{ await openON(); })()'); await pg.wait_for_timeout(3500)
    ok = {}
    r = await pg.evaluate("""(async()=>{ const M=ON.man; const sfc=M.items.filter(i=>i.m==="ecmwf"&&i.r==="me"&&i.p==="sfc"); M.items.push(...sfc.map(i=>Object.assign({},i,{r:"eu",f:i.f.replace("/me/","/eu/")})));
      NV.s.m="ecmwf"; NV.s.p="sfc"; NV.s.cat=nvPar("sfc").cat; NV.s.reg="me"; nvFillCat(); await new Promise(r=>setTimeout(r,800));
      const o0={rk:NV_RK,box:NV_BOX.join(),n:NV.items.length,r0:NV.items[0]&&NV.items[0].r};
      $("nvReg").value="eu"; $("nvReg").onchange(); await new Promise(r=>setTimeout(r,1500));
      const o1={rk:NV_RK,box:NV_BOX.join(),tw:NV_TW,n:NV.items.length,r0:NV.items[0]&&NV.items[0].r,reg:NV.s.reg,ent:NV.entry&&NV.entry.item.r,img:NV.entry&&NV.entry.img&&NV.entry.img.naturalWidth,view:NV.view&&Math.round(NV.view.k)};
      const dis=$("nvReg").querySelector('option[value="eu"]').disabled;
      // پارامتری که eu ندارد: برگشت به me
      NV.s.p="z850"; NV.s.cat=nvPar("z850").cat; nvFillFr(); await new Promise(r=>setTimeout(r,1200));
      const o2={rk:NV_RK,reg:NV.s.reg,box:NV_BOX.join(),ent:NV.entry&&NV.entry.item.r,dis:$("nvReg").querySelector('option[value="eu"]').disabled};
      return {o0,o1,dis,o2}; })()""")
    print(name, r)
    ok['start_me'] = r['o0']['rk'] == 'me' and r['o0']['r0'] == 'me'
    ok['eu_geometry'] = r['o1']['rk'] == 'eu' and r['o1']['box'] == '-12,68,12,62' and r['o1']['tw'] == 1280 and r['o1']['r0'] == 'eu' and r['o1']['ent'] == 'eu' and r['o1']['img'] == 1280
    ok['eu_enabled'] = r['dis'] is False
    ok['fallback_me'] = r['o2']['rk'] == 'me' and r['o2']['reg'] == 'me' and r['o2']['box'] == '20,65,12,42' and r['o2']['ent'] == 'me' and r['o2']['dis'] is True
    # رسم بدون خطا + اسکرین‌شات
    await pg.evaluate("(async()=>{ NV.s.p='sfc'; NV.s.cat=nvPar('sfc').cat; NV.s.reg='eu'; nvFillCat(); await new Promise(r=>setTimeout(r,1500)); })()")
    await pg.screenshot(path=f'/tmp/eu_{name}.png')
    ok['no_errors'] = not [e for e in errs if 'favicon' not in e]
    if errs: print(errs[:3])
    print(name, {k: ('PASS' if v else 'FAIL') for k, v in ok.items()}); await ctx.close(); return all(ok.values())
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(); res = []
        for name, vp, mob in (('desktop', {'width': 1280, 'height': 900}, False), ('mobile', {'width': 390, 'height': 800}, True)): res.append(await run(b, name, vp, mob))
        await b.close(); print('ALL PASS' if all(res) else 'SOME FAIL'); sys.exit(0 if all(res) else 1)
asyncio.run(main())
