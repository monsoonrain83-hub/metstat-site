from playwright.sync_api import sync_playwright
OUT="/tmp/syn68_"
CNT="()=>{const c=document.querySelector('#synCv'),x=c.getContext('2d');const d=x.getImageData(0,0,c.width,c.height).data;const s=new Set();for(let i=0;i<d.length;i+=4*97)s.add(d[i]+','+d[i+1]+','+d[i+2]);return s.size}"
with sync_playwright() as p:
    b=p.chromium.launch()
    for mob in (False,True):
        pg=b.new_page(viewport={"width":420,"height":900} if mob else {"width":1280,"height":900}); errs=[]; pg.on("pageerror",lambda e:errs.append(str(e)))
        
        pg.goto("http://localhost:8098/index.html"); pg.wait_for_timeout(2500)
        pg.evaluate("openSynTab()"); pg.wait_for_function("document.querySelector('#synTime') && document.querySelector('#synTime').textContent.length>5",timeout=20000)
        res={}
        for lay in ["vo","dv","ta","tw","te","t","rh","ws","w","th","msl","t2","ws10","pw","mfc","ki","tt","dte","lr","shr","gtw","cc"]:
            L=pg.evaluate(f"SYN_LAY['{lay}'].lev[0]")
            pg.select_option("#synLay",lay)
            pg.wait_for_timeout(250); res[lay]=pg.evaluate(CNT)
        pg.select_option("#synLay","cape"); pg.wait_for_function("SYN.col[Object.keys(SYN.col)[0]]&&SYN.col[Object.keys(SYN.col)[0]].done>=SYN.col[Object.keys(SYN.col)[0]].N",timeout=120000); pg.wait_for_timeout(500); res["cape"]=pg.evaluate(CNT)
        pg.select_option("#synLay","vo"); pg.select_option("#synLev","850")
        # multi-layer: second shade + 3 contour lines
        pg.select_option("#synLay2","t"); pg.select_option("#synAddL","msl"); pg.click("#synAddB"); pg.select_option("#synAddL","t"); pg.click("#synAddB")
        pg.check("#synF"); pg.check("#synW"); pg.check("[data-b=prov]"); pg.wait_for_timeout(700)
        res["lines"]=pg.evaluate("SYN.st.lines.length"); res["fronts"]=pg.evaluate("(SYN.fr||[]).length")
        # zoom
        v0=pg.evaluate("SYN.view.ppd"); pg.click("#synZi"); pg.wait_for_timeout(300); res["zoom"]=pg.evaluate("SYN.view.ppd")/v0
        pg.locator("#synCv").scroll_into_view_if_needed(); box=pg.locator("#synCv").bounding_box(); pg.mouse.move(box["x"]+box["width"]/2,box["y"]+box["height"]/2); cx=pg.evaluate("SYN.view.cx")
        pg.mouse.down(); pg.mouse.move(box["x"]+box["width"]/2+80,box["y"]+box["height"]/2+10,steps=5); pg.mouse.up(); res["pan"]=abs(pg.evaluate("SYN.view.cx")-cx)>0.1
        # skew-T probe
        pg.check("#synSkOn"); pg.mouse.click(box["x"]+box["width"]*0.4,box["y"]+box["height"]*0.5); pg.wait_for_timeout(800)
        res["skew"]=pg.evaluate("!!document.querySelector('#synSkSvg svg')"); res["cards"]=pg.evaluate("document.querySelectorAll('#synCards .labCard').length")
        pg.click("#synAn1"); pg.wait_for_timeout(300); res["analysis"]=pg.evaluate("document.querySelector('#synAn').innerText.length>50")
        # fullscreen (pseudo)
        pg.click("#synFs"); pg.wait_for_timeout(400); res["full"]=pg.evaluate("SYN.box.clientHeight")>=600
        pg.locator("body").screenshot(path=OUT+("m" if mob else "d")+"_full.png") if False else None
        pg.click("#synFs"); pg.wait_for_timeout(300)
        # GFS
        pg.select_option("#synModel","gfs"); pg.wait_for_timeout(1500); res["gfs"]=pg.evaluate("SYN.model")
        pg.screenshot(path=OUT+("m" if mob else "d")+".png",full_page=True)
        # menu / tabs
        tabs=pg.evaluate("[...document.querySelectorAll('#anTabs .anTab')].filter(b=>!b.hidden).map(b=>b.dataset.k)")
        pg.evaluate("openAN('auto')"); pg.wait_for_timeout(500); tabs2=pg.evaluate("[...document.querySelectorAll('#anTabs .anTab')].filter(b=>!b.hidden).map(b=>b.dataset.k)")
        pg.evaluate("openLab()"); pg.wait_for_timeout(500); lab=pg.evaluate("[getComputedStyle(document.querySelector('#labApp .labSeg')).display,!!document.querySelector('#mgChart')]")
        print("mobile" if mob else "desktop",res,tabs,tabs2,lab,errs)
        assert not errs, errs
        assert all(v>3 for k,v in res.items() if k in ["vo","dv","ta","tw","te","t","rh","ws","w","th","msl","t2","ws10","pw","mfc","ki","tt","dte","lr","shr","gtw","cc","cape"]), res
        assert res["skew"] and res["cards"]>5 and res["analysis"] and res["pan"] and res["zoom"]>1.2 and res["gfs"]=="gfs" and res["lines"]==3
        assert tabs==["syn","lab"] and tabs2==["auto","multi","wn","cv"]
print("ALL PASS")
