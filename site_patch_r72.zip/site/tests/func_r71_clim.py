import json, math, datetime as dt
from playwright.sync_api import sync_playwright
def fc(route):
    u=route.request.url
    t0=dt.datetime.now().replace(minute=0,second=0,microsecond=0)-dt.timedelta(days=1)
    times=[(t0+dt.timedelta(hours=i)).strftime("%Y-%m-%dT%H:%M") for i in range(24*17)]
    H={"time":times,"temperature_2m":[18+8*math.sin((i%24-9)/24*2*math.pi)+0.1*i/24 for i in range(len(times))],"relative_humidity_2m":[40]*len(times),"wind_speed_10m":[10]*len(times),"wind_direction_10m":[200]*len(times),"wind_gusts_10m":[20]*len(times),"precipitation":[0.2 if i%24==5 else 0 for i in range(len(times))],"cloud_cover":[30]*len(times)}
    days=sorted({x[:10] for x in times}); D={"time":days,"precipitation_sum":[0.2]*len(days)}
    route.fulfill(status=200,content_type="application/json",body=json.dumps({"latitude":29.13,"longitude":54.04,"elevation":1700,"hourly":H,"daily":D}))
def ar(route):
    days=[];tm=[];tx=[];tn=[];pr=[]
    d=dt.date(1991,1,1)
    while d<=dt.date(2020,12,31):
        doy=d.timetuple().tm_yday; c=15+14*math.sin((doy-110)/365*2*math.pi)+((d.year*7+doy)%5-2)
        days.append(d.isoformat()); tm.append(c); tx.append(c+8); tn.append(c-8); pr.append(1.0 if (d.year+doy)%4==0 else 0.0); d+=dt.timedelta(days=1)
    route.fulfill(status=200,content_type="application/json",body=json.dumps({"latitude":29.0,"longitude":54.0,"elevation":1700,"daily":{"time":days,"temperature_2m_mean":tm,"temperature_2m_max":tx,"temperature_2m_min":tn,"precipitation_sum":pr}}))
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={"width":420,"height":900}); errs=[]; pg.on("pageerror",lambda e:errs.append(str(e)))
    pg.route("https://api.open-meteo.com/**",fc); pg.route("https://archive-api.open-meteo.com/**",ar)
    pg.goto("http://localhost:8098/index.html"); pg.wait_for_timeout(2000); pg.evaluate("openLab()"); pg.wait_for_timeout(800)
    pg.click("#labOmGo"); pg.wait_for_selector("#mgChart svg",timeout=60000)
    pg.click("[data-mgc]"); pg.wait_for_function("document.querySelector('#mgClimInfo').textContent.includes('°C')",timeout=60000)
    r={"info":pg.inner_text("#mgClimInfo")[:140],"band":pg.evaluate("document.querySelectorAll('#mgChart polygon[fill=\"#f59e0b\"]').length"),"btn":pg.evaluate("!!document.querySelector('[data-mgc].on')")}
    pg.click("[data-mgp=pd]"); pg.wait_for_timeout(600); r["pinfo"]=pg.inner_text("#mgClimInfo")[:100]; r["ticks"]=pg.evaluate("document.querySelectorAll('#mgChart line[stroke=\"#b45309\"]').length")
    pg.click("[data-mgp=t]"); pg.wait_for_timeout(500); pg.locator("#mgChart").screenshot(path="/tmp/clim.png")
    print(r,errs); assert not errs and r["band"]==1 and r["ticks"]>=3 and "°C" in r["info"]
print("ALL PASS")
