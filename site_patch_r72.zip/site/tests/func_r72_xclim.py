import json, math, datetime as dt
from playwright.sync_api import sync_playwright
def ar(route):
    days=[];tm=[];tx=[];tn=[];pr=[]
    d=dt.date(1950,1,1); end=dt.date(dt.date.today().year-1,12,31)
    while d<=end:
        doy=d.timetuple().tm_yday; c=15+14*math.sin((doy-110)/365*2*math.pi)+0.03*(d.year-1950)+((d.year*7+doy)%5-2)
        days.append(d.isoformat()); tm.append(c); tx.append(c+8); tn.append(c-8); pr.append(float((d.year+doy)%9) if (d.year*3+doy)%4==0 else 0.0); d+=dt.timedelta(days=1)
    route.fulfill(status=200,content_type="application/json",body=json.dumps({"latitude":35.7,"longitude":51.4,"elevation":1200,"daily":{"time":days,"temperature_2m_mean":tm,"temperature_2m_max":tx,"temperature_2m_min":tn,"precipitation_sum":pr}}))
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={"width":420,"height":900}); errs=[]; pg.on("pageerror",lambda e:errs.append(str(e)))
    pg.route("https://archive-api.open-meteo.com/**",ar)
    pg.goto("http://localhost:8098/index.html"); pg.wait_for_timeout(2000); pg.evaluate("openDR()"); pg.wait_for_timeout(1500)
    pg.click(".dwTabs button[data-t=xi]"); pg.wait_for_timeout(500)
    pg.click("#xiGo"); pg.wait_for_function("document.querySelectorAll('#drCards .card').length>=6",timeout=100000)
    n=pg.evaluate("document.querySelectorAll('#drCards .card').length"); st=pg.inner_text("#drStatus")
    print("point cards",n,repr(st)); pg.locator("#drCards .card").nth(0).screenshot(path="/tmp/xi_ov.png"); pg.locator("#drCards .card").nth(1).screenshot(path="/tmp/xi_pan.png")
    pg.locator("#drCards .card").nth(4).screenshot(path="/tmp/xi_stripes.png"); pg.locator("#drCards .card").nth(5).screenshot(path="/tmp/xi_heat.png")
    pg.click(".dwSub button[data-xs=map]"); pg.wait_for_timeout(400)
    for k in ["dm","gb","pci","cont","ai"]:
        pg.select_option("#xiMap",k); c0=pg.evaluate("document.querySelectorAll('#drCards .card').length"); pg.click("#xiGoM")
        pg.wait_for_function(f"document.querySelectorAll('#drCards .card').length>{c0} || document.getElementById('drStatus').textContent.includes('⚠')",timeout=100000)
        s=pg.inner_text("#drStatus"); print(k,"status:",s[:120])
        if k in("dm","ai"): pg.locator("#drCards .card").nth(0).screenshot(path=f"/tmp/xi_map_{k}.png")
    print(errs); assert not errs
print("ALL PASS")
