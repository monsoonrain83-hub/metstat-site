from playwright.sync_api import sync_playwright
def run(pg, btn, shots):
    pg.evaluate("document.querySelectorAll('#drCards .card').forEach(c=>c.dataset.old=1)")
    pg.click(btn); pg.wait_for_function("document.querySelectorAll('#drCards .card:not([data-old])').length>=1 || document.getElementById('drStatus').textContent.includes('⚠')",timeout=150000)
    st=pg.inner_text("#drStatus"); n=pg.evaluate("document.querySelectorAll('#drCards .card').length"); print(btn,repr(st)[:160],n); assert "⚠" not in st
    for i,s in enumerate(shots): pg.locator("#drCards .card").nth(i).screenshot(path=s)
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={"width":420,"height":900}); errs=[]; pg.on("pageerror",lambda e:errs.append(str(e)))
    pg.goto("http://localhost:8098/index.html"); pg.wait_for_timeout(2000); pg.evaluate("openDR()"); pg.wait_for_timeout(1500)
    pg.click(".dwTabs button[data-t=cm]"); pg.wait_for_timeout(800)
    # پایه: نقطه با مبنای ۱۹۸۱–۲۰۱۰ و دوره‌های ۳۰ ساله
    pg.select_option("#cmBp","wmo"); pg.select_option("#cmWl","30"); pg.wait_for_timeout(400)
    run(pg,"#cmGo",["/tmp/cm_pt0.png","/tmp/cm_pt1.png"])
    pg.click(".dwSub button[data-cs=map]"); pg.wait_for_timeout(400); pg.select_option("#cmUnc","ar6"); run(pg,"#cmGoM",["/tmp/cm_map_ar6.png"])
    pg.select_option("#cmBp","ar6"); pg.select_option("#cmWl","20")
    pg.click(".dwSub button[data-cs=adv]"); pg.wait_for_timeout(400)
    run(pg,"#cmAdvGo",["/tmp/cm_gwl0.png","/tmp/cm_gwl1.png"])
    run(pg,"#cmAdvMap",["/tmp/cm_gwl_map.png"])
    pg.select_option("#cmAm","toe"); pg.wait_for_timeout(400); run(pg,"#cmAdvGo",["/tmp/cm_toe0.png","/tmp/cm_toe1.png"]); run(pg,"#cmAdvMap",["/tmp/cm_toe_map.png"])
    pg.select_option("#cmAm","prob"); pg.wait_for_timeout(400); pg.select_option("#cmV","pr"); pg.wait_for_timeout(500); print("thr",pg.input_value("#cmThr"))
    run(pg,"#cmAdvGo",["/tmp/cm_pr0.png","/tmp/cm_pr1.png"]); run(pg,"#cmAdvMap",["/tmp/cm_pr_map.png"])
    print(errs); assert not errs
print("ALL PASS")
