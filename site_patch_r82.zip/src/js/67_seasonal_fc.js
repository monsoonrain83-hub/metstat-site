/* ===== r82 — «پیش‌بینی ماهانه و فصلی» (هستهٔ تحلیل اقلیم) =====
   پیش‌بینی آماری بارش (و دما) برای ۵ ماه آینده از برهمکنش شاخص‌های پیوند از دور، با دادهٔ ماهانهٔ ایستگاه‌های اطلس (تکمیل با ERA5).
   ── گام ۱: پیش‌بینی شاخص‌ها — برای هر شاخص و هر ماه هدف، رگرسیون تأخیری فصل‌به‌فصل (x(t+h) از x(t)، x(t−1) و برای QBO مؤلفهٔ دیگرش)
            روی تاریخچهٔ همان شاخص؛ میانگین (= حالت کنترل) و ۱۰ حالت ممبر از باقی‌ماندهٔ مشترک سال‌های گذشته (هم‌بستگی بین شاخص‌ها حفظ می‌شود).
   ── گام ۲: برای هر نقطه و ماه هدف (نمونه‌ها: همان ماه و دو ماه مجاور در همهٔ سال‌ها)
            • وزن هر شاخص = همبستگی معنی‌دار آن با ناهنجاری استانداردشدهٔ بارش (هموارشده در شعاع ~۱۵۰ km)
            • «آنالوگ هسته‌ای» (kNN): سال‌هایی که ترکیب شاخص‌هایشان نزدیک است — برهمکنش غیرخطی را از خود تاریخ می‌گیرد
            • «رگرسیون ستیغی با جملهٔ برهمکنش» (z_i·z_j برای ۴ شاخص مهم‌تر) — برای ترکیب‌هایی که هرگز رخ نداده‌اند برون‌یابی می‌کند
            • سهم آنالوگ با نزدیکی نزدیک‌ترین سال تعیین می‌شود (ترکیب بی‌سابقه ⇒ سهم رگرسیون بیشتر)
            • اعتبارسنجی حذف‌یک‌سال (LOYO): مهارت r و ضریب کالیبراسیون (پیش‌بینی بی‌مهارت به سمت نرمال کشیده می‌شود)
   ── خروجی هر ماه: کنترل، ۱۰ ممبر (حالت شاخص ممبر + باقی‌ماندهٔ واقعی نزدیک‌ترین سال‌های مشابه، که الگوی مکانی را حفظ می‌کند)، و میانگین ۱۰ ممبر.
   دادهٔ تازهٔ شاخص‌ها: online/data/sfc/sfc_idx.json و ERA5: online/data/sfc/era5_iran.json (ساختهٔ sfc_build.py، روز ۱ و ۱۵ هر ماه میلادی). */
const SFT=(fa,en)=>LANG==="en"?en:fa;
const SF_MAIN=["NINO 3/4","DMI","QBO30","MJO","PDO","PNA","AO","NAO","EAWR","SCAND"];
const SF_GRP=[["اقیانوسی (انسو، اقیانوس هند و …)","Oceanic (ENSO, Indian Ocean …)",["NINO 3/4","ONI","MEI v2","SOI","Nino 4","nino 3","nino 1","DMI","PDO","AMO","TNA","BEST"]],
  ["پوشن‌سپهر و حاره (QBO، MJO)","Stratosphere & tropics (QBO, MJO)",["QBO30","QBO50","MJO","MJO act","MJO 2-3","MJO 4-5"]],
  ["الگوهای جوی نیم‌کرهٔ شمالی","Northern-hemisphere patterns",["NAO","AO","PNA","EAWR","SCAND","EA","WP","POL","EPO","ep/np","GBI"]]];
const SF_PARTNER={"QBO30":"QBO50","QBO50":"QBO30"};
const SF_Y0=1330;                       // آغاز دورهٔ آموزش (۱۹۵۱)
const SF={busy:false, ready:false, J:null, era:null, idx:{}, Z:{}, zs:{}, NMX:0, tNow:0, issued:null, fc:null, models:new Map(), out:{}, cards:new Map(), view:{mode:"auto",ti:0,kind:"c"},
  o:Object.assign({par:"prcp",src:"ae",reg:"",pal:"wm",idx:SF_MAIN.slice()},store.get("sf.o",{})), conds:store.get("sf.conds",null), cm:store.get("sf.cm",null)};
const sfSave=()=>{ store.set("sf.o",SF.o); store.set("sf.conds",SF.conds); store.set("sf.cm",SF.cm); };
const sfIsP=()=>SF.o.par==="prcp";
const sfMonLab=t=>{ const jy=CLIM_META.jy0+Math.floor(t/12), jm=t%12; return SFT(`${CA_MN[jm]} ${FA(jy)}`,`${CA_MN_EN?CA_MN_EN[jm]:jm+1} ${jy}`); };
const CA_MN_EN=["Farvardin","Ordibehesht","Khordad","Tir","Mordad","Shahrivar","Mehr","Aban","Azar","Dey","Bahman","Esfand"];
const sfGDate=t=>{ const jy=CLIM_META.jy0+Math.floor(t/12), jm=t%12+1; const [gy,gm,gd]=j2gArr(jy,jm,1); return new Date(Date.UTC(gy,gm-1,gd)); };
const SF_GFMT=new Intl.DateTimeFormat("en-GB",{day:"numeric",month:"short",timeZone:"UTC"});
const sfGRange=t=>{ const a=sfGDate(t), b=new Date(sfGDate(t+1).getTime()-864e5); return `${SF_GFMT.format(a)} – ${SF_GFMT.format(b)} ${b.getUTCFullYear()}`; };
const sfDFmt=d=>new Intl.DateTimeFormat(LANG==="en"?"en-GB":"fa-IR-u-ca-persian",{year:"numeric",month:"long",day:"numeric",timeZone:"Asia/Tehran"}).format(d);
function sfNextUpd(d){ const y=d.getUTCFullYear(), m=d.getUTCMonth(), dd=d.getUTCDate(); return dd<15?new Date(Date.UTC(y,m,15)):new Date(Date.UTC(y,m+1,1)); }
const sfStatus=(s)=>{ const e=$("sfStatus"); if(e) e.textContent=s||""; };
const sfTick=()=>new Promise(r=>setTimeout(r,0));

/* ---------- داده: شاخص‌ها (اطلس + فایل تازه)، ERA5 ---------- */
function sfG2P(arr, g0, NMX){ const out=new Float32Array(NMX).fill(NaN), jy0=CLIM_META.jy0;
  for(let t=0;t<NMX;t++){ const jy=jy0+Math.floor(t/12), jm=t%12+1, [gy,gm,gd]=j2gArr(jy,jm,1), dn=jm<=6?31:jm<=11?30:29, gi=(gy-g0[0])*12+(gm-g0[1]); if(gi<0||gi>=arr.length) continue;
    const a=arr[gi], b=gi+1<arr.length?arr[gi+1]:null, dimG=new Date(Date.UTC(gy,gm,0)).getUTCDate(), w1=Math.max(0,Math.min(dn,dimG-gd+1)), w2=dn-w1;
    if(a==null&&b==null) continue; out[t]=a==null?(w2>dn/2?b:NaN):b==null?(w1>dn/2?a:NaN):(a*w1+b*w2)/dn; if(out[t]!==out[t]) out[t]=NaN; }
  return out; }
function sfB64(s){ const b=atob(s), u=new Uint8Array(b.length); for(let i=0;i<b.length;i++) u[i]=b.charCodeAt(i); return new Int16Array(u.buffer); }
async function sfLoad(){ if(SF.ready) return; await caLoad(); const M=CLIM_META, now=new Date();
  let J=null; try{ const r=await fetch((typeof ON!=="undefined"&&ON.base?ON.base:"online/")+"data/sfc/sfc_idx.json?"+(Date.now()/36e5|0),{cache:"no-store"}); if(r.ok) J=await r.json(); }catch(e){}
  SF.J=J&&J.ver===1&&J.v?J:null; SF.issued=SF.J&&SF.J.issued?new Date(SF.J.issued):null;
  const ref=SF.issued||now; let t=CA.db.NM-36; while(sfGDate(t+1)<=ref) t++; SF.tNow=t; SF.NMX=Math.max(CA.db.NM,t+8);
  for(const [k,a] of Object.entries(CA.idx)){ const o=new Float32Array(SF.NMX).fill(NaN); o.set(a.subarray(0,Math.min(a.length,SF.NMX))); SF.idx[k]=o; }
  if(SF.J) for(const [k,a] of Object.entries(SF.J.v||{})){ const f=sfG2P(a,SF.J.g0,SF.NMX), o=SF.idx[k]||(SF.idx[k]=new Float32Array(SF.NMX).fill(NaN)); for(let i=0;i<SF.NMX;i++) if(f[i]===f[i]&&!(o[i]===o[i])) o[i]=f[i]; }  /* اطلس مرجع تاریخچه است؛ فایل آنلاین فقط جاهای خالی/ماه‌های تازه را پر می‌کند */
  // z-score هر شاخص نسبت به ماه تقویمی (دورهٔ آموزش)
  const t0=(SF_Y0-M.jy0)*12; for(const [k,a] of Object.entries(SF.idx)){ const mu=new Float64Array(12), sd=new Float64Array(12);
    for(let m=0;m<12;m++){ let s=0,s2=0,n=0; for(let i=t0+m;i<SF.NMX;i+=12){ const v=a[i]; if(v===v){ s+=v; s2+=v*v; n++; } } mu[m]=n?s/n:NaN; sd[m]=n>2?Math.sqrt(Math.max(1e-12,(s2-s*s/n)/(n-1))):NaN; }
    const z=new Float32Array(SF.NMX).fill(NaN); for(let i=0;i<SF.NMX;i++){ const v=a[i], m=i%12; if(v===v&&sd[m]>0) z[i]=(v-mu[m])/sd[m]; } SF.Z[k]=z; SF.zs[k]={mu,sd}; }
  try{ const r=await fetch((typeof ON!=="undefined"&&ON.base?ON.base:"online/")+"data/sfc/era5_iran.json?"+(Date.now()/864e5|0),{cache:"default"}); if(r.ok){ const E=await r.json(); if(E.v===1){
      const n=E.pts.length, NG=E.nm, P=sfB64(E.pr), T2=E.t2?sfB64(E.t2):null, ser=(A,sc,i)=>{ const g=new Array(NG); for(let j=0;j<NG;j++){ const v=A[i*NG+j]; g[j]=v===-32768?null:v/sc; } return sfG2P(g,E.g0,CA.db.NM); };
      SF.era={pts:E.pts, n, g0:E.g0, built:E.built||"", pr:[...Array(n)].map((_,i)=>ser(P,10,i)), tm:T2?[...Array(n)].map((_,i)=>ser(T2,100,i)):null}; } } }catch(e){ console.warn("era5",e); }
  if(!SF.era&&SF.o.src!=="a") SF.o.src="a";
  SF.ready=true; }
const sfKeys=()=>SF.o.idx.filter(k=>SF.idx[k]&&sfLastObs(k)>=0);
function sfLastObs(k){ const a=SF.idx[k]; if(!a) return -1; for(let i=Math.min(SF.tNow,a.length-1);i>=0;i--) if(a[i]===a[i]) return i; return -1; }

/* ---------- جبر خطی کوچک ---------- */
function sfSolve(A,b){ const n=b.length, M=A.map((r,i)=>[...r,b[i]]); for(let c=0;c<n;c++){ let p=c; for(let r=c+1;r<n;r++) if(Math.abs(M[r][c])>Math.abs(M[p][c])) p=r; if(Math.abs(M[p][c])<1e-12) return null; [M[c],M[p]]=[M[p],M[c]];
    for(let r=0;r<n;r++){ if(r===c) continue; const f=M[r][c]/M[c][c]; if(!f) continue; for(let k=c;k<=n;k++) M[r][k]-=f*M[c][k]; } } return M.map((r,i)=>r[n]/r[i]); }

/* ---------- گام ۱: پیش‌بینی شاخص‌ها ---------- */
function sfIdxForecast(keys){ const T0=(SF_Y0-CLIM_META.jy0)*12, out={};
  for(const k of keys){ const a=SF.idx[k], L=sfLastObs(k); if(L<0) continue; const pk=SF_PARTNER[k], pa=pk&&SF.idx[pk]&&sfLastObs(pk)>=L?SF.idx[pk]:null, fc=[];
    for(let j=1;j<=5;j++){ const T=SF.tNow+j, h=T-L, mT=T%12;
      if(h<=0){ fc.push({T,h,mu:a[T],sd:0,res:new Map(),obs:true}); continue; }
      const X=[],Y=[],yr=[];
      for(let t=T0+1;t+h<=L;t++){ const tt=t+h, cm=tt%12; if(!(cm===mT||cm===(mT+1)%12||cm===(mT+11)%12)) continue; const x0=a[t], x1=a[t-1], y=a[tt]; if(!(x0===x0&&x1===x1&&y===y)) continue; const r=[1,x0,x1]; if(pa){ const p0=pa[t]; if(!(p0===p0)) continue; r.push(p0); } X.push(r); Y.push(y); yr.push(cm===mT?CLIM_META.jy0+Math.floor(tt/12):null); }
      const st=SF.zs[k]; let mu=st.mu[mT], sd=st.sd[mT], res=new Map(), skill=0;
      if(X.length>=30){ const p=X[0].length, A=[...Array(p)].map(()=>new Array(p).fill(0)), c=new Array(p).fill(0); X.forEach((r,i)=>{ for(let q=0;q<p;q++){ c[q]+=r[q]*Y[i]; for(let s=0;s<p;s++) A[q][s]+=r[q]*r[s]; } }); for(let q=1;q<p;q++) A[q][q]+=1e-6*X.length;
        const b=sfSolve(A,c); if(b){ const q=[1,a[L],a[L-1]]; if(pa) q.push(pa[L]); if(q.every(v=>v===v)){ let ss=0; X.forEach((r,i)=>{ const e=Y[i]-r.reduce((s,v,j)=>s+v*b[j],0); ss+=e*e; if(yr[i]!=null) res.set(yr[i],e); });
            const sdr=Math.sqrt(ss/Math.max(1,X.length-p)); mu=q.reduce((s,v,j)=>s+v*b[j],0); skill=Math.max(0,1-(sdr*sdr)/(sd*sd)); sd=Math.min(sd,sdr); } } }
      if(!res.size){ const m0=st.mu[mT]; for(let t=T0+mT;t<=L;t+=12){ const v=a[t]; if(v===v) res.set(CLIM_META.jy0+Math.floor(t/12),v-m0); } }
      fc.push({T,h,mu,sd,res,skill}); }
    out[k]={k,L,Lv:a[L],fc}; }
  return out; }
// ۱۰ حالت ممبر برای هر ماه هدف: باقی‌ماندهٔ مشترک یک سال گذشته برای همهٔ شاخص‌ها (مرتب‌شده با مؤلفهٔ اول)
function sfMemberStates(F, keys, j){ const yrs=new Set(); for(const k of keys){ const f=F[k]&&F[k].fc[j]; if(f) for(const y of f.res.keys()) yrs.add(y); }
  const Y=[...yrs].filter(y=>keys.filter(k=>F[k]&&F[k].fc[j]&&F[k].fc[j].res.has(y)).length>=Math.ceil(keys.length*0.7)).sort((a,b)=>a-b);
  const R=Y.map(y=>keys.map(k=>{ const f=F[k]&&F[k].fc[j]; if(!f) return 0; const e=f.res.get(y); return e==null?0:e; }));
  const sc=keys.map((k,q)=>{ const v=R.map(r=>r[q]); const m=v.reduce((s,x)=>s+x,0)/(v.length||1); return Math.sqrt(v.reduce((s,x)=>s+(x-m)**2,0)/Math.max(1,v.length-1))||1; });
  let pc=keys.map(()=>1); for(let it=0;it<30;it++){ const nv=keys.map(()=>0); for(const r of R){ const d=r.reduce((s,x,q)=>s+x/sc[q]*pc[q],0); r.forEach((x,q)=>nv[q]+=d*x/sc[q]); } const n=Math.hypot(...nv)||1; pc=nv.map(v=>v/n); }
  const ord=R.map((r,i)=>({y:Y[i],r,s:r.reduce((s,x,q)=>s+x/sc[q]*pc[q],0)})).sort((a,b)=>a.s-b.s), out=[];
  for(let i=0;i<10;i++){ const o=ord.length?ord[Math.min(ord.length-1,Math.floor((i+0.5)/10*ord.length))]:null; out.push({y:o?o.y:null, v:keys.map((k,q)=>{ const f=F[k]&&F[k].fc[j]; return f?f.mu+(o?o.r[q]:0):NaN; })}); }
  // ترتیب ممبرها: نزدیک‌ترین به کنترل اول
  const mu=keys.map(k=>F[k]&&F[k].fc[j]?F[k].fc[j].mu:0); out.sort((a,b)=>a.v.reduce((s,x,q)=>s+((x-mu[q])/sc[q])**2,0)-b.v.reduce((s,x,q)=>s+((x-mu[q])/sc[q])**2,0)); return out; }
const sfZ=(k,v,m)=>{ const s=SF.zs[k]; return s&&s.sd[m]>0?(v-s.mu[m])/s.sd[m]:NaN; };

/* ---------- نقاط: ایستگاه‌های اطلس (تکمیل با ERA5) + نقاط ERA5 در جاهای خالی ---------- */
const sfKm=(a,b,c,d)=>{ const R=6371, dl=(c-a)*Math.PI/180, dg=(d-b)*Math.PI/180, x=Math.sin(dl/2)**2+Math.cos(a*Math.PI/180)*Math.cos(c*Math.PI/180)*Math.sin(dg/2)**2; return 2*R*Math.asin(Math.sqrt(x)); };
function sfInReg(lat,lon){ if(!SF.o.reg) return true; const LY=window.CQC_LAYERS||{}, f=(LY.ostan||[]).find(o=>o.p&&o.p.name===SF.o.reg); if(!f) return true;
  const inR=(ring)=>{ let c=false; for(let i=0,j=ring.length-1;i<ring.length;j=i++){ const [xi,yi]=ring[i],[xj,yj]=ring[j]; if(((yi>lat)!==(yj>lat))&&lon<(xj-xi)*(lat-yi)/(yj-yi)+xi) c=!c; } return c; };
  if(f.g.some(p=>inR(p[0]))) return true; for(const p of f.g) for(const [x,y] of p[0]) if(sfKm(lat,lon,y,x)<35) return true; return false; }
function sfPoints(){ const par=SF.o.par, src=SF.o.src, NM=CA.db.NM, P=[], E=SF.era, eser=E?(par==="prcp"?E.pr:E.tm):null;
  const near=(lat,lon)=>{ if(!E) return -1; let b=-1,bd=1e9; for(let i=0;i<E.n;i++){ const d=Math.abs(E.pts[i][0]-lat)+Math.abs(E.pts[i][1]-lon); if(d<bd){ bd=d; b=i; } } return bd<0.8?b:-1; };
  if(src!=="e") for(const s of CLIM_META.st){ if(s.lat==null||!s.d[par]||!sfInReg(s.lat,s.lon)) continue; let y=caSeries(s,par); if(!y) continue; let fill=0;
    if(src==="ae"&&eser){ const ei=near(s.lat,s.lon); if(ei>=0){ const e=eser[ei]; y=Float32Array.from(y);
        for(let m=0;m<12;m++){ let so=0,eo=0,n=0; for(let t=m;t<NM;t+=12) if(y[t]===y[t]&&e[t]===e[t]){ so+=y[t]; eo+=e[t]; n++; } if(n<8) continue;
          const add=par!=="prcp", f=add?(so-eo)/n:(eo>0?so/eo:NaN); if(!(f===f)) continue; for(let t=m;t<NM;t+=12) if(!(y[t]===y[t])&&e[t]===e[t]&&t>=(SF_Y0-CLIM_META.jy0)*12){ y[t]=add?e[t]+f:e[t]*f; fill++; } } } }
    P.push({lat:s.lat,lon:s.lon,elev:s.elev||0,name:caStName(s),ty:s.type,uv:s.vs==="unverified",y,fill,src:"st"}); }
  if(eser&&src!=="a"){ for(let i=0;i<E.n;i++){ const [la,lo]=E.pts[i]; if(!sfInReg(la,lo)) continue; if(src==="ae"&&P.some(p=>p.src==="st"&&sfKm(la,lo,p.lat,p.lon)<60)) continue; P.push({lat:la,lon:lo,elev:0,name:`ERA5 ${caF(la,1)}°N ${caF(lo,1)}°E`,y:eser[i],fill:0,src:"era"}); } }
  return P; }

/* ---------- گام ۲: آموزش مدل نقطه‌ای برای یک ماه تقویمی ---------- */
async function sfTrain(m, keys, prog){ const ck=[SF.o.par,SF.o.src,SF.o.reg,m,keys.join("|")].join("#"); if(SF.models.has(ck)) return SF.models.get(ck);
  const jy0=CLIM_META.jy0, NM=CA.db.NM, P=sfPoints(), K=keys.length, Y1=jy0+Math.floor((NM-1)/12), samp=[];
  for(let y=SF_Y0;y<=Y1;y++) for(const d of [-1,0,1]){ const t=(y-jy0)*12+m+d; if(t<0||t>=NM) continue; const z=keys.map(k=>SF.Z[k][t]); if(z.some(v=>!(v===v))) continue; samp.push({t,y,d,z}); }
  if(samp.length<60) throw new Error(SFT("دادهٔ شاخص‌ها برای آموزش کافی نیست","Not enough index data for training"));
  // ناهنجاری استانداردشدهٔ هر نقطه + همبستگی با هر شاخص
  const pts=[];
  for(const p of P){ const mu=new Float64Array(12), sd=new Float64Array(12);
    for(let c=0;c<12;c++){ let s=0,s2=0,n=0; for(let t=(SF_Y0-jy0)*12+c;t<NM;t+=12){ const v=p.y[t]; if(v===v){ s+=v; s2+=v*v; n++; } } mu[c]=n>=20?s/n:NaN; sd[c]=n>=20?Math.sqrt(Math.max(1e-9,(s2-s*s/n)/(n-1))):NaN; }
    const ix=[], ys=[]; for(let i=0;i<samp.length;i++){ const t=samp[i].t, c=t%12, v=p.y[t]; if(v===v&&sd[c]>0){ ix.push(i); ys.push((v-mu[c])/sd[c]); } }
    if(ix.filter(i=>samp[i].d===0).length<25||!(sd[m]>0)) continue;
    const r=keys.map((k,q)=>{ let sx=0,sy=0,sxx=0,syy=0,sxy=0; const n=ix.length; ix.forEach((i,j)=>{ const x=samp[i].z[q], y=ys[j]; sx+=x; sy+=y; sxx+=x*x; syy+=y*y; sxy+=x*y; }); const v=(sxy-sx*sy/n)/Math.sqrt(Math.max(1e-12,(sxx-sx*sx/n)*(syy-sy*sy/n))); return v===v?v:0; });
    pts.push({...p, mu:mu[m], sd:sd[m], ix, ys, r}); }
  if(pts.length<5) throw new Error(SFT("نقطه‌های دارای دادهٔ کافی کم است","Too few points with enough data"));
  // هموارسازی مکانی همبستگی‌ها (گاوسی ۱۵۰ km) و وزن شاخص‌ها
  for(const p of pts){ const n=p.ix.filter(i=>samp[i].d===0).length, rc=1/Math.sqrt(n); let ws=new Array(K).fill(0), gs=0;
    for(const q of pts){ const d=sfKm(p.lat,p.lon,q.lat,q.lon); if(d>400) continue; const g=Math.exp(-0.5*(d/150)**2); gs+=g; for(let k=0;k<K;k++) ws[k]+=g*q.r[k]; }
    p.rs=ws.map(v=>v/gs); p.w=p.rs.map(v=>Math.max(0,Math.abs(v)-rc)/(1-rc)); }
  const out={m,keys,samp,pts,ck}; let done=0; SFS.samp=samp;
  for(const p of pts){ sfFitPoint(p,samp,K); if(++done%40===0){ if(prog) prog(done/pts.length); await sfTick(); } }
  // وزن سراسری (برای انتخاب سال‌های مشابه): میانگین وزن نقطه‌ها
  out.wg=keys.map((_,k)=>pts.reduce((s,p)=>s+p.w[k],0)/pts.length);
  SF.models.set(ck,out); return out; }
function sfFeat(z,p){ const f=z.map((v,k)=>v*Math.sqrt(p.w[k])); for(const [i,j] of p.pairs) f.push(z[i]*z[j]*Math.sqrt(p.w[i]*p.w[j])); return f; }
function sfFitPoint(p,samp,K){ const ord=p.w.map((w,k)=>[w,k]).filter(a=>a[0]>0).sort((a,b)=>b[0]-a[0]).slice(0,4).map(a=>a[1]); p.pairs=[]; for(let a=0;a<ord.length;a++) for(let b=a+1;b<ord.length;b++) p.pairs.push([ord[a],ord[b]]);
  p.sw=p.w.reduce((s,v)=>s+v,0); if(p.sw<=0){ p.b=null; p.beta=0; p.skill=0; p.eps=new Map(); return; }
  const F=p.ix.map(i=>sfFeat(samp[i].z,p)), nf=F[0].length, n=F.length, mf=new Array(nf).fill(0); let my=0; F.forEach((f,i)=>{ f.forEach((v,q)=>mf[q]+=v/n); my+=p.ys[i]/n; });
  const Fc=F.map(f=>f.map((v,q)=>v-mf[q])), Yc=p.ys.map(v=>v-my), A=[...Array(nf)].map(()=>new Array(nf).fill(0)), c=new Array(nf).fill(0);
  Fc.forEach((f,i)=>{ for(let a=0;a<nf;a++){ c[a]+=f[a]*Yc[i]; for(let b=0;b<nf;b++) A[a][b]+=f[a]*f[b]; } });
  const lam=Math.max(2,0.08*n); const reg=M=>M.map((r,a)=>r.map((v,b)=>a===b?v+lam:v));
  p.mf=mf; p.my=my; p.b=sfSolve(reg(A),c)||new Array(nf).fill(0);
  // فاصلهٔ آنالوگ (فقط اثرهای اصلی، با وزن)
  const zw=p.ix.map(i=>samp[i].z.map((v,k)=>v*Math.sqrt(p.w[k]))); p.zw=zw;
  const dist=(a,b)=>{ let s=0; for(let k=0;k<K;k++){ const d=a[k]-b[k]; s+=d*d; } return Math.sqrt(s/p.sw); };
  // فاصلهٔ معمول نزدیک‌ترین سال (d0)
  const q0=p.ix.map((i,j)=>j).filter(j=>samp[p.ix[j]].d===0), nn=[];
  for(const j of q0.filter((_,u)=>u%2===0)){ let b=1e9; for(let l=0;l<n;l++){ if(samp[p.ix[l]].y===samp[p.ix[j]].y) continue; const d=dist(zw[j],zw[l]); if(d<b) b=d; } nn.push(b); }
  nn.sort((a,b)=>a-b); p.d0=nn[nn.length>>1]||0.3;
  // اعتبارسنجی حذف‌یک‌سال روی نمونه‌های ماه هدف
  const cv=[], ob=[], yrs=[];
  for(const j of q0){ const yy=samp[p.ix[j]].y, drop=[]; for(let l=0;l<n;l++) if(samp[p.ix[l]].y===yy) drop.push(l);
    const Ay=A.map(r=>r.slice()), cy=c.slice(); for(const l of drop){ const f=Fc[l]; for(let a=0;a<nf;a++){ cy[a]-=f[a]*Yc[l]; for(let b=0;b<nf;b++) Ay[a][b]-=f[a]*f[b]; } }
    const by=sfSolve(reg(Ay),cy); if(!by) continue; const rg=Fc[j].reduce((s,v,q)=>s+v*by[q],0)+my;
    const kn=sfKnn(p,zw[j],yy,dist); const lb=0.6*Math.exp(-0.5*(kn.d1/(p.d0||0.3))**2), f=lb*kn.v+(1-lb)*rg; cv.push(f); ob.push(p.ys[j]); yrs.push(yy); }
  const N=cv.length, mc=cv.reduce((s,v)=>s+v,0)/N, mo=ob.reduce((s,v)=>s+v,0)/N; let sco=0,scc=0,soo=0; for(let i=0;i<N;i++){ sco+=(cv[i]-mc)*(ob[i]-mo); scc+=(cv[i]-mc)**2; soo+=(ob[i]-mo)**2; }
  p.skill=scc>0&&soo>0?sco/Math.sqrt(scc*soo):0; p.beta=scc>0?Math.max(0,Math.min(1,sco/scc)):0; p.eps=new Map(); for(let i=0;i<N;i++) p.eps.set(yrs[i],ob[i]-p.beta*cv[i]); }
function sfKnn(p,q,exY,dist){ const D=[]; for(let l=0;l<p.zw.length;l++){ const s=SFS.samp[p.ix[l]]; if(exY!=null&&s.y===exY) continue; D.push([dist(q,p.zw[l]),l]); } D.sort((a,b)=>a[0]-b[0]);
  const k=Math.min(10,D.length), h=Math.max(1e-3,D[k-1][0]); let sw=0,sv=0; for(let i=0;i<k;i++){ const w=Math.exp(-((D[i][0]/h)**2)); sw+=w; sv+=w*p.ys[D[i][1]]; } return {v:sw?sv/sw:0, d1:D[0][0]}; }
const SFS={samp:null};
function sfPredict(p,z,samp){ if(!p.b||p.sw<=0) return 0; SFS.samp=samp; const K=z.length, dist=(a,b)=>{ let s=0; for(let k=0;k<K;k++){ const d=a[k]-b[k]; s+=d*d; } return Math.sqrt(s/p.sw); };
  const f=sfFeat(z,p), rg=f.reduce((s,v,q)=>s+(v-p.mf[q])*p.b[q],0)+p.my, qw=z.map((v,k)=>v*Math.sqrt(p.w[k])), kn=sfKnn(p,qw,null,dist), lb=0.6*Math.exp(-0.5*(kn.d1/(p.d0||0.3))**2);
  return p.beta*(lb*kn.v+(1-lb)*rg); }
// سال‌های مشابه (برای نوفهٔ ممبرها و جدول)
function sfAnalogYears(M, z){ const yrs=new Map(); for(const s of M.samp){ if(s.d!==0) continue; let d=0,sw=0; s.z.forEach((v,k)=>{ d+=M.wg[k]*(v-z[k])**2; sw+=M.wg[k]; }); yrs.set(s.y,Math.sqrt(d/(sw||1))); }
  return [...yrs].sort((a,b)=>a[1]-b[1]); }
function sfToMm(p,zv){ const a=zv*p.sd; return SF.o.par==="prcp"?Math.max(-p.mu,a):a; }
// اجرای یک ماه: states = [{z:[...]}]: کنترل + ۱۰ ممبر
function sfRunMonth(M, zc, zm){ const an=sfAnalogYears(M,zc), noiseY=an.slice(0,10).map(a=>a[0]), res=[];
  for(const p of M.pts){ const c=sfToMm(p,sfPredict(p,zc,M.samp)), mem=zm.map((z,i)=>sfToMm(p,sfPredict(p,z,M.samp)+(p.eps.get(noiseY[i])||0))), mean=mem.reduce((s,v)=>s+v,0)/mem.length;
    res.push({lat:p.lat,lon:p.lon,elev:p.elev,name:p.name,ty:p.ty,uv:p.uv,src:p.src,c,mem,mean,skill:p.skill,mu:p.mu,sd:p.sd}); }
  return {pts:res, an:an.slice(0,10), noiseY}; }

/* ---------- اجرای خودکار (۵ ماه) ---------- */
async function sfRunAuto(){ if(SF.busy) return; SF.busy=true; SF.cards.clear();
  try{ sfStatus(SFT("بارگذاری داده‌ها…","Loading data…")); await sfLoad(); const keys=sfKeys(); if(keys.length<2) throw new Error(SFT("دست‌کم دو شاخص با داده انتخاب کنید","Select at least two indices with data"));
    const F=sfIdxForecast(keys); SF.fc=F; const T=[];
    for(let j=0;j<5;j++){ const t=SF.tNow+1+j, m=t%12; sfStatus(SFT(`آموزش مدل ${sfMonLab(t)} (${FA(j+1)} از ۵)…`,`Training ${sfMonLab(t)} (${j+1}/5)…`)); await sfTick();
      const M=await sfTrain(m,keys,f=>sfStatus(SFT(`آموزش مدل ${sfMonLab(t)}: ${FA(Math.round(f*100))}٪`,`Training ${sfMonLab(t)}: ${Math.round(f*100)}%`)));
      const zc=keys.map(k=>sfZ(k,F[k].fc[j].mu,m)), ms=sfMemberStates(F,keys,j), zm=ms.map(s=>s.v.map((v,q)=>sfZ(keys[q],v,m)));
      const R=sfRunMonth(M,zc,zm); T.push({t,m,keys,zc,ms,...R,M}); }
    SF.out.auto={T,keys,F}; SF.view={mode:"auto",ti:0,kind:"c"}; sfRenderIdxTable(); sfRenderViewer("auto"); sfStatus("");
  }catch(e){ console.error(e); sfStatus("⚠ "+e.message); } SF.busy=false; }

/* ---------- حالت سفارشی (شرط‌های دستی) ---------- */
const SF_PH=[["sp","فاز مثبت قوی (≥ +۱٫۵σ)","strong positive (≥ +1.5σ)",1.5,2.5],["mp","فاز مثبت متوسط (+۱ تا +۱٫۵σ)","moderate positive (+1…+1.5σ)",1,1.5],["wp","فاز مثبت ضعیف (+۰٫۵ تا +۱σ)","weak positive (+0.5…+1σ)",0.5,1],["nu","خنثی (−۰٫۵ تا +۰٫۵σ)","neutral (−0.5…+0.5σ)",-0.5,0.5],["wn","فاز منفی ضعیف","weak negative",-1,-0.5],["mn","فاز منفی متوسط","moderate negative",-1.5,-1],["sn","فاز منفی قوی (≤ −۱٫۵σ)","strong negative (≤ −1.5σ)",-2.5,-1.5]];
async function sfRunCustom(){ if(SF.busy) return; SF.busy=true;
  try{ sfStatus(SFT("بارگذاری داده‌ها…","Loading data…")); await sfLoad(); const C=sfReadConds(); if(!C.length) throw new Error(SFT("دست‌کم یک شرط تعریف کنید","Define at least one condition"));
    const keys=[...new Set(C.map(c=>c.k))].filter(k=>SF.idx[k]); const months=SF.cm&&SF.cm.length?SF.cm:[(SF.tNow+1)%12]; const T=[];
    for(const m of months){ sfStatus(SFT(`آموزش مدل ${CA_MN[m]}…`,`Training ${CA_MN_EN[m]}…`)); await sfTick(); const M=await sfTrain(m,keys,f=>sfStatus(SFT(`آموزش مدل ${CA_MN[m]}: ${FA(Math.round(f*100))}٪`,`Training ${CA_MN_EN[m]}: ${Math.round(f*100)}%`)));
      const rng=keys.map(k=>{ const cs=C.filter(c=>c.k===k); let lo=-Infinity,hi=Infinity; for(const c of cs){ let a,b; if(c.op==="ph"){ const ph=SF_PH.find(x=>x[0]===c.ph)||SF_PH[3]; a=ph[3]; b=ph[4]; } else { const za=sfZ(k,c.a,m), zb=c.op==="bt"?sfZ(k,c.b,m):za; a=Math.min(za,zb); b=Math.max(za,zb); if(c.op==="ge"){ a=za; b=za+1.5; } if(c.op==="le"){ b=za; a=za-1.5; } } lo=Math.max(lo,a); hi=Math.min(hi,b); } if(!(lo<=hi)) throw new Error(SFT(`شرط‌های ${caIdxName(k)} با هم سازگار نیستند`,`Conditions on ${k} contradict each other`)); return [lo,hi]; });
      const zc=rng.map(r=>(r[0]+r[1])/2), zm=[...Array(10)].map((_,i)=>rng.map((r,q)=>{ const u=((i*(3+2*q)+q)%10+0.5)/10; return r[0]+(r[1]-r[0])*u; }));
      const R=sfRunMonth(M,zc,zm), t=SF.tNow+1+((m-(SF.tNow+1)%12+12)%12); T.push({t,m,keys,zc,ms:zm.map(z=>({v:z.map((v,q)=>v*SF.zs[keys[q]].sd[m]+SF.zs[keys[q]].mu[m])})),...R,M,cond:C}); }
    SF.out.cust={T,keys}; SF.view={mode:"cust",ti:0,kind:"c"}; sfRenderViewer("cust"); sfStatus("");
  }catch(e){ console.error(e); sfStatus("⚠ "+e.message); } SF.busy=false; }
function sfReadConds(){ return [...document.querySelectorAll(".sfCond")].map(r=>({k:r.querySelector(".ck").value, op:r.querySelector(".co").value, ph:r.querySelector(".cp").value, a:parseFloat(r.querySelector(".ca").value), b:parseFloat(r.querySelector(".cb").value)})).filter(c=>c.k&&(c.op==="ph"||c.a===c.a)); }

/* ---------- رنگ‌بندی (گسسته) ---------- */
function sfScheme(kind){ const P=sfIsP();
  if(kind==="skill") return {breaks:[-1,0,0.1,0.2,0.3,0.4,0.5,0.6,1.0001],colors:["#e5e7eb","#fef3c7","#fde68a","#fbbf24","#f59e0b","#d97706","#b45309","#78350f"],fmt:v=>v>1?"":caF(v,1),step:1};
  if(!P) return null;
  if(SF.o.pal==="wm"&&typeof WMC_PRECIP_PAL!=="undefined"){ const hx=c=>"#"+c.map(v=>v.toString(16).padStart(2,"0")).join(""), at=a=>{ let i=WMC_PRECIP_LAB.findIndex(x=>x>=a); if(i<0) i=WMC_PRECIP_LAB.length-1; return hx(WMC_PRECIP_PAL[Math.min(WMC_PRECIP_PAL.length-1,i+1)]); };
    const pos=[5,10,20,30,50,75,100,150]; return {breaks:[-1000,-100,-50,-30,-20,-10,-5,5,10,20,30,50,75,100,150,1000],colors:["#543005","#8c510a","#bf812d","#dfc27d","#f0dcae","#f8efd9","#ffffff",...pos.map(at)],fmt:v=>Math.abs(v)>=1000?"":FA(v),step:1}; }
  return null; }

/* ---------- نمایش نقشه ---------- */
async function sfShowMap(){ const v=SF.view, O=SF.out[v.mode]; if(!O||!O.T[v.ti]) return; const box=$(v.mode==="auto"?"sfMapBox":"sfMapBoxC"); if(!box) return;
  const key=[v.mode,v.ti,v.kind,SF.o.pal,LANG].join("|"); if(SF.cards.has(key)){ box.replaceChildren(SF.cards.get(key)); return; }
  if(SF.mapBusy){ SF.mapPend=true; return; } SF.mapBusy=true; SF.mapPend=false;
  try{ const T=O.T[v.ti], P=sfIsP(), kn=v.kind, val=p=>kn==="c"?p.c:kn==="mean"?p.mean:kn==="skill"?p.skill:p.mem[+kn.slice(1)-1];
    const pts=T.pts.map(p=>({lat:p.lat,lon:p.lon,elev:p.elev,name:p.name,ty:p.ty,uv:p.uv,v:val(p),sig:kn==="skill"?p.skill>=0.3:p.src==="st"&&p.skill>=0.3})).filter(p=>p.v===p.v);
    const klab=kn==="c"?SFT("کنترل","Control"):kn==="mean"?SFT("میانگین ۱۰ ممبر (Mean)","Mean of 10 members"):kn==="skill"?SFT("مهارت (همبستگی اعتبارسنجی)","Skill (cross-validated r)"):SFT(`ممبر ${FA(+kn.slice(1))}`,`Member ${kn.slice(1)}`);
    const mon=v.mode==="auto"?`${sfMonLab(T.t)} (${sfGRange(T.t)})`:SFT(CA_MN[T.m],CA_MN_EN[T.m]);
    const ttl=kn==="skill"?SFT(`مهارت پیش‌بینی ${P?"بارش":"دما"} — ${mon}`,`Forecast skill — ${mon}`):SFT(`پیش‌بینی ناهنجاری ${P?"بارش":"دمای میانگین"} — ${mon} — ${klab}`,`${P?"Precipitation":"Mean temperature"} anomaly forecast — ${mon} — ${klab}`);
    const iss=v.mode==="auto"?SFT(`صدور ${sfDFmt(SF.issued||new Date())}`,`issued ${sfDFmt(SF.issued||new Date())}`):SFT("سناریوی دستی","manual scenario");
    const sub=kn==="skill"?SFT(`همبستگی پیش‌بینی حذف‌یک‌سال با مشاهده (${FA(SF_Y0)} به بعد) · نقطهٔ سیاه: r ≥ ۰٫۳`,`Leave-one-year-out forecast vs observed r · black: r ≥ 0.3`)
      :SFT(`آنالوگ هسته‌ای + رگرسیون برهمکنش ${FA(T.keys.length)} شاخص · ${iss} · نسبت به میانگین ${FA(SF_Y0)} به بعد · نقطهٔ سیاه: ایستگاه با مهارت r ≥ ۰٫۳`,`Kernel analog + interaction regression on ${T.keys.length} indices · ${iss} · vs ${SF_Y0}+ mean · black: station skill r ≥ 0.3`);
    if(!$("caPalSel")||!$("caRes")) caBuildUI();
    const sc=sfScheme(kn==="skill"?"skill":"");
    const cv=await caMap({ws:1,pts,title:ttl,sub,unit:kn==="skill"?SFT("همبستگی r","correlation r"):P?SFT("ناهنجاری بارش (میلی‌متر در ماه)","Precipitation anomaly (mm/month)"):SFT("ناهنجاری دما (°C)","Temperature anomaly (°C)"),
      kind:kn==="skill"?"seq":"div",scheme:sc||(P?"panom":"tanom"),center:0,breaks:sc?undefined:(P?[-50,-30,-20,-10,-5,5,10,20,30,50]:[-3,-2,-1.5,-1,-0.5,0.5,1,1.5,2,3]),method:"auto",useElev:false,
      note:SFT("پیش‌بینی آماری از برهمکنش شاخص‌ها؛ مقدار دور از ایستگاه‌ها درون‌یابی است.","Statistical forecast from index interactions; values away from stations are interpolated.")});
    const note=kn==="skill"?SFT("همبستگی بالای ۰٫۳ یعنی شاخص‌ها در این ماه بخش معنی‌داری از تغییرات بارش این نقطه را توضیح می‌دهند؛ زیر ۰٫۱ پیش‌بینی تقریباً همان نرمال است.","r above 0.3 means indices explain a meaningful part of this month's variability here; below 0.1 the forecast is essentially climatology.")
      :SFT(`کنترل: بهترین برآورد از حالت پیش‌بینی‌شدهٔ شاخص‌ها. ممبرها: ۱۰ حالت دیگر شاخص‌ها + الگوی باقی‌ماندهٔ ${T.noiseY.length} سال مشابه (${T.noiseY.map(FA).join("، ")}). میانگین: میانگین ۱۰ ممبر.`,`Control: best estimate from the forecast index state. Members: 10 other index states + residual pattern of the ${T.noiseY.length} most similar years (${T.noiseY.join(", ")}). Mean: average of the members.`);
    const card=caCard(ttl,cv,note,{prepend:n=>box.replaceChildren(n)}); SF.cards.set(key,card);
  }catch(e){ console.error(e); sfStatus("⚠ "+e.message); } SF.mapBusy=false; if(SF.mapPend){ SF.mapPend=false; sfShowMap(); } }

/* ---------- جدول‌ها ---------- */
function sfPhaseTxt(k,z){ if(!(z===z)) return "—"; const a=Math.abs(z), lv=a<0.5?SFT("خنثی","neutral"):a<1?SFT("ضعیف","weak"):a<1.5?SFT("متوسط","moderate"):SFT("قوی","strong"); return a<0.5?lv:`${z>0?SFT("مثبت","positive"):SFT("منفی","negative")} ${lv}`; }
function sfPhaseCol(z){ if(!(z===z)) return "#fff"; const a=Math.abs(z); if(a<0.5) return "#eef2f7"; const P=["#fde2e2","#f4a6a6","#e05555"], N=["#dbeafe","#93c5fd","#3b82f6"], i=a<1?0:a<1.5?1:2; return z>0?P[i]:N[i]; }
function sfRenderIdxTable(){ const O=SF.out.auto, box=$("sfIdxTab"); if(!O||!box) return; const F=O.F, ts=O.T.map(T=>T.t);
  const rows=O.keys.map(k=>{ const f=F[k], Lm=f.L%12; return `<tr><td><b>${caIdxName(k)}</b></td><td><small>${sfMonLab(f.L)}</small><br>${caF(f.Lv,2)} <small>(${sfPhaseTxt(k,sfZ(k,f.Lv,Lm))})</small></td>${f.fc.map((c,j)=>{ const z=sfZ(k,c.mu,ts[j]%12); return `<td style="background:${sfPhaseCol(z)}"><b>${caF(c.mu,2)}</b> <small>±${caF(c.sd,2)}</small><br><small>${sfPhaseTxt(k,z)}${c.obs?" · "+SFT("مشاهده","observed"):""}</small></td>`; }).join("")}</tr>`; }).join("");
  const stale=O.keys.filter(k=>SF.tNow-F[k].L>2);
  box.innerHTML=`<div class="dwTblW fit"><table class="dwTbl sfTbl"><tr><th>${SFT("شاخص","Index")}</th><th>${SFT("آخرین مشاهده","Last observed")}</th>${ts.map(t=>`<th>${sfMonLab(t)}</th>`).join("")}</tr>${rows}</table></div>
   <p class="hint">${SFT("مقدار پیش‌بینی (± انحراف معیار خطا) و فاز؛ رنگ: قرمز = فاز مثبت، آبی = منفی (کم‌رنگ ضعیف تا پررنگ قوی). روش: رگرسیون تأخیری فصلی روی تاریخچهٔ هر شاخص (QBO با مؤلفهٔ دیگرش)؛ شاخص‌های جوی (NAO، AO، …) پس از یکی دو ماه به سمت نرمال می‌روند چون پیش‌بینی‌پذیری‌شان کم است.","Forecast value (± error SD) and phase; red = positive, blue = negative. Method: seasonal lagged regression on each index's history (QBO with its other component); atmospheric patterns (NAO, AO …) relax to normal after a month or two because their predictability is low.")}</p>
   ${stale.length?`<p class="hint dwWeak">⚠ ${SFT(`دادهٔ این شاخص‌ها قدیمی است و پیش‌بینی با تأخیر بلند ساخته شد: ${stale.map(caIdxName).join("، ")}. فایل به‌روز شاخص‌ها (workflow «sfc») را اجرا کنید.`,`Old data for: ${stale.join(", ")} — run the “sfc” workflow.`)}</p>`:""}`; }
function sfAnalogHtml(T){ return `<div class="dwTblW fit"><table class="dwTbl"><tr><th>${SFT("سال (ماه هدف)","Year (target month)")}</th><th>${SFT("فاصله در فضای شاخص (σ)","Distance in index space (σ)")}</th><th>${SFT("میانگین ناهنجاری مشاهده‌شده","Observed mean anomaly")}</th></tr>${T.an.map(([y,d])=>{ let s=0,n=0; for(const p of T.M.pts){ const t=(y-CLIM_META.jy0)*12+T.m, v=p.y[t]; if(v===v){ s+=sfIsP()?v-p.mu:v-p.mu; n++; } } return `<tr><td>${FA(y)}</td><td>${caF(d,2)}</td><td>${n?(s/n>=0?"+":"")+caF(s/n,1)+(sfIsP()?SFT(" میلی‌متر"," mm"):" °C"):"—"}</td></tr>`; }).join("")}</table></div>`; }

/* ---------- نمایشگر (منوی دکمه‌ای) ---------- */
function sfRenderViewer(mode){ const O=SF.out[mode], host=$(mode==="auto"?"sfView":"sfViewC"); if(!O||!host) return; const v=SF.view.mode===mode?SF.view:(SF.view={mode,ti:0,kind:"c"});
  const mb=O.T.map((T,i)=>`<button type="button" class="sfB${v.ti===i?" on":""}" data-ti="${i}">${mode==="auto"?sfMonLab(T.t):SFT(CA_MN[T.m],CA_MN_EN[T.m])}</button>`).join("");
  const kb=(k,l)=>`<button type="button" class="sfB${v.kind===k?" on":""}" data-k="${k}">${l}</button>`;
  host.innerHTML=`<div class="sfRow"><span class="sfL">${SFT("ماه","Month")}</span>${mb}</div>
   <div class="sfRow"><span class="sfL">${SFT("کنترل و میانگین","Control & mean")}</span>${kb("c",SFT("کنترل","Control"))}${kb("mean","Mean")}${kb("skill",SFT("نقشهٔ مهارت","Skill map"))}</div>
   <div class="sfRow"><span class="sfL">${SFT("ممبرها","Members")}</span>${[...Array(10)].map((_,i)=>kb("m"+(i+1),FA(i+1))).join("")}</div>
   <div id="${mode==="auto"?"sfMapBox":"sfMapBoxC"}" class="sfMapBox"></div>
   <details class="sfDet"><summary>${SFT("سال‌های مشابه و حالت شاخص‌ها در این ماه","Similar years and index states for this month")}</summary><div>${sfStateHtml(O.T[v.ti])}${sfAnalogHtml(O.T[v.ti])}</div></details>`;
  host.querySelectorAll("[data-ti]").forEach(b=>b.onclick=()=>{ SF.view={mode,ti:+b.dataset.ti,kind:SF.view.kind}; sfRenderViewer(mode); });
  host.querySelectorAll("[data-k]").forEach(b=>b.onclick=()=>{ SF.view={mode,ti:SF.view.ti,kind:b.dataset.k}; host.querySelectorAll("[data-k]").forEach(x=>x.classList.toggle("on",x===b)); sfShowMap(); });
  sfShowMap(); }
function sfStateHtml(T){ const k=T.keys, m=T.m, row=(lab,vals)=>`<tr><td>${lab}</td>${vals.map((v,q)=>{ const z=sfZ(k[q],v,m); return `<td style="background:${sfPhaseCol(z)}">${caF(v,2)}</td>`; }).join("")}</tr>`;
  const ctrl=k.map((kk,q)=>T.zc[q]*SF.zs[kk].sd[m]+SF.zs[kk].mu[m]);
  return `<div class="dwTblW fit"><table class="dwTbl sfTbl"><tr><th></th>${k.map(x=>`<th>${x}</th>`).join("")}</tr>${row(SFT("کنترل","Control"),ctrl)}${T.ms.map((s,i)=>row(SFT(`ممبر ${FA(i+1)}`,`Member ${i+1}`),s.v)).join("")}</table></div>`; }

/* ---------- صفحه ---------- */
function sfCondRow(c){ const ks=Object.keys(SF.idx).sort((a,b)=>caIdxName(a).localeCompare(caIdxName(b)));
  return `<div class="sfCond"><select class="ck">${ks.map(k=>`<option value="${k}"${c&&c.k===k?" selected":""}>${caIdxName(k)}</option>`).join("")}</select>
   <select class="co">${[["eq",SFT("= مقدار","= value")],["bt",SFT("بین دو مقدار","between")],["ge","≥"],["le","≤"],["ph",SFT("فاز","phase")]].map(([v,l])=>`<option value="${v}"${c&&c.op===v?" selected":""}>${l}</option>`).join("")}</select>
   <select class="cp"${c&&c.op==="ph"?"":" hidden"}>${SF_PH.map(p=>`<option value="${p[0]}"${c&&c.ph===p[0]?" selected":""}>${SFT(p[1],p[2])}</option>`).join("")}</select>
   <input class="ca" type="number" step="0.1" placeholder="${SFT("مقدار","value")}" value="${c&&c.a===c.a&&c.a!=null?c.a:""}"${c&&c.op==="ph"?" hidden":""}><input class="cb" type="number" step="0.1" placeholder="${SFT("تا","to")}" value="${c&&c.b===c.b&&c.b!=null?c.b:""}"${c&&c.op==="bt"?"":" hidden"}>
   <button type="button" class="btn sm sfDel" title="${SFT("حذف شرط","Remove")}">✕</button></div>`; }
function sfHTML(){ const o=SF.o, era=!!SF.era, J=SF.J, iss=SF.issued, nx=sfNextUpd(iss||new Date()), LY=window.CQC_LAYERS||{}, ost=(LY.ostan||[]).map(f=>f.p&&f.p.name).filter(Boolean).sort((a,b)=>a.localeCompare(b,"fa"));
  const grp=SF_GRP.map(([fa,en,ks])=>{ const av=ks.filter(k=>SF.idx[k]); if(!av.length) return ""; return `<fieldset class="sfGrp"><legend>${SFT(fa,en)}</legend>${av.map(k=>`<label class="chk"><input type="checkbox" class="sfIdx" value="${k}"${o.idx.includes(k)?" checked":""}> ${caIdxName(k)}${SF_MAIN.includes(k)?" ★":""}</label>`).join("")}</fieldset>`; }).join("");
  if(!SF.conds) SF.conds=[{k:"NINO 3/4",op:"eq",a:1.5},{k:"DMI",op:"eq",a:0.3},{k:"QBO30",op:"eq",a:8}];
  if(!SF.cm) SF.cm=[(SF.tNow+1)%12];
  return `<div class="dwHead"><h2>${SFT("پیش‌بینی ماهانه و فصلی","Monthly & seasonal forecast")}</h2>
   <p class="hint">${SFT("پیش‌بینی آماری بارش و دما برای ۵ ماه آینده از برهمکنش شاخص‌های اقلیمی (انسو، IOD، QBO، MJO، PDO، PNA، AO، NAO، EA/WR، اسکاندیناوی و …) با دادهٔ ماهانهٔ ایستگاه‌های اطلس، تکمیل‌شده با ERA5. حتی اگر ترکیب پیش‌بینی‌شدهٔ شاخص‌ها در گذشته رخ نداده باشد، نزدیک‌ترین ترکیب‌ها و رگرسیون برهمکنش، پیش‌بینی را می‌سازند.","Statistical precipitation and temperature forecast for the next 5 months from the interaction of climate indices with atlas station data completed by ERA5. Even if the forecast index combination never happened, the nearest combinations and an interaction regression build the forecast.")}</p>
   <div class="sfUpd"><span>${SFT("صدور","Issued")}: <b>${iss?sfDFmt(iss):SFT("— (فایل به‌روز شاخص‌ها روی هاست نیست؛ از دادهٔ اطلس استفاده می‌شود)","— (no fresh index file on host; atlas data used)")}</b></span><span>${SFT("به‌روزرسانی خودکار بعدی","Next automatic update")}: <b>${sfDFmt(nx)}</b> <small>(${SFT("روز ۱ و ۱۵ هر ماه میلادی","1st & 15th of each month")})</small></span><span>ERA5: <b>${era?SFT("موجود","available")+(SF.era.built?" · "+SF.era.built:""):SFT("روی هاست نیست (فقط اطلس)","not on host (atlas only)")}</b></span></div></div>
  <section class="card sfSet"><h3>${SFT("تنظیمات","Settings")}</h3>
   <div class="sfCtl"><label>${SFT("پارامتر","Parameter")}<select id="sfPar"><option value="prcp"${o.par==="prcp"?" selected":""}>${SFT("بارش ماهانه (ناهنجاری mm/ماه)","Monthly precipitation (anomaly, mm/month)")}</option><option value="tmean"${o.par==="tmean"?" selected":""}>${SFT("دمای میانگین (ناهنجاری °C)","Mean temperature (anomaly, °C)")}</option></select></label>
    <label>${SFT("داده","Data")}<select id="sfSrc"><option value="ae"${o.src==="ae"?" selected":""}${era?"":" disabled"}>${SFT("اطلس + تکمیل با ERA5 (پیشنهادی)","Atlas + ERA5 completion (suggested)")}</option><option value="a"${o.src==="a"?" selected":""}>${SFT("فقط ایستگاه‌های اطلس","Atlas stations only")}</option><option value="e"${o.src==="e"?" selected":""}${era?"":" disabled"}>${SFT("فقط ERA5","ERA5 only")}</option></select></label>
    <label>${SFT("محدوده","Region")}<select id="sfReg"><option value="">${SFT("کل ایران","All Iran")}</option>${ost.map(n=>`<option${o.reg===n?" selected":""}>${n}</option>`).join("")}</select></label>
    <label>${SFT("رنگ‌بندی","Colour bar")}<select id="sfPal"><option value="wm"${o.pal==="wm"?" selected":""}>${SFT("بارش WeatherModels (پیش‌فرض)","WeatherModels precipitation (default)")}</option><option value="cfs"${o.pal==="cfs"?" selected":""}>${SFT("ناهنجاری tropicaltidbits (CFS)","tropicaltidbits anomaly (CFS)")}</option></select></label></div>
   <details class="sfDet" open><summary>${SFT("شاخص‌ها (★ = ده شاخص اصلی)","Indices (★ = ten main indices)")}</summary><div class="sfGrps">${grp}</div>
    <div class="row2"><button type="button" class="btn sm" id="sfMain">${SFT("ده شاخص اصلی","Ten main indices")}</button><button type="button" class="btn sm" id="sfAll">${SFT("همه","All")}</button><button type="button" class="btn sm" id="sfNone">${SFT("هیچ","None")}</button></div></details>
   <button class="btn main" type="button" id="sfGo">${SFT("ساخت پیش‌بینی ۵ ماه آینده","Build 5-month forecast")}</button><div class="hint" id="sfStatus" aria-live="polite"></div></section>
  <section class="card"><h3>${SFT("پیش‌بینی شاخص‌ها","Index forecast")}</h3><div id="sfIdxTab"><p class="hint">${SFT("پس از ساخت پیش‌بینی نمایش داده می‌شود.","Shown after building the forecast.")}</p></div></section>
  <section class="card wide"><h3>${SFT("نقشه‌های پیش‌بینی (کنترل، میانگین و ۱۰ ممبر برای هر ماه)","Forecast maps (control, mean and 10 members per month)")}</h3><div id="sfView"></div></section>
  <section class="card wide sfCust"><h3>${SFT("حالت سفارشی: «اگر شاخص‌ها این‌طور باشند…»","Custom: “if the indices were…”")}</h3>
   <p class="hint">${SFT("مقدار یا بازه یا فاز دلخواه هر شاخص را وارد کنید (به تعداد دلخواه شرط). فقط شاخص‌های شرط‌دار در مدل می‌آیند. مقدارها به واحد خود شاخص‌اند (مثلاً نینو ۳٫۴ به °C، QBO به m/s).","Enter any value, range or phase for each index (as many conditions as you like). Only the conditioned indices enter the model. Values are in each index's own units (e.g. Niño 3.4 in °C, QBO in m/s).")}</p>
   <div id="sfConds">${SF.conds.map(sfCondRow).join("")}</div><button type="button" class="btn sm" id="sfAdd">＋ ${SFT("افزودن شرط","Add condition")}</button>
   <div class="sfMons"><span class="sfL">${SFT("ماه‌های هدف","Target months")}</span>${CA_MN.map((n,i)=>`<label class="chk"><input type="checkbox" class="sfCm" value="${i}"${SF.cm.includes(i)?" checked":""}> ${SFT(n,CA_MN_EN[i])}</label>`).join("")}</div>
   <button class="btn main" type="button" id="sfGoC">${SFT("اجرای سناریو","Run scenario")}</button><div id="sfViewC"></div></section>
  <section class="card"><h3>${SFT("روش، داده‌ها و محدودیت‌ها","Method, data and limitations")}</h3>${sfMethod()}</section>`; }
function sfMethod(){ return `<ul class="hint">
  <li>${SFT("پیش‌بینی شاخص‌ها: برای هر شاخص و هر ماه هدف، رگرسیون تأخیری فصل‌به‌فصل روی تاریخچهٔ ۱۳۳۰ به بعد (مقدار آخرین ماه و ماه قبلش؛ QBO با مؤلفهٔ ۵۰ و ۳۰ هکتوپاسکال که چرخش فاز را درست درمی‌آورد). انسو و PDO پایدارند و تا چند ماه مهارت دارند؛ NAO، AO و دیگر الگوهای جوی بعد از ۱ تا ۲ ماه به نرمال نزدیک می‌شوند.","Index forecast: per index and target month, seasonal lagged regression on the history from 1951 (last month and the month before; QBO with its 50/30 hPa components which captures the phase rotation). ENSO and PDO persist and keep skill for months; NAO, AO and other atmospheric patterns approach normal after 1–2 months.")}</li>
  <li>${SFT("ممبرها: ۱۰ حالت دیگر شاخص‌ها از خطاهای واقعی گذشته (همهٔ شاخص‌ها از یک سال، تا هم‌بستگی آن‌ها حفظ شود؛ مرتب‌شده از نزدیک‌ترین به کنترل) + الگوی باقی‌ماندهٔ بارش در ۱۰ سالِ مشابه‌ترین ترکیب شاخص‌ها (که پراکندگی واقعی و الگوی مکانی را می‌دهد).","Members: 10 other index states from real past errors (all indices from the same year to keep their correlation; ordered nearest-to-control first) + the residual precipitation pattern of the 10 years with the most similar index combination (gives realistic spread and spatial pattern).")}</li>
  <li>${SFT("برهمکنش شاخص‌ها: هر نقطه با «آنالوگ هسته‌ای» (۱۰ نمونهٔ نزدیک در فضای وزن‌دار شاخص‌ها؛ برهمکنش غیرخطی واقعی گذشته) و «رگرسیون ستیغی با جملهٔ ضربی» (برای ترکیب‌های بی‌سابقه) پیش‌بینی می‌شود؛ هرچه ترکیب پیش‌بینی‌شده از گذشته دورتر باشد، سهم رگرسیون بیشتر است. وزن هر شاخص = همبستگی معنی‌دار آن با بارش همان ماه (ماه هدف ± ۱)، هموارشده در شعاع ~۱۵۰ کیلومتر.","Index interaction: each point uses a kernel analog (10 nearest samples in weighted index space — real past non-linear interaction) and a ridge regression with product terms (for unprecedented combinations); the farther the forecast combination from the past, the larger the regression share. Index weight = significant correlation with that month's precipitation (target month ±1), smoothed over ~150 km.")}</li>
  <li>${SFT("اعتبارسنجی حذف‌یک‌سال: پیش‌بینی هر سال بدون آن سال ساخته و با مشاهده سنجیده می‌شود؛ ضریب کالیبراسیون پیش‌بینی را به نسبت مهارت به سمت نرمال می‌کشد (پیش‌بینی بی‌مهارت ≈ نرمال). «نقشهٔ مهارت» همین همبستگی است.","Leave-one-year-out validation: each year is forecast without itself and compared with observations; the calibration slope shrinks the forecast toward normal in proportion to skill (no skill ⇒ normal). The skill map shows this correlation.")}</li>
  <li>${SFT("داده: بارش و دمای ماهانهٔ ایستگاه‌های اطلس؛ ماه‌های خالی هر ایستگاه با ERA5 مقیاس‌شده (نسبت ماهانه در دورهٔ هم‌پوشان) پر می‌شود و در جاهای بی‌ایستگاه (دورتر از ۶۰ کیلومتر) نقطه‌های ۰٫۵° ERA5 اضافه می‌شوند. شاخص‌ها و ERA5 روز ۱ و ۱۵ هر ماه میلادی با workflow «sfc» به‌روز می‌شوند.","Data: monthly atlas station precipitation and temperature; each station's gaps are filled with scaled ERA5 (monthly ratio over the overlap) and 0.5° ERA5 points are added where there is no station within 60 km. Indices and ERA5 are refreshed on the 1st and 15th by the “sfc” workflow.")}</li>
  <li>${SFT("محدودیت: مهارت پیش‌بینی ماهانهٔ بارش در ایران متوسط تا ضعیف است (بیشتر در پاییز و زمستان و در سال‌های انسو/IOD قوی). نقشه را همراه نقشهٔ مهارت بخوانید. این پیش‌بینی آماری است و جای مدل‌های دینامیکی (ECMWF، CFS، NMME) را نمی‌گیرد؛ کنار آن‌ها استفاده کنید.","Limitation: monthly precipitation skill over Iran is modest (best in autumn–winter and strong ENSO/IOD years). Read the maps with the skill map. This is a statistical forecast and complements, not replaces, dynamical models (ECMWF, CFS, NMME).")}</li></ul>`; }
function sfWire(){ const m=$("sfMain"), g=id=>m&&$(id); const on=(id,f)=>{ const e=$(id); if(e) e.onchange=()=>{ f(e.value); sfSave(); }; };
  on("sfPar",v=>{ SF.o.par=v; SF.out={}; SF.cards.clear(); sfRender(); }); on("sfSrc",v=>{ SF.o.src=v; SF.out={}; SF.cards.clear(); });
  on("sfReg",v=>{ SF.o.reg=v; SF.out={}; SF.cards.clear(); }); on("sfPal",v=>{ SF.o.pal=v; if(SF.view) sfShowMap(); });
  const syncIdx=()=>{ SF.o.idx=[...document.querySelectorAll(".sfIdx:checked")].map(c=>c.value); sfSave(); };
  document.querySelectorAll(".sfIdx").forEach(c=>c.onchange=syncIdx);
  const setAll=f=>{ document.querySelectorAll(".sfIdx").forEach(c=>c.checked=f(c.value)); syncIdx(); };
  if($("sfMain")) $("sfMain").onclick=()=>setAll(k=>SF_MAIN.includes(k)); if($("sfAll")) $("sfAll").onclick=()=>setAll(()=>true); if($("sfNone")) $("sfNone").onclick=()=>setAll(()=>false);
  $("sfGo").onclick=()=>sfRunAuto(); $("sfGoC").onclick=()=>{ SF.conds=sfReadConds(); sfSave(); sfRunCustom(); };
  const wc=r=>{ const co=r.querySelector(".co"); co.onchange=()=>{ const v=co.value; r.querySelector(".cp").hidden=v!=="ph"; r.querySelector(".ca").hidden=v==="ph"; r.querySelector(".cb").hidden=v!=="bt"; }; r.querySelector(".sfDel").onclick=()=>{ r.remove(); SF.conds=sfReadConds(); sfSave(); }; };
  document.querySelectorAll(".sfCond").forEach(wc);
  $("sfAdd").onclick=()=>{ const d=document.createElement("div"); d.innerHTML=sfCondRow({k:"NAO",op:"ph",ph:"wn"}); const r=d.firstElementChild; $("sfConds").append(r); wc(r); };
  document.querySelectorAll(".sfCm").forEach(c=>c.onchange=()=>{ SF.cm=[...document.querySelectorAll(".sfCm:checked")].map(x=>+x.value); sfSave(); });
  if(SF.out.auto){ sfRenderIdxTable(); sfRenderViewer("auto"); } if(SF.out.cust) sfRenderViewer("cust"); }
function sfRender(){ const m=$("sfMain"); if(!m) return; m.innerHTML=sfHTML(); sfWire(); }
async function openSF(){ for(const id of ["landing","app","dsApp","cvApp","ltApp","wnApp","cqcApp","caApp","onApp","ciApp","saApp","anApp","labApp","synApp","drApp"]) if($(id)) $(id).hidden=true;
  $("sfApp").hidden=false; store.set("mode","sf"); window.scrollTo(0,0); const m=$("sfMain"); m.innerHTML=`<p class="hint">${SFT("بارگذاری پایگاه داده و شاخص‌ها…","Loading database and indices…")}</p>`;
  try{ await sfLoad(); }catch(e){ m.innerHTML=`<p class="hint">⚠ ${e.message}</p>`; return; } sfRender(); try{ vOnPage(); }catch(e){} }
for(const fn of ["switchMode","showLanding","openCQC","openDS","openCV","openLT","openWN","openCA","openON","openSA","openAN","openCI","openDR"]){ const f=window[fn]; if(typeof f!=="function") continue; window[fn]=function(...a){ if($("sfApp")) $("sfApp").hidden=true; return f.apply(this,a); }; }
document.addEventListener("langchange",()=>{ if($("sfApp")&&!$("sfApp").hidden&&SF.ready){ SF.cards.clear(); sfRender(); } });
