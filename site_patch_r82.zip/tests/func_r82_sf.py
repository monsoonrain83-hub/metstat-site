import time, sys
from playwright.sync_api import sync_playwright
def wait(pg, sel, n=1, t=300000):
    pg.wait_for_function(f"document.querySelectorAll('{sel}').length>={n} || (document.getElementById('sfStatus')||{{}}).textContent.includes('⚠')",timeout=t)
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={"width":420,"height":900}); errs=[]; pg.on("pageerror",lambda e:errs.append(str(e)))
    pg.goto("http://localhost:8098/index.html"); pg.wait_for_timeout(2000); pg.evaluate("openSF()"); pg.wait_for_selector("#sfGo",timeout=60000)
    pg.screenshot(path="/tmp/sf_top.png",full_page=False)
    t0=time.time(); pg.click("#sfGo"); wait(pg,"#sfMapBox .card")
    print("auto",round(time.time()-t0,1),"s status:",repr(pg.inner_text("#sfStatus")))
    assert "⚠" not in pg.inner_text("#sfStatus")
    pg.locator("#sfIdxTab").screenshot(path="/tmp/sf_idx.png"); pg.locator("#sfMapBox .card").screenshot(path="/tmp/sf_c.png")
    pg.click("#sfView [data-k=mean]"); pg.wait_for_timeout(300); wait(pg,"#sfMapBox .card"); pg.wait_for_timeout(2500); pg.locator("#sfMapBox .card").screenshot(path="/tmp/sf_mean.png")
    pg.click("#sfView [data-k=m3]"); pg.wait_for_timeout(3000); pg.locator("#sfMapBox .card").screenshot(path="/tmp/sf_m3.png")
    pg.click("#sfView [data-k=skill]"); pg.wait_for_timeout(3000); pg.locator("#sfMapBox .card").screenshot(path="/tmp/sf_skill.png")
    pg.click("#sfView [data-ti='3']"); pg.wait_for_timeout(3500); pg.locator("#sfView").screenshot(path="/tmp/sf_view.png")
    print(pg.evaluate("(()=>{ const T=SF.out.auto.T[0]; const v=T.pts.map(p=>p.c), s=T.pts.map(p=>p.skill); const q=a=>{a=a.slice().sort((x,y)=>x-y); return [a[0],a[a.length>>1],a[a.length-1]].map(x=>+x.toFixed(2));}; return {n:T.pts.length, c:q(v), skill:q(s), mean:q(T.pts.map(p=>p.mean)), an:T.an.slice(0,5), keys:T.keys}; })()"))
    # custom
    t0=time.time(); pg.click("#sfGoC"); wait(pg,"#sfMapBoxC .card")
    print("custom",round(time.time()-t0,1),"s",repr(pg.inner_text("#sfStatus"))); pg.locator("#sfMapBoxC .card").screenshot(path="/tmp/sf_cust.png")
    pg.click("#sfAdd"); pg.wait_for_timeout(200); print("conds",pg.evaluate("document.querySelectorAll('.sfCond').length"))
    print(errs); assert not errs
print("ALL PASS")
