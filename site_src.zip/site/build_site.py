import re,sys,os
root=os.path.dirname(os.path.abspath(__file__))
S=root+'/src'
def rd(p): return open(p,encoding='utf8').read()
import hashlib,json
t=rd(S+'/index.tpl.html')
t=re.sub(r'\{\{CSS:([^}]+)\}\}',lambda m:rd(f'{S}/css/{m.group(1)}'),t)
t=re.sub(r'\{\{JS:([^}]+)\}\}',lambda m:rd(f'{S}/js/{m.group(1)}'),t)
t=re.sub(r'\{\{BLOB:([^}]+)\}\}',lambda m:rd(f'{S}/blobs/{m.group(1)}.txt'),t)
BID=hashlib.md5(t.encode('utf8')).hexdigest()[:12]  # شناسهٔ نسخه از محتوای ساخته‌شده
t=t.replace('__BUILD_ID__',BID)
out=sys.argv[1] if len(sys.argv)>1 else root+'/index.html'
open(out,'w',encoding='utf8').write(t); print(len(t)//1024,'KB ->',out)
json.dump({'build':BID},open(os.path.join(os.path.dirname(os.path.abspath(out)),'version.json'),'w'))
