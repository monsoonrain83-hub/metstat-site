/* =====================================================================
   نقاط مراکز شهرستان‌ها روی نقشه‌های خروجی (روشن/خاموش)
   ۴۸۰ مرکز شهرستان از لایهٔ نقاط مراکز جمعیتی (GNS) و مرز شهرستان‌ها استخراج شده است.
   نقطهٔ ریز سیاه با حلقهٔ سفید: سیاهِ توپر و ترکیب سیاه‌وسفید در هیچ‌کدام از نوارهای رنگ بارش و دما نیست و
   روی هر رنگی دیده می‌شود. اندازه از مقیاس هر قالب (پیکسل در هر درجه) گرفته می‌شود تا روی WeatherBELL،
   weather.us، weathermodels، tropicaltidbits، حالت آزاد و زوم‌های استانی یکسان و کوچک بماند.
   ===================================================================== */
{{BLOB:county_seats}}
function seatsOn(){ return store.get("seats.on", false); }
function setSeats(on){
  store.set("seats.on", !!on);
  document.querySelectorAll(".seatSel").forEach(s=>s.value=on?"1":"0"); document.querySelectorAll(".ovChk[data-k=seats]").forEach(c=>c.checked=!!on);
  for(const id of ["seatsChk","caSeats"]){ const e=$(id); if(e) e.checked=!!on; }
  const k=typeof vPageKey==="function"?vPageKey():null;
  try{ if(k==="main") schedule(); else if(k==="wn" && wn.res) wnSchedule(50); else if(k==="cv" && cv.res) cvSchedule(50); }catch(e){}
}
// رسم روی بوم: proj(lat,lon) → [x,y] در مختصات منطقی بوم؛ clip = [x0,y0,x1,y1]؛ pxPerDeg برای اندازهٔ نقطه
function seatsDraw(ctx, proj, clip, pxPerDeg){
  const r=Math.max(1.25, Math.min(2.3, pxPerDeg*0.042)), ring=Math.max(0.45, r*0.28);
  ctx.save(); if(clip){ ctx.beginPath(); ctx.rect(clip[0],clip[1],clip[2]-clip[0],clip[3]-clip[1]); ctx.clip(); }
  const P_=[]; for(const [,la,lo] of SEATS){ const [x,y]=proj(la,lo); if(!isFinite(x)||!isFinite(y)) continue; if(clip && (x<clip[0]||y<clip[1]||x>clip[2]||y>clip[3])) continue; P_.push([x,y]); }
  ctx.fillStyle="rgba(255,255,255,.85)"; ctx.beginPath(); for(const [x,y] of P_){ ctx.moveTo(x+r+ring,y); ctx.arc(x,y,r+ring,0,7); } ctx.fill();
  ctx.fillStyle="#000000"; ctx.beginPath(); for(const [x,y] of P_){ ctx.moveTo(x+r,y); ctx.arc(x,y,r,0,7); } ctx.fill();
  ctx.restore(); return P_.length;
}
// نقشه‌های قالبی (WeatherBELL، weather.us، حالت آزاد/weathermodels/tropicaltidbits با زمین‌مرجع)
function seatsOverlay(cv){
  try{ if(!seatsOn() || !P || typeof mrGeo!=="function" || !mrGeo()) return; const s=cv.width/P.W, ctx=cv.getContext("2d");
    ctx.save(); ctx.setTransform(s,0,0,s,0,0);
    seatsDraw(ctx, (la,lo)=>[P.ax+P.bx*lo, P.ay+P.by*la], [P.fx0,P.fy0,P.fx1+1,P.fy1+1], Math.abs(P.bx));
    ctx.restore(); }catch(e){ console.warn("seats",e); }
}
/* ===== منوی کشویی «لایه‌ها» (PROGRESS 35): مرز استان، مرز شهرستان، رودخانه‌های مهم، جاده‌های مهم، مراکز شهرستان =====
   مرز استان/شهرستان: در حالت «مرز OpenStreetMap (شیپ‌فایل)» (برداری) با ubDraw روشن/خاموش می‌شود. در حالت «بدون مرز» اگر کاربر خودش روشن کند، همین خطوط یکپارچه رسم می‌شود.
   (در حالت «مرز weather.us» و زوم‌های PNG، مرز داخل خود تصویر است و خاموش‌شدنی نیست.)
   رودخانه‌ها (۱۲ رودخانهٔ اصلی) و جاده‌ها (فقط طبقهٔ ۱ = ۸۳ قطعهٔ بسیار مهم) از MAPF؛ مراکز شهرستان همان SEATS قبلی. */
function ovOn(k){ return k==="seats" ? seatsOn() : store.get("ov."+k, k==="prov"||k==="cty"); }
function ovSet(k,on){
  if(k==="seats") return setSeats(on);
  store.set("ov."+k, !!on); store.set("ov.t", true);
  document.querySelectorAll(".ovChk[data-k="+k+"]").forEach(c=>c.checked=!!on);
  const kk=typeof vPageKey==="function"?vPageKey():null;
  try{ if(kk==="main") schedule(); else if(kk==="wn" && wn.res) wnSchedule(50); else if(kk==="cv" && cv.res) cvSchedule(50); }catch(e){}
}
function ovExtra(cv){
  try{ if(!P || typeof mrGeo!=="function" || !mrGeo()) return;
    const wantB=(typeof brdMode==="function"&&brdMode()==="none"&&store.get("ov.t",false));
    const dP=wantB&&ovOn("prov"), dC=wantB&&ovOn("cty"), dR=ovOn("river"), dD=ovOn("road");
    if(!(dP||dC||dR||dD)) return;
    const s=cv.width/P.W, ctx=cv.getContext("2d"), sc=Math.max(1,Math.min(2.2,Math.abs(P.bx)/35));
    ctx.save(); ctx.setTransform(s,0,0,s,0,0); ctx.beginPath(); ctx.rect(P.fx0,P.fy0,P.fx1-P.fx0+1,P.fy1-P.fy0+1); ctx.clip(); ctx.lineJoin="round"; ctx.lineCap="round";
    const X=lo=>P.ax+P.bx*lo, Y=la=>P.ay+P.by*la;
    const strokeLL=(lines,col,w,halo)=>{ const path=new Path2D(); for(const ln of lines){ ln.forEach(([lo,la],i)=>{ if(i) path.lineTo(X(lo),Y(la)); else path.moveTo(X(lo),Y(la)); }); }
      if(halo){ ctx.strokeStyle="rgba(255,255,255,.8)"; ctx.lineWidth=w+1.4*sc; ctx.stroke(path); } ctx.strokeStyle=col; ctx.lineWidth=w; ctx.stroke(path); };
    if(dP||dC){ const B=ubLines(); const flat=a=>{ const path=new Path2D(); for(const pts of a){ for(let i=0;i<pts.length;i+=2){ const x=X(pts[i]),y=Y(pts[i+1]); if(i) path.lineTo(x,y); else path.moveTo(x,y); } } return path; };
      if(dC){ ctx.strokeStyle="rgba(60,95,150,.85)"; ctx.lineWidth=0.55*sc; ctx.stroke(flat(B.cty||[])); }
      if(dP){ ctx.strokeStyle="#0a3d8f"; ctx.lineWidth=1.0*sc; ctx.stroke(flat(B.prov||[])); } }
    if(dD && typeof MAPF!=="undefined") strokeLL(MAPF.roads.filter(r=>r[0]===1).map(r=>r[1]),"#b45309",0.9*sc,true);
    if(dR && typeof MAPF!=="undefined") strokeLL(MAPF.rivers.map(r=>r[1]),"#1473e6",1.1*sc,true);
    ctx.restore();
  }catch(e){ console.warn("ovExtra",e); }
}
{ const _cu=renderCU, _wb=renderWB, _wu=renderWU;
  renderCU=function(o){ const cv=_cu(o); if(!o.barLayout){ ovExtra(cv); seatsOverlay(cv); } return cv; };
  renderWB=function(o){ const cv=_wb(o); ovExtra(cv); seatsOverlay(cv); return cv; };
  renderWU=function(o){ const cv=_wu(o); ovExtra(cv); seatsOverlay(cv); return cv; }; }
// کنترل‌ها: چک‌باکس در تنظیمات صفحه
document.addEventListener("DOMContentLoaded",()=>{});
(function(){ const row=$("bordersChkRow"); if(row && !$("seatsChk")){ const l=document.createElement("label"); l.className="chk"; l.id="seatsRow";
    l.innerHTML=`<input type="checkbox" id="seatsChk"> نقاط مراکز شهرستان‌ها روی نقشهٔ نهایی (نقطهٔ ریز سیاه با حلقهٔ سفید)`; row.after(l);
    const c=$("seatsChk"); c.checked=seatsOn(); c.onchange=()=>setSeats(c.checked); } })();
