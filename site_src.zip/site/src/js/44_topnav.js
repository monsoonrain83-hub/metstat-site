/* ---------- نوار دکمه‌های بالای سایت + عنوان تب + نمایش آدرس صفحه (مرحلهٔ ۲-الف) ---------- */
(function(){
  const ORDER=["on","an","sa","lt","ci","ca","ds","wb","wu","wm","tt","cu"];
  const COLOR={on:"#2563eb",an:"#dc2626",sa:"#0891b2",lt:"#ca8a04",ci:"#7c3aed",ca:"#16a34a",ds:"#0d9488",wb:"#475569",wu:"#4f46e5",wm:"#db2777",tt:"#0284c7",cu:"#64748b"};
  const SHORT={on:"نقشه‌های آنلاین",an:"تحلیل و هشدار",sa:"ماهواره و رادار",lt:"ساخت نقشه تراکم رعدوبرق",ci:"شاخص‌های اقلیمی",ca:"اطلس اقلیمی",ds:"اصلاح با ارتفاع",wb:"WeatherBELL",wu:"weather.us",wm:"weathermodels",tt:"tropicaltidbits",cu:"نقشه از هر سایت"};
  const EN={on:"Online maps",an:"Analysis & warnings",sa:"Satellite & radar",lt:"Lightning",ci:"Climate indices",ca:"Climate atlas",ds:"Elevation fix",wb:"WeatherBELL",wu:"weather.us",wm:"weathermodels",tt:"tropicaltidbits",cu:"Any-site map"};
  const keyOf=b=>b.dataset.tt?"tt":b.dataset.wm?"wm":b.dataset.mode;
  const land=document.getElementById("landing"); if(!land) return;
  const nav=document.createElement("nav"); nav.id="topnav"; nav.className="topnav"; nav.setAttribute("data-noi18n",""); nav.hidden=true; nav.setAttribute("aria-label","صفحه‌های سایت");
  const btns={}; let _lastK=null,_userT=0,_prog=false;
  const srcs=[...land.querySelectorAll(".choice")];
  ORDER.forEach(k=>{
    const src=k==="an"?{click:()=>openAN(),querySelector:()=>null}:srcs.find(b=>keyOf(b)===k); if(!src) return;
    const b=document.createElement("button"); b.type="button"; b.className="tn-btn"; b.dataset.k=k; b.style.setProperty("--c",COLOR[k]||"#2563eb");
    const ic=src.querySelector(".ch-ic"); if(ic) b.appendChild(ic.cloneNode(true)); else if(k==="an"){ b.insertAdjacentHTML("beforeend",'<svg class="ch-ic" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3l10 18H2z"/><path d="M12 10v5M12 18v.5"/></svg>'); }
    const s=document.createElement("span"); s.dataset.fa=SHORT[k]||k; s.dataset.en=EN[k]||k; s.textContent=SHORT[k]||k; b.appendChild(s);
    b.onclick=()=>{ src.click(); window.scrollTo(0,0); };
    nav.appendChild(b); btns[k]=b;
  });
  ["pointerdown","touchstart","wheel","mousedown"].forEach(ev=>nav.addEventListener(ev,()=>{_userT=Date.now();},{passive:true})); nav.addEventListener("scroll",()=>{ if(!_prog) _userT=Date.now(); },{passive:true});
  const top=document.querySelector(".top"); top.parentNode.insertBefore(nav, top.nextSibling);
  /* نوار آدرس صفحه */
  const adr=document.createElement("div"); adr.id="pgAddr"; adr.className="pgaddr"; adr.hidden=true;
  adr.innerHTML='<span class="pa-l">آدرس این صفحه:</span><code class="pa-u" dir="ltr"></code><button type="button" class="pa-c">کپی</button>';
  nav.parentNode.insertBefore(adr, nav.nextSibling);
  adr.querySelector(".pa-c").onclick=()=>{ const u=location.href; const done=()=>{ const c=adr.querySelector(".pa-c"); c.textContent="کپی شد ✓"; setTimeout(()=>c.textContent="کپی",1500); };
    if(navigator.clipboard&&navigator.clipboard.writeText) navigator.clipboard.writeText(u).then(done,()=>{}); else { const t=document.createElement("textarea"); t.value=u; document.body.append(t); t.select(); try{document.execCommand("copy");}catch(e){} t.remove(); done(); } };
  /* صفحهٔ اول = «نقشه‌های آنلاین»؛ لندینگ قدیمی دیگر نشان داده نمی‌شود */
  const _showLanding=window.showLanding;
  window.showLanding=function(){ try{ if(typeof _showLanding==="function") _showLanding.apply(this,arguments); }catch(e){} land.hidden=true; return openON(); };
  const TITLE0="نقشه‌های آماری هواشناسی";
  function sync(){
    const en=typeof LANG!=="undefined"&&LANG==="en"; nav.querySelectorAll("span").forEach(s=>{ const v=en?s.dataset.en:s.dataset.fa; if(s.textContent!==v) s.textContent=v; });
    const isLand=!land.hidden; nav.hidden=isLand; adr.hidden=isLand;
    let m=""; try{ m=store.get("mode",""); }catch(e){}
    let k=m; if(m==="cu"){ k=(typeof state!=="undefined"&&state.ttPage)?"tt":"cu"; } else if(m==="cv"||m==="wn") k="an";
    Object.entries(btns).forEach(([id,b])=>b.classList.toggle("on",!isLand && (id===k || (id==="cu"&&m==="cu"&&!btns.tt)) ));
    const name=(typeof PAGE_NAME!=="undefined"&&PAGE_NAME[m])||"";
    document.title = isLand||!name ? TITLE0 : name+" — MetStat";
    adr.querySelector(".pa-u").textContent=location.host+location.pathname+location.hash;
    const a=nav.querySelector(".tn-btn.on");
    /* رفع پرش نوار بالا در موبایل (PROGRESS 35): فقط وقتی صفحهٔ فعال عوض شد و کاربر در ۵ ثانیهٔ اخیر نوار را لمس/اسکرول نکرده، دکمهٔ فعال وسط می‌آید؛ نه هر ۱٫۵ ثانیه، و بدون scrollIntoView (که صفحه را هم می‌پراند) */
    if(k!==_lastK){ _lastK=k; if(a&&nav.scrollWidth>nav.clientWidth&&Date.now()-_userT>5000){ try{ const ar=a.getBoundingClientRect(), nr=nav.getBoundingClientRect(); _prog=true; nav.scrollBy({left:(ar.left+ar.width/2)-(nr.left+nr.width/2),behavior:"auto"}); setTimeout(()=>{_prog=false;},120); }catch(e){} } }
  }
  const mo=new MutationObserver(()=>setTimeout(sync,60));
  for(const id of ["landing","app","dsApp","cvApp","ltApp","wnApp","cqcApp","caApp","onApp","ciApp","saApp","anApp"]){ const e=document.getElementById(id); if(e) mo.observe(e,{attributes:true,attributeFilter:["hidden"]}); }
  addEventListener("popstate",()=>setTimeout(sync,80)); addEventListener("hashchange",()=>setTimeout(sync,80));
  setInterval(sync,1500); sync();
})();

/* ===== ابزار فونت و اندازهٔ نوشته (کنار دکمهٔ راهنما) ===== */
(function(){
  const hb=document.getElementById("helpBtn"); if(!hb||document.getElementById("fontBtn")) return;
  const ls=(k,d)=>{ try{ const v=localStorage.getItem(k); return v==null?d:v; }catch(e){ return d; } }, ss=(k,v)=>{ try{ localStorage.setItem(k,v); }catch(e){} };
  const FFS=[["","پیش‌فرض سایت"],["Vazirmatn,Tahoma,sans-serif","وزیرمتن"],["Tahoma,sans-serif","Tahoma"],["system-ui,sans-serif","فونت سیستم"],["serif","سریف"]];
  function apply(){ const u=+ls("ui.fs",1), ff=ls("ui.ff","");
    document.documentElement.style.setProperty("--uiz",u); document.documentElement.toggleAttribute("data-uiz",u!==1);
    if(ff){ document.documentElement.style.setProperty("--uff",ff); document.documentElement.setAttribute("data-ff",""); } else { document.documentElement.removeAttribute("data-ff"); }
    try{ NV.s.fs=+ls("ui.mfs",1); if(typeof nvDraw==="function") nvDraw(); }catch(e){} }
  const b=document.createElement("button"); b.id="fontBtn"; b.type="button"; b.className="langbtn helpbtn"; b.title=(LANG==="en"?"Text size and font":"اندازه و نوع نوشته‌ها"); b.setAttribute("data-noi18n",""); b.textContent="Aa"; hb.after(b);
  b.onclick=()=>{ let d=document.getElementById("fontDlg"); if(!d){ d=document.createElement("dialog"); d.id="fontDlg"; d.className="nvDlg"; document.body.appendChild(d); }
    d.innerHTML=`<div class="nvDlgB"><button type="button" class="nvDlgX" aria-label="بستن">×</button><p><b>اندازه و نوع نوشته‌ها</b></p>
     <label class="fdl">اندازهٔ نوشته‌های منو و پنل‌ها: <output id="fdU">${Math.round(+ls("ui.fs",1)*100)}٪</output><input type="range" id="fdUi" min="0.8" max="1.6" step="0.05" value="${ls("ui.fs",1)}"></label>
     <label class="fdl">اندازهٔ نوشته‌های روی نقشه (نام شهر، رود، دریا): <output id="fdM">${Math.round(+ls("ui.mfs",1)*100)}٪</output><input type="range" id="fdMi" min="0.7" max="2" step="0.05" value="${ls("ui.mfs",1)}"></label>
     <label class="fdl">نوع فونت: <select id="fdF">${FFS.map(f=>`<option value="${f[0]}"${f[0]===ls("ui.ff","")?" selected":""}>${f[1]}</option>`).join("")}</select></label>
     <button type="button" class="btn sm" id="fdR">بازگشت به پیش‌فرض</button><p class="hint">اندازهٔ نوشته‌های نقشه فقط در صفحهٔ «نقشه‌های آنلاین» اثر دارد.</p></div>`;
    const q=id=>d.querySelector(id);
    q("#fdUi").oninput=e=>{ ss("ui.fs",e.target.value); q("#fdU").textContent=Math.round(e.target.value*100)+"٪"; apply(); };
    q("#fdMi").oninput=e=>{ ss("ui.mfs",e.target.value); q("#fdM").textContent=Math.round(e.target.value*100)+"٪"; apply(); };
    q("#fdF").onchange=e=>{ ss("ui.ff",e.target.value); apply(); };
    q("#fdR").onclick=()=>{ ss("ui.fs",1); ss("ui.mfs",1); ss("ui.ff",""); apply(); b.onclick(); };
    d.querySelector(".nvDlgX").onclick=()=>d.close(); d.onclick=e=>{ if(e.target===d) d.close(); };
    try{ d.showModal(); }catch(e){ d.setAttribute("open",""); } };
  apply();
})();
