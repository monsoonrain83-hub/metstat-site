/* ===== گرید خام مدل‌های عددی (nwp_grid.py → online/data/grid) =====
   فقط خواندن و نمونه‌برداری؛ داخلی است و هیچ عددی به کاربر نمایش داده نمی‌شود (مرحله‌های بعد: موتور همرفت/تگرگ/رعدوبرق روی همین گرید).
   فایل .mg:  'MG1' | uint32-BE طول هدر | هدر JSON | zlib( برای هر متغیر: صفحهٔ بایت بالا + صفحهٔ بایت پایین از int16 اختلاف‌گیری‌شده روی محور x )
   مقدار = (q + 32767) * s + o ؛ q = -32768 یعنی بدون داده.
   API:  NwpGrid.index() · NwpGrid.frame(model, valid[, run]) · NwpGrid.staticFrame(model) · fr.has(n) · fr.get(n) · fr.at(n, lon, lat) · fr.names()
         NwpGrid.nearestValid(model, Date|'YYYYMMDDHH')  ·  NwpGrid.resample(fr, name, lons, lats) */
const NwpGrid=(function(){
  const base=()=> (typeof ON!=="undefined" && ON.base ? ON.base : "online/")+"data/grid/";
  let _idx=null, _idxAt=0; const _fr=new Map(), MAXFR=6;
  async function index(force){
    if(!force && _idx && Date.now()-_idxAt<120000) return _idx;
    try{ const r=await fetch(base()+"index.json?"+Date.now(),{cache:"no-store"}); if(!r.ok) throw new Error(r.status); _idx=await r.json(); _idxAt=Date.now(); }
    catch(e){ _idx=null; }
    return _idx;
  }
  async function inflate(u8){
    if(typeof DecompressionStream==="undefined") throw new Error("DecompressionStream در این مرورگر نیست");
    const ds=new DecompressionStream("deflate");
    const ab=await new Response(new Blob([u8]).stream().pipeThrough(ds)).arrayBuffer();
    return new Uint8Array(ab);
  }
  class Frame{
    constructor(h, raw){ this.h=h; this.raw=raw; this.n=h.nx*h.ny; this.idx={}; h.vars.forEach((v,k)=>{ this.idx[v.n]=k; }); this._c={}; }
    names(){ return this.h.vars.map(v=>v.n); }
    has(n){ return n in this.idx; }
    get(n){
      if(this._c[n]) return this._c[n];
      const k=this.idx[n]; if(k===undefined) return null;
      const v=this.h.vars[k], N=this.n, nx=this.h.nx, ny=this.h.ny, raw=this.raw, hi=2*k*N, lo=(2*k+1)*N, out=new Float32Array(N), s=v.s, o=v.o;
      for(let j=0;j<ny;j++){
        let q=0; const r=j*nx;
        for(let i=0;i<nx;i++){
          const d=((raw[hi+r+i]<<8)|raw[lo+r+i])<<16>>16;
          q=(q+d)<<16>>16;
          out[r+i]= q===-32768 ? NaN : (q+32767)*s+o;
        }
      }
      this._c[n]=out; return out;
    }
    at(n, lon, lat){            // درون‌یابی دوخطی؛ بیرون از کادر یا کنار دادهٔ خالی: NaN
      const a=this.get(n); if(!a) return NaN;
      const {nx,ny,lon0,lat0,dx,dy}=this.h, fi=(lon-lon0)/dx, fj=(lat-lat0)/dy;
      if(!(fi>=0 && fj>=0 && fi<=nx-1 && fj<=ny-1)) return NaN;
      const i0=Math.min(Math.floor(fi),nx-2), j0=Math.min(Math.floor(fj),ny-2), u=fi-i0, w=fj-j0;
      const p=a[j0*nx+i0], q=a[j0*nx+i0+1], r=a[(j0+1)*nx+i0], t=a[(j0+1)*nx+i0+1];
      return (p*(1-u)+q*u)*(1-w)+(r*(1-u)+t*u)*w;
    }
  }
  function decodeHeader(buf){
    const u8=buf instanceof Uint8Array?buf:new Uint8Array(buf);
    if(u8[0]!==77||u8[1]!==71||u8[2]!==49) throw new Error("فایل گرید نامعتبر (MG1)");
    const hl=((u8[3]<<24)|(u8[4]<<16)|(u8[5]<<8)|u8[6])>>>0;
    const h=JSON.parse(new TextDecoder().decode(u8.subarray(7,7+hl)));
    return {h, body:u8.subarray(7+hl)};
  }
  async function decode(buf){
    const {h,body}=decodeHeader(buf); const raw=await inflate(body);
    if(raw.length<2*h.vars.length*h.nx*h.ny) throw new Error("داده‌های گرید ناقص است");
    return new Frame(h,raw);
  }
  async function load(url){
    if(_fr.has(url)){ const f=_fr.get(url); _fr.delete(url); _fr.set(url,f); return f; }
    const r=await fetch(url); if(!r.ok) throw new Error("گرید "+r.status);
    const f=await decode(await r.arrayBuffer());
    _fr.set(url,f); while(_fr.size>MAXFR) _fr.delete(_fr.keys().next().value);
    return f;
  }
  const vstr=v=> typeof v==="string" ? v : (v.getUTCFullYear()+String(v.getUTCMonth()+1).padStart(2,"0")+String(v.getUTCDate()).padStart(2,"0")+String(v.getUTCHours()).padStart(2,"0"));
  // ران قابل‌استفاده: جدیدترین اگر کامل است؛ وگرنه ران قبلیِ کامل (تا سایت هنگام دانلود ران جدید خالی نماند)
  function pick(m){ if(m.status!=="complete" && m.prev && m.prev.status==="complete") return m.prev; return m; }
  async function frame(model, valid, run){
    const ix=await index(); const m=ix && ix.models && ix.models[model]; if(!m) throw new Error("گرید مدل "+model+" روی هاست نیست");
    return load(base()+model+"/"+(run||pick(m).run)+"/"+vstr(valid)+".mg");
  }
  async function staticFrame(model){
    const ix=await index(); let m=ix && ix.models && ix.models[model]; if(!m) return null; m=pick(m); if(!m.static) return null;
    try{ return await load(base()+model+"/"+m.run+"/static.mg"); }catch(e){ return null; }
  }
  async function nearestValid(model, when){
    const ix=await index(); let m=ix && ix.models && ix.models[model]; if(!m) return null; m=pick(m); if(!m.steps || !m.steps.length) return null;
    const t=typeof when==="string" ? Date.UTC(+when.slice(0,4),+when.slice(4,6)-1,+when.slice(6,8),+when.slice(8,10)) : +when;
    let best=null, bd=1/0;
    for(const [v] of m.steps){ const d=Math.abs(Date.UTC(+v.slice(0,4),+v.slice(4,6)-1,+v.slice(6,8),+v.slice(8,10))-t); if(d<bd){ bd=d; best=v; } }
    return best;
  }
  function resample(fr, name, lons, lats){       // lons/lats: آرایه‌های هم‌طول → Float32Array
    const out=new Float32Array(lons.length); for(let k=0;k<lons.length;k++) out[k]=fr.at(name,lons[k],lats[k]); return out;
  }
  return {index, frame, staticFrame, nearestValid, resample, decode, Frame};
})();
if(typeof module!=="undefined" && module.exports) module.exports=NwpGrid;
