/* ===== دریافت خودکار «نقشهٔ بارش مقایسه» از هاست (زبانهٔ همرفت) =====
   وقتی در همرفت هیچ نقشهٔ بارشِ مقایسه نیست، به‌جای خطای «بارگذاری کنید»، برای زمان هر نقشهٔ شاخص
   نقشهٔ بارشی که همان بازه را می‌پوشاند (بارش ۳، ۶، ۱ یا ۲۴ ساعتهٔ منتهی به زمان نقشه یا بعد از آن) از هاست گرفته می‌شود.
   مدل: همان مدلی که از عنوان نقشه‌های شاخص خوانده شده؛ اگر در هاست نباشد، ECMWF سپس GFS. */
const CV_CMP_PS=["p3","p6","p1","p24"], CV_CMP_MAX=12, CV_CMP_TRIED=new Set();
function cvCmpPick(all, tMs){            // نزدیک‌ترین بارش با زمان پایان ≥ زمان نقشه (تا ۱۲ ساعت؛ برای ۲۴ ساعته تا ۲۴)
  let best=null;
  CV_CMP_PS.forEach((p,pi)=>{ for(const i of all){ if(i.p!==p) continue; const dt=(+onDate(i.v)-tMs)/36e5, lim=p==="p24"?24:12;
    if(!isFinite(dt)||dt<-0.01||dt>lim) continue; const sc=dt*10+pi; if(!best||sc<best.sc) best={i,sc}; } });
  return best&&best.i;
}
async function cvAutoCmp(){
  try{
    if(!(ON.man&&ON.man.items)){ try{ await onLoadManifest(); }catch(e){} }
    const items=(ON.man&&ON.man.items)||[]; if(!items.length) return false;
    const idx=cv.maps.filter(m=>!m.bad && m.role!=="cmp");
    const ts=[...new Set(idx.map(m=>m.times&&m.times.end?+m.times.end:null).filter(t=>t!==null&&isFinite(t)))].sort((a,b)=>a-b);
    // مدل: پرتکرارترین نام مدل در نقشه‌های شاخص؛ وگرنه ECMWF و GFS
    const cnt={}; for(const m of idx) if(m.model) cnt[m.model]=(cnt[m.model]||0)+1;
    const want=Object.keys(cnt).sort((a,b)=>cnt[b]-cnt[a]), lab=k=>ON_MODEL_FILE[k]||k;
    const keys=[...new Set(items.filter(i=>i.r==="iran").map(i=>i.m))];
    const order=[...want.flatMap(w=>keys.filter(k=>lab(k)===w)), ...["ECMWF","GFS"].flatMap(w=>keys.filter(k=>lab(k)===w))].filter((k,i,a)=>a.indexOf(k)===i);
    // اگر زمان نقشه‌ها از روی عکس خوانده نشد: زمان‌های نقشه‌های بارش هاست در بازهٔ زمانی انتخاب‌شده (در صورت فعال‌بودن بازه)
    let tsx=ts;
    if(!tsx.length && typeof anActive==="function" && anActive()){
      const hv=new Set(); for(const i of items){ if(i.r!=="iran"||!order.includes(i.m)||!CV_CMP_PS.includes(i.p)) continue; if(anInR(i.v)) hv.add(+onDate(i.v)); }
      tsx=[...hv].sort((a,b)=>a-b);
    }
    if(!tsx.length) return false;
    const sig=order.join(",")+"|"+tsx.join(","); if(CV_CMP_TRIED.has(sig)) return false; CV_CMP_TRIED.add(sig);
    for(const mk of order){
      const all=items.filter(i=>i.r==="iran"&&i.m===mk), pick=[];
      for(const t of tsx.slice(0,CV_CMP_MAX)){ const c=cvCmpPick(all,t); if(c&&!pick.some(o=>o.f===c.f)) pick.push(c); }
      if(!pick.length) continue;
      cvStatus(`دریافت نقشهٔ بارش ${lab(mk)} از هاست (${FA(pick.length)} نقشه)…`, 0.05);
      const files=[]; for(const i of pick){ const r=await fetch(ON.base+i.f); if(!r.ok) throw new Error("نقشه روی هاست پیدا نشد: "+i.f);
        files.push(new File([await r.blob()], `${lab(i.m)}_${i.p}_${i.v}.png`, {type:"image/png"})); }
      await cvAdd_(files, "cmp");        // داخل قفل cvRun است؛ cvAdd_ خودش اجرای دوباره را زمان‌بندی می‌کند
      return cv.maps.some(m=>m.role==="cmp" && !m.bad && m.v);
    }
  }catch(e){ console.warn("cvAutoCmp", e); }
  return false;
}
