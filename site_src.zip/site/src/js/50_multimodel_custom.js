/* =====================================================================
   مالتی مدل سفارشی — ترکیب خودکار نقشه‌های مدل‌ها از هاست (نه PNG دستی)
   • مدل‌ها و پارامتر و زمان معتبر را کاربر انتخاب می‌کند؛ کاشی‌های ۱۴۴۰×۹۶۰ (خاورمیانه) از هاست خوانده می‌شود.
   • هر کاشی گسسته است (هر پیکسل = شمارهٔ کلاس رنگ)؛ مقدار هر پیکسل = وسط بازهٔ همان کلاس (همان روش نوار رنگ).
     عدد خام مدل جایی نمایش یا ذخیره نمی‌شود؛ خروجی هم دوباره «کلاس گسسته» است (بدون درون‌یابی رنگ).
   • خروجی: میانگین وزنی، بیشینه، کمینه و نقشهٔ توافق (احتمال) با سه آستانه. همه چیز فقط در حافظهٔ مرورگر ساخته می‌شود؛
     هیچ فایلی روی هاست ساخته یا ذخیره نمی‌شود و با تازه‌سازی صفحه همه پاک می‌شود.
   ===================================================================== */
const MC={m:new Set(), w:{}, p:"", v:"", elev:false, res:2, sm:1, nep:0, thr:[], wp:true, open:{d:true,o:false,p:true,w:true,s:false},
  lay:{brd:true,cnty:false,riv:false,road:false,lake:false,vill:false,city:true}, reg:"iran", res_:null, tab:0, tok:0, sig:"", view:null, busy:false, msg:""};
const MC_TW=1440, MC_TH=960;

function mcModelGroups(){
  const d=nvModelsOf("daily"), seen=new Set(d.map(e=>e[0])), o=[];
  for(const tc of ["weekly","monthly","seasonal","ens"]) for(const e of nvModelsOf(tc)) if(!seen.has(e[0])){ seen.add(e[0]); o.push(e); }
  return {d,o};
}
function mcLab(k){ const M=ON.man.models[k]; return M?nvLabU(k,M,Object.keys(ON.man.models)):k; }
function mcTcFa(k){ const tc=((ON.man.models[k]||{}).info||{}).tclass||"daily"; return {weekly:"هفتگی",monthly:"ماهانه",seasonal:"فصلی",ens:"انسمبل",daily:"روزانه"}[tc]||""; }
function mcPid(par){ return par&&par.alt&&!MC.elev?par.alt:(par&&par.id); }
/* پارامتر اول انتخاب می‌شود؛ فقط مدل‌هایی که آن پارامتر را دارند فهرست می‌شوند */
function mcAllModels(){ const G=mcModelGroups(); return G.d.concat(G.o); }
function mcHas(m,par){ return !!par&&nvMeItems(m).some(i=>i.p===par.id||(par.alt&&i.p===par.alt)); }
const MC_FAM=[["ecmwf9","ecmwf"],["gfs","gfs25"]];      // نسخه‌های هم‌خانواده؛ از بالا به پایین رزولوشن کمتر
function mcIsEns(k){ return ((((ON.man.models[k]||{}).info)||{}).tclass)==="ens"; }
function mcIsDaily(k){ return ((((ON.man.models[k]||{}).info)||{}).tclass||"daily")==="daily"; }
/* اگر دو نسخهٔ یک مدل (ECMWF 9/28 km، GFS 13/28 km) هر دو پارامتر را دارند، فقط نسخهٔ با رزولوشن بالاتر می‌ماند، به شرط آنکه اجرایش از نسخهٔ پایین‌تر قدیمی‌تر نباشد */
function mcSuper(par,keys){ const hid=new Set(); for(const f of MC_FAM){ const av=f.filter(k=>keys.includes(k)&&mcHas(k,par)); if(av.length<2) continue;
    const run=k=>String((ON.man.models[k]||{}).run||""), mx=av.map(run).sort().pop(), win=av.find(k=>run(k)===mx); av.forEach(k=>{ if(k!==win) hid.add(k); }); } return hid; }
function mcAvail(par){ const all=mcAllModels(), keys=all.map(e=>e[0]), hid=mcSuper(par,keys); return all.filter(e=>mcHas(e[0],par)&&!hid.has(e[0])); }
function mcParams(){
  if(!ON.man) return [];
  const alts=nvAltSet(), have=new Map();
  for(const [m] of mcAllModels()) for(const i of nvMeItems(m)) have.set(i.p,(have.get(i.p)||new Set()).add(m));
  return (ON.man.params||[]).filter(p=>!alts.has(p.id)&&!/L$/.test(p.id)&&(have.has(p.id)||(p.alt&&have.has(p.alt)))&&(()=>{ const s=nvScale(p.sc); return s&&!s.lab; })())
    .map(p=>({p,n:mcAvail(p).length}));
}
function mcTimes(){
  const par=nvPar(MC.p); if(!par) return []; const pid=mcPid(par), cnt=new Map();
  for(const m of MC.m) for(const v of new Set(nvMeItems(m).filter(i=>i.p===pid).map(i=>i.v))) cnt.set(v,(cnt.get(v)||0)+1);
  return [...cnt.entries()].sort((a,b)=>a[0].localeCompare(b[0]));
}
function mcDefThr(par){
  const id=String(par&&par.id||""), k=nvKind(par);
  if(k==="precip"||k==="snow"){ if(/acc|tot|^pt|^pacc/.test(id)) return [10,25,50]; if(/1$/.test(id)&&!/24$/.test(id)) return [0.5,2,5]; if(/^p3$|3$/.test(id)) return [1,5,10]; if(/6$/.test(id)) return [1,10,25]; return [1,10,25]; }
  if(k==="temp") return /anom/.test(id)?[-2,0,2]:/tmin|tmn/.test(id)?[0,10,20]:[0,20,35];
  const s=nvScale(par.sc), E=(s&&s.e||[]).filter(Number.isFinite); if(E.length>=4) return [E[Math.floor(E.length*.25)],E[Math.floor(E.length*.5)],E[Math.floor(E.length*.75)]];
  return [10,20,30];
}
const mcN=n=>{ try{ return FA(n); }catch(e){ return String(n); } };

/* ---------------- فرم ---------------- */
function mcRender(){
  const box=$("mcBox"); if(!box||!ON.man||!ON.man.models) return;
  const sig=Object.keys(ON.man.models).join(",")+"|"+(ON.man.updated||"");
  if($("mcForm")&&MC.sig===sig) return;           // با هر تغییر فریم نمایشگر، فرم دوباره ساخته نمی‌شود (انتخاب‌های کاربر حفظ شود)
  MC.sig=sig; [...MC.m].forEach(m=>{ if(!ON.man.models[m]) MC.m.delete(m); });
  if(!$("mcForm")) box.innerHTML=`<div id="mcForm"></div><div id="mcOut"></div>`;
  mcForm(); if(!box.__b){ box.__b=1; mcBind(box); }
}
function mcForm(){
  const f=$("mcForm"); if(!f) return; const G=mcModelGroups();
  const ck=([k,o])=>`<label class="mcCk"><input type="checkbox" data-mm="${k}"${MC.m.has(k)?" checked":""}${!MC.m.has(k)&&((mcIsEns(k)&&hasD)||(mcIsDaily(k)&&hasE))?' disabled title="مدل انسمبل با مدل روزانه ترکیب نمی‌شود"':""}> ${mcLab(k)}${(o.info&&o.info.res)?` <small>${o.info.res}</small>`:""}${mcTcFa(k)&&mcTcFa(k)!=="روزانه"?` <small>(${mcTcFa(k)})</small>`:""}</label>`;
  const dd=(key,title,body,dis)=>`<details class="mcDd" data-od="${key}"${MC.open[key]?" open":""}${dis?" data-dis":""}><summary>${title}</summary><div class="mcPn">${body}</div></details>`;
  const ps=mcParams(), par=nvPar(MC.p)&&ps.some(x=>x.p.id===MC.p)?nvPar(MC.p):null;
  if(!par){ MC.p=ps.length?(ps.find(x=>x.p.id===NV.s.p)||ps[0]).p.id:""; }
  const AV=new Set(mcAvail(nvPar(MC.p)).map(e=>e[0])); [...MC.m].forEach(m=>{ if(!AV.has(m)) MC.m.delete(m); });
  const sel=[...MC.m], hasE=sel.some(mcIsEns), hasD=sel.some(mcIsDaily);
  const P=nvPar(MC.p), tms=mcTimes(); G.d=G.d.filter(e=>AV.has(e[0])); G.o=G.o.filter(e=>AV.has(e[0])); if(!tms.some(t=>t[0]===MC.v)) MC.v=(tms.slice().sort((a,b)=>b[1]-a[1]||a[0].localeCompare(b[0]))[0]||[""])[0];
  if(P&&!MC.thr.length||(P&&MC.thrFor!==P.id)){ MC.thr=mcDefThr(P); MC.thrFor=P.id; }
  const un=P?(P.mu||P.unit||""):"";
  const parBody=ps.length?ps.map(x=>`<label class="mcCk"><input type="radio" name="mcP" data-mp="${x.p.id}"${x.p.id===MC.p?" checked":""}> ${x.p.fa} <small>(${mcN(x.n)} مدل)</small></label>`).join(""):'<span class="hint">پارامتری مشترک نیست.</span>';
  const wBody=sel.length?sel.map(k=>`<div class="mcW"><span>${mcLab(k)}</span><input type="range" min="0" max="5" step="0.25" value="${MC.w[k]==null?1:MC.w[k]}" data-mw="${k}"><b id="mcWv_${k}">${mcN(MC.w[k]==null?1:MC.w[k])}</b></div>`).join("")+`<button type="button" class="btn sm" data-mact="eq">برابر کردن وزن‌ها</button>`:'<span class="hint">ابتدا مدل‌ها را تیک بزنید.</span>';
  f.innerHTML=`<div class="nvXh mcTitle">مالتی مدل سفارشی</div>
   <div class="hint">نقشه‌های خودکار هاست (نه PNG دستی) داده‌به‌داده ترکیب می‌شوند. خروجی فقط در مرورگر ساخته می‌شود و روی هاست ذخیره نمی‌شود؛ با تازه‌سازی صفحه پاک می‌شود.</div>
   ${dd("p","۱) پارامتر"+(P?": <b>"+P.fa+"</b>":"")+" <small>(اول پارامتر را انتخاب کنید؛ فقط مدل‌های دارای آن فهرست می‌شوند)</small>",parBody)}
   ${dd("d","۲) مدل‌های روزانه ("+mcN(G.d.filter(e=>MC.m.has(e[0])).length)+" انتخاب)",G.d.map(ck).join("")||'<span class="hint">مدلی نیست</span>')}
   ${dd("o","۳) مدل‌های فصلی، هفتگی، ماهانه و انسمبل ("+mcN(G.o.filter(e=>MC.m.has(e[0])).length)+" انتخاب)",G.o.map(ck).join("")||'<span class="hint">هنوز مدلی در این گروه روی هاست نیست</span>')}
   <div class="mcRow"><label>زمان معتبر <select id="mcV"${tms.length?"":" disabled"}>${tms.map(([v,n])=>`<option value="${v}"${v===MC.v?" selected":""}>${onFmtValid(v)} — ${mcN(n)} از ${mcN(sel.length)} مدل</option>`).join("")||"<option>—</option>"}</select></label>
   <label class="mcCk"><input type="checkbox" id="mcEl"${MC.elev?" checked":""}${P&&P.alt?"":" disabled"}> اصلاح پارامتر با ارتفاع (نسخهٔ DEM هاست)</label></div>
   <div class="hint">${P&&P.alt?"برای این پارامتر نسخهٔ اصلاح‌شده با ارتفاع (فرمول مخصوص همین پارامتر) روی هاست هست؛ با تیک زدن از آن استفاده می‌شود.":"برای «<b>"+(P?P.fa:"این پارامتر")+"</b>» نسخهٔ اصلاح‌شده با ارتفاع روی هاست نیست، پس تیک غیرفعال است."+(ps.filter(x=>x.p.alt).length?" پارامترهای دارای این نسخه: <b>"+ps.filter(x=>x.p.alt).map(x=>x.p.fa).join("، ")+"</b>.":" (بعد از اجرای بعدی تولیدکنندهٔ نقشه‌ها، بارش، برف، دما و رطوبت نسبی این نسخه را خواهند داشت؛ باد و شاخص‌های همرفتی اصلاح ارتفاعی ساده ندارند.)")}</div>
   ${dd("w","تعیین وزن مدل‌ها در نقشهٔ ترکیبی",wBody)}
   ${dd("s","رزولوشن، هموارسازی و همسایگی توافق",`<div class="mcRow">
      <label>رزولوشن محاسبه <select id="mcRes"><option value="1"${MC.res===1?" selected":""}>کامل (۱۴۴۰×۹۶۰)</option><option value="2"${MC.res===2?" selected":""}>نیم (۷۲۰×۴۸۰)</option><option value="4"${MC.res===4?" selected":""}>یک‌چهارم (۳۶۰×۲۴۰)</option></select></label>
      <label>هموارسازی توافق <select id="mcSm">${[[0,"بدون"],[1,"کم"],[2,"متوسط"],[4,"زیاد"]].map(([v,t])=>`<option value="${v}"${MC.sm===v?" selected":""}>${t}</option>`).join("")}</select></label>
      <label>همسایگی توافق <select id="mcNe">${[[0,"بدون (هر پیکسل)"],[30,"۳۰ کیلومتر"],[60,"۶۰ کیلومتر"],[120,"۱۲۰ کیلومتر"],[200,"۲۰۰ کیلومتر"]].map(([v,t])=>`<option value="${v}"${MC.nep===v?" selected":""}>${t}</option>`).join("")}</select></label></div>
      <div class="mcRow"><span>آستانه‌های توافق${un?` (${un})`:""}:</span>${[0,1,2].map(i=>`<input type="number" step="any" class="mcThr" data-mt="${i}" value="${MC.thr[i]==null?"":MC.thr[i]}">`).join("")}</div>
      <label class="mcCk"><input type="checkbox" id="mcWp"${MC.wp?" checked":""}> اعمال وزن مدل‌ها در نقشهٔ احتمال</label>`)}
   ${(()=>{ const e=tms.find(t=>t[0]===MC.v), n=e?e[1]:0; return sel.length&&n<2?`<div class="hint" style="color:#b4530a;font-weight:700">⚠ برای زمان انتخاب‌شده فقط ${mcN(n)} مدل نقشه دارد؛ با یک مدل، میانگین، بیشینه و کمینه دقیقاً یکی می‌شوند. زمان دیگری انتخاب کنید که مدل‌های بیشتری دارد (در منوی «زمان معتبر» نوشته «x از y مدل»).</div>`:""; })()}
   <button type="button" class="btn mcGo" data-mact="go"${sel.length&&MC.p&&MC.v&&!MC.busy?"":" disabled"}>تولید نقشه مالتی مدل سفارشی</button>
   <div class="hint" id="mcSt">${MC.msg||""}</div>`;
}
function mcBind(box){
  box.addEventListener("toggle",e=>{ const d=e.target; if(d.dataset&&d.dataset.od) MC.open[d.dataset.od]=d.open; },true);
  box.addEventListener("click",e=>{ const d=e.target.closest("summary"); if(d&&d.parentElement.hasAttribute("data-dis")){ e.preventDefault(); return; }
    const b=e.target.closest("[data-mact]"); if(!b) return; const a=b.dataset.mact;
    if(a==="eq"){ MC.m.forEach(k=>MC.w[k]=1); mcForm(); }
    else if(a==="go") mcRun().catch(err=>{ console.error(err); MC.busy=false; mcForm(); mcMsg("⚠ "+err.message); });
    else if(a==="zin") mcZoom(1.5); else if(a==="zout") mcZoom(1/1.5); else if(a==="zfit") mcFit();
    else if(a==="png") mcSavePng(); else if(a==="tab"){ MC.tab=+b.dataset.k; mcShow(); } });
  box.addEventListener("input",e=>{ const t=e.target; if(t.dataset&&t.dataset.mw){ MC.w[t.dataset.mw]=+t.value; const s=$("mcWv_"+t.dataset.mw); if(s) s.textContent=mcN(+t.value); } });
  box.addEventListener("change",e=>{ const t=e.target, d=t.dataset||{};
    if(d.mm){ if(t.checked&&[...MC.m].some(q=>mcIsEns(q)!==mcIsEns(d.mm)&&(mcIsEns(q)||mcIsEns(d.mm))&&(mcIsDaily(q)||mcIsDaily(d.mm)))){ t.checked=false; return mcMsg("مدل انسمبل با مدل روزانه ترکیب نمی‌شود."); } t.checked?MC.m.add(d.mm):MC.m.delete(d.mm); if(MC.w[d.mm]==null) MC.w[d.mm]=1; MC.p=MC.p; return mcForm(); }
    if(d.mp){ MC.p=d.mp; MC.thr=[]; return mcForm(); }
    if(t.id==="mcV"){ MC.v=t.value; return; }
    if(t.id==="mcEl"){ MC.elev=t.checked; MC.v=MC.v; return mcForm(); }
    if(t.id==="mcRes") MC.res=+t.value; else if(t.id==="mcSm") MC.sm=+t.value; else if(t.id==="mcNe") MC.nep=+t.value; else if(t.id==="mcWp") MC.wp=t.checked;
    else if(d.mt!==undefined){ MC.thr[+d.mt]=t.value===""?null:+t.value; }
    else if(d.ml){ MC.lay[d.ml]=t.checked; mcDraw(); }
    else if(t.id==="mcRg"){ MC.reg=t.value; mcFit(); } });
}
/* دکمهٔ بزرگ/کوچک‌کردن فونت لیبل‌های نقشه؛ پله‌ای و با سقف تا لیبل‌ها شلوغ نشوند (همپوشانی را geoLabels با مستطیل‌های اشغال‌شده حذف می‌کند) */
const LF_STEPS=[1,1.15,1.3,1.45,1.6];
function lfIdx(){ const v=+NV.s.fs||1; let b=0; LF_STEPS.forEach((x,i)=>{ if(Math.abs(x-v)<Math.abs(LF_STEPS[b]-v)) b=i; }); return b; }
function mcFsBtn(){ const i=lfIdx(); return `<button type="button" class="btn sm lfB" data-lf="-1" title="کوچک‌کردن فونت لیبل‌های نقشه"${i<=0?" disabled":""}>A−</button><button type="button" class="btn sm lfB" data-lf="1" title="بزرگ‌کردن فونت لیبل‌های نقشه (هر بار یک درجه؛ تا ${LF_STEPS.length-1} درجه)"${i>=LF_STEPS.length-1?" disabled":""}>A+ <small>${mcN(i)}/${mcN(LF_STEPS.length-1)}</small></button>`; }
function lfStep(d){ const i=Math.max(0,Math.min(LF_STEPS.length-1,lfIdx()+d)); NV.s.fs=LF_STEPS[i]; try{ localStorage.setItem("ui.mfs",LF_STEPS[i]); }catch(e){}
  document.querySelectorAll(".lfBt").forEach(e=>e.innerHTML=mcFsBtn()); try{ nvDraw(); }catch(e){} try{ mcDraw(); }catch(e){} }
document.addEventListener("click",e=>{ const b=e.target.closest&&e.target.closest("[data-lf]"); if(b&&!b.disabled) lfStep(+b.dataset.lf); });
function mcMsg(t,pr){ MC.msg=t||""; const s=$("mcSt"); if(s) s.innerHTML=MC.msg; if(pr!=null) MC.pr=pr; mcWait(); }
/* اسپینر و نوار انتظار وسط صفحه هنگام تولید نقشه */
function mcWait(){ let w=$("mcWait");
  if(!MC.busy){ if(w) w.hidden=true; return; }
  if(!w){ w=document.createElement("div"); w.id="mcWait"; w.setAttribute("role","status"); w.innerHTML='<div class="mcWb"><div class="mcWsp"></div><div class="mcWt" id="mcWt"></div><div class="mcWbar"><i id="mcWi"></i></div></div>'; document.body.appendChild(w); }
  w.hidden=false; $("mcWt").innerHTML=(MC.msg||"در حال تولید نقشه…").replace(/<span class="spn"><\/span>\s*/,""); $("mcWi").style.width=Math.max(6,Math.min(100,(MC.pr||0)*100))+"%"; }

/* ---------------- محاسبه ---------------- */
function mcReps(sc){ const E=sc.e||[], n=sc.c.length; return sc.c.map((_,k)=>{ const a=E[k], b=E[k+1]; if(Number.isFinite(a)&&Number.isFinite(b)) return (a+b)/2; if(Number.isFinite(b)) return b-1e-6; return a; }); }
function mcClassOf(v,sc){ if(!Number.isFinite(v)) return -1; const E=sc.e||[], n=sc.c.length; let c=0; for(let j=1;j<n;j++){ if(Number.isFinite(E[j])&&v>=E[j]) c=j; else if(Number.isFinite(E[j])) break; } return c; }
async function mcField(item, par, f){
  const sc=nvScale(par.sc), im=await nvImg(ON.base+item.f); if(!im) throw new Error("نقشه از هاست بارگذاری نشد: "+item.f);
  const e={img:im,sc}; const I=nvIndex(e); if(!I) throw new Error("رنگ‌های نقشهٔ "+item.m+" با مقیاس پارامتر نمی‌خواند");
  const reps=mcReps(sc), W=MC_TW/f, H=MC_TH/f, out=new Float32Array(W*H);
  for(let y=0;y<H;y++) for(let x=0;x<W;x++){ let s=0,n=0; for(let dy=0;dy<f;dy++){ const r=(y*f+dy)*MC_TW+x*f; for(let dx=0;dx<f;dx++){ const c=I[r+dx]; if(c>=0){ const v=reps[c]; if(Number.isFinite(v)){ s+=v; n++; } } } } out[y*W+x]=n?s/n:NaN; }
  return out;
}
function mcGauss(src,sg,W,H){
  if(!(sg>0)) return src; const r=Math.max(1,Math.ceil(3*sg)), k=[]; let t=0; for(let i=-r;i<=r;i++){ const w=Math.exp(-0.5*(i/sg)**2); k.push(w); t+=w; } for(let i=0;i<k.length;i++) k[i]/=t;
  const N=W*H, num=new Float32Array(N), den=new Float32Array(N); for(let i=0;i<N;i++){ if(Number.isFinite(src[i])){ num[i]=src[i]; den[i]=1; } }
  const refl=(j,n)=>j<0?-j-1:(j>=n?2*n-j-1:j), pass=(a)=>{ const t1=new Float32Array(N), o=new Float32Array(N);
    for(let y=0;y<H;y++) for(let x=0;x<W;x++){ let s=0; for(let u=-r;u<=r;u++) s+=k[u+r]*a[y*W+refl(x+u,W)]; t1[y*W+x]=s; }
    for(let y=0;y<H;y++) for(let x=0;x<W;x++){ let s=0; for(let u=-r;u<=r;u++) s+=k[u+r]*t1[refl(y+u,H)*W+x]; o[y*W+x]=s; } return o; };
  const a=pass(num), b=pass(den), out=new Float32Array(N); for(let i=0;i<N;i++) out[i]=Number.isFinite(src[i])&&b[i]>1e-6?a[i]/b[i]:NaN; return out;
}
function mcExpand(cls,f){ const W=MC_TW/f, I=new Int16Array(MC_TW*MC_TH); for(let y=0;y<MC_TH;y++){ const r=((y/f)|0)*W; for(let x=0;x<MC_TW;x++) I[y*MC_TW+x]=cls[r+((x/f)|0)]; } return I; }
function mcImgOf(I,sc){ const cv=document.createElement("canvas"); cv.width=MC_TW; cv.height=MC_TH; const x=cv.getContext("2d"), d=x.createImageData(MC_TW,MC_TH), o=new Uint32Array(d.data.buffer), pal=nvPal32(sc), W=0xFFFFFFFF;
  for(let i=0;i<I.length;i++){ const c=I[i]; o[i]=c>=0&&c<pal.length?pal[c]:W; } x.putImageData(d,0,0); return cv; }
async function mcRun(){
  if(MC.busy) return; const par=nvPar(MC.p); if(!par||!MC.m.size||!MC.v) return; const tok=++MC.tok; MC.busy=true; mcForm();
  const pid=mcPid(par), f=MC.res, W=MC_TW/f, H=MC_TH/f, N=W*H, sc=nvScale(par.sc), use=[], skip=[];
  for(const m of MC.m){ const w=MC.w[m]==null?1:MC.w[m]; if(!(w>0)) continue; const it=nvMeItems(m).find(i=>i.p===pid&&i.v===MC.v); if(it) use.push({m,w,it}); else skip.push(mcLab(m)); }
  if(!use.length){ MC.busy=false; mcForm(); return mcMsg("برای این پارامتر و زمان، مدلی با وزن مثبت نقشه ندارد."); }
  let k=0; mcMsg("در حال آماده‌سازی…",0.03); for(const u of use){ mcMsg(`<span class="spn"></span> دریافت و رمزگشایی ${mcLab(u.m)} (${mcN(k+1)} از ${mcN(use.length)})…`,0.05+0.8*k/use.length); k++; u.F=await mcField(u.it,par,f); if(tok!==MC.tok) return; await new Promise(r=>setTimeout(r,0)); }
  mcMsg('<span class="spn"></span> در حال ترکیب مدل‌ها و ساخت نقشه‌ها…',0.9); await new Promise(r=>setTimeout(r,20));
  const mean=new Float32Array(N), mx=new Float32Array(N), mn=new Float32Array(N);
  for(let i=0;i<N;i++){ let s=0,w=0,hi=-Infinity,lo=Infinity; for(const u of use){ const v=u.F[i]; if(!Number.isFinite(v)) continue; s+=u.w*v; w+=u.w; if(v>hi) hi=v; if(v<lo) lo=v; } if(w){ mean[i]=s/w; mx[i]=hi; mn[i]=lo; } else mean[i]=mx[i]=mn[i]=NaN; }
  const maps=[], reg=(nvRegions().find(r=>r[0]===MC.reg)||[])[1]||"";
  const names=use.map(u=>`${mcLab(u.m)}${use.some(q=>q.w!==use[0].w)?" ×"+mcN(u.w):""}`).join("، ");
  const mk=(F,title,sub,sc2,par2)=>{ const cls=new Int16Array(N); for(let i=0;i<N;i++) cls[i]=sc2.__prob?probClass(F[i]):mcClassOf(F[i],sc2); const I=mcExpand(cls,f), sc3=sc2.__prob?{c:sc2.c,e:sc2.e}:sc2; maps.push({title,sub,sc:sc3,par:par2,idx:I,img:mcImgOf(I,sc3),item:{v:MC.v,s:0}}); };
  mk(mean,"میانگین وزنی","میانگین وزنی مدل‌های انتخابی",sc,par); mk(mx,"بیشینه مدل‌ها","بیشینهٔ مقدار در هر نقطه",sc,par); mk(mn,"کمینه مدل‌ها","کمینهٔ مقدار در هر نقطه",sc,par);
  const PS={__prob:true,c:PROB_COLORS,e:PROB_EDGES.slice()}, pp={id:"mcprob",fa:"احتمال",mu:"٪",unit:"٪",sc:"",cat:"pr"}, un=par.mu||par.unit||"";
  const sg=MC.sm, nsg=MC.nep>0?(MC.nep/2/111.32)*(32/f):0;
  for(let q=0;q<3;q++){ const t=MC.thr[q]; if(t==null||!Number.isFinite(t)) continue; let P=new Float32Array(N), sw=0;
    for(const u of use) sw+=MC.wp?u.w:1;
    for(let i=0;i<N;i++){ let s=0,w=0; for(const u of use){ const v=u.F[i]; if(!Number.isFinite(v)) continue; const ww=MC.wp?u.w:1; w+=ww; if(v>=t) s+=ww; } P[i]=w?100*s/w:NaN; }
    if(nsg>0) P=mcGauss(P,nsg,W,H); if(sg>0) P=mcGauss(P,sg,W,H);
    for(let i=0;i<N;i++) if(Number.isFinite(P[i])){ if(P[i]>PROB_MAX) P[i]=PROB_MAX; }
    mk(P,`توافق: احتمال ≥ ${mcN(t)}${un?" "+un:""}`,`درصد مدل‌هایی که مقدار را ≥ ${mcN(t)}${un?" "+un:""} می‌بینند${MC.wp?" (با وزن مدل‌ها)":" (وزن برابر)"}${nsg>0?` · همسایگی ${mcN(MC.nep)} کیلومتر`:""}${sg>0?" · هموارسازی":""}`,PS,pp); }
  MC.res_={maps,names,skip,par,reg,v:MC.v,n:use.length}; MC.tab=0; MC.busy=false; mcForm();
  mcMsg(`${use.length<2?"⚠ فقط یک مدل نقشه داشت؛ میانگین، بیشینه و کمینه یکسان‌اند. ":""}✓ ${mcN(maps.length)} نقشه ساخته شد (${mcN(use.length)} مدل: ${use.map(u=>mcLab(u.m)).join("، ")})${skip.length?` — بدون نقشه برای این زمان: ${skip.join("، ")}`:""}`); mcOut();
}

/* ---------------- نمایش ---------------- */
function mcOut(){
  const o=$("mcOut"), R=MC.res_; if(!o||!R) return;
  const layOpts=[["brd","مرزها"],["cnty","مرز شهرستان‌ها"],["riv","رودها"],["road","جاده‌ها"],["lake","دریاچه‌ها"],["vill","روستاها و شهرها"],["city","نام شهرهای اصلی"]];
  o.innerHTML=`<article class="card wide mcCard"><header><h3 id="mcT"></h3><div class="sub" id="mcS"></div></header>
   <div class="mcTop"><details class="ovd mcLay"><summary>لایه‌ها</summary><div class="ovp">${layOpts.map(([k,t])=>`<label><input type="checkbox" data-ml="${k}"${MC.lay[k]?" checked":""}> ${t}</label>`).join("")}</div></details>
     <span class="lfBt">${mcFsBtn()}</span><label class="mcRg">زوم منطقه‌ای <select id="mcRg">${nvRegions().map(r=>`<option value="${r[0]}"${r[0]===MC.reg?" selected":""}>${r[1]}</option>`).join("")}</select></label></div>
   <div class="mcTabs">${R.maps.map((m,i)=>`<button type="button" class="btn sm" data-mact="tab" data-k="${i}">${m.title}</button>`).join("")}</div>
   <div class="nvStage mcStage" id="mcStage"><canvas id="mcCv"></canvas><div class="ztools nvZm"><button type="button" data-mact="zin" title="بزرگ‌نمایی">+</button><button type="button" data-mact="zout" title="کوچک‌نمایی">−</button><button type="button" data-mact="zfit" title="نمای کامل منطقه">⤢</button></div><button type="button" class="mcSave" data-mact="png" title="ذخیره PNG">⬇ PNG</button></div>
   <canvas id="mcLg" class="nvLg"></canvas></article>`;
  const st=$("mcStage"); mcBindStage(st); MC.view=null; mcShow(); o.scrollIntoView({behavior:"smooth",block:"nearest"});
}
function mcCur(){ return MC.res_&&MC.res_.maps[MC.tab]; }
function mcShow(){
  const R=MC.res_, m=mcCur(); if(!R||!m) return;
  [...document.querySelectorAll("#mcOut .mcTabs button")].forEach((b,i)=>b.classList.toggle("on",i===MC.tab));
  $("mcT").textContent=`${R.par.fa} — ${m.title}`;
  $("mcS").textContent=`${m.sub} · ${R.names} · ${onFmtValid(R.v)}`;
  mcSize(); if(!MC.view) mcFit(); else { mcClamp(); mcDraw(); }
}
function mcSize(){ const st=$("mcStage"), cv=$("mcCv"); if(!st||!cv) return; const r=st.getBoundingClientRect(); if(!r.width) return; MC.d=Math.min(2,window.devicePixelRatio||1); MC.cw=r.width; MC.ch=r.height; cv.width=Math.round(r.width*MC.d); cv.height=Math.round(r.height*MC.d);
  const lg=$("mcLg"), m=mcCur(); if(lg&&m){ const w=Math.max(300,Math.round(r.width*MC.d)); lg.width=w; lg.height=Math.round(MC.d*70); lg.style.height=(lg.height/MC.d)+"px"; nvLegendDraw(lg,w,mcEff(m),m.par.mu||m.par.unit,MC.d); } }
function mcEff(m){ try{ return nvEffScale(m)||m.sc; }catch(e){ return m.sc; } }
function mcFit(){ if(!MC.cw) mcSize(); const [w,e,s,n]=nvRegBox(MC.reg), k=Math.min(MC.cw/(e-w),MC.ch/(n-s)); MC.view={k,x0:(w+e)/2-MC.cw/2/k,y0:(s+n)/2+MC.ch/2/k}; mcClamp(); mcDraw(); }
function mcClamp(){ const v=MC.view; if(!v) return; const kmin=Math.max(MC.cw/(NV_BOX[1]-NV_BOX[0]),MC.ch/(NV_BOX[3]-NV_BOX[2])); v.k=Math.max(kmin,Math.min(2400,v.k)); const vw=MC.cw/v.k, vh=MC.ch/v.k; v.x0=Math.max(NV_BOX[0],Math.min(NV_BOX[1]-vw,v.x0)); v.y0=Math.max(NV_BOX[2]+vh,Math.min(NV_BOX[3],v.y0)); }
function mcLayS(){ return Object.assign({},NV.s,MC.lay,{reg:MC.reg}); }
function mcDraw(fast){ const cv=$("mcCv"), m=mcCur(); if(!cv||!m||!MC.view||!cv.width) return; const x=cv.getContext("2d"), v=MC.view, k=v.k*MC.d;
  nvPaintTile(x,cv.width,cv.height,k,v.x0,v.y0,m,!!fast); nvPaintVec(x,cv.width,cv.height,k,v.x0,v.y0,mcLayS(),MC.d); }
function mcSharp(){ clearTimeout(MC.sh); MC.sh=setTimeout(()=>mcDraw(false),140); }
function mcZoom(f,cx,cy){ const v=MC.view; if(!v) return; cx=cx==null?MC.cw/2:cx; cy=cy==null?MC.ch/2:cy; const lon=v.x0+cx/v.k, lat=v.y0-cy/v.k; v.k*=f; mcClamp(); v.x0=lon-cx/v.k; v.y0=lat+cy/v.k; mcClamp(); mcDraw(true); mcSharp(); }
function mcBindStage(st){
  const pts=new Map(); let last=null; const pos=e=>{ const r=st.getBoundingClientRect(); return [e.clientX-r.left,e.clientY-r.top]; };
  st.addEventListener("pointerdown",e=>{ if(e.target.closest&&e.target.closest(".ztools,.mcSave")) return; st.setPointerCapture(e.pointerId); pts.set(e.pointerId,pos(e)); last=null; st.classList.add("drag"); });
  st.addEventListener("pointermove",e=>{ if(!pts.has(e.pointerId)) return; const p=pos(e), o=pts.get(e.pointerId); pts.set(e.pointerId,p); const v=MC.view; if(!v) return;
    if(pts.size===1){ v.x0-=(p[0]-o[0])/v.k; v.y0+=(p[1]-o[1])/v.k; mcClamp(); mcDraw(true); mcSharp(); }
    else if(pts.size===2){ const [a,b]=[...pts.values()], dd=Math.hypot(a[0]-b[0],a[1]-b[1]), c=[(a[0]+b[0])/2,(a[1]+b[1])/2]; if(last){ mcZoom(dd/last.d,c[0],c[1]); v.x0-=(c[0]-last.c[0])/v.k; v.y0+=(c[1]-last.c[1])/v.k; mcClamp(); } last={d:dd,c}; } });
  const up=e=>{ pts.delete(e.pointerId); last=null; if(!pts.size) st.classList.remove("drag"); };
  st.addEventListener("pointerup",up); st.addEventListener("pointercancel",up);
  st.addEventListener("wheel",e=>{ e.preventDefault(); const [x,y]=pos(e); mcZoom(e.deltaY<0?1.25:0.8,x,y); },{passive:false});
  st.addEventListener("dblclick",e=>{ if(e.target.closest&&e.target.closest(".ztools,.mcSave")) return; const [x,y]=pos(e); mcZoom(2,x,y); });
  window.addEventListener("resize",()=>{ if($("mcStage")){ mcSize(); mcClamp(); mcDraw(); } });
}
/* خروجی PNG: فقط نقشه + تیتر + نوار رنگ + نشان؛ دکمه‌ها و منوها (عناصر DOM) هرگز داخل تصویر نمی‌آیند */
function mcCanvas(W){
  const m=mcCur(), R=MC.res_; if(!m||!R) return null; const mapH=Math.round(W*MC.ch/MC.cw), hd=210, lg=Math.round(W/760*108), ft=150, c=document.createElement("canvas"); c.width=W; c.height=hd+mapH+lg+ft;
  const x=c.getContext("2d"); x.fillStyle="#fff"; x.fillRect(0,0,c.width,c.height); const sub=document.createElement("canvas"); sub.width=W; sub.height=mapH; const k=MC.view.k*W/MC.cw, sx=sub.getContext("2d");
  nvPaintTile(sx,W,mapH,k,MC.view.x0,MC.view.y0,m,false); nvPaintVec(sx,W,mapH,k,MC.view.x0,MC.view.y0,mcLayS(),W/MC.cw);
  x.drawImage(sub,0,hd); x.strokeStyle="#000"; x.lineWidth=2; x.strokeRect(1,hd,W-2,mapH);
  txt(x,`${R.par.fa} — ${m.title}`,W-28,92,`78px ${FT.titr}`,{maxW:W-56}); txt(x,`${R.names} · ${onFmtValid(R.v)} · ${R.reg}`,W-28,172,`40px ${FT.body}`,{color:"#111",maxW:W-56});
  const l=document.createElement("canvas"); l.width=W; l.height=lg; nvLegendDraw(l,W,mcEff(m),m.par.mu||m.par.unit,W/760*1.5); x.drawImage(l,0,hd+mapH);
  const fy=hd+mapH+lg; txt(x,`داده: مدل‌های انتخابی · Open-Meteo.com (CC BY 4.0)`,W-28,fy+62,`40px ${FT.body}`,{color:"#222"}); txt(x,`MetStat — wtafkik.ir`,W-28,fy+118,`bold 44px ${FT.body}`,{color:"#0a3d8f",dir:"ltr"});
  try{ drawBrand(x,{brand:$("brand")?$("brand").value.trim():"",handle:$("handle")?$("handle").value.trim():"",logoImg:state.logoImg},20,fy+8,Math.round(W*0.4),ft-16,{side:true,align:"left",fs:36}); }catch(err){}
  return c;
}
function mcSavePng(){ const c=mcCanvas(1800); if(!c) return; c.toBlob(b=>onSave(b,`metstat_multimodel_${MC.p}_${MC.v}_${MC.tab}.png`)); }

/* ===== دکمهٔ «ذخیره PNG» گوشهٔ بالا-راست داخل کادر نقشه‌ها (همهٔ صفحه‌ها)؛ عنصر DOM است و داخل خروجی PNG نمی‌آید ===== */
function mfPngBtn(host,fn){
  if(!host||host.querySelector(":scope>.mcSave")) return null; try{ if(getComputedStyle(host).position==="static") host.style.position="relative"; }catch(e){}
  const b=document.createElement("button"); b.type="button"; b.className="mcSave"; b.title="ذخیره PNG"; b.setAttribute("aria-label","ذخیره PNG"); b.textContent="⬇ PNG";
  b.addEventListener("pointerdown",e=>e.stopPropagation()); b.addEventListener("click",e=>{ e.stopPropagation(); e.preventDefault(); try{ fn(); }catch(err){ console.warn(err); } }); host.append(b); return b; }
function mfSaveImg(img,name){ if(!img||!img.naturalWidth) return; const c=document.createElement("canvas"); c.width=img.naturalWidth; c.height=img.naturalHeight; c.getContext("2d").drawImage(img,0,0); c.toBlob(b=>onSave(b,name||"metstat_map.png"),"image/png"); }

/* شناسهٔ نسخهٔ سایت (گوشهٔ پایین) تا بشود دید نسخهٔ تازه واقعاً روی هاست نصب شده است؛ باید با wtafkik.ir/version.json یکی باشد */
(function(){ try{ const b=document.createElement("div"); b.id="msBuild"; b.textContent="ساخت "+(window.MS_BUILD||"—"); b.style.cssText="position:fixed;left:6px;bottom:4px;font:10px/1 system-ui,sans-serif;opacity:.55;z-index:5;pointer-events:none;direction:rtl;color:#334155;background:rgba(255,255,255,.7);padding:2px 5px;border-radius:4px"; document.body.append(b); }catch(e){} })();
