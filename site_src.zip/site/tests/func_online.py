import sys, asyncio
from playwright.async_api import async_playwright
async def main(url):
    async with async_playwright() as p:
        b = await p.chromium.launch(args=['--no-sandbox']); ctx = await b.new_context(viewport={'width': 1300, 'height': 1000}, locale='fa-IR', accept_downloads=True)
        await ctx.add_init_script('localStorage.setItem("mmap.lang", JSON.stringify("fa")); localStorage.setItem("mmap.seats.on","false")')
        pg = await ctx.new_page(); errs = []; pg.on('response', lambda r: print('HTTP', r.status, r.url[-90:]) if r.status>=400 and 'stats.php' not in r.url and 'online-maps' not in r.url and 'analysis' not in r.url else None); pg.on('pageerror', lambda e: errs.append('PAGEERR ' + str(e)[:200])); pg.on('console', lambda m: errs.append('C:' + m.text[:150]) if m.type == 'error' and 'status of 501' not in m.text else None)
        await pg.goto(url); await pg.wait_for_timeout(1500); await pg.evaluate('openON()'); await pg.wait_for_timeout(4500)
        print('state', await pg.evaluate('({m:NV.s.m,p:NV.s.p,fr:NV.s.fr,reg:NV.s.reg,secs:[...document.querySelectorAll("#nvWx .wxHd")].map(b=>b.textContent.trim().slice(0,22))})'))
        # فریم‌ها برای هر مدل و پارامتر: گام ۳ ساعته
        for m in ['ecmwf', 'gfs']:
            await pg.evaluate(f'wxSet("nvM","{m}")'); await pg.wait_for_timeout(1500)
            for par in ['t2m', 'p3', 'pacc']:
                r = await pg.evaluate(f'''()=>{{ const it=ON.man.items.filter(i=>i.r==="me"&&i.m==="{m}"&&i.p==="{par}"&&!/L$/.test(i.p)); const s=it.map(i=>i.s).sort((a,b)=>a-b); const d=s.slice(1).map((v,i)=>v-s[i]); return {{n:s.length, first:s.slice(0,6), steps:[...new Set(d)]}}; }}''')
                print(m, par, r)
        # GIF/PNG
        print('toolbar', await pg.evaluate('[...document.querySelectorAll(".nvTools button, .nvTools select")].map(e=>(e.id||"")+":"+(e.textContent||"").trim().slice(0,12)).join(" | ")'))
        await pg.screenshot(path='/tmp/n3_a.png')
        try:
            async with pg.expect_download(timeout=20000) as d: await pg.click('#nvPng')
            print('png ok', (await d.value).suggested_filename)
        except Exception as e: print('png FAIL', str(e)[:100])
        print('gif ui', await pg.evaluate('({gif:!!$("nvGif"), gf:!!$("nvGf"), gt:!!$("nvGt"), gw:!!$("nvGw")})'))
        print('errors', errs[:8]); await b.close()
asyncio.run(main(sys.argv[1]))
