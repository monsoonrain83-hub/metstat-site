# -*- coding: utf-8 -*-
"""میزبان آزمایشی محلی برای نمایشگر نقشه‌های آنلاین (بدون PHP و بدون اینترنت).
۱) python3 nwp_maps.py --mock --out /tmp/mock --models ecmwf,gfs --regions iran,me --max-steps 12
۲) python3 mock_host.py /path/to/nwp /tmp/mock /tmp/srv      ← manifest.json و پوشهٔ data/nwp را می‌سازد (همان کار manifest() در nwp_upload.php)
۳) (cd /tmp/srv && python3 -m http.server 8099)  ؛ سپس index.html را در /tmp/srv بگذارید."""
import sys, os, json, glob, shutil, re
nwp, src, dst = sys.argv[1:4]; sys.path.insert(0, nwp)
import nwp_maps as N
D = f'{dst}/online/data'; os.makedirs(D, exist_ok=True)
man = dict(source='nwp', updated='2026-10-11T09:00:00+00:00', status='complete', run=None, models={}, regions={'iran': {'fa': 'ایران'}, 'fars': {'fa': 'فارس'}, 'me': {'fa': 'خاورمیانه'}},
           params=[], items=[], cats=[dict(id=i, fa=fa, o=o) for i, fa, o in N.CATS], scales=N.scales_payload())
used = set()
for mdir in sorted(glob.glob(f'{src}/*/')):
    m = os.path.basename(mdir.rstrip('/')); M = N.MODELS[m]; runs = sorted(glob.glob(f'{mdir}/20*')); run = os.path.basename(runs[-1])
    man['models'][m] = dict(fa=M['label'], name=M['name'], run=run, status='complete', done=0, info=dict(tclass='daily', res=M.get('res', ''), cyc=M.get('cyc', ''), prov=M['prov']))
    man['run'] = run
    out = f'{D}/nwp/{m}/{run}'; shutil.rmtree(out, ignore_errors=True); shutil.copytree(f'{mdir}/{run}', out)
    for f in glob.glob(f'{out}/*/*.*'):
        reg = f.split('/')[-2]; nm = os.path.basename(f); p, rest = nm.split('_', 1); v = rest.split('.')[0]
        if p.endswith('L') and f.endswith('.webp'): continue
        if reg == 'me' and not f.endswith('.webp'): continue
        if reg != 'me' and not f.endswith('.png'): continue
        used.add(p); man['items'].append(dict(f=f'data/nwp/{m}/{run}/{reg}/{nm}', r=reg, m=m, p=p, s=int(v[-2:]) if False else 0, v=v, run=run))
# ساعت پیش‌بینی از اختلاف با ساعت اجرا
import datetime as dt
for i in man['items']:
    a = dt.datetime.strptime(i['run'], '%Y%m%d%H'); b = dt.datetime.strptime(i['v'], '%Y%m%d%H'); i['s'] = int((b - a).total_seconds() // 3600)
for pid, P in N.PARAMS.items():
    if pid in used: man['params'].append(dict(id=pid, fa=P['fa'], unit=P['unit'], cat=P['cat'], o=P['ord'], sc=(P.get('me') or {}).get('sc', P['sc']), mu=(P.get('me') or {}).get('unit', P['unit']), alt=P.get('alt', ''), me=int(bool(P.get('me_only'))), ln=int(bool(P.get('cont') or P.get('barbs') or P.get('ln')))))
man['done'] = man['expected'] = len(man['items'])
json.dump(man, open(f'{D}/manifest.json', 'w'), ensure_ascii=False)
print('manifest ok', len(man['items']), 'items', len(man['params']), 'params', list(man['models']))
