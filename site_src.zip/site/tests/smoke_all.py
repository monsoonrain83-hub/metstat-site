# دود کل سایت: همهٔ صفحه‌ها را باز می‌کند و خطاها/درخواست‌های ناموفق/ظرف‌های خالی را گزارش می‌دهد
import sys, asyncio, json
from playwright.async_api import async_playwright
async def main(url):
    async with async_playwright() as p:
        b = await p.chromium.launch(args=['--no-sandbox'])
        for vp, tag in [({'width': 1300, 'height': 900}, 'desktop')]:
            ctx = await b.new_context(viewport=vp, locale='fa-IR'); await ctx.add_init_script('localStorage.setItem("mmap.lang", JSON.stringify("fa")); localStorage.setItem("mmap.seats.on","false")')
            pg = await ctx.new_page(); errs = []; bad = []
            pg.on('pageerror', lambda e: errs.append('PAGEERR ' + str(e)[:200])); pg.on('console', lambda m: errs.append('CONSOLE ' + m.text[:160]) if m.type == 'error' else None)
            pg.on('response', lambda r: bad.append(f'{r.status} {r.url[-70:]}') if r.status >= 400 and 'stats.php' not in r.url else None)
            await pg.goto(url); await pg.wait_for_timeout(1500)
            modes = await pg.evaluate('Object.keys(ROUTES)'); print(tag, 'modes', modes)
            for m in modes:
                e0 = len(errs)
                try:
                    await pg.evaluate(f'(async()=>{{ await openMode("{m}"); }})()'); await pg.wait_for_timeout(1800)
                    info = await pg.evaluate('''()=>{ const vis=[...document.querySelectorAll("body > *, .wrap, main, section")].filter(e=>e.id&&!e.hidden&&e.offsetParent!==null).map(e=>e.id).slice(0,6); const ov=document.documentElement.scrollWidth>innerWidth+2; return {vis, hscroll:ov, hash:location.hash, path:location.pathname, title:document.title}; }''')
                    print(f'  [{tag}] {m:3} {info}')
                except Exception as ex: print(f'  [{tag}] {m} EXC {str(ex)[:140]}')
                if len(errs) > e0: print('     errors:', errs[e0:][:3])
            print(f'  [{tag}] failed requests:', sorted(set(bad))[:8]); await ctx.close()
        await b.close()
asyncio.run(main(sys.argv[1]))
