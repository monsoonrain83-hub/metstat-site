# ابزار بازسازی مرزها (PROGRESS 34)
ترتیب اجرا (نیاز: python3, numpy, scipy, opencv, pillow). مسیرها در اسکریپت‌ها /home/claude/w است؛ قبل از اجرا اصلاح کنید.
1. fit.npy: ضرایب زمین‌مرجع JPG مرجع: x = A + K*cos30*lon ، y = B - K*lat (A,B,K = محتوای fit.npy). برازش با chamfer روی خطوط JPG؛ میانهٔ خطا ۰ پیکسل، ۹۱٪ رأس‌ها ≤۱٫۵ پیکسل.
2. build_geo.py: گروه‌بندی شهرستان‌ها به استان (آزمون خط آبی)، شطرنجی ۰٫۰۰۳ درجه، پرکردن شکاف‌ها.
3. topo.py: استخراج زنجیرهٔ لبه‌ها (هر مرز مشترک یک‌بار).
4. finalize_geo.py: ساده‌سازی، unified_borders.txt، ۳۱ چندضلعی استان و data_layers_shapefile.txt.
