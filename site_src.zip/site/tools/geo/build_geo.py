# -*- coding: utf-8 -*-
"""Stage 1: provinces from blue-line test + single-line topology (out/prov/cty) + new LAYERS.ostan"""
import sys,json,pickle,collections,time
sys.path.insert(0,'/home/claude/w')
from load import *
import numpy as np, cv2
from scipy import ndimage as ndi
t0=time.time()
pre,L,post=load_layers(); C=L['county']; O=L['ostan']
pairs=pickle.load(open('/home/claude/w/pairs2.pkl','rb')); old,_=pickle.load(open('/home/claude/w/groups2.pkl','rb'))
oname=lambda k:O[k]['p']['name']
strip=lambda s:s[8:] if s.startswith('شهرستان ') else s
nm=lambda i:strip(C[i-1]['p']['name'])
# ---- 1. union-find with rules
FORCE_UNION={('چهاربرج','میاندوآب'),('هلیلان','چرداول')}   # ambiguous partial blue; confirmed by user/visual
FORCE_SEP={('خوی','شبستر')}                                  # contact only across Lake Urmia, no line drawn
par={}
def find(x):
    while par.setdefault(x,x)!=x: par[x]=par[par[x]]; x=par[x]
    return x
for (u,v),(n,f) in pairs.items():
    if (u-1) not in old or (v-1) not in old: continue
    key=(nm(u),nm(v)); rk=(key[1],key[0])
    if key in FORCE_SEP or rk in FORCE_SEP: continue
    same_old=old[u-1]==old[v-1]
    if key in FORCE_UNION or rk in FORCE_UNION or (n>=15 and (f<0.2 or (f<0.5 and same_old))): par[find(u)]=find(v)
groups=collections.defaultdict(list)
for i in old: groups[find(i+1)].append(i+1)
# name groups: majority of old province; Alborz special
prov_of={}   # county idx(1-based) -> province name
used=collections.Counter()
glist=sorted(groups.values(),key=lambda m:-len(m))
for mem in glist:
    c=collections.Counter(oname(old[i-1]) for i in mem)
    top,topn=c.most_common(1)[0]
    if top=='تهران' and len(mem)<=8 and not any(nm(i)=='تهران' for i in mem): top='البرز'
    if len(mem)==1 and False: pass
    for i in mem: prov_of[i]=top
# large groups sanity
cnt=collections.Counter(prov_of.values())
print('province group sizes',len(cnt),dict(cnt))
# singletons (islands etc.) keep old province unless group merged: fine already (named from old)
# Alborz members
print('Alborz:',[nm(i) for i in prov_of if prov_of[i]=='البرز'])
# counties that changed vs old
chg=[(nm(i),oname(old[i-1]),p) for i,p in prov_of.items() if oname(old[i-1])!=p and not(oname(old[i-1])=='تهران' and p=='البرز')]
print('CHANGED (old->new):'); [print(' ',c) for c in chg]
alb=[(nm(i)) for i,p in prov_of.items() if p=='البرز']
pickle.dump(prov_of,open('/home/claude/w/prov_of.pkl','wb'))
# ---- 2. raster at RES deg
RES=0.003; LON0,LAT1=43.80,40.00; LON1,LAT0=63.60,24.80
W=int(round((LON1-LON0)/RES)); H=int(round((LAT1-LAT0)/RES)); print('grid',W,H)
lab=np.zeros((H,W),np.int16)
def bb(f): 
    xs=[p[0] for poly in f['g'] for p in poly[0]]; ys=[p[1] for poly in f['g'] for p in poly[0]]
    return (max(xs)-min(xs))*(max(ys)-min(ys)) if xs else 0
order=sorted([i for i in range(len(C)) if C[i]['g']],key=lambda i:-bb(C[i]))
SH=4
for i in order:
    if (i+1) not in prov_of: continue
    cnts=[]
    for poly in C[i]['g']:
        for ring in poly:
            a=np.array(ring); px=np.round(((a[:,0]-LON0)/RES)*(1<<SH)).astype(np.int32); py=np.round(((LAT1-a[:,1])/RES)*(1<<SH)).astype(np.int32)
            cnts.append(np.stack([px,py],1).reshape(-1,1,2))
    tmp=np.zeros((H,W),np.uint8)
    # per-polygon even-odd for holes: fill each polygon (outer+holes) separately
    for poly in C[i]['g']:
        pc=[]
        for ring in poly:
            a=np.array(ring); px=np.round(((a[:,0]-LON0)/RES)*(1<<SH)).astype(np.int32); py=np.round(((LAT1-a[:,1])/RES)*(1<<SH)).astype(np.int32)
            pc.append(np.stack([px,py],1).reshape(-1,1,2))
        x0=min(int(c[:,0,0].min()>>SH) for c in pc)-2; x1=max(int(c[:,0,0].max()>>SH) for c in pc)+3
        y0=min(int(c[:,0,1].min()>>SH) for c in pc)-2; y1=max(int(c[:,0,1].max()>>SH) for c in pc)+3
        x0=max(x0,0);y0=max(y0,0);x1=min(x1,W);y1=min(y1,H)
        m=np.zeros((y1-y0,x1-x0),np.uint8)
        pc2=[c-np.array([x0<<SH,y0<<SH],np.int32) for c in pc]
        cv2.fillPoly(m,[pc2[0]],1,shift=SH)
        for h in pc2[1:]:
            cv2.fillPoly(m,[h],0,shift=SH)
        sub=lab[y0:y1,x0:x1]; sub[m>0]=i+1
print('raster',round(time.time()-t0,1),'s')
# ---- 3. close tiny gaps inside land
land=(lab>0).astype(np.uint8)
closed=cv2.morphologyEx(land,cv2.MORPH_CLOSE,cv2.getStructuringElement(cv2.MORPH_RECT,(9,9)))
gap=(closed>0)&(lab==0)
print('gap cells',int(gap.sum()))
lab16=lab.astype(np.uint16)
for it in range(6):
    dil=cv2.dilate(lab16,np.ones((3,3),np.uint8))
    fill=gap&(lab16==0)&(dil>0)
    lab16[fill]=dil[fill]
lab=lab16.astype(np.int16)
np.save('/home/claude/w/lab_topo.npy',lab)
print('filled',round(time.time()-t0,1))
