# -*- coding: utf-8 -*-
import sys,json,pickle,collections,copy
sys.path.insert(0,'/home/claude/w')
from load import *
import numpy as np, cv2
pre,L,post=load_layers(); C=L['county']; O=L['ostan']
prov_of=pickle.load(open('/home/claude/w/prov_of.pkl','rb'))
chains,W,H,RES,LON0,LAT1=pickle.load(open('/home/claude/w/chains.pkl','rb'))
NV=W+1
def vcoord(v): r,c=divmod(v,NV); return (c,r)
arcs=[]  # dict(s,e,xy(lonlat array),a,b,cls)
EPS=1.0   # grid px (=0.003 deg)
for path,a,b in chains:
    pts=np.array([vcoord(v) for v in path],np.float32)
    closed=path[0]==path[-1]
    # smoothing (moving average, w=5) keeping ends for open chains
    if len(pts)>6:
        k=2
        if closed:
            core=pts[:-1]; n=len(core); sm=np.zeros_like(core)
            for d in range(-k,k+1): sm+=np.roll(core,d,axis=0)
            sm/= (2*k+1); pts=np.vstack([sm,sm[:1]])
        else:
            sm=pts.copy()
            for i in range(k,len(pts)-k): sm[i]=pts[i-k:i+k+1].mean(0)
            pts=sm
    ap=cv2.approxPolyDP(pts.reshape(-1,1,2),EPS,closed).reshape(-1,2)
    if closed and len(ap)>=2 and not np.allclose(ap[0],ap[-1]): ap=np.vstack([ap,ap[:1]])
    lon=LON0+ap[:,0]*RES; lat=LAT1-ap[:,1]*RES
    xy=np.stack([np.round(lon,3),np.round(lat,3)],1)
    # drop consecutive dups
    keep=[0]+[i for i in range(1,len(xy)) if (xy[i]!=xy[i-1]).any()]
    xy=xy[keep]
    if len(xy)<2: continue
    if a==0 or b==0: cls='out'
    else: cls='prov' if prov_of[a]!=prov_of[b] else 'cty'
    arcs.append(dict(s=path[0],e=path[-1],xy=xy,a=a,b=b,cls=cls))
print('arcs',len(arcs),collections.Counter(x['cls'] for x in arcs),
      {c:sum(len(x['xy']) for x in arcs if x['cls']==c) for c in('out','prov','cty')})
# ---- encode UBD
def zz(x): return (x<<1) if x>=0 else (((-x)<<1)-1)
def varint(v):
    o=bytearray()
    while True:
        c=v&127; v>>=7
        if v: o.append(c|128)
        else: o.append(c); break
    return o
import base64
def enc(lines):
    o=bytearray()
    for xy in lines:
        o+=varint(zz(len(xy))); px=py=0
        for x,y in xy:
            ix=int(round(x*1000)); iy=int(round(y*1000)); o+=varint(zz(ix-px)); o+=varint(zz(iy-py)); px,py=ix,iy
    return base64.b64encode(bytes(o)).decode()
ubd={c:enc([x['xy'] for x in arcs if x['cls']==c]) for c in('out','prov','cty')}
hdr='// مرزهای یکپارچهٔ MetStat (نسخهٔ ۲: ۳۱ استان، بازسازی‌شده از JPG مرجع با آزمون خط آبی): هر مرز مشترک دقیقاً یک‌بار (بدون دوبل)؛ out=ساحل و مرز کشور، prov=مرز استان، cty=مرز شهرستان؛ مختصات ×۱۰۰۰\n'
open('/home/claude/w/out/unified_borders.txt','w',encoding='utf8').write(hdr+'const UBD='+json.dumps(ubd)+';\n')
# ---- province rings
provs=sorted(set(prov_of.values()))
def sarea(r):
    x=r[:,0];y=r[:,1]; return 0.5*np.sum(x[:-1]*y[1:]-x[1:]*y[:-1])
def build(P):
    pa=[x for x in arcs if ((x['a']!=0 and prov_of[x['a']]==P)!=(x['b']!=0 and prov_of[x['b']]==P))]
    used=[False]*len(pa); rings=[]
    byv=collections.defaultdict(list)
    for i,x in enumerate(pa): byv[x['s']].append(i); byv[x['e']].append(i)
    for i0 in range(len(pa)):
        if used[i0]: continue
        used[i0]=True; ring=[pa[i0]['xy']]; start=pa[i0]['s']; cur=pa[i0]['e']
        while cur!=start:
            nx=[j for j in byv[cur] if not used[j]]
            if not nx: break
            j=nx[0]; used[j]=True; x=pa[j]
            seg=x['xy'] if x['s']==cur else x['xy'][::-1]
            ring.append(seg); cur=x['e'] if x['s']==cur else x['s']
        r=np.vstack([ring[0]]+[s[1:] for s in ring[1:]])
        if not np.allclose(r[0],r[-1]): r=np.vstack([r,r[:1]])
        rings.append(r)
    return rings
newO=[]
oldmap={f['p']['name']:f for f in O}
EN=dict(البرز='Alborz')
def pointin(r,pt): return cv2.pointPolygonTest(r.astype(np.float32).reshape(-1,1,2),(float(pt[0]),float(pt[1])),False)>=0
for P in provs:
    rings=[r for r in build(P) if len(r)>=4 and abs(sarea(r))>1e-6]
    depth=[]
    for i,r in enumerate(rings):
        d=sum(1 for j,q in enumerate(rings) if j!=i and abs(sarea(q))>abs(sarea(r)) and pointin(q,r[0]))
        depth.append(d)
    polys=[]
    for i,r in enumerate(rings):
        if depth[i]%2==0:
            rr=r if sarea(r)>0 else r[::-1]   # outer ccw (matches typical)
            polys.append([rr.tolist()])
    for i,r in enumerate(rings):
        if depth[i]%2==1:
            c=[j for j in range(len(rings)) if depth[j]%2==0 and abs(sarea(rings[j]))>abs(sarea(r)) and pointin(rings[j],r[0])]
            if c:
                j=min(c,key=lambda j:abs(sarea(rings[j]))); k=[ii for ii,jj in enumerate([x for x in range(len(rings)) if depth[x]%2==0]) if jj==j][0]
                polys[k].append((r if sarea(r)<0 else r[::-1]).tolist())
    p=dict(name=P,en=(oldmap[P]['p']['en'] if P in oldmap else EN[P]))
    newO.append(dict(p=p,g=polys)); print(P,len(polys),'polys',sum(len(q[0]) for q in polys),'pts')
newO.sort(key=lambda f:f['p']['en'])
L2=dict(L); L2['ostan']=newO
# county -> province attribute
for i,f in enumerate(L2['county']):
    if (i+1) in prov_of: f['p']['ostan']=prov_of[i+1]
open('/home/claude/w/out/data_layers_shapefile.txt','w',encoding='utf8').write('const LAYERS='+json.dumps(L2,ensure_ascii=False)+';')
pickle.dump((arcs,newO),open('/home/claude/w/arcs.pkl','wb'))
