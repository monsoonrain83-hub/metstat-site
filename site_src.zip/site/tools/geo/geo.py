import numpy as np
c30=np.cos(np.radians(30))
A,B,K=np.load('/home/claude/w/fit.npy')
def ll2px(lon,lat): return A+K*c30*np.asarray(lon),B-K*np.asarray(lat)
def px2ll(x,y): return (np.asarray(x)-A)/(K*c30),(B-np.asarray(y))/K
