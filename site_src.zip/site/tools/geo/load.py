import json,re
def load_layers(path='/home/claude/w/site/site/src/blobs/data_layers_shapefile.txt'):
    s=open(path,encoding='utf8').read()
    i=s.index('const LAYERS=')+len('const LAYERS=')
    # find end of JSON object
    dec=json.JSONDecoder()
    obj,end=dec.raw_decode(s[i:])
    return s[:i],obj,s[i+end:]
