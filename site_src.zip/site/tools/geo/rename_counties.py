"""مرحلهٔ ۳ (PROGRESS 36): یکدست‌کردن نام شهرستان‌ها در data_layers_shapefile.txt
- حذف پیشوند «شهرستان » از همهٔ نام‌ها
- چندضلعی بدون پیشوند «نظرآباد» در البرز در واقع شهرستان چهارباغ است (مرکز ۵۰٫۷۸E، ۳۵٫۸۳N) → «چهارباغ»؛ شهرستان نظرآباد واقعی «نظرآباد» می‌ماند
- «خرم بید» (فارس) → «خرمبید»؛ «ویژه مراغه» → «مراغه»، «مبراباد» → «میرآباد»، «نی ریز» → «نیریز» (نام رسمی)
اجرا: python3 tools/geo/rename_counties.py src/blobs/data_layers_shapefile.txt   (درجا؛ دوباره‌اجرا بی‌اثر است) """
import sys,json,re
p=sys.argv[1]; t=open(p,encoding='utf-8').read()
m=re.match(r'^const LAYERS=(.*);\s*$',t,re.S); assert m,"قالب فایل شناخته نشد"
D=json.loads(m.group(1)); C=D['county']
fix={}   # (نام قبلی، استان) → نام جدید
def cx(f):   # طول جغرافیایی میانگین رأس‌ها
    pts=[q for poly in f['g'] for ring in poly[:1] for q in ring]; return sum(q[0] for q in pts)/len(pts) if pts else None
def rename(f):
    n=re.sub(r'^شهرستان\s+','',f['p']['name']); o=f['p'].get('ostan')
    if n in ('نظرآباد','چهارباغ') and o=='البرز':   # تشخیص با مکان (دوباره‌اجرا بی‌اثر است): نظرآباد ۵۰٫۵۵E ، چهارباغ ۵۰٫۷۸E
        c=cx(f); return 'چهارباغ' if c and c>50.7 else 'نظرآباد'
    n={'خرم بید':'خرمبید', 'ویژه مراغه':'مراغه', 'مبراباد':'میرآباد', 'نی ریز':'نیریز'}.get(n,n)   # ۳ مورد آخر بر پایهٔ نام رسمی شهرستان‌ها
    return n
ch=0
for f in C:
    n2=rename(f)
    if n2!=f['p']['name']: f['p']['name']=n2; ch+=1
print('تغییر نام:',ch,'از',len(C))
out='const LAYERS='+json.dumps(D,ensure_ascii=False)+';'
open(p,'w',encoding='utf-8').write(out)
