# -*- coding: utf-8 -*-
import sys,json,pickle,collections,time
sys.path.insert(0,'/home/claude/w')
from load import *
import numpy as np
t0=time.time()
pre,L,post=load_layers(); C=L['county']
prov_of=pickle.load(open('/home/claude/w/prov_of.pkl','rb'))
lab=np.load('/home/claude/w/lab_topo.npy').astype(np.int32)
RES=0.003; LON0,LAT1=43.80,40.00
H,W=lab.shape
print('Mahdishahr',[ (i,prov_of.get(i)) for i in range(1,len(C)+1) if 'مهدیشهر' in C[i-1]['p']['name']],'Bashagard',[ (i,prov_of.get(i)) for i in range(1,len(C)+1) if 'بشاگرد' in C[i-1]['p']['name']])
# pad
P=np.zeros((H+2,W+2),np.int32); P[1:-1,1:-1]=lab
# grid corners: (r,c) r in 0..H, c in 0..W ; vertex id=r*(W+1)+c
NV=(W+1)
# horizontal edges: between P[r] and P[r+1] rows (cell rows r-1 and r in lab coords): cells lab[r-1,c], lab[r,c], edge from corner(r,c)->(r,c+1)
a=P[0:H+1,1:W+1]; b=P[1:H+2,1:W+1]   # shape (H+1,W): a=cell above, b=cell below
m=a!=b; rr,cc=np.nonzero(m)
hu=rr*NV+cc; hv=rr*NV+cc+1; ha=a[m]; hb=b[m]
# vertical edges: cells lab[r,c-1], lab[r,c]; edge corner(r,c)->(r+1,c)
a=P[1:H+1,0:W+1]; b=P[1:H+1,1:W+2]  # (H,W+1)
m=a!=b; rr,cc=np.nonzero(m)
vu=rr*NV+cc; vv=(rr+1)*NV+cc; va=a[m]; vb=b[m]
U=np.concatenate([hu,vu]); V=np.concatenate([hv,vv]); A=np.concatenate([ha,va]); B=np.concatenate([hb,vb])
print('edges',len(U),round(time.time()-t0,1))
# adjacency via sorting
E=len(U)
ends=np.concatenate([U,V]); eid=np.concatenate([np.arange(E),np.arange(E)])
o=np.argsort(ends,kind='stable'); ends_s=ends[o]; eid_s=eid[o]
uniq,start=np.unique(ends_s,return_index=True)
deg=np.diff(np.append(start,len(ends_s)))
vidx={int(v):(int(s),int(d)) for v,s,d in zip(uniq,start,deg)}
junction=set(int(v) for v,d in zip(uniq,deg) if d!=2)
print('vertices',len(uniq),'junctions',len(junction),round(time.time()-t0,1))
visited=np.zeros(E,bool)
def other(e,v): return int(V[e]) if int(U[e])==v else int(U[e])
def inc(v):
    s,d=vidx[v]; return eid_s[s:s+d]
chains=[]  # (vertex list, labelA, labelB)
def walk(v0,e0):
    path=[v0]; v=v0; e=e0
    while True:
        visited[e]=True; v=other(e,v); path.append(v)
        if v in junction or v==v0: break
        nxt=[x for x in inc(v) if not visited[x]]
        if not nxt: break
        e=int(nxt[0])
    return path
for j in junction:
    for e in inc(j):
        if not visited[e]:
            p=walk(j,int(e)); chains.append((p,int(A[e]),int(B[e])))
for e in range(E):
    if not visited[e]:
        p=walk(int(U[e]),e); chains.append((p,int(A[e]),int(B[e])))
print('chains',len(chains),round(time.time()-t0,1))
pickle.dump((chains,W,H,RES,LON0,LAT1),open('/home/claude/w/chains.pkl','wb'))
